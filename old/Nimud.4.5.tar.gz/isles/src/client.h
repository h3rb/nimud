
void	sendcl_html    args( (  DESCRIPTOR_DATA *d, char *html_code ) );
void    sendcl_vrml    args( (  DESCRIPTOR_DATA *d, char *vrml_code ) );
