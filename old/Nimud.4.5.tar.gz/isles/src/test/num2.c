#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


/*
char *  numberize       ( int n );
*/
char *   const  ones_numerals [10] =
{
    "",
    "one",
    "two",
    "three",
    "four",
    "five",
    "six",
    "seven",
    "eight",
    "nine"
};

char *   const  tens_numerals [10] =
{
    "",
    "",
    "twenty",
    "thirty",
    "forty",
    "fifty",
    "sixty",
    "seventy",
    "eighty",
    "ninety"
};

char *   const  meta_numerals [4] =
{
    "hundred",
    "thousand",
    "million",
    "billion"
};

char *   const  special_numbers [10] =
{
    "ten",
    "eleven",
    "twelve",
    "thirteen",
    "fourteen",
    "fifteen",
    "sixteen",
    "seventeen",
    "eighteen",
    "nineteen"
};


      
char *numberize( int n )
{
    static char buf[4096];
    short int    digits[3];
    int t = abs(n);
        
    buf[0] = '\0';
        
    /*
     * Special cases (10-19)
     */
    if ( n >= 10 && n <= 19 )
    {
        sprintf( buf, "%s", special_numbers[n-10] );
        return buf;
    }
     
    if ( n < 10 && n >= 0 )
    {
        sprintf( buf, "%s", ones_numerals[n] );
        return buf;
    }
    
    /*
     * Cha.
     */
    if ( n >= 10000 || n < 0 )
    {
        sprintf( buf, "%d", n );
        return buf;
    }
     
    
    digits[3] = t / 1000;
    t -= 1000*digits[3];
    digits[2] = t / 100;
    t -= 100*digits[2];
    digits[1] = t / 10;
    t -= 10*digits[1];
    digits[0] = t;
    
    if ( digits[3] > 0 )
    {
        sprintf( buf, "%s%s", buf, ones_numerals[digits[3]] );
        sprintf( buf, "%s thousand ", buf );
    }
    
    if ( digits[2] > 0 )
    {
        sprintf( buf, "%s%s", buf, ones_numerals[digits[2]] );
        sprintf( buf, "%s hundred ", buf );
    }   
      
    if ( digits[1] > 0 )
    {  
        sprintf( buf, "%s%s", buf, tens_numerals[digits[1]] );
        if ( digits[0] > 0 ) sprintf( buf, "%s-", buf );
    }
        
    if ( digits[0] > 0 )
    {
        sprintf( buf, "%s%s", buf, ones_numerals[digits[0]] );
    }
        
    if ( buf[(t = strlen(buf)-1)] == ' ' )  buf[t] = '\0';
    if ( buf[(t = strlen(buf)-1)] == ' ' )  buf[t] = '\0';
    return buf;
}

void main() {
 int i;

for ( i=9900; i<10030;i++) {
 printf ("%d is %s\n", i, numberize(i));
}

return;
}
