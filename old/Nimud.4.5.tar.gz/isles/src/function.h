/*
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___| G| v4.0   Version 4.0 GOLD EDITION      *
* |  /   \  __|  \__/  |  | |  |     O|        documentation release         *
* |       ||  |        |  \_|  | ()  L|        Hallow's Eve 1999             *
* |    |  ||  |  |__|  |       |     D|                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 */


/*
 * Internal stuff.
 */
extern int gotoloops;

#define  VD    VARIABLE_DATA

/*
 * Reserved functions for internal parsing.
 */
VD * func_goto     args( ( void * owner, int type, VD *label ) );
VD * func_if       args( ( void * owner, int type, VD *exp, VD *iftrue, VD *iffalse ) );
VD * func_label    args( ( void * owner, int type ) );
VD * func_return   args( ( void * owner, int type, VD *value ) );
VD * func_halt     args( ( void * owner, int type, VD *value ) );
VD * func_permhalt args( ( void * owner, int type ) );
VD * func_wait     args( ( void * owner, int type, VD *value ) );
VD * func_autowait args( ( void * owner, int type, VD *value ) );
VD * func_call     args( ( void * owner, int type, VD *trigname, VD *target ) );
VD * func_vget     args( ( void * owner, int type, VD *newvar, VD *varname, VD *trigname, VD *target ) );
VD * func_vset     args( ( void * owner, int type, VD *varname, VD *ourvar, VD *trigname, VD *target ) );

/*
 * Further stuff.
 */
VD * func_vcpy     args( ( void * owner, int type, VD *old, VD *new, VD *trigname ) );
VD * func_self     args( ( void * owner, int type, VD *varname ) );

/*
 * "Constants."
 */

VD * func_null     args( ( void * owner, int type ) );

/*
 * Boolean conditionals.
 */
VD * func_cmp      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_not      args( ( void * owner, int type, VD *value ) );
VD * func_or       args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_and      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_xor      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_less     args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_greater  args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_pre      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_in       args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_strstr   args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_pcmp     args( ( void * owner, int type, VD *astr, VD *bstr ) );

VD * func_range    args( ( void * owner, int type, VD *astr, VD *val, VD *bstr ) );

/*
 * Mathematics.
 */
VD * func_add      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_sub      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_mult     args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_div      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_mod      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_random   args( ( void * owner, int type, VD *astr, VD *bstr ) );

VD * func_band     args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_bor      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_bxor     args( ( void * owner, int type, VD *astr, VD *bstr ) );

VD * func_eq       args( ( void * owner, int type, VD *astr, VD *bstr ) );


/*
 * String things.
 */
VD * func_cat      args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_word     args( ( void * owner, int type, VD *astr, VD *value ) );

/*
 * Output functions.
 */
VD * func_act      args( ( void * owner, int type, VD *out, VD *ch, VD *arg1, VD *arg2, VD *act_type ) );
VD * func_recho    args( ( void * owner, int type, VD *target, VD *out ) );
VD * func_echo     args( ( void * owner, int type, VD *str ) );
VD * func_dream    args( ( void * owner, int type, VD *out ) );

/*
VD * func_pecho    args( ( void * owner, int type, VD *target, VD *str ) );
VD * func_oecho    args( ( void * owner, int type, VD *target, VD *str ) );
 */
VD * func_numw     args( ( void * owner, int type, VD *astr ) );
VD * func_strp     args( ( void * owner, int type, VD *value, VD *old, VD *new ) );

/*
 * Game-related functions for mobiles.
 */
VD * func_do       args( ( void * owner, int type, VD *exp0, VD *exp1, VD *exp2, VD *exp3, VD *exp4, VD *exp5 ) );
VD * func_step     args( ( void * owner, int type, VD *value ) );
VD * func_ms       args( ( void * owner, int type, VD *astr, VD *bstr ) );
VD * func_jump     args( ( void * owner, int type, VD *location ) );

/*
 * Game-related functions for objects.
 */
VD *func_os        args( ( void * owner, int type, VD *astr, VD *bstr ) );

/*
 * Game-related functions for rooms.
 */
VD *func_open      args( ( void * owner, int type, VD *loc, VD *dir ) );
VD *func_close     args( ( void * owner, int type, VD *loc, VD *dir ) );

/*
 * Other game-related functions.
 */
VD *func_sameroom  args( ( void * owner, int type, VD *value ) );
VD *func_here      args( ( void * owner, int type ) );
VD *func_purge     args( ( void * owner, int type, VD *target ) );
VD *func_force     args( ( void * owner, int type, VD *target ) );
VD *func_disarm    args( ( void * owner, int type, VD *target ) );
VD *func_strip     args( ( void * owner, int type, VD *target ) );
VD *func_pos       args( ( void * owner, int type, VD *target, VD *gain ) );
VD *func_pay       args( ( void * owner, int type, VD *target, VD *gain ) );
VD *func_elude     args( ( void * owner, int type ) );
VD *func_reset     args( ( void * owner, int type, VD *target ) );
VD *func_move      args( ( void * owner, int type, VD *target, VD *dest) );
VD *func_moveall   args( ( void * owner, int type, VD *from, VD *dest, VD *cmd ) );
VD *func_home      args( ( void * owner, int type, VD *target, VD *dest) );
VD *func_death     args( ( void * owner, int type, VD *target, VD *dest) );
VD *func_heal      args( ( void * owner, int type, VD *target, VD *gain) );
VD *func_hurt      args( ( void * owner, int type, VD *target, VD *gain) );
VD *func_mana      args( ( void * owner, int type, VD *target, VD *gain) );
VD *func_mix       args( ( void * owner, int type, VD *target, VD *list, VD *quantity ) );
VD *func_reagents  args( ( void * owner, int type, VD *target, VD *list, VD *quantity ) );
VD *func_dispense  args( ( void * owner, int type, VD *target, VD *disp) );
VD *func_create    args( ( void * owner, int type, VD *vnum, VD *loc) );
VD *func_eat       args( ( void * owner, int type, VD *target )  );
VD *func_eval      args( ( void * owner, int type, VD *value ) );
VD *func_rndplr    args( ( void * owner, int type, VD *from ) );
VD *func_rnddir    args( ( void * owner, int type ) );
VD *func_players   args( ( void * owner, int type ) );
VD *func_addbounty args( ( void * owner, int type, VD *target, VD *gain) );
VD *func_bounty    args( ( void * owner, int type, VD *target ) );
VD *func_addowed   args( ( void * owner, int type, VD *target, VD *gain) );
VD *func_owed      args( ( void * owner, int type, VD *target ) );
VD *func_level     args( ( void * owner, int type, VD *target ) );

/*
 * Time, date and weather functions. (world-state functions)
 */
VD *func_time      args( ( void * owner, int type ) );
VD *func_weather   args( ( void * owner, int type ) );
VD *func_moon      args( ( void * owner, int type ) );
VD *func_day       args( ( void * owner, int type ) );
VD *func_dayofweek args( ( void * owner, int type ) );
VD *func_month     args( ( void * owner, int type ) );
VD *func_year      args( ( void * owner, int type ) );

VD *func_skill     args( ( void * owner, int type, VD *target, VD *sn, VD *value ) );
VD *func_alert     args( ( void * owner, int type, VD *name, VD *limits ) );

VD *func_tname     args( ( void * owner, int type, VD *var ) );

/*
 * List and stack functions.
 * Imported from COOCOOO and subject to a seperate license.
 * See: http://www.nationwideinteractive.com/coocoo
 */

VD *func_push     args ( ( void * owner, int type, VD *stack, VD *value ) 
);
VD *func_pop      args ( ( void * owner, int type, VD *stack ) );
VD *func_lrem     args ( ( void * owner, int type, VD *stack, VD *value ) 
);
VD *func_sort     args ( ( void * owner, int type, VD *stack, VD *mask ) 
);
VD *func_lrnd     args ( ( void * owner, int type, VD *stack ) ); 
VD *func_lshift   args ( ( void * owner, int type, VD *stack ) );
VD *func_rshift   args ( ( void * owner, int type, VD *stack ) );
VD *func_empty    args ( ( void * owner, int type, VD *stack ) );
VD *func_users    args ( ( void * owner, int type, VD *mask ) );
/*
VD *func_queue    args ( ( void * owner, int type, VD *mask ) );
VD *func_objects  args ( ( void * owner, int type, VD *mask ) );
VD *func_commands args ( ( void * owner, int type, VD *mask ) );
 */
VD *func_foreach  args ( ( void * owner, int type, VD *stack, VD *code ) 
);
VD *func_each     args ( ( void * owner, int type, VD *stack )  );



#undef  VD
