
/****************************************************************************
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___|  | v5.0a  Version 5.0a                  *
* |  /   \  __|  \__/  |  | |  |      |        documentation release         *
* |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
* |    |  ||  |  |__|  |       |      |                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 *                                                                          *
 *      This is the server software for The Isles, called NiMUD 5.0a        *
 *                                                                          *
 *    Portions of this code are copyrighted to Herb Gilliland.              * 
 *    Copyright (c) 1994-2003 by Herb Gilliland.  All rights reserved.      *
 *                                                                          *
 *  Much time and thought has gone into this software and you are           *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                                                   *
 *                                                                          *
 ****************************************************************************
 *   Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *   Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 ****************************************************************************/


#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "mud.h"
#include "client.h"

void sendcl_html( DESCRIPTOR_DATA *d, char *html_code )
{
	int lenstr = 0;
	char finalstr[MAX_STRING_LENGTH];

	sprintf( finalstr, "$html_#%s#html_$", html_code );
	lenstr = strlen(finalstr);
	if ( d != NULL ) write_to_buffer( d, finalstr, lenstr );

	return;
}


void sendcl_vrml( DESCRIPTOR_DATA *d, char *vrml_code )
{
	int lenstr = 0;
        char finalstr[MAX_STRING_LENGTH];

        sprintf( finalstr, "$vrml_#%s#vrml_$", vrml_code );
        lenstr = strlen(finalstr);
        if ( d != NULL ) write_to_buffer( d, finalstr, lenstr );

        return;
}
