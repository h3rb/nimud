/******************************************************************************
 * Locke's   __ -based on merc v2.2-____        NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5.0a  Version 5.0a                  *
 * |  /   \  __|  \__/  |  | |  |      |        documentation release         *
 * |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "mud.h"


PC_NAME *    pc_name_list;

char * last;





void generate_statistics( void )
{
    return;
};






