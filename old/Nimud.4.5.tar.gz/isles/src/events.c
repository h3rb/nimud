
/****************************************************************************
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___|  | v5.0a  Version 5.0a                  *
* |  /   \  __|  \__/  |  | |  |      |        documentation release         *
* |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
* |    |  ||  |  |__|  |       |      |                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 *                                                                          *
 *      This is the server software for The Isles, called NiMUD 5.0a        *
 *                                                                          *
 *    Portions of this code are copyrighted to Herb Gilliland.              * 
 *    Copyright (c) 1994-2003 by Herb Gilliland.  All rights reserved.      *
 *                                                                          *
 *  Much time and thought has gone into this software and you are           *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                                                   *
 *                                                                          *
 ****************************************************************************
 *   Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *   Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 ****************************************************************************/



/*
 * Locke's event queue for scripts.
 * Part of NiMUD Version 5.0a. 
 * See readme.txt and license.txt
 */


#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "mud.h"
#include "script.h"
#include "defaults.h"

EVENT_DATA *event_queue;

void assign_var_trig( void * owner, int type, TRIGGER_DATA *trig, 
                      VARIABLE_DATA *var, char *name )
{
    VARIABLE_DATA *v;

    if ( trig == NULL ) return;
    if (var == NULL) return;

    v = new_variable( );
    v->next = trig->locals;
    trig->locals = v;
    v->name = str_dup( name );
    v->value = str_dup( "" );

    v->type = var->type;
    v->value = var->type == TYPE_STRING ? str_dup( var->value ) : 
               var->value;
    return;
}


/*
 * Adds a trigger event to the queue.
 */ 
void add_event( void * owner, int type, int vnum, int delay, 
                char *special, CHAR_DATA *actor,
                OBJ_DATA *catalyst, char *astr, char *bstr   ) 
{
    EVENT_DATA *pEvent;
    SCRIPT_DATA *proc;
    TRIGGER_DATA *pTrig;
    VARIABLE_DATA *var;

    proc = get_script_index( vnum );
    if ( proc == NULL ) return;
    if ( owner == NULL ) return; 

    pTrig = new_trigger( );    
    pEvent = new_event_data( ); 
    pEvent->time = delay;
    pEvent->trig = pTrig;
    pTrig->script = proc;
    pTrig->location = pTrig->script->commands;  /* Start! */

    var = new_variable( );

    if ( actor )
            {
                var->type  = TYPE_MOB;
                var->value = (CHAR_DATA *)actor;
                assign_var_trig( owner, type, pTrig, var, "%actor%" );

                var->type = TYPE_STRING;
                var->value = (char *)str_dup( STR((CHAR_DATA *)actor,name));
                assign_var_trig( owner, type, pTrig, var, "%aname%" );
                free_string((char *)var->value);
            }


     if ( catalyst )
            {
                var->type = TYPE_OBJ;
                var->value = (OBJ_DATA *)catalyst;
                assign_var_trig( owner, type, pTrig, var, "%catalyst%" );
            }

     if ( astr )
            {
                var->type = TYPE_STRING;
                var->value = str_dup( astr );
                assign_var_trig( owner, type, pTrig, var, "%astr%" );
            }

     if ( bstr )
            {
                var->type = TYPE_STRING;
                var->value = str_dup( bstr );
                assign_var_trig( owner, type, pTrig, var, "%bstr%" );
            }

    free_variable( var );

    pEvent->next = event_queue;  
    event_queue = pEvent;
    return; 
}


void rem_event( EVENT_DATA *event ) 
{
    EVENT_DATA *pEvent;
    EVENT_DATA *event_next;
    EVENT_DATA *event_prev;    

    if ( event == NULL || event_queue == NULL ) return;

    /*
     * Remove the head of the chain.
     */
    if ( event == event_queue ) {
         event_queue = event->next; 
         free_event_data( event );  
         return; 
    }

    /*
     * Remove the tail of the chain.
     */
    if ( event->next == NULL )
    {

    for ( pEvent = event_queue;  pEvent != NULL;  pEvent = pEvent->next )
    if ( pEvent->next == event ) break;  
 
    if ( pEvent == NULL ) return;

    pEvent->next = NULL;
    free_event_data( event );
    return;
    }

    /*
     * Remove something in the middle. 
     */
    event_prev = event_queue;
    for ( pEvent = event_queue;  pEvent != NULL;  pEvent = event_next )
    {
        event_next = pEvent->next;
        if ( pEvent == event ) {
             for ( event_prev = event_queue;  event_prev != NULL; 
                   event_prev = event_prev->next ) {
                 if ( event_prev->next == event ) {
                      event_prev->next = event_prev->next->next;
                      free_event_data( event );
                    }
               }
        }
    }       

    return;
}

/*
 * Called from Update Handler
 * Updates future events, removes past events, runs all current events 
 */
void update_event( void ) {
    EVENT_DATA *pEvent;
    EVENT_DATA *pEvent_next;

    for ( pEvent = event_queue;  pEvent != NULL;  pEvent = pEvent_next ) {
         pEvent_next = pEvent->next;
         if ( pEvent->time-- <= 0 )  {
            pEvent->time = 0;            
            if (pEvent->trig->location == NULL) rem_event( pEvent );  
            else 
            parse_script( pEvent->trig, pEvent->owner, pEvent->type );
         }
    }
}  

void clear_events( void * owner, int type ) {
    EVENT_DATA *pEvent, *pEvent_next;

    for ( pEvent = event_queue; pEvent != NULL; pEvent = pEvent_next )  {
          pEvent_next = pEvent->next; 
          if ( pEvent->type == type
            && pEvent->owner == NULL ) rem_event( pEvent );
    } 
} 


void do_events( CHAR_DATA *ch, char *argument ) {
    OBJ_DATA *pObj = NULL;
    CHAR_DATA *pMob = NULL;
    ROOM_INDEX_DATA *pRoom = NULL;
    char buf[MAX_STRING_LENGTH];
    EVENT_DATA *pEvent;

    send_to_char( "Current events:\n\r", ch );
    for ( pEvent = event_queue;   pEvent != NULL;   pEvent = pEvent->next ) {

          pMob = NULL;
          pObj = NULL;
          pRoom = NULL;

          if ( pEvent->type == TYPE_MOB ) 
          pMob = (CHAR_DATA *)(pEvent->owner); 
          if ( pEvent->type == TYPE_OBJ ) 
          pObj = (OBJ_DATA *)(pEvent->owner); 
          if ( pEvent->type == TYPE_ROOM ) 
          pRoom = (ROOM_INDEX_DATA *)(pEvent->owner);
          if ( pEvent->type == TYPE_STRING ) continue;  

          sprintf( buf, "Delay: [%5d]   Caller: [%11s]   Name: [%11s]\n\r",
                pEvent->time, 
                pMob ? STR(pMob,short_descr) :
               (pObj ? STR(pObj,short_descr) : 
               (pRoom ? pRoom->name : "" )), pEvent->trig->script->name );
 
          send_to_char( buf, ch );
            /* add debugging features */          
    } 

    return;
}
