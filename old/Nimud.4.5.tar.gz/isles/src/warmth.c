/******************************************************************************
 * Locke's   __ -based on merc v2.2-____        NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5.0a  Version 5.0a                  *
 * |  /   \  __|  \__/  |  | |  |      |        documentation release         *
 * |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/


/*
 * Returns the temperature of the
 * room the character is in.
 */
int room_temp( CHAR_DATA *ch, ROOM_INDEX_DATA *pRoom ) {
    EXIT_DATA *pExit;
        int direction = 0;
        int room_temp = 0;
        int temp_adjust = 0;
        int temp = weather_info.temperature;

        if ( IS_NPC( ch ) || !ch->in_room )
                return 0;

        /*
         * If I am not mistaken this doesn't work as of yet.
         * I am rather lazy so I dont know if I will get this
         * part working ever.  What it is SUPPOSE to do is if
         * the current room your in has exits that lead to the
         * outside and they don't have doors or the doors are
         * open then the room temperature drops down.
         * Also I should add a check to see if the exit is a
         * window and if the window is open I just keep forgetting
         * about that.  Also Daurven you need to add that check into
         * the archery code you dumb shit.
         *                                               -- Daurven
         */
    for( direction = 0;  direction < MAX_DIR; direction++ ) {
        pExit = ch->in_room->exit[direction];

                if ( IS_SET( ch->in_room->room_flags, ROOM_INDOORS )
                && ch->in_room->room_temp != 0 ) {
                        if ( pExit != NULL && !IS_SET( pExit->exit_info, EX_CLOSED )
                        && !IS_SET( pExit->to_room->room_flags, ROOM_INDOORS ) )
                                room_temp = temp / 2 - ch->in_room->room_temp;
                        else
                                room_temp = ch->in_room->room_temp;
                }
        }

        switch (ch->in_room->sector_type) {
        default:
                temp_adjust = 0;
                break;
        case SECT_INSIDE:
                case SECT_CITY:
                temp_adjust = 0;
                break;
        case SECT_DESERT:
                temp_adjust = 10;
                break;
        case SECT_ICELAND:
                temp_adjust = -30;
                break;
        case SECT_MOUNTAIN:
                temp_adjust = -15;
                break;
        case SECT_HILLS:
                case SECT_FIELD:
                temp_adjust = -5;
                break;
                case SECT_FOREST:
                        temp_adjust = -10;
                        break;
        case SECT_AIR:
                temp_adjust = -3;
                break;
    }

        room_temp += temp_adjust;
        temp += room_temp;
        return temp;
}
