/******************************************************************************
 * Locke's   __ -based on merc v2.2-____        NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5.0a  Version 5.0a                  *
 * |  /   \  __|  \__/  |  | |  |      |        documentation release         *
 * |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/

/* Change shop_data struct in in mud.h */

#define T_CORN         0
#define T_FLOUR        1
#define T_FABRIC       2
#define T_HIDE         3
#define T_DYE          4
#define T_METAL        5
#define T_ORE          6
#define T_SPICE        7
#define T_SUGAR        8
#define T_OIL          9


#define HAGGLE_BUY     1
#define HAGGLE_ANGRY   2
