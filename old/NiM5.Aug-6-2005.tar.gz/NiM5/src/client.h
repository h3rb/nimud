
bool sendcli    args( ( CONNECTION_DATA *d, char *buf ) );
