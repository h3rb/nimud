# vi: ts=4 sw=4

package Charsets::TIS_620;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw();
$VERSION	= 0.00;

# Character set TIS-620 / Windows Thai code page 874

my $upper = 'A-Z';
my $lower = 'a-z';
my $consonants   = "\xa1-\xcf";
my $vowels_right = "\xd0-\xd3";
my $vowels_above = "\xd4-\xd7";
my $vowels_below = "\xd8-\xda";
my $vowels_left  = "\xe0-\xe4";
my $special      = "\xe6";			# not sure about \xe5
my $diacritics   = "\xe7-\xee";
my $digits       = "0-9\xf0-\xf9";

my $vowels = $vowels_right . $vowels_above . $vowels_below . $vowels_left;

my (%_from_utf8, %_to_utf8);

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters_upper {
	return '[' . $upper . ']';
}

sub letters_lower {
	return '[' . $lower . ']';
}

sub letters {
	return '[' . $upper . $lower . $consonants . $vowels . $diacritics . $special . ']';
}

sub digits {
	return '[' . $digits . ']';
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z/a-z/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z/A-Z/;

	return $str;
}

sub translate_digits {
	my $self = shift;
	my $str = shift;

	$str =~ tr/\xf0-\xf9/0-9/;

	return $str;
}

sub to_utf8 {
	my ($self, $input) = @_;
	my $output = '';

	while (($input =~ /(.|\n|\r)/g)) {
		my $c = $1;
		my $o = ord($c);
		my $u = $_to_utf8{$o};
		$output .= $u ? $u : $c;
	}
	return $output;
}

sub from_utf8 {
	my ($self, $input) = @_;
	my $output = '';
	my $state = 0;
	my $len;
	my $u;

	while (($input =~ /(.|\n|\r)/g)) {
		my $c = $1;
		my $o = ord($c);
		if ($state == 0) {
			if ($o >= 0xfe) {
				# Invalid initial byte
				$output .= '?';
				print STDERR "** invalid initial byte\n";
			} elsif ($o >= 0xc0) {
				$state = 1;
				if ($o >= 0xfc) {
					$len = 6;
				} elsif ($o >= 0xf8) {
					$len = 5;
				} elsif ($o >= 0xf0) {
					$len = 4;
				} elsif ($o >= 0xe0) {
					$len = 3;
				} else {
					$len = 2;
				}
				$u = $o & ((1 << (7 - $len)) - 1);
			} else {
				$output .= $c;
			}
		} else {
			if (($o & 0xc0) != 0x80) {
				# Invalid trailing byte
				$output .= '?';
				print STDERR "** invalid trailing byte\n";
				$state = 0;
			} else {
				$u <<= 6;
				$u += ($o & 0x3f);
				--$len;
				if ($len <= 1) {
					$state = 0;
					my $a = $_from_utf8{$u};
					if ($a) {
						$output .= chr($a);
					} else {
						$output .= '?';
					}
				}
			}
		}
	}
	return $output;
}

sub BEGIN {
	$_from_utf8{0x20AC} = 0x80;
	$_from_utf8{0x2026} = 0x85;
	$_from_utf8{0x2018} = 0x91;
	$_from_utf8{0x2019} = 0x92;
	$_from_utf8{0x201C} = 0x93;
	$_from_utf8{0x201D} = 0x94;
	$_from_utf8{0x2022} = 0x95;
	$_from_utf8{0x2013} = 0x96;
	$_from_utf8{0x2014} = 0x97;
	$_from_utf8{0x00A0} = 0xA0;
	$_from_utf8{0x0E01} = 0xA1;
	$_from_utf8{0x0E02} = 0xA2;
	$_from_utf8{0x0E03} = 0xA3;
	$_from_utf8{0x0E04} = 0xA4;
	$_from_utf8{0x0E05} = 0xA5;
	$_from_utf8{0x0E06} = 0xA6;
	$_from_utf8{0x0E07} = 0xA7;
	$_from_utf8{0x0E08} = 0xA8;
	$_from_utf8{0x0E09} = 0xA9;
	$_from_utf8{0x0E0A} = 0xAA;
	$_from_utf8{0x0E0B} = 0xAB;
	$_from_utf8{0x0E0C} = 0xAC;
	$_from_utf8{0x0E0D} = 0xAD;
	$_from_utf8{0x0E0E} = 0xAE;
	$_from_utf8{0x0E0F} = 0xAF;
	$_from_utf8{0x0E10} = 0xB0;
	$_from_utf8{0x0E11} = 0xB1;
	$_from_utf8{0x0E12} = 0xB2;
	$_from_utf8{0x0E13} = 0xB3;
	$_from_utf8{0x0E14} = 0xB4;
	$_from_utf8{0x0E15} = 0xB5;
	$_from_utf8{0x0E16} = 0xB6;
	$_from_utf8{0x0E17} = 0xB7;
	$_from_utf8{0x0E18} = 0xB8;
	$_from_utf8{0x0E19} = 0xB9;
	$_from_utf8{0x0E1A} = 0xBA;
	$_from_utf8{0x0E1B} = 0xBB;
	$_from_utf8{0x0E1C} = 0xBC;
	$_from_utf8{0x0E1D} = 0xBD;
	$_from_utf8{0x0E1E} = 0xBE;
	$_from_utf8{0x0E1F} = 0xBF;
	$_from_utf8{0x0E20} = 0xC0;
	$_from_utf8{0x0E21} = 0xC1;
	$_from_utf8{0x0E22} = 0xC2;
	$_from_utf8{0x0E23} = 0xC3;
	$_from_utf8{0x0E24} = 0xC4;
	$_from_utf8{0x0E25} = 0xC5;
	$_from_utf8{0x0E26} = 0xC6;
	$_from_utf8{0x0E27} = 0xC7;
	$_from_utf8{0x0E28} = 0xC8;
	$_from_utf8{0x0E29} = 0xC9;
	$_from_utf8{0x0E2A} = 0xCA;
	$_from_utf8{0x0E2B} = 0xCB;
	$_from_utf8{0x0E2C} = 0xCC;
	$_from_utf8{0x0E2D} = 0xCD;
	$_from_utf8{0x0E2E} = 0xCE;
	$_from_utf8{0x0E2F} = 0xCF;
	$_from_utf8{0x0E30} = 0xD0;
	$_from_utf8{0x0E31} = 0xD1;
	$_from_utf8{0x0E32} = 0xD2;
	$_from_utf8{0x0E33} = 0xD3;
	$_from_utf8{0x0E34} = 0xD4;
	$_from_utf8{0x0E35} = 0xD5;
	$_from_utf8{0x0E36} = 0xD6;
	$_from_utf8{0x0E37} = 0xD7;
	$_from_utf8{0x0E38} = 0xD8;
	$_from_utf8{0x0E39} = 0xD9;
	$_from_utf8{0x0E3A} = 0xDA;
	$_from_utf8{0x0E3F} = 0xDF;
	$_from_utf8{0x0E40} = 0xE0;
	$_from_utf8{0x0E41} = 0xE1;
	$_from_utf8{0x0E42} = 0xE2;
	$_from_utf8{0x0E43} = 0xE3;
	$_from_utf8{0x0E44} = 0xE4;
	$_from_utf8{0x0E45} = 0xE5;
	$_from_utf8{0x0E46} = 0xE6;
	$_from_utf8{0x0E47} = 0xE7;
	$_from_utf8{0x0E48} = 0xE8;
	$_from_utf8{0x0E49} = 0xE9;
	$_from_utf8{0x0E4A} = 0xEA;
	$_from_utf8{0x0E4B} = 0xEB;
	$_from_utf8{0x0E4C} = 0xEC;
	$_from_utf8{0x0E4D} = 0xED;
	$_from_utf8{0x0E4E} = 0xEE;
	$_from_utf8{0x0E4F} = 0xEF;
	$_from_utf8{0x0E50} = 0xF0;
	$_from_utf8{0x0E51} = 0xF1;
	$_from_utf8{0x0E52} = 0xF2;
	$_from_utf8{0x0E53} = 0xF3;
	$_from_utf8{0x0E54} = 0xF4;
	$_from_utf8{0x0E55} = 0xF5;
	$_from_utf8{0x0E56} = 0xF6;
	$_from_utf8{0x0E57} = 0xF7;
	$_from_utf8{0x0E58} = 0xF8;
	$_from_utf8{0x0E59} = 0xF9;
	$_from_utf8{0x0E5A} = 0xFA;
	$_from_utf8{0x0E5B} = 0xFB;
	$_to_utf8{0x80} = '€';
	$_to_utf8{0x85} = '…';
	$_to_utf8{0x91} = '‘';
	$_to_utf8{0x92} = '’';
	$_to_utf8{0x93} = '“';
	$_to_utf8{0x94} = '”';
	$_to_utf8{0x95} = '•';
	$_to_utf8{0x96} = '–';
	$_to_utf8{0x97} = '—';
	$_to_utf8{0xA0} = ' ';
	$_to_utf8{0xA1} = 'ก';
	$_to_utf8{0xA2} = 'ข';
	$_to_utf8{0xA3} = 'ฃ';
	$_to_utf8{0xA4} = 'ค';
	$_to_utf8{0xA5} = 'ฅ';
	$_to_utf8{0xA6} = 'ฆ';
	$_to_utf8{0xA7} = 'ง';
	$_to_utf8{0xA8} = 'จ';
	$_to_utf8{0xA9} = 'ฉ';
	$_to_utf8{0xAA} = 'ช';
	$_to_utf8{0xAB} = 'ซ';
	$_to_utf8{0xAC} = 'ฌ';
	$_to_utf8{0xAD} = 'ญ';
	$_to_utf8{0xAE} = 'ฎ';
	$_to_utf8{0xAF} = 'ฏ';
	$_to_utf8{0xB0} = 'ฐ';
	$_to_utf8{0xB1} = 'ฑ';
	$_to_utf8{0xB2} = 'ฒ';
	$_to_utf8{0xB3} = 'ณ';
	$_to_utf8{0xB4} = 'ด';
	$_to_utf8{0xB5} = 'ต';
	$_to_utf8{0xB6} = 'ถ';
	$_to_utf8{0xB7} = 'ท';
	$_to_utf8{0xB8} = 'ธ';
	$_to_utf8{0xB9} = 'น';
	$_to_utf8{0xBA} = 'บ';
	$_to_utf8{0xBB} = 'ป';
	$_to_utf8{0xBC} = 'ผ';
	$_to_utf8{0xBD} = 'ฝ';
	$_to_utf8{0xBE} = 'พ';
	$_to_utf8{0xBF} = 'ฟ';
	$_to_utf8{0xC0} = 'ภ';
	$_to_utf8{0xC1} = 'ม';
	$_to_utf8{0xC2} = 'ย';
	$_to_utf8{0xC3} = 'ร';
	$_to_utf8{0xC4} = 'ฤ';
	$_to_utf8{0xC5} = 'ล';
	$_to_utf8{0xC6} = 'ฦ';
	$_to_utf8{0xC7} = 'ว';
	$_to_utf8{0xC8} = 'ศ';
	$_to_utf8{0xC9} = 'ษ';
	$_to_utf8{0xCA} = 'ส';
	$_to_utf8{0xCB} = 'ห';
	$_to_utf8{0xCC} = 'ฬ';
	$_to_utf8{0xCD} = 'อ';
	$_to_utf8{0xCE} = 'ฮ';
	$_to_utf8{0xCF} = 'ฯ';
	$_to_utf8{0xD0} = 'ะ';
	$_to_utf8{0xD1} = 'ั';
	$_to_utf8{0xD2} = 'า';
	$_to_utf8{0xD3} = 'ำ';
	$_to_utf8{0xD4} = 'ิ';
	$_to_utf8{0xD5} = 'ี';
	$_to_utf8{0xD6} = 'ึ';
	$_to_utf8{0xD7} = 'ื';
	$_to_utf8{0xD8} = 'ุ';
	$_to_utf8{0xD9} = 'ู';
	$_to_utf8{0xDA} = 'ฺ';
	$_to_utf8{0xDF} = '฿';
	$_to_utf8{0xE0} = 'เ';
	$_to_utf8{0xE1} = 'แ';
	$_to_utf8{0xE2} = 'โ';
	$_to_utf8{0xE3} = 'ใ';
	$_to_utf8{0xE4} = 'ไ';
	$_to_utf8{0xE5} = 'ๅ';
	$_to_utf8{0xE6} = 'ๆ';
	$_to_utf8{0xE7} = '็';
	$_to_utf8{0xE8} = '่';
	$_to_utf8{0xE9} = '้';
	$_to_utf8{0xEA} = '๊';
	$_to_utf8{0xEB} = '๋';
	$_to_utf8{0xEC} = '์';
	$_to_utf8{0xED} = 'ํ';
	$_to_utf8{0xEE} = '๎';
	$_to_utf8{0xEF} = '๏';
	$_to_utf8{0xF0} = '๐';
	$_to_utf8{0xF1} = '๑';
	$_to_utf8{0xF2} = '๒';
	$_to_utf8{0xF3} = '๓';
	$_to_utf8{0xF4} = '๔';
	$_to_utf8{0xF5} = '๕';
	$_to_utf8{0xF6} = '๖';
	$_to_utf8{0xF7} = '๗';
	$_to_utf8{0xF8} = '๘';
	$_to_utf8{0xF9} = '๙';
	$_to_utf8{0xFA} = '๚';
	$_to_utf8{0xFB} = '๛';
}

1;
