# vi: ts=4 sw=4 sts=4

package Charsets::CentralEuroWin;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw(letters_upper letters_lower);
$VERSION	= 0.00;

# Character set Windows Central European (code page 1250)
# not ISO 8859-2

my $upper = 'A-Z��-�������-��-�';
my $lower = 'a-z��-�������-��-�';
my $invariant = '�';

my (%_from_utf8, %_to_utf8);

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters_upper {
	return '[' . $upper . ']';
}

sub letters_lower {
	return '[' . $lower . ']';
} 

sub letters {
	return '[' . $upper . $lower . $invariant . ']';
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z��-�������-��-�/a-z��-�������-��-�/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z��-�������-��-�/A-Z��-�������-��-�/;

	return $str;
}

sub to_utf8 {
	my ($self, $input) = @_;
	my $output = '';

	while ($input =~ /(.|\r|\n)/g) {
		my $c = $1;
		my $o = ord($c);
		my $u = $_to_utf8{$o};
		$output .= $u ? $u : $c;
	}
	return $output;
}

sub from_utf8 {
	my ($self, $input) = @_;
	my $output = '';
	my $state = 0;
	my $len;
	my $u;

	while ($input =~ /(.|\r|\n)/g) {
		my $c = $1;
		my $o = ord($c);
		if ($state == 0) {
			if ($o >= 0xfe) {
				# Invalid initial byte
				$output .= '?';
			} elsif ($o >= 0xc0) {
				$state = 1;
				if ($o >= 0xfc) {
					$len = 6;
				} elsif ($o >= 0xf8) {
					$len = 5;
				} elsif ($o >= 0xf0) {
					$len = 4;
				} elsif ($o >= 0xe0) {
					$len = 3;
				} else {
					$len = 2;
				}
				$u = $o & ((1 << (7 - $len)) - 1);
			} else {
				$output .= $c;
			}
		} else {
			if (($o & 0xc0) != 0x80) {
				# Invalid trailing byte
				$output .= '?';
				$state = 0;
			} else {
				$u <<= 6;
				$u += ($o & 0x3f);
				--$len;
				if ($len <= 1) {
					$state = 0;
					my $a = $_from_utf8{$u};
					if ($a) {
						$output .= chr($a);
					} else {
						$output .= '?';
					}
				}
			}
		}
	}
	return $output;
}

sub BEGIN {
	$_from_utf8{0x20AC} = 0x80;
	$_from_utf8{0x201A} = 0x82;
	$_from_utf8{0x201E} = 0x84;
	$_from_utf8{0x2026} = 0x85;
	$_from_utf8{0x2020} = 0x86;
	$_from_utf8{0x2021} = 0x87;
	$_from_utf8{0x2030} = 0x89;
	$_from_utf8{0x0160} = 0x8A;
	$_from_utf8{0x2039} = 0x8B;
	$_from_utf8{0x015A} = 0x8C;
	$_from_utf8{0x0164} = 0x8D;
	$_from_utf8{0x017D} = 0x8E;
	$_from_utf8{0x0179} = 0x8F;
	$_from_utf8{0x2018} = 0x91;
	$_from_utf8{0x2019} = 0x92;
	$_from_utf8{0x201C} = 0x93;
	$_from_utf8{0x201D} = 0x94;
	$_from_utf8{0x2022} = 0x95;
	$_from_utf8{0x2013} = 0x96;
	$_from_utf8{0x2014} = 0x97;
	$_from_utf8{0x2122} = 0x99;
	$_from_utf8{0x0161} = 0x9A;
	$_from_utf8{0x203A} = 0x9B;
	$_from_utf8{0x015B} = 0x9C;
	$_from_utf8{0x0165} = 0x9D;
	$_from_utf8{0x017E} = 0x9E;
	$_from_utf8{0x017A} = 0x9F;
	$_from_utf8{0x00A0} = 0xA0;
	$_from_utf8{0x02C7} = 0xA1;
	$_from_utf8{0x02D8} = 0xA2;
	$_from_utf8{0x0141} = 0xA3;
	$_from_utf8{0x00A4} = 0xA4;
	$_from_utf8{0x0104} = 0xA5;
	$_from_utf8{0x00A6} = 0xA6;
	$_from_utf8{0x00A7} = 0xA7;
	$_from_utf8{0x00A8} = 0xA8;
	$_from_utf8{0x00A9} = 0xA9;
	$_from_utf8{0x015E} = 0xAA;
	$_from_utf8{0x00AB} = 0xAB;
	$_from_utf8{0x00AC} = 0xAC;
	$_from_utf8{0x00AD} = 0xAD;
	$_from_utf8{0x00AE} = 0xAE;
	$_from_utf8{0x017B} = 0xAF;
	$_from_utf8{0x00B0} = 0xB0;
	$_from_utf8{0x00B1} = 0xB1;
	$_from_utf8{0x02DB} = 0xB2;
	$_from_utf8{0x0142} = 0xB3;
	$_from_utf8{0x00B4} = 0xB4;
	$_from_utf8{0x00B5} = 0xB5;
	$_from_utf8{0x00B6} = 0xB6;
	$_from_utf8{0x00B7} = 0xB7;
	$_from_utf8{0x00B8} = 0xB8;
	$_from_utf8{0x0105} = 0xB9;
	$_from_utf8{0x015F} = 0xBA;
	$_from_utf8{0x00BB} = 0xBB;
	$_from_utf8{0x013D} = 0xBC;
	$_from_utf8{0x02DD} = 0xBD;
	$_from_utf8{0x013E} = 0xBE;
	$_from_utf8{0x017C} = 0xBF;
	$_from_utf8{0x0154} = 0xC0;
	$_from_utf8{0x00C1} = 0xC1;
	$_from_utf8{0x00C2} = 0xC2;
	$_from_utf8{0x0102} = 0xC3;
	$_from_utf8{0x00C4} = 0xC4;
	$_from_utf8{0x0139} = 0xC5;
	$_from_utf8{0x0106} = 0xC6;
	$_from_utf8{0x00C7} = 0xC7;
	$_from_utf8{0x010C} = 0xC8;
	$_from_utf8{0x00C9} = 0xC9;
	$_from_utf8{0x0118} = 0xCA;
	$_from_utf8{0x00CB} = 0xCB;
	$_from_utf8{0x011A} = 0xCC;
	$_from_utf8{0x00CD} = 0xCD;
	$_from_utf8{0x00CE} = 0xCE;
	$_from_utf8{0x010E} = 0xCF;
	$_from_utf8{0x0110} = 0xD0;
	$_from_utf8{0x0143} = 0xD1;
	$_from_utf8{0x0147} = 0xD2;
	$_from_utf8{0x00D3} = 0xD3;
	$_from_utf8{0x00D4} = 0xD4;
	$_from_utf8{0x0150} = 0xD5;
	$_from_utf8{0x00D6} = 0xD6;
	$_from_utf8{0x00D7} = 0xD7;
	$_from_utf8{0x0158} = 0xD8;
	$_from_utf8{0x016E} = 0xD9;
	$_from_utf8{0x00DA} = 0xDA;
	$_from_utf8{0x0170} = 0xDB;
	$_from_utf8{0x00DC} = 0xDC;
	$_from_utf8{0x00DD} = 0xDD;
	$_from_utf8{0x0162} = 0xDE;
	$_from_utf8{0x00DF} = 0xDF;
	$_from_utf8{0x0155} = 0xE0;
	$_from_utf8{0x00E1} = 0xE1;
	$_from_utf8{0x00E2} = 0xE2;
	$_from_utf8{0x0103} = 0xE3;
	$_from_utf8{0x00E4} = 0xE4;
	$_from_utf8{0x013A} = 0xE5;
	$_from_utf8{0x0107} = 0xE6;
	$_from_utf8{0x00E7} = 0xE7;
	$_from_utf8{0x010D} = 0xE8;
	$_from_utf8{0x00E9} = 0xE9;
	$_from_utf8{0x0119} = 0xEA;
	$_from_utf8{0x00EB} = 0xEB;
	$_from_utf8{0x011B} = 0xEC;
	$_from_utf8{0x00ED} = 0xED;
	$_from_utf8{0x00EE} = 0xEE;
	$_from_utf8{0x010F} = 0xEF;
	$_from_utf8{0x0111} = 0xF0;
	$_from_utf8{0x0144} = 0xF1;
	$_from_utf8{0x0148} = 0xF2;
	$_from_utf8{0x00F3} = 0xF3;
	$_from_utf8{0x00F4} = 0xF4;
	$_from_utf8{0x0151} = 0xF5;
	$_from_utf8{0x00F6} = 0xF6;
	$_from_utf8{0x00F7} = 0xF7;
	$_from_utf8{0x0159} = 0xF8;
	$_from_utf8{0x016F} = 0xF9;
	$_from_utf8{0x00FA} = 0xFA;
	$_from_utf8{0x0171} = 0xFB;
	$_from_utf8{0x00FC} = 0xFC;
	$_from_utf8{0x00FD} = 0xFD;
	$_from_utf8{0x0163} = 0xFE;
	$_from_utf8{0x02D9} = 0xFF;
	$_to_utf8{0x80} = '€';
	$_to_utf8{0x82} = '‚';
	$_to_utf8{0x84} = '„';
	$_to_utf8{0x85} = '…';
	$_to_utf8{0x86} = '†';
	$_to_utf8{0x87} = '‡';
	$_to_utf8{0x89} = '‰';
	$_to_utf8{0x8A} = 'Š';
	$_to_utf8{0x8B} = '‹';
	$_to_utf8{0x8C} = 'Ś';
	$_to_utf8{0x8D} = 'Ť';
	$_to_utf8{0x8E} = 'Ž';
	$_to_utf8{0x8F} = 'Ź';
	$_to_utf8{0x91} = '‘';
	$_to_utf8{0x92} = '’';
	$_to_utf8{0x93} = '“';
	$_to_utf8{0x94} = '”';
	$_to_utf8{0x95} = '•';
	$_to_utf8{0x96} = '–';
	$_to_utf8{0x97} = '—';
	$_to_utf8{0x99} = '™';
	$_to_utf8{0x9A} = 'š';
	$_to_utf8{0x9B} = '›';
	$_to_utf8{0x9C} = 'ś';
	$_to_utf8{0x9D} = 'ť';
	$_to_utf8{0x9E} = 'ž';
	$_to_utf8{0x9F} = 'ź';
	$_to_utf8{0xA0} = ' ';
	$_to_utf8{0xA1} = 'ˇ';
	$_to_utf8{0xA2} = '˘';
	$_to_utf8{0xA3} = 'Ł';
	$_to_utf8{0xA4} = '¤';
	$_to_utf8{0xA5} = 'Ą';
	$_to_utf8{0xA6} = '¦';
	$_to_utf8{0xA7} = '§';
	$_to_utf8{0xA8} = '¨';
	$_to_utf8{0xA9} = '©';
	$_to_utf8{0xAA} = 'Ş';
	$_to_utf8{0xAB} = '«';
	$_to_utf8{0xAC} = '¬';
	$_to_utf8{0xAD} = ' ';
	$_to_utf8{0xAE} = '®';
	$_to_utf8{0xAF} = 'Ż';
	$_to_utf8{0xB0} = '°';
	$_to_utf8{0xB1} = '±';
	$_to_utf8{0xB2} = '˛';
	$_to_utf8{0xB3} = 'ł';
	$_to_utf8{0xB4} = '´';
	$_to_utf8{0xB5} = 'µ';
	$_to_utf8{0xB6} = '¶';
	$_to_utf8{0xB7} = '·';
	$_to_utf8{0xB8} = '¸';
	$_to_utf8{0xB9} = 'ą';
	$_to_utf8{0xBA} = 'ş';
	$_to_utf8{0xBB} = '»';
	$_to_utf8{0xBC} = 'Ÿ';
	$_to_utf8{0xBD} = '˝';
	$_to_utf8{0xBE} = 'Ľ';
	$_to_utf8{0xBF} = 'ż';
	$_to_utf8{0xC0} = 'Ŕ';
	$_to_utf8{0xC1} = 'Á';
	$_to_utf8{0xC2} = 'Â';
	$_to_utf8{0xC3} = 'Ă';
	$_to_utf8{0xC4} = 'Ä';
	$_to_utf8{0xC5} = 'Ĺ';
	$_to_utf8{0xC6} = 'Ć';
	$_to_utf8{0xC7} = 'Ç';
	$_to_utf8{0xC8} = 'Č';
	$_to_utf8{0xC9} = 'É';
	$_to_utf8{0xCA} = 'Ę';
	$_to_utf8{0xCB} = 'Ë';
	$_to_utf8{0xCC} = 'Ě';
	$_to_utf8{0xCD} = 'Í';
	$_to_utf8{0xCE} = 'Î';
	$_to_utf8{0xCF} = 'Ď';
	$_to_utf8{0xD0} = 'Đ';
	$_to_utf8{0xD1} = 'Ń';
	$_to_utf8{0xD2} = 'Ň';
	$_to_utf8{0xD3} = 'Ó';
	$_to_utf8{0xD4} = 'Ô';
	$_to_utf8{0xD5} = 'Ő';
	$_to_utf8{0xD6} = 'Ö';
	$_to_utf8{0xD7} = '×';
	$_to_utf8{0xD8} = 'Ř';
	$_to_utf8{0xD9} = 'Ů';
	$_to_utf8{0xDA} = 'Ú';
	$_to_utf8{0xDB} = 'Ű';
	$_to_utf8{0xDC} = 'Ü';
	$_to_utf8{0xDD} = 'Ý';
	$_to_utf8{0xDE} = 'Ţ';
	$_to_utf8{0xDF} = 'ß';
	$_to_utf8{0xE0} = 'ŕ';
	$_to_utf8{0xE1} = 'á';
	$_to_utf8{0xE2} = 'â';
	$_to_utf8{0xE3} = 'ă';
	$_to_utf8{0xE4} = 'ä';
	$_to_utf8{0xE5} = 'ĺ';
	$_to_utf8{0xE6} = 'ć';
	$_to_utf8{0xE7} = 'ç';
	$_to_utf8{0xE8} = 'č';
	$_to_utf8{0xE9} = 'é';
	$_to_utf8{0xEA} = 'ę';
	$_to_utf8{0xEB} = 'ë';
	$_to_utf8{0xEC} = 'ě';
	$_to_utf8{0xED} = 'í';
	$_to_utf8{0xEE} = 'î';
	$_to_utf8{0xEF} = 'ď';
	$_to_utf8{0xF0} = 'đ';
	$_to_utf8{0xF1} = 'ń';
	$_to_utf8{0xF2} = 'ň';
	$_to_utf8{0xF3} = 'ó';
	$_to_utf8{0xF4} = 'ô';
	$_to_utf8{0xF5} = 'ő';
	$_to_utf8{0xF6} = 'ö';
	$_to_utf8{0xF7} = '÷';
	$_to_utf8{0xF8} = 'ř';
	$_to_utf8{0xF9} = 'ů';
	$_to_utf8{0xFA} = 'ú';
	$_to_utf8{0xFB} = 'ű';
	$_to_utf8{0xFC} = 'ü';
	$_to_utf8{0xFD} = 'ý';
	$_to_utf8{0xFE} = 'ţ';
	$_to_utf8{0xFF} = '˙';
}

1;

