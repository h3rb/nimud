# vi: ts=8 sw=8 sts=8

package Tongues::Dansk;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B C D E F G H I J K L M N O P Q R S T U V W X Y Z � � �
# a b c d e f g h i j k l m n o p q r s t u v w x y z � � �
# A B C D E F G H I J K L M N O P Q R S T U V W X Y Z � � �
# a b c d e f g h i j k l m n o p q r s t u v w x y z � � �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun
 #  Noun definiteness
 [ 'n',		'',	'the ',		'',	'n' ],	# comm. sing. def.
 [ 'en',	'',	'the ',		'',	'n' ],	# comm. sing. def.
 [ 't',		'',	'the ',		'',	'n' ],	# neut. sing. def.
 [ 'et',	'',	'the ',		'',	'n' ],	# neut. sing. def.
 [ 'ne',	'',	'the ',		's',	'n' ],	# plur. def.
 [ 'ene',	'',	'the ',		's',	'n' ],	# plur. def.
 #  Noun plural (flertal)
 [ 'e',		'',	'',		's',	'n' ],	# comm. sing. def.
 [ 'er',	'',	'',		's',	'n' ],	# comm. sing. def.
 #  Noun cases - genitive
 #  -s (is added to the last ending of the word): bilens (of the car), mandens (the man's)
 [ 's',		'',	'',		'\'s',	'n' ],	# comm. sing. def.
 # Adjectives
 [ 't',		'',	'',		'',	'a' ],	# indef. et
 [ 'e',		'',	'',		'',	'a' ],	# definite det/den/de
 #  Adjective comparitive and superlative
 [ 'ere',	'',	'',		'er',	'a' ],	# comparitive
 [ 'est',	'',	'',		'er',	'a' ],	# superlative
 # Verb infinitive (navnem�de, this is the dictionary form)
 # Verb past participle
 [ 't',		'e',	'',		'ed',	'v' ],	# All persons
 [ 'et',	'e',	'',		'ed',	'v' ],	# All persons
 # Verb gerund
 # Verb present participle
 [ 'ende',	'e',	'',		'ed',	'v' ],	# All persons
 # Verb present
 [ 'r',		'',	'',		'',	'v' ],	# All persons
 # Verb present subjunctive
 # Verb imperitive (bydem�de)
 [ '',		'e',	'',		'',	'v' ],	# All persons
 # Verb preterite
 [ 'te',	'e',	'',		'ed',	'v' ],	# All persons
 [ 'ede',	'e',	'',		'ed',	'v' ],	# All persons
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 [ 't',		'',	'',		'ly',	'a' ],
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	c -> common		en/den nouns
#	n -> neuter		et/det nouns
#	m -> masculine		pronouns
#	f -> feminine		pronouns
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative

# Danish to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 'den'		=> { 'x' => 'the',
		     '#' => '-n, -en',
 		     't' => 'art',
		     'g' => 'c',
		     'n' => 's' },
 'det'		=> { 'x' => 'the',
		     '#' => '-t, -et',
 		     't' => 'art',
		     'g' => 'n',
		     'n' => 's' },
 'de'		=> { 'x' => 'the',
		     '#' => '-ne, -ene',
 		     't' => 'art',
		     'n' => 'p' },
 #   Indefinite articles
 'en'		=> { 'x' => 'a',
 		     't' => 'art',
		     'g' => 'c' },
 'et'		=> { 'x' => 'a',
 		     't' => 'art',
		     'g' => 'n' },
 #  Pronouns & possessive adjectives
 #   1st person
 'jeg'		=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'mig'		=> { 'x' => 'me',
		     '#' => 'obj., refl.',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'min'		=> { 'x' => 'my',
		     '#' => 'poss. adjective',
		     't' => 'a' },
 'vi'		=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 #   2nd person
 'du'		=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'dig'		=> { 'x' => 'you',
		     '#' => 'obj., refl.',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'i'		=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p' },
 #   3rd person
 'han'		=> { 'x' => 'he',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
 'hun'		=> { 'x' => 'she',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f' },
 'ham'		=> { 'x' => 'him',
		     '#' => 'obj.',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
 'hende'	=> { 'x' => 'her',
		     '#' => 'obj.',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f' },
 'sig'		=> { 'x' => '(self)',
		     '#' => 'refl. pron. for he/she/it/they',
		     't' => 'pro' },

 #   Relative pronouns
 'der'		=> { 'x' => 'that',
		     '#' => 'who',
		     't' => 'pro' },
 'som'		=> { 'x' => 'that',
		     '#' => 'who',
		     't' => 'pro' },
 #   Indefinite pronouns
 'ingen'	=> { 'x' => 'nobody',
		     't' => 'pro' },
 'ingenting'	=> { 'x' => 'nothing',
		     't' => 'pro' },
 'nogen'	=> { 'x' => 'somebody',
		     't' => 'pro' },
 'noget'	=> { 'x' => 'something',
		     't' => 'pro' },

 #  Interrogatives
 'hvad'		=> { 'x' => 'what',
		     't' => 'pro' },
 'hvem'		=> { 'x' => 'who',
		     't' => 'pro' },
 'hvilke'	=> { 'x' => 'which' },
 'hvilken'	=> { 'x' => 'which' },
 'hvilket'	=> { 'x' => 'which' },
 'hvis'		=> { 'x' => 'whose' },
 'hvor'		=> { 'x' => 'where',
		     '#' => 'adv?' },
 'hvordan'	=> { 'x' => 'how',
		     '#' => 'adv?' },
 'hvorfor'	=> { 'x' => 'why' },
 'hvorn�r'	=> { 'x' => 'when',
		     '#' => 'adv?' },

 #  Other functional words
 'aldrig'	=> { 'x' => 'never',
		     't' => 'adv' },
 'at'		=> { 'x' => 'to',
		     '#' => 'part of infinitive' },
 'eller'	=> { 'x' => 'or',
		     't' => 'conj' },
 'fordi'	=> { 'x' => 'because',
		     't' => 'conj' },
 'fra'		=> { 'x' => 'from',
		     't' => 'p' },
 'f�r'		=> { 'x' => 'before',
		     '#' => 'temporal adv.',
		     't' => 'adv' },
 'hej'		=> { 'x' => 'hello',
		     '#' => 'hi',
		     't' => 'interj' },
 'ja'		=> { 'x' => 'yes',
		     't' => 'interj' },
 'med'		=> { 'x' => 'with',
		     't' => 'p' },
 'men'		=> { 'x' => 'but',
		     't' => 'conj' },
 'mens'		=> { 'x' => 'while',
		     't' => 'conj' },
 'mere'		=> { 'x' => 'more',
		     '#' => 'comparitive' },
 'mest'		=> { 'x' => 'most',
		     '#' => 'superlative' },
 'nej'		=> { 'x' => 'no',
		     't' => 'interj' },
 'n�r'		=> { 'x' => 'when',
		     't' => 'conj' },
 'og'		=> { 'x' => 'and',
 		     't' => 'conj' },
 'om' 		=> { 'x' => 'if',
		     '#' => 'whether',
		     't' => 'conj' },
 's�'		=> { 'x' => 'so' },
 'tit'		=> { 'x' => 'often',
		     '#' => 'temporal adv.',
		     't' => 'adv' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'f�rste'	=> { 'x' => 'first' },
 'to'		=> { 'x' => 'two' },
 'anden'	=> { 'x' => 'second' },
 'tre'		=> { 'x' => 'three' },
 'tredie'	=> { 'x' => 'third' },
 'fire'		=> { 'x' => 'four' },
 'fjerde'	=> { 'x' => 'fourth' },
 'fem'		=> { 'x' => 'five' },
 'femte'	=> { 'x' => 'fifth' },
 'seks'		=> { 'x' => 'six' },
 'sjette'	=> { 'x' => 'sixth' },
 'syv'		=> { 'x' => 'seven' },
 'syvende'	=> { 'x' => 'seventh' },
 'otte'		=> { 'x' => 'eight' },
 'ottende'	=> { 'x' => 'eighth' },
 'ni'		=> { 'x' => 'nine' },
 'niende'	=> { 'x' => 'ninth' },
 'ti'		=> { 'x' => 'ten' },
 'tiende'	=> { 'x' => 'tenth' },
 'elleve'	=> { 'x' => 'eleven' },
 'tolv'		=> { 'x' => 'twelve' },
 'tretten'	=> { 'x' => 'thirteen' },
 'fjorten'	=> { 'x' => 'fourteen' },
 'sytten'	=> { 'x' => 'seventeen' },
 'atten'	=> { 'x' => 'eighteen' },
 'nitten'	=> { 'x' => 'nineteen' },
 'tyve'		=> { 'x' => 'twenty' },
 'tredive'	=> { 'x' => 'thirty' },
 'fyrre'	=> { 'x' => 'forty' },
 'halvtreds'	=> { 'x' => 'fifty' },
 'tres'		=> { 'x' => 'sixty' },
 'halvfjerds'	=> { 'x' => 'seventy' },
 'firs'		=> { 'x' => 'eighty' },
 'halvfems'	=> { 'x' => 'ninety' },
 'hundrede'	=> { 'x' => 'hundred' },
 'tusind'	=> { 'x' => 'thousand' },
 'milion'	=> { 'x' => 'milion' },

 # Days and months
 's�ndag'	=> { 'x' => 'sunday' },
 'mandag'	=> { 'x' => 'monday' },
 'tirsdag'	=> { 'x' => 'tuesday' },
 'onsdag'	=> { 'x' => 'wednesday' },
 'torsdag'	=> { 'x' => 'thursday' },
 'fredag'	=> { 'x' => 'friday' },
 'l�rdag'	=> { 'x' => 'saturday' },

 'januar'	=> { 'x' => 'january' },
 'februar'	=> { 'x' => 'february' },
 'marts'	=> { 'x' => 'march' },
 'april'	=> { 'x' => 'april' },
 'maj'		=> { 'x' => 'may' },
 'juni'		=> { 'x' => 'june' },
 'juli'		=> { 'x' => 'july' },
 'august'	=> { 'x' => 'august' },
 'september'	=> { 'x' => 'september' },
 'oktober'	=> { 'x' => 'october' },
 'november'	=> { 'x' => 'november' },
 'december'	=> { 'x' => 'december' },

 # Key verbs
 #  er - to be
 'er'		=> { 'x' => 'is',
 		     't' => 'v' },
 #  har - have
 'har'		=> { 'x' => 'have',
		     't' => 'v' },
 #  burde - to ought to; modal
 #  gide - to feel like; modal
 #  kunne - can; modal
 'kan'		=> { 'x' => 'can',
		     '#' => 'be able to',
		     't' => 'v' },
 'kunne'	=> { 'x' => 'could',
		     't' => 'v' },
 #  m�tte - may, must; modal
 #  skulle - shall, would; modal
 #  turde - to dare; modal
 #  ville - will, to want to; modal

 # Vocabulary
 'arabisk'	=> { 'x' => 'arabic',
		     '#' => 'noun & adj.' },
 'armensk'	=> { 'x' => 'armenian',
		     '#' => 'noun & adj.' },
 'artikel'	=> { 'x' => 'article',
		     't' => 'n' },
 'barn'		=> { 'x' => 'child',
		     '#' => 'irreg',
 		     't' => 'n',
		     'p' => 'b�rn' },
 'bestemt'	=> { 'x' => 'definite',
		     '#' => 'gramm.',
		     't' => 'a' },
 'bil'		=> { 'x' => 'car',
 		     't' => 'n',
		     'g' => 'en' },
 'billig'	=> { 'x' => 'cheap',
		     't' => 'a' },
 'blomst'	=> { 'x' => 'flower',
		     't' => 'n' },
 'bog'		=> { 'x' => 'book',
		     '#' => 'irreg.',
 		     't' => 'n' },
  'b�ger'	=> { 'x' => 'books',
		     'r' => 'bog',
		     't' => 'n',
		     'n' => 'p' },
 'bringe'	=> { 'x' => 'bring',
		     't' => 'v' },
 'katalansk'	=> { 'x' => 'catalan',
		     '#' => 'noun & adj.' },
 'dag'		=> { 'x' => 'day',
 		     't' => 'n',
		     'p' => 'e' },
 'danmark'	=> { 'x' => 'denmark',
		     '#' => 'proper, place',
		     't' => 'n',
		     'g' => 'n' },
 'dansk'	=> { 'x' => 'danish',
		     '#' => 'noun and adj.?' },
 'dreng'	=> { 'x' => 'boy',
 		     't' => 'n',
		     'g' => 'c' },
 'drille'	=> { 'x' => 'tease',
		     't' => 'v' },
 'd�rlig'	=> { 'x' => 'bad',
		     '#' => 'irreg.',
		     't' => 'a' },
 'eje'		=> { 'x' => 'possessive',
		     '#' => 'gramm.',
		     't' => 'a' },
 'ejefald'	=> { 'x' => 'genetive',
		     '#' => 'gramm.',
		     't' => 'a' },
 'elektricitet'	=> { 'x' => 'electricity',
 		     't' => 'n' },
 'elske'	=> { 'x' => 'love',
		     't' => 'v' },
 'endelse'	=> { 'x' => 'suffix',
		     't' => 'n' },
 'ental'	=> { 'x' => 'singular',
		     '#' => 'adj?' },
 'finsk'	=> { 'x' => 'finnish',
		     '#' => 'noun & adj.' },
 'flertal'	=> { 'x' => 'plural',
		     '#' => 'adj?' },
 'foreg�ende'	=> { 'x' => 'previous',
		     't' => 'p' },
 'forsamling'	=> { 'x' => 'meeting',
 		     't' => 'n' },
 'fransk'	=> { 'x' => 'french',
		     '#' => 'adj. and noun' },
 'gammel'	=> { 'x' => 'old',
		     '#' => 'irreg.',
 		     't' => 'a' },
 'gang'		=> { 'x' => 'time',
		     '#' => 'as in "one time"',
		     't' => 'n',
		     'x-de' => 'mal',
		     'x-es' => 'vez' },
 'give'		=> { 'x' => 'give',
		     '#' => 'irreg.',
		     't' => 'v' },
 'god'		=> { 'x' => 'good',
		     '#' => 'irreg. compar./super.',
 		     't' => 'a' },
 'g�s'		=> { 'x' => 'geese',
		     'r' => 'g�s',
		     't' => 'n',
		     'n' => 'p',
		     'g' => 'c' },
 'g�s'		=> { 'x' => 'goose',
		     '#' => 'irreg.',
		     't' => 'n',
		     'g' => 'c' },
 'gradb�jning'	=> { 'x' => 'comparison',
		     't' => 'n' },
 'gr�sk'	=> { 'x' => 'greek',
		     '#' => 'adj. and noun' },
 'handleform'	=> { 'x' => 'active',
		     't' => 'a' },
 'hat'		=> { 'x' => 'hat',
 		     't' => 'n' },
 'hebraisk'	=> { 'x' => 'hebrew',
		     '#' => 'adj. and noun' },
 'henf�rende'	=> { 'x' => 'relative',
		     't' => 'a' },
 'hest'		=> { 'x' => 'horse',
 		     't' => 'n' },
 'hollandsk'	=> { 'x' => 'dutch',
		     '#' => 'noun and adj.' },
 'hus'		=> { 'x' => 'house',
 		     't' => 'n',
		     'g' => 'n' },
 'hvid'		=> { 'x' => 'white',
 		     't' => 'a' },
 'h�j'		=> { 'x' => 'high',
		     't' => 'a' },
 'h�rje'	=> { 'x' => 'right',
		     '#' => 'opp. of left; noun, adj, adv?' },
 'japan'	=> { 'x' => 'japan',
 		     't' => 'n' },
 'kaffe'	=> { 'x' => 'coffee',
 		     't' => 'n' },
 'kage'		=> { 'x' => 'cake',
		     't' => 'n' },
 'kapitel'	=> { 'x' => 'chapter',
		     't' => 'n' },
 'kende'	=> { 'x' => 'know',
		     't' => 'v',
		     'x-de' => 'kennen',
		     'x-es' => 'conocer' },
 'kendeord'	=> { 'x' => 'article',
		     '#' => 'grammat.',
		     't' => 'n' },
 'komme'	=> { 'x' => 'come',
		     't' => 'v' },
 'konvolut'	=> { 'x' => 'envelope',
 		     't' => 'n' },
 'koreansk'	=> { 'x' => 'korean',
		     '#' => 'adj and noun' },
 'kysse'	=> { 'x' => 'kiss',
		     't' => 'v' },
 'lang'		=> { 'x' => 'long',
		     '#' => 'irreg. compar./super.',
 		     't' => 'a' },
 'lettisk'	=> { 'x' => 'latvian',
		     '#' => 'noun & adj.' },
 'lideform'	=> { 'x' => 'passive',
		     't' => 'a' },
 'lille'	=> { 'x' => 'small',
		     '#' => 'invariant for singular; cf sm� ',
 		     't' => 'a',
		     '#' => 'irreg. compar./super.' },
 'litauisk'	=> { 'x' => 'lithuanian',
		     '#' => 'adj and noun' },
 'l�se'		=> { 'x' => 'read',
		     't' => 'v' },
 'l�b'		=> { 'x' => 'run',
		     't' => 'v' },
 'l�ne'		=> { 'x' => 'borrow',
		     '#' => 'lend?',
		     't' => 'v' },
 'mand'		=> { 'x' => 'man',
 		     't' => 'n' },
 'minut'	=> { 'x' => 'minute',
 		     't' => 'n' },
 'mor'		=> { 'x' => 'mother',
		     '#' => 'person',
		     't' => 'n' },
 'm�ned'	=> { 'x' => 'month',
 		     't' => 'n',
		     'p' => 'er' },
 'navn'		=> { 'x' => 'name',
		     't' => 'n' },
 'navneord'	=> { 'x' => 'noun',
		     't' => 'n' },
 'norsk'	=> { 'x' => 'norwegian',
		     '#' => 'adj. and noun' },
 'n�ste'	=> { 'x' => 'next',
		     't' => 'a' },
 'ordbog'	=> { 'x' => 'dictionary',
 		     't' => 'n' },
 'pas'		=> { 'x' => 'passport',
 		     't' => 'n' },
 'personligt'	=> { 'x' => 'personal',
		     '#' => 'gramm.',
		     't' => 'a' },
 'pige'		=> { 'x' => 'girl',
		     '#' => 'person',
		     't' => 'n',
		     'g' => 'c' },
 'polen'	=> { 'x' => 'poland',
		     '#' => 'proper, place',
		     't' => 'n' },
 'popul�r'	=> { 'x' => 'popular',
		     't' => 'a' },
 'p�pegende'	=> { 'x' => 'demonstrative',
		     '#' => 'gramm.',
		     't' => 'a' },
 'ransage'	=> { 'x' => 'search',
 		     't' => 'v' },
 'ret'		=> { 'x' => 'right',
		     '#' => 'correct; meal',
		     't' => 'a' },
 'rettighed'	=> { 'x' => 'right',
		     '#' => 'as in human rights',
		     't' => 'n' },
 'r�d'		=> { 'x' => 'red',
 		     't' => 'a' },
 'synge'	=> { 'x' => 'sing',
		     't' => 'v' },
 'smuk'		=> { 'x' => 'beautiful',
		     't' => 'a' },
 'sm�'		=> { 'x' => 'small',
		     '#' => 'invariant for plural; cf lille',
 		     't' => 'a' },
 'sort'		=> { 'x' => 'black',
 		     't' => 'a' },
 'sove'		=> { 'x' => 'sleep',
		     't' => 'v' },
 'spanien'	=> { 'x' => 'spain',
		     '#' => 'proper, place',
 		     't' => 'n' },
 'spansk'	=> { 'x' => 'spanish',
		     '#' => 'noun & adj.' },
 'sp�rgende'	=> { 'x' => 'interrogative',
		     '#' => 'gramm.',
		     't' => 'a' },
 'spise'	=> { 'x' => 'eat',
		     't' => 'v' },
 'stedord'	=> { 'x' => 'pronoun',
		     '#' => 'gramm.',
		     't' => 'n' },
 'stolt'	=> { 'x' => 'proud',
		     't' => 'a' },
 'stor'		=> { 'x' => 'big',
 		     't' => 'a' },
 'st�'		=> { 'x' => 'stand',
		     't' => 'v' },
 'sulten'	=> { 'x' => 'hungry',
 		     't' => 'a' },
 'sv�mme'	=> { 'x' => 'swim',
 		     't' => 'v' },
 'tag'		=> { 'x' => 'roof',
 		     't' => 'n' },
 'tale'		=> { 'x' => 'speak',
		     't' => 'v' },
 'te'		=> { 'x' => 'tea',
 		     't' => 'n' },
 'tid'		=> { 'x' => 'time',
		     '#' => 'as in plenty of time',
		     't' => 'n',
		     'x-de' => 'zeit',
		     'x-es' => 'tiempo' },
 'tilbagevisende'	=> { 'x' => 'reflexive',
			     '#' => 'gramm.',
			     't' => 'a' },
 'till�gsord'	=> { 'x' => 'adjective',
		     't' => 'n' },
 'tjekkisk'	=> { 'x' => 'czech',
		     '#' => 'noun & adj.' },
 'tr�'		=> { 'x' => 'tree',
		     't' => 'n',
		     'g' => 'n' },
 'tysk'		=> { 'x' => 'german',
		     '#' => 'noun & adj.' },
 'tyskland'	=> { 'x' => 'germany',
 		     't' => 'n' },
 'ubestemt'	=> { 'x' => 'indefinite',
		     '#' => 'gramm.',
		     't' => 'a' },
 'udsangsord'	=> { 'x' => 'verb',
		     '#' => 'gramm.',
		     't' => 'n' },
 'uge'		=> { 'x' => 'week',
 		     't' => 'n',
		     'p' => 'r' },
 'varm'		=> { 'x' => 'warm',
 		     't' => 'a' },
 'vindue'	=> { 'x' => 'window',
 		     't' => 'n' },
 '�l'		=> { 'x' => 'beer',
		     't' => 'n' },
 '�strig'	=> { 'x' => 'austria',
		     '#' => 'proper; place',
 		     't' => 'n' },
 '�r'		=> { 'x' => 'year',
 		     't' => 'n' },
);
}

1;

