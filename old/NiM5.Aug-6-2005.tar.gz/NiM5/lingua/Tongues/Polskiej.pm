# vi: ts=8 sw=8 sts=8

package Tongues::Polskiej;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Central European CP1250
# not ISO 8859-2

# Alphabetical order
# A � B C � D E � F G H I J K L � M N � O � P R S � T U W Y Z � �
# a � b c � d e � f g h i j k l � m n � o � p r s � t u w y z � �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::CentralEuroWin;

$charset = new Charsets::CentralEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun
 #  Noun gender
 #  Noun plural
 #  Noun case
 # Adjectives
 # Verb
 #  Verb present imperfective
 [ '�',		'�',	'',		'',	'v' ],	# I
 [ 'sz',	'�',	'',		'',	'v' ],	# you
 [ '',		'�',	'',		's',	'v' ],	# he
 [ 'my',	'�',	'',		'',	'v' ],	# we
 [ 'cie',	'�',	'',		'',	'v' ],	# you (plural)
 [ '�',		'�',	'',		'',	'v' ],	# they
 #  Verb present perfective
 [ 'z-�',	'�',	'',		'',	'v' ],	# I
 [ 'z-sz',	'�',	'',		'',	'v' ],	# you
 [ 'z-',	'�',	'',		's',	'v' ],	# he
 [ 'z-my',	'�',	'',		'',	'v' ],	# we
 [ 'z-cie',	'�',	'',		'',	'v' ],	# you (plural)
 [ 'z-�',	'�',	'',		'',	'v' ],	# they
 #  Verb impersonal imperfective
 [ '�cy',	'�',	'',		'ing',	'v' ],	# imp. pres. part.
 [ 'ony',	'�',	'',		'ed',	'v' ],	# imp. past. part.
 #  Verb impersonal perfective
 [ 'z-wszy',	'�',	'having ',	'ed',	'v' ],	# perf. pres. part.
 [ 'z-ony',	'�',	'',		'ed',	'v' ],	# perf. past. part.
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine
#	f -> feminine
#	n -> neuter
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation/tense:
#	inf -> infinitive	default
#	p -> present
#	t -> preterite
# c -> case:
#	n -> nominative
#	g -> genitive
#	d -> dative
#	a -> accusative
#	l -> locative
#	inst -> instrumental
#	v -> vocative

# Polish to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 'ja'		=> { 'x' => 'i',
 		     't' => 'pro',
 		     'p' => '1',
		     'n' => 's' },
 'ty'		=> { 'x' => 'you',
 		     't' => 'pro',
 		     'p' => '2',
		     'n' => 's' },
 'on'		=> { 'x' => 'he',
 		     't' => 'pro',
 		     'p' => '3',
		     'n' => 's' },
 'my'		=> { 'x' => 'we',
 		     't' => 'pro',
 		     'p' => '1',
		     'n' => 'p' },
 'wy'		=> { 'x' => 'you',
 		     't' => 'pro',
 		     'p' => '2',
		     'n' => 'p' },
 'oni'		=> { 'x' => 'they',
 		     't' => 'pro',
 		     'p' => '3',
		     'n' => 'p' },
 #  Other functional words
 'nie'		=> { 'x' => 'not' },
 #   Prepositions
 'bez'		=> { 'x' => 'without',
		     '#' => 'gen., out of.',
 		     't' => 'p' },
 'dla'		=> { 'x' => 'for',
		     '#' => 'gen.',
 		     't' => 'p' },
 'do'		=> { 'x' => 'to',
		     '#' => 'gen., into, toward, for, until',
 		     't' => 'p' },
 'ku'		=> { 'x' => 'to ',
		     '#' => 'dat',
 		     't' => 'p' },
 'na'		=> { 'x' => 'to',
		     '#' => 'locat./ acc., in, on, for',
 		     't' => 'p' },
 'nad'		=> { 'x' => 'at',
		     '#' => 'locat./ acc., to, by, over',
 		     't' => 'p' },
 'o'		=> { 'x' => 'about',
		     '#' => 'locat./ acc., at (hour)',
 		     't' => 'p' },
 'obok'		=> { 'x' => 'by',
		     '#' => 'gen., next to',
 		     't' => 'p' },
 'od'		=> { 'x' => 'from',
		     '#' => 'gen., since',
 		     't' => 'p' },
 'po'		=> { 'x' => 'after',
		     '#' => 'locat./ acc., at (price, hour)',
 		     't' => 'p' },
 'pod'		=> { 'x' => 'under',
		     '#' => 'instr./ acc.',
 		     't' => 'p' },
 'przeciw'	=> { 'x' => 'against',
		     '#' => 'dative',
 		     't' => 'p' },
 'przeciwko'	=> { 'x' => 'against',
		     '#' => 'dative',
 		     't' => 'p' },
 'przed'	=> { 'x' => 'before',
		     '#' => 'instr./ acc.',
 		     't' => 'p' },
 'przez'	=> { 'x' => 'through',
		     '#' => 'acc.',
 		     't' => 'p' },
 'u'		=> { 'x' => 'by',
		     '#' => 'gen., at (store, house)',
 		     't' => 'p' },
 'w'		=> { 'x' => 'in',
		     '#' => 'locat./ acc., on, into , onto',
 		     't' => 'p' },
 'we'		=> { 'x' => 'in',
		     '#' => 'locat./ acc., on, into , onto',
 		     't' => 'p' },
 'z'		=> { 'x' => 'from',
		     '#' => 'gen.; instr. with',
 		     't' => 'p' },
 'ze'		=> { 'x' => 'from',
		     '#' => 'gen.; instr. with',
 		     't' => 'p' },
 'za'		=> { 'x' => 'behind',
		     '#' => 'instr./ acc., in (time), for (price)',
 		     't' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 # From http://oss.software.ibm.com/cgi-bin/icu/lx/en_AU/?_=pl&
 'niedziela'	=> { 'x' => 'sunday' },
 'poniedzia�ek'	=> { 'x' => 'monday' },
 'wtorek'	=> { 'x' => 'tuesday' },
 '�roda'	=> { 'x' => 'wednesday' },
 'czwartek'	=> { 'x' => 'thursday' },
 'pi�tek'	=> { 'x' => 'friday' },
 'sobota'	=> { 'x' => 'saturday' },
 'stycze�'	=> { 'x' => 'january' },
 'luty'		=> { 'x' => 'february' },
 'marzec'	=> { 'x' => 'march' },
 'kwiecie�'	=> { 'x' => 'april' },
 'maj'		=> { 'x' => 'may' },
 'czerwiec'	=> { 'x' => 'june' },
 'lipiec'	=> { 'x' => 'july' },
 'sierpie�'	=> { 'x' => 'august' },
 'wrzesie�'	=> { 'x' => 'september' },
 'pa�dziernik'	=> { 'x' => 'october' },
 'listopad'	=> { 'x' => 'november' },
 'grudzie�'	=> { 'x' => 'december' },
 # From ?, what do the three versions mean?  Different cases?
 'stycze�'	=> { 'x' => 'january',
		     '#' => 'stycznia, styczniu' },
 'luty'		=> { 'x' => 'february',
		     '#' => 'lutego, lutym' },
 'marzec'	=> { 'x' => 'march',
		     '#' => 'marca, marcu' },
 'kwiecie�'	=> { 'x' => 'april',
		     '#' => 'kwietnia, kwietniu' },
 'maj'		=> { 'x' => 'may',
		     '#' => 'maja, maju' },
 'czerwiec'	=> { 'x' => 'june',
		     '#' => 'czerwca, czerwcu' },
 'lipiec'	=> { 'x' => 'july',
		     '#' => 'lipca, lipcu' },
 'sierpie�'	=> { 'x' => 'august',
		     '#' => 'sierpnia, sierpniu' },
 'wrzesie�'	=> { 'x' => 'september',
		     '#' => 'wrze�nia, wrze�niu' },
 'pa�dziernik'	=> { 'x' => 'october',
		     '#' => 'pa�dziernika, pa�dzierniku' },
 'listopad'	=> { 'x' => 'november',
		     '#' => 'listopada, listopadzie' },
 'grudzie�'	=> { 'x' => 'december',
		     '#' => 'grudnia, grudniu' },
 # Key verbs
 'robi�'	=> { 'x' => 'do',
 		     't' => 'v' },
 # Vocabulary
 'artyku�'	=> { 'x' => 'article',
		     't' => 'n' },
 'japonia'	=> { 'x' => 'japan',
		     '#' => 'proper; place',
 		     't' => 'n' },
 'paragwaj'	=> { 'x' => 'paraguay',
		     '#' => 'proper; place',
 		     't' => 'n' },
 'solidarno��'	=> { 'x' => 'solidarity',
 		     't' => 'n' },
);
}

1;

