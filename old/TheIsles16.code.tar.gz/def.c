/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <time.h>
#include "merc.h"

/*               DUMs (3)
Name             Address                 Numeric Address  Port  Status Notes
----------------------------------------------------------------------------
CanDUM II        cheetah.vlsi.uwaterloo.ca                2001  up 
                 cheetah.vlsi-cheetahnet.uwaterloo.ca 
                                         129.97.180.1 
                                         129.97.94.45 
DUM II           elektra.ling.umu.se     130.239.24.66    2001  up 
FranDUM          mousson.enst.fr         137.194.160.48   2001  up 
----------------------------------------------------------------------------
*/



char *   const  percent_hit [] =
{
    "massacred",
    "slaughtered",
    "bloodied",
    "beaten",
    "wounded",
    "hurt",
    "bruised",
    "scratched",
    "fine",
    "fine",
    "excellent"
};


char *   const  percent_tired [] =
{
    "exhausted",
    "beat",
    "tired",
    "weary",
    "haggard",
    "fatigued",
    "worked",
    "winded",
    "rested",
    "fresh",
    "fresh"
};

char *   const  color_list [MAX_COLOR_LIST] =
{
    "red",
    "blue",
    "black",
    "turquoise",
    "yellow",
    "faded indigo",
    "purple",
    "magenta",
    "lavender",
    "green",
    "white",
    "faded orange",
    "violet",
    "maroon",
    "mauve",
    "brown",          /* 16 */
    "tan",
    "grey"
};

char *   const  cloth_list [MAX_CLOTH_LIST] =
{
    "satin",
    "linen",
    "silk",
    "cloth",
    "wool",
    "cotton",
    "reed"            /* 7 */
};

/*
 * Coin information
 */
const struct coin_type coin_table[MAX_COIN] =
{
   {  10,   10000,   3, "obsidian",   "op"  },
   {  10,    1000,   2, "platinum",   "pp"  },
   {  10,     100,   1, "gold",       "gp"  },
   {  10,      10,   1, "silver",     "sp"  },
   {  10,       1,   1, "copper",     "cp"  }
};



/*
 * bust a race.
 */
const struct   race_type  race_table [MAX_RACE] =
{
  { "Human",
    {  0,  0,  0,  0,  0 },                                 /* S I W D C */
    10001,                                                  /* Room      */
    50,                                                     /* Max Skill */
    0,                                                      /* Bits      */
    SIZE_AVERAGE,                                           /* Size      */
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG |         /* BodyParts */
    PART_HEART  | PART_REDBLOOD,
    ALIGN_LG, ALIGN_CE                                  /* Min/Max Align */
  },
  { "Half-Elf",
    { -1,  1,  0,  1, -1 },
    10001,
    50,
    0,
    SIZE_AVERAGE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_LG, ALIGN_CE
  },
  { "Elf",
    { -1,  2,  1,  1, -2 },
    10001,
    60,
    0,
    SIZE_PETITE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_LG, ALIGN_CE
  },
  { "Wild-Elf",
    { -1,  0, -1,  1,  1 },
    10001,
    65,
    AFF_DETECT_HIDDEN,
    SIZE_PETITE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_NG, ALIGN_E
  },
  { "High-Elf",
    {  1,  1,  0,  1, -1 },
    10001,
    55,
    0,
    SIZE_PETITE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_G, ALIGN_NE
  },
  { "Shadowelf",
    { -1,  0,  0,  2, -1 },
    10001,
    50,
    0,
    SIZE_SMALL,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_NG, ALIGN_CE
  },
  { "Drow",
    {  1,  1,  1, -1, -2 },
    10001,
    70,
    AFF_INFRARED,
    SIZE_PETITE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_N, ALIGN_CE
  },
  { "Dwarf",
    {  3, -3, -2, -1,  3 },
    6501,
    40,
    AFF_INFRARED,
    SIZE_SMALL,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_LG, ALIGN_CE
  },
  { "Hilldwarf",
    {  2,  0,  0, -2,  2 },
    6501,
    30,
    0,
    SIZE_SMALL,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_G, ALIGN_E
  },
  { "Gnome",
    {  3,  0, -3,  0,  3 },
    10001,
    35,
    0,
    SIZE_SMALL,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_G, ALIGN_E
  },
  { "Tinkergnome",
    {  0,  1,  0,  0,  2 },
    10001,
    30,
    0,
    SIZE_SMALL,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_G, ALIGN_E
  },
  { "Giant",
    {  5,  0, -5,  0,  3 },
    10001,
    25,
    0,
    SIZE_HUGE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_LG, ALIGN_CE
  },
  { "Kender",
    {  2, -1, -1,  0,  3 },
    10001,
    35,
    0,
    SIZE_SMALL,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_G, ALIGN_NE
  },
  { "ShadaoSlav",
    {  0,  5,  5, -3, -2 },
    10001,
    75,    
    AFF_INFRARED,
    SIZE_LARGE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART,
    ALIGN_NG, ALIGN_CE
  },
  { "Dragonkin",   
    {  2,  2,  2, -5,  1 },   
    10001,
    15,    
    AFF_DETECT_INVIS,
    SIZE_LARGE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD
    | PART_WING,
    ALIGN_NG, ALIGN_CE
  },
  { "Buckawn",     
    { -4,  0,  1,  2, -2 },   
    10001,
    50,    
    AFF_FREEACTION,
    SIZE_SMALL,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_G, ALIGN_E
  },
  { "Skulk",       
    {  0,  1,  0,  2, -3 },   
    10001,
    35,    
    4,  
    SIZE_AVERAGE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART,
    ALIGN_NG, ALIGN_NE
  },
  { "Beastman",    
    {  1,  1, -3,  1,  0 },   
    10001,
    40,    
    0,
    SIZE_AVERAGE,
    PART_BOWELS | PART_HEAD | PART_ARM | PART_LEG | PART_HEART | PART_REDBLOOD,
    ALIGN_G, ALIGN_NE
  }
};


/*
 * Class table.
 */
const   struct  class_type  class_table [MAX_CLASS] =
{
  {
     "",  APPLY_NONE,  0, 85,   /* name, prime req, room, max percent */
     18, 6,  5, 15              /* thac0 1st, thac0 32nd, minhits, maxhits */
  }

};


/*
 * A single set of colors for use with the COLOR command. :)
 */

const   struct  color_data color_table[] =
{
   { "\x1b[30m",     "$R$0",   "black",         0 },
   { "\x1b[34m",     "$R$1",   "blue",          1 },
   { "\x1b[32m",     "$R$2",   "green",         2 },
   { "\x1b[36m",     "$R$3",   "cyan",          3 },
   { "\x1b[31m",     "$R$4",   "red",           4 },
   { "\x1b[35m",     "$R$5",   "purple",        5 },
   { "\x1b[33m",     "$R$6",   "brown",         6 },
   { "\x1b[37m",     "$R$7",   "grey",          7 },
   { "\x1b[30;1m",   "$B$0",   "dark_grey",     8 },
   { "\x1b[34;1m",   "$B$1",   "light_blue",    9 },
   { "\x1b[32;1m",   "$B$2",   "light_green",  10 },
   { "\x1b[36;1m",   "$B$3",   "light_cyan",   11 },
   { "\x1b[31;1m",   "$B$4",   "light_red",    12 },
   { "\x1b[35;1m",   "$B$5",   "magenta",      13 },
   { "\x1b[33;1m",   "$B$6",   "yellow",       14 },
   { "\x1b[37;1m",   "$B$7",   "white",        15 },
   { "\x1b[1m",      "$B",     "bold",         16 },
   { "\x1b[5m",      "$F",     "flashing",     17 },
   { "\x1b[7m",      "$I",     "inverse",      18 },
   { "\x1b[0m",      "$R",     "normal",       19 }
};


/*
 *  Attack damage type and string.
 */
const   struct  attack_type attack_table [] =         /* CHANGE MAX_ATTACK */
{
    {   "hit",          TYPE_HIT,       NULL                   },  /*  0   */
    {   "slice",        TYPE_SLASH,     NULL                   },  /*  1   */
    {   "stab",         TYPE_PIERCE,    NULL                   },
    {   "slash",        TYPE_SLASH,     NULL                   },
    {   "whip",         TYPE_WHIP,      NULL                   },
    {   "claw",         TYPE_SLASH,     NULL                   },  /*  5   */
    {   "blast",        TYPE_EXPLODE,   NULL                   },
    {   "pound",        TYPE_POUND,     NULL                   },
    {   "crush",        TYPE_POUND,     NULL                   },
    {   "gore",         TYPE_PIERCE,    NULL                   },
    {   "bite",         TYPE_PIERCE,    NULL                   },  /*  10  */
    {   "pierce",       TYPE_PIERCE,    NULL                   },
    {   "suction",      TYPE_SUCTION,   hit_suck_disarm        },
    {   "vorpal",       TYPE_SLASH,     hit_vorpal             },
    {   "cleave",       TYPE_SLASH,     NULL                   },
    {   "wail",         TYPE_HIT,       NULL                   }   /*  15  */
};



/*
 * Attribute bonus tables.
 */
const   struct  str_app_type    str_app     [26]        =
{
    { -5, -4,   0,  0 },  /* 0  */
    { -5, -4,   3,  1 },  /* 1  */
    { -3, -2,   3,  2 },
    { -3, -1,  10,  3 },  /* 3  */
    { -2, -1,  25,  4 },
    { -2, -1,  55,  5 },  /* 5  */
    { -1,  0,  80,  6 },
    { -1,  0,  90,  7 },
    {  0,  0, 100,  8 },
    {  0,  0, 100,  9 },
    {  0,  0, 115, 10 }, /* 10  */
    {  0,  0, 115, 11 },
    {  0,  0, 140, 12 },
    {  0,  0, 140, 13 }, /* 13  */
    {  0,  1, 170, 14 },
    {  1,  1, 170, 15 }, /* 15  */
    {  1,  2, 195, 16 },
    {  2,  3, 220, 22 },
    {  2,  4, 250, 25 }, /* 18  */
    {  3,  5, 400, 30 },
    {  3,  6, 500, 35 }, /* 20  */
    {  4,  7, 600, 40 },
    {  5,  7, 700, 45 },
    {  6,  8, 800, 50 },
    {  8, 10, 900, 55 },
    { 10, 12, 999, 60 }  /* 25   */
};



const   struct  int_app_type    int_app     [26]        =
{
    {  3 },	/*  0 */
    {  5 },	/*  1 */
    {  7 },
    {  8 },	/*  3 */
    {  9 },
    { 10 },	/*  5 */
    { 11 },
    { 12 },
    { 13 },
    { 15 },
    { 17 },	/* 10 */
    { 19 },
    { 22 },
    { 25 },
    { 28 },
    { 31 },	/* 15 */
    { 34 },
    { 37 },
    { 40 },	/* 18 */
    { 44 },
    { 49 },	/* 20 */
    { 55 },
    { 60 },
    { 70 },
    { 85 },
    { 99 }	/* 25 */
};



const   struct  wis_app_type    wis_app     [26]        =
{
    { 1 },      /*  0 */
    { 1 },      /*  1 */
    { 1 },
    { 1 },      /*  3 */
    { 1 },
    { 1 },	/*  5 */
    { 1 },
    { 1 },
    { 1 },
    { 2 },
    { 2 },	/* 10 */
    { 2 },
    { 2 },
    { 2 },
    { 2 },
    { 3 },	/* 15 */
    { 3 },
    { 4 },
    { 5 },	/* 18 */
    { 5 },
    { 5 },	/* 20 */
    { 6 },
    { 6 },
    { 6 },
    { 6 },
    { 7 }	/* 25 */
};



const   struct  dex_app_type    dex_app     [26]        =
{
    {   60 },   /* 0 */
    {   50 },   /* 1 */
    {   50 },
    {   40 },
    {   30 },
    {   20 },   /* 5 */
    {   10 },
    {    0 },
    {    0 },
    {    0 },
    {    0 },   /* 10 */
    {    0 },
    {    0 },
    {    0 },
    {    0 },
    { - 10 },   /* 15 */
    { - 15 },
    { - 20 },
    { - 30 },
    { - 40 },
    { - 50 },   /* 20 */
    { - 60 },
    { - 75 },
    { - 90 },
    { -105 },
    { -120 }    /* 25 */
};



const   struct  con_app_type    con_app     [26]        =
{
    { -40, 20 },   /*  0 */
    { -30, 25 },   /*  1 */
    { -20, 30 },
    { -20, 35 },   /*  3 */
    { -10, 40 },
    { -10, 45 },   /*  5 */
    { -10, 50 },
    {  0, 55 },
    {  0, 60 },
    {  0, 65 },
    {  0, 70 },   /* 10 */
    {  0, 75 },
    {  0, 80 },
    {  0, 85 },
    {  0, 88 },
    {  10, 90 },   /* 15 */
    {  20, 95 },
    {  20, 97 },
    {  30, 99 },   /* 18 */
    {  30, 99 },
    {  40, 99 },   /* 20 */
    {  40, 99 },
    {  50, 99 },
    {  60, 99 },
    {  70, 99 },
    {  80, 99 }    /* 25 */
};



/*
 * Liquid properties.
 * Used in world.obj.
 */
const	struct	liq_type	liq_table	[LIQ_MAX]	=
{                                   /* D  F  T */
    { "water",          "clear",    {  0, 1, 10 }   },  /*  0 */
    { "beer",           "amber",    {  1, 1,  5 }   },
    { "wine",           "rose",     {  1, 0,  5 }   },
    { "ale",            "brown",    {  2, 1,  5 }   },
    { "brandy",         "dark",     {  5, 0,  5 }   },

    { "whisky",         "golden",   {  6, 0,  4 }   },  /*  5 */
    { "whapple juice",  "golden",   { 10, 0,  0 }   },
    { "vodka",          "clear",    {  3, 0,  3 }   },
    { "salt water",     "clear",    {  0, 1, -2 }   },

    { "milk",           "white",    {  0, 3,  6 }   },  
    { "coffee",         "black",    { -1, 0,  6 }   },  /* 10 */
    { "tea",            "tan",      {  0, 0,  6 }   },

    { "blood",			"red",		{  0, 2, -1 }	},
    { "unblood",        "green",    {  0,-5, -2 }   },

    { "lemonade",       "pink",     {  0, 0,  8 }   },
    { "cola",           "cherry",   {  0, 0,  5 }   }   /* 15 */
};


/*
 * The skill and spell table.
 * Slot numbers must never be changed as they appear in #OBJECTS sections.
 * In the damage messages:  %s = singular message      $t = plural
 */
#define SLOT(n)	n
#define WAIT(n) n
#define MANA(n) n
#define PRAC(n) n
#define TIME(n) n

const   struct  skill_type  skill_table [MAX_SKILL] =
{

/*
 * Magic spells.
 */

    {
    "reserved",     { 99 },
    0, 0,        TAR_IGNORE,     POS_STANDING,
    NULL,           SLOT( 0),    0,  0,  0,  0,
    "",         "",      "",
    NULL,
    0,  TIME(25)
    },

    {
    "water wall",       { 2 },
    NULL, spell_acid_blast,   TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(70),   MANA(20), MANA_WATER, PRAC(20),
    WAIT(12),
    "A swipe of your hand sends a wall of water to %s $N!",
    "$n swings $s arm and a wall of water $t you!",
    "$n moves $s hand and a wall of water $t $N.",
    "advanced watercasting",
    25,  TIME(25)
    },

    {
    "armor",        {  2 },
    NULL, spell_armor,     TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT( 1),    MANA(5), MANA_EARTH, PRAC(20),
    WAIT(12),    "",    "You feel less protected.",    "",
    "basic earthcasting",
    15,  TIME(25)
    },

    {
    "bless",        { LEVEL_IMMORTAL },
    NULL, spell_bless,        TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT( 3),    MANA(5), MANA_AIR,   PRAC(20),
    WAIT(12),    "",         "You feel less righteous.",   "",
    NULL,
    0,  TIME(25)
    },

    {
    "blindness",        {  2 },
    NULL, spell_blindness,    TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    &gsn_blindness,     SLOT( 4),    MANA(5), MANA_FIRE, PRAC(20),
    WAIT(12),    "",         "You can see again.",    "",
    "basic firecasting",
    30,  TIME(25)
    },
/* 5 */
    {
    "burning hands",    {  2 },
    NULL, spell_burning_hands,    TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT( 5),   MANA(15), MANA_FIRE, PRAC(20),
    WAIT(12),
    "Your hands turn to flame as you %s $N!",
    "$n's fiery hands %s you!",
    "$n's hands are ablaze as they %s $N.",
    "advanced firecasting",
    20,  TIME(25)
    },

    {
    "call lightning",   { 2 },
    NULL, spell_call_lightning,   TAR_IGNORE,     POS_FIGHTING,
    NULL,           SLOT( 6),   MANA(15), MANA_AIR,  PRAC(20),
    WAIT(12),
    "A bolt of heat lightning strikes $N from the heavens!",
    "You are shocked by a powerful bolt of lightning!",
    "A bolt of lightning strikes $N.",
    "expert aircasting",
    20,  TIME(25)
    },

    {
    "hands of wind",   { 2 },
    NULL, spell_cause_critical,   TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(63),   MANA(20), MANA_AIR,  PRAC(20),
    WAIT(12),
    "Your hands move like a hurricane as you %s $N!",
    "$n's hands move over you like a hurricane!",
    "$n's hands hit $N in fast, repetative motions.",
    "advanced aircasting",
    80,  TIME(25)
    },

    {
    "fists of fire",      { 2 },
    NULL, spell_cause_light,  TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(62),   MANA(15), MANA_FIRE, PRAC(20),
    WAIT(12),    
    "Your fiery hits %s $N!",        
    "$n's fiery hits %s you!",
    "$n's fiery hits %s $N.",
    "advanced firecasting",
    20,  TIME(25)
    },

    {
    "ice shards",    { 2 },
    NULL, spell_cause_serious,    TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(64),   MANA(17),  MANA_WATER, PRAC(20),
    WAIT(12),
    "Hundreds of razor sharp shards of ice pummel $N!",
    "You are pummeled by razorlike shards of ice from $n!",
    "$n's palms emit clouds of ice shards at $N.",
    "advanced watercasting",
    60,  TIME(25)
    },

    {
    "charm person",     { 2 },
    NULL, spell_charm_person, TAR_CHAR_OFFENSIVE, POS_STANDING,
    &gsn_charm_person,  SLOT( 7),    MANA(5), MANA_ANY, PRAC(20),
    WAIT(12),    "",  "You begin to shake the bonds of your master.",  "",
    "general spellcasting",
    75,  TIME(25)
    },

    {
    "channeling",       { 2 },
    NULL, spell_channeling,  TAR_OBJ_INV,  POS_STANDING,
    NULL,            SLOT(301), MANA(25), MANA_ANY, PRAC(20),
    WAIT(12),        "",    "!Channeling!",   "",
    "general spellcasting",
    40,  TIME(25)
    },

    {
    "chill touch",      {  2 },
    NULL, spell_chill_touch,  TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT( 8),   MANA(15), MANA_WATER, PRAC(20),
    WAIT(12),    
    "You touch $N with an arctic chill.",   
    "You shiver.",
    "$n freezes $N with a touch of cold.",
    "basic watercasting",
    60,  TIME(25)
    },
/* 13 */
    {
    "fire fingers",     { 2 },
    NULL, spell_colour_spray, TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(10),   MANA(15),  MANA_FIRE, PRAC(20),
    WAIT(12),     
    "Jets of flame spout from your fingertips at $N.",     
    "$n $t you with jets of flame from $s fingers.",
    "$n $t $N with jets of flame that emit from $n's fingers.",
    "basic firecasting",
    60,  TIME(25)
    },

    {
    "light",  {  2 },
    NULL, spell_continual_light,  TAR_IGNORE,     POS_STANDING,
    NULL,           SLOT(57),    MANA(7), MANA_FIRE,  PRAC(20),
    WAIT(12),    "",      "!Continual Light!",    "",
    "basic firecasting",
    45,  TIME(25)
    },

    {
    "control weather",  { 2 },
    NULL, spell_control_weather,  TAR_IGNORE,     POS_STANDING,
    NULL,           SLOT(11),   MANA(TIME(25)), MANA_AIR, PRAC(20),
    WAIT(12),    "",    "!Control Weather!",   "",
    "expert aircasting",
    30,  TIME(25)
    },

    {
    "create food",      { 2 },
    NULL, spell_create_food,  TAR_IGNORE,     POS_STANDING,
    NULL,           SLOT(12),    MANA(5), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "!Create Food!",      "",
    "advanced earthcasting",
    10,  TIME(25)
    },

    {
    "create spring",    { 2 },
    NULL, spell_create_spring,    TAR_IGNORE,     POS_STANDING,
    NULL,           SLOT(80),   MANA(20), MANA_WATER, PRAC(20),
    WAIT(12),    "",         "!Create Spring!",      "",
    "advanced watercasting",
    20,  TIME(25)
    },

    {
    "create water",     { 2 },
    NULL, spell_create_water, TAR_OBJ_INV,        POS_STANDING,
    NULL,           SLOT(13),    MANA(5), MANA_WATER, PRAC(20),
    WAIT(12),    "",         "!Create Water!",     "",
    "basic watercasting",
    60,  TIME(25)
    },

    {
    "cure blindness",   { 2 },
    NULL, spell_cure_blindness,   TAR_CHAR_DEFENSIVE, POS_FIGHTING,
    NULL,           SLOT(14),    MANA(5), MANA_WATER, PRAC(20),
    WAIT(12),    "",           "!Cure Blindness!",    "",
    "advanced watercasting",
    10,  TIME(25)
    },

    {
    "heal critical",    { 2 },
    NULL, spell_cure_critical,    TAR_CHAR_DEFENSIVE, POS_FIGHTING,
    NULL,           SLOT(15),   MANA(20), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "!Cure Critical!",      "",
    "advanced earthcasting",
    50,  TIME(25)
    },
/* 21 */
    {
    "heal light",       { 2 },
    NULL, spell_cure_light,   TAR_CHAR_DEFENSIVE, POS_FIGHTING,
    NULL,           SLOT(16),   MANA(10), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "!Cure Light!",       "",
    "advanced earthcasting",
    10,  TIME(25)
    },

    {
    "cure poison",      { 2 },
    NULL, spell_cure_poison,  TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT(43),    MANA(5), MANA_WATER, PRAC(20),
    WAIT(12),    "",         "!Cure Poison!",    "",
    "advanced watercasting",
    10,  TIME(25)
    },

    {
    "heal serious",     { 2 },
    NULL, spell_cure_serious, TAR_CHAR_DEFENSIVE, POS_FIGHTING,
    NULL,           SLOT(61),   MANA(15), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "!Cure Serious!",    "",
    "advanced earthcasting",
    40,  TIME(25)
    },

    {
    "curse",        { 2 },
    NULL, spell_curse,        TAR_CHAR_OFFENSIVE, POS_STANDING,
    &gsn_curse,     SLOT(17),   MANA(20), MANA_AIR,   PRAC(20),
    WAIT(12),    
    "You curse $N.",        
    "You feel ripples in your soul.",
    "$n puts a curse on $N.",
    "advanced aircasting",
    20,  TIME(25)
    },

    {
    "detect evil",      { 2 },
    NULL, spell_detect_evil,  TAR_CHAR_SELF,      POS_STANDING,
    NULL,           SLOT(18),    MANA(5), MANA_FIRE,  PRAC(20),
    WAIT(12),    "",   "The red in your vision disappears.",    "",
    "basic firecasting",
    10,  TIME(25)
    },
    
    {
    "detect hidden",    { 2 },
    NULL, spell_detect_hidden,    TAR_CHAR_SELF,      POS_STANDING,
    NULL,           SLOT(44),    MANA(5), MANA_FIRE,  PRAC(20),
    WAIT(12),    "",    "You feel less aware of your suroundings.", "",
    "basic firecasting",
    80,  TIME(25)
    },

    {
    "detect invisible",     {  2 },
    NULL, spell_detect_invis, TAR_CHAR_SELF,      POS_STANDING,
    NULL,           SLOT(19),    MANA(5), MANA_FIRE,  PRAC(20),
    WAIT(12),    "",         "Some things fade from existance.",    "",
    "advanced firecasting",
    40,  TIME(25)
    },

    {
    "detect magic",     {  2 },
    NULL, spell_detect_magic, TAR_CHAR_SELF,      POS_STANDING,
    NULL,           SLOT(20),    MANA(5), MANA_FIRE,  PRAC(20),
    WAIT(12),    "",         "You lose the sense of auras.",     "",
    "basic firecasting",
    45,  TIME(25)
    },

    {
    "detect poison",    { 2 },
    NULL, spell_detect_poison,    TAR_OBJ_INV,        POS_STANDING,
    NULL,           SLOT(21),    MANA(5), MANA_FIRE,  PRAC(20),
    WAIT(12),    "",         "!Detect Poison!",    "",
    "basic firecasting",
    10,  TIME(25)
    },

    {
    "dispel evil",      { 2 },
    NULL, spell_dispel_evil,  TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(22),   MANA(15), MANA_WATER, PRAC(20),
    WAIT(12),    
    "You purify $N.",      
    "$n purifies you!",
    "$n purifies $N.",
    "advanced watercasting",
    45,  TIME(25)
    },
/* 31 */
    {
    "dispel magic",     { 2 },
    NULL, spell_dispel_magic, TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(59),   MANA(15), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "!Dispel Magic!",      "",
    "advanced earthcasting",
    50,  TIME(25)
    },
    
    {
    "earthquake",       { 2 },
    NULL, spell_earthquake,   TAR_IGNORE,     POS_FIGHTING,
    NULL,           SLOT(23),   MANA(15), MANA_EARTH, PRAC(20),
    WAIT(12),    
    "You raise your arms into the air and feel the earth shift under your feet.",
    "$n shifts the earth under your feet!",
    "$n shifts the earth under $N's feet.",
    "expert earthcasting",
    60,  TIME(25)
    },

    {
    "enchant weapon",   { 2 },
    NULL, spell_enchant_weapon,   TAR_OBJ_INV,        POS_STANDING,
    NULL,           SLOT(24),   MANA(100),    MANA_FIRE, PRAC(20),
    WAIT(24),    "",         "!Enchant Weapon!",    "",
    "expert firecasting",
    80,  TIME(25)
    },

    {
    "energy drain",     { 2 },
    NULL, spell_energy_drain, TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(25),   MANA(35),  MANA_FIRE, PRAC(20),
    WAIT(12),    
    "You feel a filling sensation.",     
    "You feel your life force draining away!",
    "$n drains some of $N's life.",
    "advanced firecasting",
    20,  TIME(25)
    },

    {
    "outline",      {  2 },
    NULL, spell_faerie_fire,  TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(72),    MANA(5), MANA_FIRE,  PRAC(20),
    WAIT(12),    "outline",      "A pink aura around you shimmers.",  "",
    "basic firecasting",
    80,  TIME(25)
    },

    {
    "rising mist",       { 2 },
    NULL, spell_faerie_fog,   TAR_IGNORE,     POS_STANDING,
    NULL,           SLOT(73),   MANA(12), MANA_AIR, PRAC(20),
    WAIT(12),    "rising mist",       "!Rising Mist!",    "",
    "basic aircasting",
    80,  TIME(25)
    },
/* 37 */
    {
    "fireball",     { 2 },
    NULL, spell_fireball,     TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(26),   MANA(15), MANA_FIRE, PRAC(20),
    WAIT(12),
    "You hold your hand out and a ball of fire shoots towards $N!",
    "$n throws a fireball that $t you!",
    "$n throws a fireball at $N.",
    "advanced firecasting",
    40,  TIME(25)
    },

    {
    "flamestrike",      { 2 },
    NULL, spell_flamestrike,  TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(65),   MANA(20), MANA_FIRE, PRAC(20),
    WAIT(12),
    "A circle of flames surrounds $N!",
    "A circle of flames surround you!",
    "A circle of flames surrounds $N.",
    "expert firecasting",
    30,  TIME(25)
    },

    {
    "fly",          {  2 },
    NULL, spell_fly,      TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT(56),   MANA(10), MANA_AIR,  PRAC(20),
    WAIT(18),    "",         "You slowly float to the ground.", "",
    "advanced aircasting",
    30,  TIME(25)
    }
    ,
    {
    "water breathing",          {  2 },
    NULL, spell_water_breathing,   TAR_CHAR_DEFENSIVE,  POS_STANDING,
    NULL,           SLOT(102),   MANA(10), MANA_WATER,  PRAC(20),
    WAIT(18),    "",         "The slits on your neck close up.", "",
    "expert watercasting",
    50,  TIME(25)
    },

    {
    "conjure undead",         { 2 },
    NULL, spell_gate,     TAR_CHAR_DEFENSIVE, POS_FIGHTING,
    NULL,           SLOT(83),   MANA(50), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "!Gate!",      "",
    "expert earthcasting",
    50,  TIME(25)
    },

    {
    "earthen strength",   {  2 },
    NULL, spell_giant_strength,   TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT(39),   MANA(20), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "You feel the strength pour out of you.",   "",
    "expert earthcasting",
    25,  TIME(25)
    },

    {
    "magic boulders",         { 2 },
    NULL, spell_harm,     TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(27),   MANA(35), MANA_EARTH, PRAC(20),
    WAIT(12),
    "You watch as large boulders crash down onto $N's head!",
    "Large boulders crash down on you from above!",
    "Large boulders appear above $N's head.",
    "advanced earthcasting",
    50,  TIME(25)
    },
/* 44 */
    {
    "healing",         { 2 },
    NULL, spell_heal,     TAR_CHAR_DEFENSIVE, POS_FIGHTING,
    NULL,           SLOT(28),   MANA(50), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "!Healing!",    "",
    "expert earthcasting",
    10,  TIME(25)
    },

    {
    "identify",     { 2 },
    NULL, spell_identify,     TAR_OBJ_INV,        POS_STANDING,
    NULL,           SLOT(53),   MANA(12), MANA_ANY,   PRAC(20),
    WAIT(24),    "",         "!Identify!",       "",
    "general spellcasting",
    70,  TIME(25)
    },

    {
    "infravision",      {  2 },
    NULL, spell_infravision,  TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT(77),    MANA(5), MANA_FIRE,  PRAC(20),
    WAIT(18),    "",         "You eyes lose their red luster.",   "",
    "basic firecasting",
    80,  TIME(25)
    },

    {
    "invisibility",        {  2 },
    NULL, spell_invis,        TAR_CHAR_DEFENSIVE, POS_STANDING,
    &gsn_invis,     SLOT(29),    MANA(5), MANA_AIR,   PRAC(20),
    WAIT(12),    "",         "You fade into existance.",    "",
    "advanced aircasting",
    70,  TIME(25)
    },

    {
    "know alignment",   {  2  },
    NULL, spell_know_alignment,   TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(58),    MANA(9), MANA_FIRE,  PRAC(20),
    WAIT(12),    "",         "!Know Alignment!",  "",
    "basic firecasting",
    20,  TIME(25)
    },

    {
    "lightning bolt",   {  2  },
    NULL, spell_lightning_bolt,   TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(30),   MANA(15), MANA_FIRE,  PRAC(20),
    WAIT(12),
    "Lightning bolts emit from your fingers at $N!",
    "You are struck by bolts of lightning from $n's fingertips!",
    "$n shoots bolts of lightning at $N!",
    "advanced firecasting",
    40,  TIME(25)
    },

    {
    "locate object",    {  2 },
    NULL, spell_locate_object,    TAR_IGNORE,     POS_STANDING,
    NULL,           SLOT(31),   MANA(20), MANA_ANY,   PRAC(20),
    WAIT(18),    "",         "!Locate Object!",         "",
    "general spellcasting",
    80,  TIME(25)
    },

    {
    "spear of fire",    {  2 },
    NULL, spell_magic_missile,    TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(32),   MANA(15), MANA_FIRE,  PRAC(20),
    WAIT(12),
    "A fiery spear appears from your hand and $t $N!",
    "$N throws a spear of fire that $t you!",
    "$n throws of flaming spear at $N.",
    "basic firecasting",
    75,  TIME(25)
    },

    {
    "phantasmal claw",    {  2 },
    NULL, spell_general_purpose,    TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(101),   MANA(15), MANA_AIR,  PRAC(20),
    WAIT(12),
    "A wispy claw of vapor $t $N!",
    "A wispy claw of vapor $t you!",
    "A wispy claw of vapor $t $N!",
    "expert aircasting",
    30,  TIME(25)
    },

    {
    "mass invisibility",       { 2 },
    NULL, spell_mass_invis,   TAR_IGNORE,     POS_STANDING,
    &gsn_mass_invis,    SLOT(69),   MANA(20), MANA_AIR, PRAC(20),
    WAIT(24),    "",         "You slowly fade into existance.",     "",
    "expert aircasting",
    50,  TIME(25)
    },

    {
    "pass door",        { 2 },
    NULL, spell_pass_door,    TAR_CHAR_SELF,      POS_STANDING,
    NULL,           SLOT(74),   MANA(20),  MANA_AIR, PRAC(20),
    WAIT(12),    "",         "You feel solid again.",     "",
    "advanced aircasting",
    75,  TIME(25)
    },

    {
    "poison",       { 2 },
    NULL, spell_poison,       TAR_CHAR_OFFENSIVE, POS_STANDING,
    &gsn_poison,        SLOT(33),   MANA(10), MANA_WATER, PRAC(20),
    WAIT(12),    "poison",       "You feel strange.",      "",
    "basic watercasting",
    50,  TIME(25)
    },

    {
    "protection",       { 2 },
    NULL, spell_protection,   TAR_CHAR_SELF,      POS_STANDING,
    NULL,           SLOT(34),    MANA(5), MANA_FIRE, PRAC(20),
    WAIT(12),    "",         "You feel less protected.",      "",
    "advanced firecasting",
    25,  TIME(25)
    },

    {
    "refresh",      {  2 },
    NULL, spell_refresh,      TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT(81),   MANA(12), MANA_EARTH, PRAC(20),
    WAIT(18),    "",      "!Refresh!",     "",
    "basic earthcasting",
    60,  TIME(25)
    },

    {
    "remove curse",     { 2 },
    NULL, spell_remove_curse, TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT(35),    MANA(5), MANA_WATER, PRAC(20),
    WAIT(12),    "",         "!Remove Curse!",     "",
    "basic watercasting",
    75,  TIME(25)
    },

    {
    "sanctuary",        { 2 },
    NULL, spell_sanctuary,    TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT(36),   WAIT(75), MANA_WATER, PRAC(20),
    WAIT(12),    "",         "The white aura around your body fades.", "",
    "expert watercasting",
    30,  TIME(25)
    },

    {
    "shield",       { 2 },
    NULL, spell_shield,       TAR_CHAR_DEFENSIVE, POS_STANDING,
    NULL,           SLOT(67),   WAIT(12), MANA_ANY, PRAC(20),
    WAIT(18),    "", "The thin transparent skin shimmers and fades away.", "",
    "general spellcasting",
    50,  TIME(25)
    },

    {
    "shocking grasp",   {  2 },
    NULL, spell_shocking_grasp,   TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(37),   WAIT(15), MANA_FIRE,  PRAC(20),
    WAIT(12),
    "You grab onto $N and watch as $e squirms under your shocking grasp!",
    "$n grabs onto you and you feel as though you have been shocked!",
    "$n grabs onto $N and releases electricity into $M.",
    "advanced firecasting",
    30,  TIME(25)
    },

    {
    "sleep",        { 2 },
    NULL, spell_sleep,        TAR_CHAR_OFFENSIVE, POS_STANDING,
    &gsn_sleep,     SLOT(38),   WAIT(15), MANA_EARTH, PRAC(20),
    WAIT(12),    "",         "You feel less tired.",    "",
    "basic earthcasting",
    45,  TIME(25)
    },

    {
    "stone skin",       { 2 },
    NULL, spell_stone_skin,   TAR_CHAR_SELF,      POS_STANDING,
    NULL,           SLOT(66),   WAIT(12), MANA_EARTH, PRAC(20),
    WAIT(18),    "",         "Your skin feels soft again.",     "",
    "expert earthcasting",
    10,  TIME(25)
    },

    {
    "summon",       { 2 },
    NULL, spell_summon,       TAR_IGNORE,     POS_STANDING,
    NULL,           SLOT(40),   MANA(50), MANA_AIR,   PRAC(20),
    WAIT(12),    "",         "!Summon!",      "",
    "expert aircasting",
    20,  TIME(25)
    },

    {
    "teleport",     {  2 },
    NULL, spell_teleport,     TAR_CHAR_SELF,      POS_FIGHTING,
    NULL,           SLOT( 2),   MANA(35), MANA_AIR,   PRAC(20),
    WAIT(12),    "",         "!Teleport!",      "",
    "expert aircasting",
    10,  TIME(25)
    },

    {
    "weaken",       {  2 },
    NULL, spell_weaken,       TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(68),   MANA(20), MANA_WATER, PRAC(20),
    WAIT(12),
    "Your spell weakens $M.",
    "You feel strange.",
    "$n weakens $N.",
    "basic watercasting",
    40,  TIME(25)
    },

    {
    "word of recall",   { 2 },
    NULL, spell_word_of_recall,   TAR_CHAR_SELF,      POS_RESTING,
    NULL,           SLOT(42),    MANA(5), MANA_AIR,   PRAC(20),
    WAIT(12),    "",         "!Word of Recall!",          "",
    "expert aircasting",
    80,  TIME(25)
    },

/*
 * Dragon breath
 */
    {
    "acid breath",      { LEVEL_IMMORTAL },
    NULL, spell_acid_breath,  TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(200),   MANA(30),  MANA_WATER, PRAC(20),
    WAIT(8),
    "A blast of acid emits from you and $t $N!",
    "$n $t you with a breath of acid!",
    "$n blasts $N with acid from $s mouth!",
    NULL,
    0,  TIME(25)
    },

    {                       
    "fire breath",      { LEVEL_IMMORTAL },
    NULL, spell_fire_breath,  TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(201),   MANA(30),  MANA_FIRE,  PRAC(20),
    WAIT(8),
    "A blast of flame erupts from your mouth at $N!",
    "You are scorched by $n's blast of flame!",
    "$n blasts $N with flame from $s mouth!",
    NULL,
    0,  TIME(25)
    },

    {
    "frost breath",     { LEVEL_IMMORTAL },
    NULL, spell_frost_breath, TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(202),   MANA(30),  MANA_WATER, PRAC(20),
    WAIT(8),
    "A blast of frost erupts from your mouth at $N!",
    "You are scorched by $n's blast of frost!",
    "$n blasts $N with frost from $s mouth!",
    NULL,
    0,  TIME(25)
    },

    {
    "gas breath",       { LEVEL_IMMORTAL },
    NULL, spell_gas_breath,   TAR_IGNORE,     POS_FIGHTING,
    NULL,           SLOT(203),   MANA(30),  MANA_AIR, PRAC(20),
    WAIT(8),
    "A blast of deadly gas erupts from your mouth at $N!",
    "You are scorched by $n's blast of deadly gas!",
    "$n blasts $N with deadly gas from $s mouth!",
    NULL,
    0,  TIME(25)
    },

    {
    "lightning breath", { LEVEL_IMMORTAL },
    NULL, spell_lightning_breath, TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    NULL,           SLOT(204),   MANA(30),  MANA_ANY,   PRAC(20),
    WAIT(8),
    "A blast of lightning erupts from your mouth at $N!",
    "You are scorched by $N's blast of lightning!",
    "$n blasts $N with lightning from $s mouth!",
    NULL,
    0,  TIME(25)
    },

    {
    "resurrection",     { LEVEL_IMMORTAL },
    NULL, spell_resurrection,     TAR_IGNORE,          POS_DEAD,
    NULL,            SLOT(501),   MANA(125), MANA_ANY, PRAC(20),
    WAIT(40),
    "", "!Resurrection!", "",
    NULL,
    0, TIME(25)
    }, 

/*
 * Skills.
 */
    {
    "backstab",     { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_STANDING,
    &gsn_backstab,      SLOT( 0),    0, 0, PRAC(20), 24,
    "You slip your weapon into $N's back and $t $M!",
    "$n slips $s weapon into your back and $t you!",
    "$n slips $s weapon into $N's back and $t $M!",
    "offensive hand-to-hand",
    70,  TIME(25)
    },

    {                                              
    "disarm",       { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_FIGHTING,
    &gsn_disarm,        SLOT( 0),    0, 0, PRAC(20), 24,
    "",         "!Disarm!",      "",
    "defensive hand-to-hand",
    70,  TIME(25)
    },

    {
    "dodge",        { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_FIGHTING,
    &gsn_dodge,     SLOT( 0),    0,  0, PRAC(10), 0,
    "",         "!Dodge!",  "",
    "defensive hand-to-hand",
    15,  TIME(25)
    },

    {
    "enhanced damage",  { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_FIGHTING,
    &gsn_enhanced_damage,   SLOT( 0),    0, 0,PRAC(10),  0,
    "",         "!Enhanced Damage!",   "",
    "offensive hand-to-hand",
    80,  TIME(25)
    },

    {
    "hide",         { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_RESTING,
    &gsn_hide,      SLOT( 0),    0, 0, PRAC(10), 12,
    "",         "!Hide!",       "",
    "general stealth",
    15,  TIME(25)
    },

    {
    "kick",         { 2 },
    NULL, spell_null,     TAR_CHAR_OFFENSIVE, POS_FIGHTING,
    &gsn_kick,      SLOT( 0),    0, 0, PRAC(15), 8,
    "Your kick at $N $t $M!",
    "$N's kick $t you!",    
    "$n kicks $N.",
    "offensive hand-to-hand",
    15,  TIME(25)
    },

    {
    "parry",        { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_FIGHTING,
    &gsn_parry,     SLOT( 0),    0, 0, PRAC(10), 0,
    "",         "!Parry!",      "",
    "defensive hand-to-hand",
    30,  TIME(25)
    },

    {
    "peek",         { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_STANDING,
    &gsn_peek,      SLOT( 0),    0, 0, PRAC(10), 0,
    "",         "!Peek!",       "",
    "general stealth",
    20,  TIME(25)
    },

    {
    "pick lock",        { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_STANDING,
    &gsn_pick_lock,     SLOT( 0),    0, 0, PRAC(10), 12,
    "",         "!Pick!",     "",
    "ledgerdemain",
    80,  TIME(25)
    },

    {
    "rescue",       {  2 },
    NULL, spell_null,     TAR_IGNORE,     POS_FIGHTING,
    &gsn_rescue,        SLOT( 0),    0, 0, PRAC(10), 12,
    "",         "!Rescue!",      "",
    "defensive hand-to-hand",  
    50, TIME(25)
    },

    {
    "second attack",    { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_FIGHTING,
    &gsn_second_attack, SLOT( 0),    0, 0, PRAC(10), 0,
    "",         "!Second Attack!", "",
    "offensive hand-to-hand",
    60, TIME(25)
    },

    {
    "sneak",        { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_STANDING,
    &gsn_sneak,     SLOT( 0),    0, 0, PRAC(15), 12,
    "",         "!Sneak!",    "",
    "general stealth",
    40,  TIME(25)
    },

    {
    "steal",        {  2 },
    NULL, spell_null,     TAR_IGNORE,     POS_STANDING,
    &gsn_steal,     SLOT( 0),    0, 0, PRAC( 5), 24,
    "",         "!Steal!",    "",
    "general stealth",
    30,  TIME(25)
    },

    {
    "third attack",     { 2 },
    NULL, spell_null,     TAR_IGNORE,     POS_FIGHTING,
    &gsn_third_attack,  SLOT( 0),    0, 0,PRAC(15),  0,
    "",         "!Third Attack!",     "",
    "offensive hand-to-hand",
    80,  TIME(25)
    },

    {
    "dual wield",       { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_FIGHTING,
    &gsn_dual_wield,   SLOT( 0),     0, 0,PRAC( 5),  0,
    "",         "!Dual Wield!",    "",
    "offensive hand-to-hand",
    80,  TIME(25)
    },

    {
    "tracking",         { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    &gsn_track,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Tracking!",     "",
    "wilderness survival",
    80,  TIME(25)
    },

    {
    "swimming",         { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    &gsn_swimming,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Swimming!",     "",
    "wilderness survival",
    20,  TIME(25)
    },

    {
    "climb",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    &gsn_climb,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Climb!",     "",
    "wilderness survival",
    40,  TIME(25)
    },


/*
 * Skill groupings.
 */

    {
    "ledgerdemain",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: Ledgerdemain!",     "",
    NULL,
    0,  TIME(25)
    },

    {
    "offensive hand-to-hand",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: Off HTH!",     "",
    NULL,
    0,  TIME(25)
    },

    {
    "defensive hand-to-hand",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: Def HTH!",     "",
    NULL,
    0,  TIME(25)
    },

    {
    "general stealth",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: General Stealth",     "",
    NULL,
    0,  TIME(25)
    },

    {
    "wilderness survival",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: Wilderness Survival!",     "",
    NULL,
    0,  TIME(25)
    },

/*
 * Basic spell casters.
 */

    {
    "basic firecasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC(15), 0,
    "",         "!Group: Element of Fire!",     "",
    NULL,
    0,  TIME(50)
    },

    {
    "basic watercasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC(15), 0,
    "",         "!Group: Element of Water!",     "",
    NULL,
    0,  TIME(50)
    },

    {
    "basic aircasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC(15), 0,
    "",         "!Group: Element of Air!",     "",
    NULL,
    0,  TIME(50)
    },

    {
    "basic earthcasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC(15), 0,
    "",         "!Group: Element of Earth!",     "",
    NULL,
    0,  TIME(50)
    },

/*
 * Advanced spell casting.
 */
    {
    "advanced firecasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC(10), 0,
    "",         "!Group: Element of Fire!",     "",
    "basic firecasting",
    80,  TIME(50)
    },

    {
    "advanced watercasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC(10), 0,
    "",         "!Group: Element of Water!",     "",
    "basic watercasting",
    80,  TIME(50)
    },

    {
    "advanced aircasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC(10), 0,
    "",         "!Group: Element of Air!",     "",
    "basic aircasting",
    80,  TIME(50)
    },

    {
    "advanced earthcasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC(10), 0,
    "",         "!Group: Element of Earth!",     "",
    "basic earthcasting",
    80,  TIME(50)
    },

/*
 * Expert spell casting.
 */
    {
    "expert firecasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: Element of Fire!",     "",
    "advanced firecasting",
    80,  TIME(50)
    },

    {
    "expert watercasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: Element of Water!",     "",
    "advanced watercasting",
    80,  TIME(50)
    },

    {
    "expert aircasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: Element of Air!",     "",
    "advanced aircasting",
    80,  TIME(50)
    },

    {
    "expert earthcasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: Element of Earth!",     "",
    "advanced earthcasting",
    80,  TIME(50)
    },

/*
 * Other spells.
 */
    {
    "general spellcasting",           { 2 },
    NULL, spell_null,     TAR_IGNORE,      POS_STANDING,
    NULL,   SLOT( 0),     0, 0, PRAC( 5), 0,
    "",         "!Group: General Spellcasting!",     "",
    NULL,
    0,  TIME(50)
    },
    

};


