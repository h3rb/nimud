/****************************************************************************
 *   ___  ___  ___  __    __                                                *
 *  |   ||   ||   ||  |\/|  | 2-x    NiMUD is a software currently under    *
 *   |  \ | |  | |  | |\/| |         development.  It is based primarily on *
 *   | |\\| |  | |  | |  | |         the discontinued package, Merc 2.2.    *
 *   | | \  |  | |  | |  | |         NiMUD is being written and developed   *
 *  |___||___||___||__|  |__|        By Locke and Surreality as a new,      *
 *   NAMELESS INCARNATE *MUD*        frequently updated package similar to  *
 *        S O F T W A R E            the original Merc 2.x.                 *
 *                                                                          *
 *  Just look for the Iron Maiden skull wherever NiMUD products are found.  *
 *                                                                          *
 *  Much time and thought has gone into this software and you are           *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                                                   *
 ****************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "merc.h"


/*
 * Return ascii name of an item type.
 */
char *item_type_name( int item_type )
{
    switch ( item_type )
    {
    case ITEM_LIGHT:         return "light";
    case ITEM_SCROLL:        return "scroll";
    case ITEM_WAND:          return "wand";
    case ITEM_STAFF:         return "staff";
    case ITEM_WEAPON:        return "weapon";
    case ITEM_RANGED_WEAPON: return "ranged";
    case ITEM_AMMO:          return "ammo";
    case ITEM_TREASURE:      return "treasure";
    case ITEM_ARMOR:         return "armor";
    case ITEM_POTION:        return "potion";
    case ITEM_BOOK:          return "book";
    case ITEM_FURNITURE:     return "furniture";
    case ITEM_TRASH:         return "trash";
    case ITEM_CONTAINER:     return "container";
    case ITEM_THROWN:        return "thrown";
    case ITEM_DRINK_CON:     return "drink container";
    case ITEM_KEY:           return "key";
    case ITEM_FOOD:          return "food";
    case ITEM_MONEY:         return "money";
    case ITEM_GEM:           return "gem";
    case ITEM_VEHICLE:       return "vehicle";
    case ITEM_CORPSE_NPC:    return "npc corpse";
    case ITEM_CORPSE_PC:     return "pc corpse";
    case ITEM_FOUNTAIN:      return "fountain";
    case ITEM_PILL:          return "pill";
    case ITEM_TOOL:          return "tool";
    case ITEM_LIST:          return "list";
    case ITEM_BOARD:         return "board";
    }

    bug( "Item_type_name: unknown type %d.", item_type );
    return "(unknown)";
}

int item_name_type( char *name )
{
    if ( !str_cmp( name, "light"     ) ) return ITEM_LIGHT;
    if ( !str_cmp( name, "scroll"    ) ) return ITEM_SCROLL;
    if ( !str_cmp( name, "wand"      ) ) return ITEM_WAND;
    if ( !str_cmp( name, "staff"     ) ) return ITEM_STAFF;
    if ( !str_cmp( name, "weapon"    ) ) return ITEM_WEAPON;
    if ( !str_cmp( name, "ranged"    ) ) return ITEM_RANGED_WEAPON;
    if ( !str_cmp( name, "ammo"      ) ) return ITEM_AMMO;
    if ( !str_cmp( name, "treasure"  ) ) return ITEM_TREASURE;
    if ( !str_cmp( name, "armor"     ) ) return ITEM_ARMOR;
    if ( !str_cmp( name, "potion"    ) ) return ITEM_POTION;
    if ( !str_cmp( name, "book"      ) ) return ITEM_BOOK;
    if ( !str_cmp( name, "furniture" ) ) return ITEM_FURNITURE;
    if ( !str_cmp( name, "trash"     ) ) return ITEM_TRASH;
    if ( !str_cmp( name, "container" ) ) return ITEM_CONTAINER;
    if ( !str_cmp( name, "thrown"    ) ) return ITEM_THROWN;
    if ( !str_cmp( name, "drink"     ) ) return ITEM_DRINK_CON;
    if ( !str_cmp( name, "key"       ) ) return ITEM_KEY;
    if ( !str_cmp( name, "food"      ) ) return ITEM_FOOD;
    if ( !str_cmp( name, "money"     ) ) return ITEM_MONEY;
    if ( !str_cmp( name, "gem"       ) ) return ITEM_GEM;
    if ( !str_cmp( name, "vehicle"   ) ) return ITEM_VEHICLE;
    if ( !str_cmp( name, "corpse"    ) ) return ITEM_CORPSE_NPC;
    if ( !str_cmp( name, "fountain"  ) ) return ITEM_FOUNTAIN;
    if ( !str_cmp( name, "pill"      ) ) return ITEM_PILL;
    if ( !str_cmp( name, "tool"      ) ) return ITEM_TOOL;
    if ( !str_cmp( name, "list"      ) ) return ITEM_LIST;
    if ( !str_cmp( name, "board"     ) ) return ITEM_BOARD;
    return 0;
}


/*
 * Return ascii name of an affect location.
 */
char *affect_loc_name( int location )
{
    switch ( location )
    {
    case APPLY_NONE:            return "none";
    case APPLY_STR:             return "strength";
    case APPLY_DEX:             return "dexterity";
    case APPLY_INT:             return "intelligence";
    case APPLY_WIS:             return "wisdom";
    case APPLY_CON:             return "constitution";
    case APPLY_SEX:             return "sex";
    case APPLY_CLASS:           return "class";
    case APPLY_LEVEL:           return "level";
    case APPLY_AGE:             return "age";
    case APPLY_HIT:             return "hp";
    case APPLY_MOVE:            return "moves";
    case APPLY_GOLD:            return "gold";
    case APPLY_AC:              return "armor class";
    case APPLY_HITROLL:         return "hit roll";
    case APPLY_DAMROLL:         return "damage roll";
    case APPLY_SAVING_THROW:    return "saving throw";
    }

    bug( "Affect_location_name: unknown location %d.", location );
    return "(unknown)";

}

int affect_name_loc( char* name )
{
    if ( !str_cmp( name, "none"          ) ) return APPLY_NONE;
    if ( !str_cmp( name, "strength"      ) ) return APPLY_STR;
    if ( !str_cmp( name, "dexterity"     ) ) return APPLY_DEX;
    if ( !str_cmp( name, "intelligence"  ) ) return APPLY_INT;
    if ( !str_cmp( name, "wisdom"        ) ) return APPLY_WIS;
    if ( !str_cmp( name, "constitution"  ) ) return APPLY_CON;
    if ( !str_cmp( name, "sex"           ) ) return APPLY_SEX;
    if ( !str_cmp( name, "class"         ) ) return APPLY_CLASS;
    if ( !str_cmp( name, "level"         ) ) return APPLY_LEVEL;
    if ( !str_cmp( name, "age"           ) ) return APPLY_AGE;
    if ( !str_cmp( name, "hp"            ) ) return APPLY_HIT;
    if ( !str_cmp( name, "move"          ) ) return APPLY_MOVE;
    if ( !str_cmp( name, "gold"          ) ) return APPLY_GOLD;
    if ( !str_cmp( name, "ac"            ) ) return APPLY_AC;
    if ( !str_cmp( name, "hit"           ) ) return APPLY_HITROLL;
    if ( !str_cmp( name, "dam"           ) ) return APPLY_DAMROLL;
    if ( !str_cmp( name, "saving_throw"  ) ) return APPLY_SAVING_THROW;
    return APPLY_NONE;
}



/*
 * Return ascii name of an affect bit vector.
 */
char *affect_bit_name( int vector )
{
    static char buf[512];

    buf[0] = '\0';
    strcat( buf, ( vector & AFF_BLIND         ) ? " blind"         : "" );
    strcat( buf, ( vector & AFF_INVISIBLE     ) ? " invisible"     : "" );
    strcat( buf, ( vector & AFF_DETECT_EVIL   ) ? " detect-evil"   : "" );
    strcat( buf, ( vector & AFF_DETECT_INVIS  ) ? " detect-invis"  : "" );
    strcat( buf, ( vector & AFF_DETECT_MAGIC  ) ? " detect-magic"  : "" );
    strcat( buf, ( vector & AFF_DETECT_HIDDEN ) ? " detect-hidden" : "" );
    strcat( buf, ( vector & AFF_HOLD          ) ? " hold"          : "" );
    strcat( buf, ( vector & AFF_SANCTUARY     ) ? " sanctuary"     : "" );
    strcat( buf, ( vector & AFF_FAERIE_FIRE   ) ? " faerie-fire"   : "" );
    strcat( buf, ( vector & AFF_INFRARED      ) ? " infrared"      : "" );
    strcat( buf, ( vector & AFF_CURSE         ) ? " curse"         : "" );
    strcat( buf, ( vector & AFF_FLAMING       ) ? " flaming"       : "" );
    strcat( buf, ( vector & AFF_POISON        ) ? " poison"        : "" );
    strcat( buf, ( vector & AFF_PROTECT       ) ? " protect"       : "" );
    strcat( buf, ( vector & AFF_PARALYSIS     ) ? " paralysis"     : "" );
    strcat( buf, ( vector & AFF_SLEEP         ) ? " sleep"         : "" );
    strcat( buf, ( vector & AFF_SNEAK         ) ? " sneak"         : "" );
    strcat( buf, ( vector & AFF_HIDE          ) ? " hide"          : "" );
    strcat( buf, ( vector & AFF_CHARM         ) ? " charm"         : "" );
    strcat( buf, ( vector & AFF_FLYING        ) ? " flying"        : "" );
    strcat( buf, ( vector & AFF_PASS_DOOR     ) ? " pass-door"     : "" );
    strcat( buf, ( vector & AFF_FREEACTION    ) ? " free-action"   : "" );
    strcat( buf, ( vector & AFF_BREATHING     ) ? " water-breath"  : "" );
    return buf+1;
}



/*
 * Return bit vector
 */
int affect_name_bit( char* buf )
{
    if (!str_cmp( buf, "blind"         )) return AFF_BLIND;
    if (!str_cmp( buf, "invisible"     )) return AFF_INVISIBLE;
    if (!str_cmp( buf, "detect-evil"   )) return AFF_DETECT_EVIL;
    if (!str_cmp( buf, "detect-invis"  )) return AFF_DETECT_INVIS;
    if (!str_cmp( buf, "detect-magic"  )) return AFF_DETECT_MAGIC;
    if (!str_cmp( buf, "detect-hidden" )) return AFF_DETECT_HIDDEN;
    if (!str_cmp( buf, "hold"          )) return AFF_HOLD;
    if (!str_cmp( buf, "sanctuary"     )) return AFF_SANCTUARY;
    if (!str_cmp( buf, "faerie-fire"   )) return AFF_FAERIE_FIRE;
    if (!str_cmp( buf, "infrared"      )) return AFF_INFRARED;
    if (!str_cmp( buf, "curse"         )) return AFF_CURSE;
    if (!str_cmp( buf, "flaming"       )) return AFF_FLAMING;
    if (!str_cmp( buf, "poisoned"      )) return AFF_POISON;
    if (!str_cmp( buf, "protect"       )) return AFF_PROTECT;
    if (!str_cmp( buf, "paralysis"     )) return AFF_PARALYSIS;
    if (!str_cmp( buf, "sleep"         )) return AFF_SLEEP;
    if (!str_cmp( buf, "sneak"         )) return AFF_SNEAK;
    if (!str_cmp( buf, "hide"          )) return AFF_HIDE;
    if (!str_cmp( buf, "charm"         )) return AFF_CHARM;
    if (!str_cmp( buf, "flying"        )) return AFF_FLYING;
    if (!str_cmp( buf, "pass-door"     )) return AFF_PASS_DOOR;
    if (!str_cmp( buf, "free-action"   )) return AFF_FREEACTION;
    if (!str_cmp( buf, "water-breath"  )) return AFF_BREATHING;
    return 0;
}



/*
 * Return ascii name of extra flags vector.
 */
char *extra_bit_name( int extra_flags )
{
    static char buf[512];

    buf[0] = '\0';
    strcat( buf, ( extra_flags & ITEM_GLOW         ) ? " glow"         : "" );
    strcat( buf, ( extra_flags & ITEM_HUM          ) ? " hum"          : "" );
    strcat( buf, ( extra_flags & ITEM_DARK         ) ? " dark"         : "" );
    strcat( buf, ( extra_flags & ITEM_LOCK         ) ? " lock"         : "" );
    strcat( buf, ( extra_flags & ITEM_EVIL         ) ? " evil"         : "" );
    strcat( buf, ( extra_flags & ITEM_INVIS        ) ? " invis"        : "" );
    strcat( buf, ( extra_flags & ITEM_MAGIC        ) ? " magic"        : "" );
    strcat( buf, ( extra_flags & ITEM_NODROP       ) ? " nodrop"       : "" );
    strcat( buf, ( extra_flags & ITEM_BLESS        ) ? " bless"        : "" );
    strcat( buf, ( extra_flags & ITEM_ANTI_GOOD    ) ? " anti-good"    : "" );
    strcat( buf, ( extra_flags & ITEM_ANTI_EVIL    ) ? " anti-evil"    : "" );
    strcat( buf, ( extra_flags & ITEM_ANTI_NEUTRAL ) ? " anti-neutral" : "" );
    strcat( buf, ( extra_flags & ITEM_NOREMOVE     ) ? " noremove"     : "" );
    strcat( buf, ( extra_flags & ITEM_INVENTORY    ) ? " inventory"    : "" );
    strcat( buf, ( extra_flags & ITEM_NOSAVE       ) ? " nosave"       : "" );
    strcat( buf, ( extra_flags & ITEM_BURNING      ) ? " burning"      : "" );
    return buf+1;
}


int extra_name_bit( char* buf )
{
    if (!str_cmp( buf, "glow"        ) ) return ITEM_GLOW;
    if (!str_cmp( buf, "hum"         ) ) return ITEM_HUM;
    if (!str_cmp( buf, "dark"        ) ) return ITEM_DARK;
    if (!str_cmp( buf, "lock"        ) ) return ITEM_LOCK;
    if (!str_cmp( buf, "evil"        ) ) return ITEM_EVIL;
    if (!str_cmp( buf, "invis"       ) ) return ITEM_INVIS;
    if (!str_cmp( buf, "magic"       ) ) return ITEM_MAGIC;
    if (!str_cmp( buf, "nodrop"      ) ) return ITEM_NODROP;
    if (!str_cmp( buf, "bless"       ) ) return ITEM_BLESS;
    if (!str_cmp( buf, "anti-good"   ) ) return ITEM_ANTI_GOOD;
    if (!str_cmp( buf, "anti-evil"   ) ) return ITEM_ANTI_EVIL;
    if (!str_cmp( buf, "anti-neutral") ) return ITEM_ANTI_NEUTRAL;
    if (!str_cmp( buf, "noremove"    ) ) return ITEM_NOREMOVE;
    if (!str_cmp( buf, "inventory"   ) ) return ITEM_INVENTORY;
    if (!str_cmp( buf, "nosave"      ) ) return ITEM_NOSAVE;
    if (!str_cmp( buf, "burning"     ) ) return ITEM_BURNING;
    return 0;
}



/*
 * Return ascii name of room flags vector.
 */
char *room_bit_name( int room_flags )
{
    static char buf[512];

    buf[0] = '\0';
    strcat( buf, ( room_flags & ROOM_DARK      ) ? " dark"      : ""   );
    strcat( buf, ( room_flags & ROOM_NO_MOB    ) ? " no_mobs"   : ""   );
    strcat( buf, ( room_flags & ROOM_INDOORS   ) ? " indoors"   : ""   );
    strcat( buf, ( room_flags & ROOM_SAFE      ) ? " safe"      : ""   );
    strcat( buf, ( room_flags & ROOM_PET_SHOP  ) ? " pet_shop"  : ""   );
    strcat( buf, ( room_flags & ROOM_NO_RECALL ) ? " no_recall" : ""   );
    strcat( buf, ( room_flags & ROOM_BANK      ) ? " bank"      : ""   );
    strcat( buf, ( room_flags & BFS_MARK       ) ? " MARKED"    : ""   );
    strcat( buf, ( room_flags & ROOM_GENERATED ) ? " GENERATED" : ""   );
    return buf+1;
}

int room_name_bit( char* buf )
{
    if ( !str_cmp( buf, "dark"         ) ) return ROOM_DARK;
    if ( !str_cmp( buf, "no_mobs"      ) ) return ROOM_NO_MOB;
    if ( !str_cmp( buf, "indoors"      ) ) return ROOM_INDOORS;
    if ( !str_cmp( buf, "safe"         ) ) return ROOM_SAFE;
    if ( !str_cmp( buf, "pet_shop"     ) ) return ROOM_PET_SHOP;
    if ( !str_cmp( buf, "no_recall"    ) ) return ROOM_NO_RECALL;
    if ( !str_cmp( buf, "bank"         ) ) return ROOM_BANK;
    return 0;
}


char *act_bit_name( int act )
{
    static char buf[512];

    buf[0] = '\0';
    strcat( buf, ( act & ACT_IS_NPC     ) ? " npc"          : ""          );
    strcat( buf, ( act & ACT_SENTINEL   ) ? " sentinel"     : ""     );
    strcat( buf, ( act & ACT_SCAVENGER  ) ? " scavenger"    : ""    );
    strcat( buf, ( act & ACT_AGGRESSIVE ) ? " aggressive"   : ""   );
    strcat( buf, ( act & ACT_STAY_AREA  ) ? " stay_area"    : ""    );
    strcat( buf, ( act & ACT_WIMPY      ) ? " wimpy"        : ""        );
    strcat( buf, ( act & ACT_PET        ) ? " pet"          : ""          );
    strcat( buf, ( act & ACT_TRAIN      ) ? " trainer"      : ""      );
    strcat( buf, ( act & ACT_PRACTICE   ) ? " practitioner" : ""  );
    strcat( buf, ( act & ACT_TRACKSCR   ) ? " track_scr"    : ""    );
    strcat( buf, ( act & ACT_HALT       ) ? " halted"       : ""       );
    strcat( buf, ( act & ACT_SCRAMBLE   ) ? " scramble"     : ""     );
    strcat( buf, ( act & ACT_MOUNTABLE  ) ? " mountable"    : ""    );
    strcat( buf, ( act & ACT_ANGRY      ) ? " angry"        : ""        );
    strcat( buf, ( act & ACT_IMMORTAL   ) ? " immortal"     : ""     );
    strcat( buf, ( act & ACT_NOSCAN     ) ? " noscan"       : ""       );
    strcat( buf, ( act & ACT_PERMINVIS  ) ? " perminvis"    : ""    );
    return buf+1;
}

char *plr_bit_name( int act )
{
    static char buf[512];

    buf[0] = '\0';
    if ( act & PLR_IS_NPC     ) strcat( buf, " npc"          );
    if ( act & PLR_BOUGHT_PET ) strcat( buf, " bought_pet"   );
    if ( act & PLR_HOLYLIGHT  ) strcat( buf, " holylight"    );
    if ( act & PLR_WIZBIT     ) strcat( buf, " wizbit"       );
    if ( act & PLR_LOG        ) strcat( buf, " log"          );
    if ( act & PLR_DENY       ) strcat( buf, " deny"         );
    if ( act & PLR_FREEZE     ) strcat( buf, " freeze"       );
    if ( act & WIZ_NOTIFY     ) strcat( buf, " notify"        );
    return ( buf[0] != '\0' ) ? buf+1 : "none";
}

int act_name_bit( char* buf )
{
    if ( !str_cmp( buf, "npc"          ) ) return ACT_IS_NPC;
    if ( !str_cmp( buf, "sentinel"     ) ) return ACT_SENTINEL;
    if ( !str_cmp( buf, "scavenger"    ) ) return ACT_SCAVENGER;
    if ( !str_cmp( buf, "aggressive"   ) ) return ACT_AGGRESSIVE;
    if ( !str_cmp( buf, "stay_area"    ) ) return ACT_STAY_AREA;
    if ( !str_cmp( buf, "wimpy"        ) ) return ACT_WIMPY;
    if ( !str_cmp( buf, "pet"          ) ) return ACT_PET;
    if ( !str_cmp( buf, "trainer"      ) ) return ACT_TRAIN;
    if ( !str_cmp( buf, "practitioner" ) ) return ACT_PRACTICE;
    if ( !str_cmp( buf, "track_scr"    ) ) return ACT_TRACKSCR;
    if ( !str_cmp( buf, "halted"       ) ) return ACT_HALT;
    if ( !str_cmp( buf, "scramble"     ) ) return ACT_SCRAMBLE;
    if ( !str_cmp( buf, "mountable"    ) ) return ACT_MOUNTABLE;
    if ( !str_cmp( buf, "angry"        ) ) return ACT_ANGRY;
    return 0;
}

/*
 * Returns the name of a wear bit.
 */
char *wear_bit_name( int wear )
{
    static char buf[512];

    buf[0] = '\0';
    strcat( buf, ( wear & ITEM_TAKE        )   ? " take"       : ""  );
    strcat( buf, ( wear & ITEM_WEAR_FINGER )   ? " finger"     : ""  );
    strcat( buf, ( wear & ITEM_WEAR_NECK   )   ? " neck"       : ""  );
    strcat( buf, ( wear & ITEM_WEAR_BODY   )   ? " body"       : ""  );
    strcat( buf, ( wear & ITEM_WEAR_HEAD   )   ? " head"       : ""  );
    strcat( buf, ( wear & ITEM_WEAR_LEGS   )   ? " legs"       : ""  );
    strcat( buf, ( wear & ITEM_WEAR_FEET   )   ? " feet"       : ""  );
    strcat( buf, ( wear & ITEM_WEAR_HANDS  )   ? " hands"      : ""  );
    strcat( buf, ( wear & ITEM_WEAR_ARMS   )   ? " arms"       : ""  );
    strcat( buf, ( wear & ITEM_WEAR_SHIELD )   ? " shield"     : ""  );
    strcat( buf, ( wear & ITEM_WEAR_ABOUT  )   ? " about"      : ""  );
    strcat( buf, ( wear & ITEM_WEAR_WAIST  )   ? " waist"      : ""  );
    strcat( buf, ( wear & ITEM_WEAR_WRIST  )   ? " wrist"      : ""  );
    strcat( buf, ( wear & ITEM_WEAR_BELT   )   ? " belt"       : ""  );
    strcat( buf, ( wear & ITEM_WIELD       )   ? " wield"      : ""  );
    strcat( buf, ( wear & ITEM_HOLD        )   ? " hold"       : ""  );
    strcat( buf, ( wear & ITEM_WEAR_SHOULDER ) ? " shoulder"   : ""  );
    strcat( buf, ( wear & ITEM_TWO_HANDED )    ? " two-handed" : ""  );
    return buf+1;
}


/*
 * Returns the bit, given a certain name.
 */
int wear_name_bit( char* buf )
{
    if (!str_cmp( buf, "take"       ) ) return ITEM_TAKE;
    if (!str_cmp( buf, "finger"     ) ) return ITEM_WEAR_FINGER;
    if (!str_cmp( buf, "neck"       ) ) return ITEM_WEAR_NECK;
    if (!str_cmp( buf, "body"       ) ) return ITEM_WEAR_BODY;
    if (!str_cmp( buf, "head"       ) ) return ITEM_WEAR_HEAD;
    if (!str_cmp( buf, "legs"       ) ) return ITEM_WEAR_LEGS;
    if (!str_cmp( buf, "feet"       ) ) return ITEM_WEAR_FEET;
    if (!str_cmp( buf, "hands"      ) ) return ITEM_WEAR_HANDS;
    if (!str_cmp( buf, "arms"       ) ) return ITEM_WEAR_ARMS;
    if (!str_cmp( buf, "shield"     ) ) return ITEM_WEAR_SHIELD;
    if (!str_cmp( buf, "about"      ) ) return ITEM_WEAR_ABOUT;
    if (!str_cmp( buf, "waist"      ) ) return ITEM_WEAR_WAIST;
    if (!str_cmp( buf, "wrist"      ) ) return ITEM_WEAR_WRIST;
    if (!str_cmp( buf, "belt"       ) ) return ITEM_WEAR_BELT;
    if (!str_cmp( buf, "wield"      ) ) return ITEM_WIELD;
    if (!str_cmp( buf, "hold"       ) ) return ITEM_HOLD;
    if (!str_cmp( buf, "shoulder"   ) ) return ITEM_WEAR_SHOULDER;
    if (!str_cmp( buf, "two-handed"   ) ) return ITEM_TWO_HANDED;
    return 0;
}


/*
 * Return ascii name of wear location.
 */
char *wear_loc_name( int wearloc )
{
    switch( wearloc )
    {
               default: return "unknown";
        case WEAR_NONE: return "none";
    case WEAR_FINGER_L: return "left finger";
    case WEAR_FINGER_R: return "right finger";
      case WEAR_NECK_1: return "neck1";
      case WEAR_NECK_2: return "neck2";
        case WEAR_BODY: return "body";
        case WEAR_HEAD: return "head";
        case WEAR_LEGS: return "legs";
        case WEAR_FEET: return "feet";
       case WEAR_HANDS: return "hands";
        case WEAR_ARMS: return "arms";
      case WEAR_SHIELD: return "shield";
       case WEAR_ABOUT: return "about";
       case WEAR_WAIST: return "waist";
     case WEAR_WRIST_L: return "lwrist";
     case WEAR_WRIST_R: return "rwrist";
    case WEAR_FLOATING: return "floating";
      case WEAR_BELT_1: return "belt1";
      case WEAR_BELT_2: return "belt2";
      case WEAR_BELT_3: return "belt3";
      case WEAR_BELT_4: return "belt4";
      case WEAR_BELT_5: return "belt5";
      case WEAR_HOLD_1: return "hold1";
      case WEAR_HOLD_2: return "hold2";
  case WEAR_SHOULDER_L: return "lshoulder";
  case WEAR_SHOULDER_R: return "rshoulder";
         case MAX_WEAR: return "max_wear";
    }
}


int wear_name_loc( char *buf )
{
    if ( !str_cmp( buf, "lfinger" ) )   return WEAR_FINGER_L;
    if ( !str_cmp( buf, "rfinger" ) )   return WEAR_FINGER_R;
    if ( !str_cmp( buf, "neck1" ) )     return WEAR_NECK_1;
    if ( !str_cmp( buf, "neck2" ) )     return WEAR_NECK_2;
    if ( !str_cmp( buf, "body" ) )      return WEAR_BODY;
    if ( !str_cmp( buf, "head" ) )      return WEAR_HEAD;
    if ( !str_cmp( buf, "legs" ) )      return WEAR_LEGS;
    if ( !str_cmp( buf, "feet" ) )      return WEAR_FEET;
    if ( !str_cmp( buf, "hands" ) )     return WEAR_HANDS;
    if ( !str_cmp( buf, "arms" ) )      return WEAR_ARMS;
    if ( !str_cmp( buf, "shield" ) )    return WEAR_SHIELD;
    if ( !str_cmp( buf, "about" ) )     return WEAR_ABOUT;
    if ( !str_cmp( buf, "waist" ) )     return WEAR_WAIST;
    if ( !str_cmp( buf, "lwrist" ) )    return WEAR_WRIST_L;
    if ( !str_cmp( buf, "rwrist" ) )    return WEAR_WRIST_R;
    if ( !str_cmp( buf, "floating" ) )  return WEAR_FLOATING;
    if ( !str_cmp( buf, "belt1" ) )     return WEAR_BELT_1;
    if ( !str_cmp( buf, "belt2" ) )     return WEAR_BELT_2;
    if ( !str_cmp( buf, "belt3" ) )     return WEAR_BELT_3;
    if ( !str_cmp( buf, "belt4" ) )     return WEAR_BELT_4;
    if ( !str_cmp( buf, "belt5" ) )     return WEAR_BELT_5;
    if ( !str_cmp( buf, "hold1" ) )     return WEAR_HOLD_1;
    if ( !str_cmp( buf, "hold2" ) )     return WEAR_HOLD_2;
    if ( !str_cmp( buf, "lshoulder" ) ) return WEAR_SHOULDER_L;
    if ( !str_cmp( buf, "rshoulder" ) ) return WEAR_SHOULDER_R;
    if ( !str_cmp( buf, "max_wear" ) )  return MAX_WEAR;
    return WEAR_NONE;
}

char *sector_name( int sect )
{
    if ( sect == SECT_INSIDE )       return "inside";
    if ( sect == SECT_CITY )         return "city";
    if ( sect == SECT_FIELD )        return "field";
    if ( sect == SECT_FOREST )       return "forest";
    if ( sect == SECT_HILLS )        return "hills";
    if ( sect == SECT_MOUNTAIN )     return "mountain";
    if ( sect == SECT_WATER_SWIM )   return "swim";
    if ( sect == SECT_WATER_NOSWIM ) return "noswim";
    if ( sect == SECT_UNDERWATER )   return "underwater";
    if ( sect == SECT_AIR )          return "air";
    if ( sect == SECT_DESERT )       return "desert";
    if ( sect == SECT_ICELAND  )     return "iceland";
    if ( sect == SECT_LADDER   )     return "ladder";
    return "unknown";
}

/*
 * Returns the bit, given a certain name.
 */
int part_name_bit( char* buf )
{
    if (!str_cmp( buf, "horn"       ) ) return PART_HORN;
    if (!str_cmp( buf, "wing"       ) ) return PART_WING;
    if (!str_cmp( buf, "has_head"   ) ) return PART_HEAD;
    if (!str_cmp( buf, "has_legs"   ) ) return PART_LEG;
    if (!str_cmp( buf, "has_arms"   ) ) return PART_ARM;
    if (!str_cmp( buf, "bowels"     ) ) return PART_BOWELS;
    if (!str_cmp( buf, "heart"      ) ) return PART_HEART;
    if (!str_cmp( buf, "eyestalk"   ) ) return PART_EYESTALK;
    if (!str_cmp( buf, "tentacle"   ) ) return PART_TENTACLE;
    if (!str_cmp( buf, "redblood"   ) ) return PART_REDBLOOD;
    return 0;
}

/*
 * Returns the name of a wear bit.
 */
char *body_bit_name( int part )
{
    static char buf[512];

    buf[0] = '\0';
    strcat( buf, ( part & PART_BOWELS   ) ? " bowels"   : ""   );
    strcat( buf, ( part & PART_HORN     ) ? " horn"     : ""   );
    strcat( buf, ( part & PART_WING     ) ? " wing"     : ""   );
    strcat( buf, ( part & PART_HEAD     ) ? " head"     : ""   );
    strcat( buf, ( part & PART_LEG      ) ? " leg"      : ""   );
    strcat( buf, ( part & PART_ARM      ) ? " arm"      : ""   );
    strcat( buf, ( part & PART_EYESTALK ) ? " eyestalk" : ""   );
    strcat( buf, ( part & PART_HEART    ) ? " heart"    : ""   );
    strcat( buf, ( part & PART_TENTACLE ) ? " tentacle" : ""   );
    strcat( buf, ( part & PART_REDBLOOD ) ? " redblood" : ""   );
    return buf+1;
}


int sector_number( char *argument )
{
    if ( !str_cmp( argument, "inside" ) )       return SECT_INSIDE;
    if ( !str_cmp( argument, "city" ) )         return SECT_CITY;
    if ( !str_cmp( argument, "field" ) )        return SECT_FIELD;
    if ( !str_cmp( argument, "forest" ) )       return SECT_FOREST;
    if ( !str_cmp( argument, "hills" ) )        return SECT_HILLS;
    if ( !str_cmp( argument, "mountain" ) )     return SECT_MOUNTAIN;
    if ( !str_cmp( argument, "swim" ) )         return SECT_WATER_SWIM;
    if ( !str_cmp( argument, "noswim" ) )       return SECT_WATER_NOSWIM;
    if ( !str_cmp( argument, "underwater" ) )   return SECT_UNDERWATER;
    if ( !str_cmp( argument, "air" ) )          return SECT_AIR;
    if ( !str_cmp( argument, "desert" ) )       return SECT_DESERT;
    if ( !str_cmp( argument, "iceland" ) )      return SECT_ICELAND;
    if ( !str_cmp( argument, "ladder" ) )       return SECT_LADDER;
    return SECT_MAX;
}


int position_number( char *argument )
{
    if ( !str_cmp( argument, "sleeping" ) )       return POS_SLEEPING;
    if ( !str_cmp( argument, "resting" ) )        return POS_RESTING;
    if ( !str_cmp( argument, "standing" ) )       return POS_STANDING;
    return POS_DEAD;
}


char *position_name( int pos )
{
    if ( pos == POS_DEAD     )    return "dead";
    if ( pos == POS_MORTAL   )    return "mortal";
    if ( pos == POS_INCAP    )    return "incapacitated";
    if ( pos == POS_STUNNED  )    return "stunned";
    if ( pos == POS_SLEEPING )    return "sleeping";
    if ( pos == POS_RESTING  )    return "resting";
    if ( pos == POS_FIGHTING )    return "fighting";
    if ( pos == POS_STANDING )    return "standing";
    return "unknown";
}


char *wp_name( int wp )
{
    if ( wp == WP_HIT     )    return "hit";
    if ( wp == WP_SLASH   )    return "slash";
    if ( wp == WP_PIERCE  )    return "pierce";
    if ( wp == WP_WHIP    )    return "whip";
    if ( wp == WP_EXPLODE )    return "explode";
    if ( wp == WP_POUND   )    return "pound";
    if ( wp == WP_SUCTION )    return "suction";
    if ( wp == WP_SHOT    )    return "shot";
    return "unknown";
}


int wp_number( char *argument )
{
    if ( !str_cmp( argument, "hit"     ) )    return WP_HIT;
    if ( !str_cmp( argument, "slash"   ) )    return WP_SLASH;
    if ( !str_cmp( argument, "pierce"  ) )    return WP_PIERCE;
    if ( !str_cmp( argument, "whip"    ) )    return WP_WHIP;
    if ( !str_cmp( argument, "explode" ) )    return WP_EXPLODE;
    if ( !str_cmp( argument, "pound"   ) )    return WP_POUND;
    if ( !str_cmp( argument, "suction" ) )    return WP_SUCTION;
    if ( !str_cmp( argument, "shot"    ) )    return WP_SHOT;
    return WP_MAX;
}




int size_number( char *argument )
{
    if ( !str_cmp( argument, "any"         ) )    return SIZE_ANY;
    if ( !str_cmp( argument, "minute"      ) )    return SIZE_MINUTE;
    if ( !str_cmp( argument, "small"       ) )    return SIZE_SMALL;
    if ( !str_cmp( argument, "petite"      ) )    return SIZE_PETITE;
    if ( !str_cmp( argument, "average"     ) )    return SIZE_AVERAGE;
    if ( !str_cmp( argument, "medium"      ) )    return SIZE_MEDIUM;
    if ( !str_cmp( argument, "large"       ) )    return SIZE_LARGE;
    if ( !str_cmp( argument, "huge"        ) )    return SIZE_HUGE;
    if ( !str_cmp( argument, "titanic"     ) )    return SIZE_TITANIC;
    if ( !str_cmp( argument, "gargantuan"  ) )    return SIZE_GARGANTUAN;
    return SIZE_ANY-1;
}



char *size_name( int size )
{
    if ( size == SIZE_ANY        )    return "any";
    if ( size == SIZE_MINUTE     )    return "minute";
    if ( size == SIZE_SMALL      )    return "small";
    if ( size == SIZE_PETITE     )    return "petite";
    if ( size == SIZE_AVERAGE    )    return "average";
    if ( size == SIZE_MEDIUM     )    return "medium";
    if ( size == SIZE_LARGE      )    return "large";
    if ( size == SIZE_HUGE       )    return "huge";
    if ( size == SIZE_TITANIC    )    return "titanic";
    if ( size == SIZE_GARGANTUAN )    return "gargantuan";
    return "unknown";
}


