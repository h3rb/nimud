/****************************************************************************
 *   ___  ___  ___  __    __                                                *
 *  |   ||   ||   ||  |\/|  | 2-x    NiMUD is a software currently under    *
 *   |  \ | |  | |  | |\/| |         development.  It is based primarily on *
 *   | |\\| |  | |  | |  | |         the discontinued package, Merc 2.2.    *
 *   | | \  |  | |  | |  | |         NiMUD is being written and developed   *
 *  |___||___||___||__|  |__|        By Locke and Surreality as a new,      *
 *   NAMELESS INCARNATE *MUD*        frequently updated package similar to  *
 *        S O F T W A R E            the original Merc 2.x.                 *
 *                                                                          *
 *  Just look for the Iron Maiden skull wherever NiMUD products are found.  *
 *                                                                          *
 *  Much time and thought has gone into this software and you are           *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                                                   *
 ****************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "merc.h"


/*
 * The following code is for the creation of a generated world file.
 * Each array is used internally by the processor in order to create
 * a larger world.  Populate this world as you wish.
 */

#define MAX_TERRAIN           1
#define MAX_SENTENCES         25


char * const     tnames[MAX_TERRAIN][2] =
{
    { "unknown",      "unknown"     },      { "ocean",        "oceans"      },
    { "beach",        "beaches"     },      { "savanna",      "savannas"    },
    { "desert",       "deserts"     },      { "mountain",     "mountains"   },
    { "plain",        "plains"      },      { "hill",         "hills"       },
    { "farmland",     "farmlands"   },      { "road",         "roads"       },
    { "road",         "roads"       },      { "crossroad",    "crossroads"  },
    { "river",        "rivers"      },      { "lake",         "lakes"       },
    { "dryland",      "drylands"    },      { "field",        "fields"      },
    { "meadow",       "meadows"     },      { "town",         "towns"       }
};


char * const tsent_Combine[MAX_SENTENCES] =
{
    "You notice %s, and %s.",
    "%s, and %s.",
    "%s, while %s."
    "As you look around, %s.",
    "Standing here, %s.",
    "Over yonder %s.",
    "%s.",    "%s.",    "%s.",    "%s.",    "%s.",    "%s.",    "%s.",
    "%s.",    "%s.",    "%s.",    "%s.",    "%s.",    "%s.",    "%s.",
    "%s.",    "%s.",    "%s.",    "%s.",    "%s.",    "%s."
};


const int tsent_total[MAX_TERRAIN] =
{
    25, 9, 25, 12, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};


char * const  tsent[MAX_TERRAIN][MAX_SENTENCES]  =
{
    {
    "nothing unusual", "nothing unusual", "nothing unusual", "nothing unusual",
    "nothing unusual", "nothing unusual", "nothing unusual", "nothing unusual",
    "nothing unusual", "nothing unusual", "nothing unusual", "nothing unusual",
    "nothing unusual", "nothing unusual", "nothing unusual", "nothing unusual",
    "nothing unusual", "nothing unusual", "nothing unusual", "nothing unusual",
    "nothing unusual", "nothing unusual", "nothing unusual", "nothing unusual",
    "nothing unusual"
    },

    {
    "the white caps of waves roll and lap away eternally",
    "high blue waves like walls of water crash and churn on endless cycles",
    "above you the calls of sea birds can be heard, carried on the salty wind",
    "ocean spray thickens the air and dusts you with moisture",
    "meandering blue sky hangs like a reflection over clear blue water",

    "tangles of seaweed can be seen just under the surface",
    "the ocean is like a wide plain; flat and featureless blue",
    "the water is briny and rather warm",
    "something moves beneath the surface of the waves, and then it is gone"
    },

    {
    "thick swirls of wave-ground sand lay smoothly packed by the lapping waters of time",
    "the beach is a white strip of sand and dirt",
    "various debris is strewn upon the beach",
    "pieces of seaweed and shells haphazardly lay where the waves have discarded them",
    "a towhead protrudes from a small sandy knoll",

    "driftwood and small shards of conch shells are scattered on the sand",
    "smooth round rocks are all over the place",
    "a long track of white sand strikes its way across the beachhead",
    "a few iron rings and other shipyard debris can be found amongst the other trash on the beach",
    "footprints of gulls track across the sand",

    "broken crab shells are telltale signs of sea bird activity",
    "a large crustacean claw is on the beach",
    "there are rivulets of water that collect in small puddles",
    "under a large rock, a turtle sleeps",
    "a few palm fronds lay on the ground, shed from one of the tall trees",

    "tall coconut trees line the shore",
    "several coconuts sit on the beach",
    "sadly, a dead fish is here, a blank look on its lifeless face",
    "a large boulder breaks from the rough and juts into the air",
    "large rocks and stones cover the shoreline",

    "gulls and other birds can be seen resting on the shore",
    "a few palm trees have fallen and are beginning to be covered in barnacles",
    "sanddollars and clam shells are strewn everywhere",
    "over yonder you can make out the shape of a few boulders",
    "footprints are marked in the sand"
    },

    {
    "sparce trees are the only breaks in endless grass",
    "waist high green and brown grass rustles in the wind",
    "gnarled trees are scattered at sixty or seventy handspan intervals",
    "kioka trees bear shriveled sourfruit, leaving grey-green seeds all over",
    "the grasslands are criss-crossed with vines and kioka root",

    "browned grass offers a good hiding place for small field rodents",
    "a few scattered bushes offer a few berries to the birds that nest in the savanna",
    "small red flowers expel a sweet, hickory scent into the air",
    "a small furry hopper scurries under a pebble",
    "the trees look like hands with green feathers, reaching toward the heavens",

    "the grass is scattered with leaves",
    "the rolling land is broken only by scatterings of groves and groups of trees",
    "a mutusi bush grows nearby; its leaves give off the telltale humm of impending changes in the weather",
    "the landscape would seem barren if it were not for all the kioka trees",
    "large boulders lined with viens of copper dot the landscape",

    "a jhotu falcon circles high above",
    "the trees bustle with avian activity",
    "a clawed mek scurries from one treetop to another, gliding on its webbed underarms",
    "the ground is scattered with weeds",
    "a tangle of grabgrass lays across your path",

    "a pop bush extrudes its fluffy white tendrils into the air",
    "some jackrabbits dash through grabgrass into a mutusi bush burrow",
    "scrubs and dustballs blow through the tall brown-green grass",
    "a dusk of some ivy grows amongst the grass and weeds",
    "a mass of trucker root extends into the base of a kioka"
    },

    {
    "rolling dunes are spotted by green cacti",
    "a huge sand-flow scatters a river of sand down a dune",
    "a bead-black scorpion scurries from rock to rock",
    "the parched, sandy earth is marred by thick ravines",
    "a steep banked ravine cuts through sand dunes",

    "the desert expands as a rolling, wrinkled landscape",
    "the skull of a hapless animal lies here, devoid of movement",
    "small ruts in the sand show recent snake activity",
    "the dried scruff of a dustball lies in a shallow ditch",
    "a mass of twigs rustles lazily in a hot updraft",

    "a wind-swept block of solid granite juts from a short dune",
    "a thick-scaled gila shuffles across the parched earth",
    },

    {
    "the rocky landscape is covered with a thin frost",
    "above the treeline, the area is sparce and the rocks coated in green and orange lichen",
    "a few broken timbers lay amongst countless boulders",
    "you catch the sight of some tiny footprints a patch of snow",
    "rock outcroppings protrude from the rough mountain face"
    },

    {
    "the plains are featureless swaths of green grass and brown bush",
    },

    {
    "the rolling hills and knolls are covered in a carpet of green grass",
    },

    {
    "farmlands of well groomed and harvested crop seem to stretch forever",
    },

    {
    "the road leads away along its dusty path",
    },

    {
    "the road leads away along its dusty path",
    },

    {
    "the roads meet at a crossroad",
    },

    {
    "the river flows past in a swift current",
    },

    {
    "the lake twinkles in the light",
    },

    {
    "the area is dry, the ground parched",
    },

    {
    "the overgrowth of the field is serene and buzzing with nature",
    },

    {
    "ah, such a lovely meadow",
    },

    {
    "the town is nice",
    },
};


#define MAX_RAND                8

void gen_room( ROOM_INDEX_DATA *pRoom )
{
    char buf[MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];
    char *pDescr;
    int nRand;
    int iRand;
    int previous[MAX_RAND][2];
    int terrain;

    buf[0] = '\0';

    terrain = pRoom->terrain;
    if ( terrain != 0 )
    {
    nRand = number_range( 1, UMIN(MAX_RAND,tsent_total[terrain]) );

    for ( iRand = 0;  iRand < nRand;  iRand++ )
    {
        previous[iRand][0] = -1;
        previous[iRand][1] = -1;
    }

    for ( iRand = 0;  iRand < nRand;  iRand++ )
    {

        while ( previous[iRand][0] == -1 && previous[iRand][1] == -1 )
        {
            int x, y, z;

            x = number_range(0, tsent_total[terrain]);
            y = number_range(0, tsent_total[terrain]);

            for ( z = 0; z < iRand; z++ )
            {
                if ( previous[z][0] == x
                  || previous[z][1] == y )
                break;
            }

            if ( z == iRand )
            {
                previous[iRand][0] = x;
                previous[iRand][1] = y;
                break;
            }
        }

        if ( iRand != nRand - 1)
        {
        sprintf( buf2, tsent_Combine[number_range( 0, MAX_SENTENCES-1 )],
                 tsent[terrain][previous[iRand][0]],
                 tsent[terrain][previous[iRand][1]] );
        }
        else
        {
        sprintf( buf2, "%s.", tsent[terrain][previous[iRand][0]] );
        }

        sprintf( buf, "%s  %s", buf, capitalize( buf2 ) );
    }
    }

/*
    REMOVE_BIT(pRoom->room_flags, ACT_GENERATED);
 */
    
    free_string( pRoom->description );
    pDescr = format_string( str_dup( buf ) );
    pRoom->description = pDescr;
    return;
}


