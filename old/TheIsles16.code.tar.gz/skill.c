/****************************************************************************
 *   ___  ___  ___  __    __                                                *
 *  |   ||   ||   ||  |\/|  | 2-x    NiMUD is a software currently under    *
 *   |  \ | |  | |  | |\/| |         development.  It is based primarily on *
 *   | |\\| |  | |  | |  | |         the discontinued package, Merc 2.2.    *
 *   | | \  |  | |  | |  | |         NiMUD is being written and developed   *
 *  |___||___||___||__|  |__|        By Locke and Surreality as a new,      *
 *   NAMELESS INCARNATE *MUD*        frequently updated package similar to  *
 *        S O F T W A R E            the original Merc 2.x.                 *
 *                                                                          *
 *  Just look for the Iron Maiden skull wherever NiMUD products are found.  *
 *                                                                          *
 *  Much time and thought has gone into this software and you are           *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                                                   *
 ****************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "merc.h"


char *   const  wp_name_array [] =
{
    "miscellaneous",
    "edged",
    "thrusting",
    "whip",
    "fragmentation",
    "bludgeon",
    "exotic",
    "ranged"
};


char *how_good(int percent)
{
  static char buf[256];
  
  if (percent == 0)           strcpy(buf, "(unknown)" );
  else if (percent <= 10)     strcpy(buf, "(awful)" );
  else if (percent <= 20)     strcpy(buf, "(bad)" );
  else if (percent <= 40)     strcpy(buf, "(poor)" );
  else if (percent <= 55)     strcpy(buf, "(average)" );
  else if (percent <= 70)     strcpy(buf, "(fair)" );
  else if (percent <= 80)     strcpy(buf, "(good)" );
  else if (percent <= 85)     strcpy(buf, "(great)" );
  else                        strcpy(buf, "(superb)" );
  
  return (buf);
}

char *how_good_2(int percent)
{
  static char buf[256];
  
  if (percent == 0)           strcpy(buf, "untrained" );
  else if (percent <= 10)     strcpy(buf, "awful" );
  else if (percent <= 20)     strcpy(buf, "bad" );
  else if (percent <= 40)     strcpy(buf, "poor" );
  else if (percent <= 55)     strcpy(buf, "average" );
  else if (percent <= 70)     strcpy(buf, "fair" );
  else if (percent <= 80)     strcpy(buf, "good" );
  else if (percent <= 85)     strcpy(buf, "great" );
  else                        strcpy(buf, "superb" );
  
  return (buf);
}


#define WP(sn)   ( (IS_NPC(ch) ? ch->level : ch->profs[sn]) )

void do_skills( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char final[2 * MAX_STRING_LENGTH];
    int col;
    int sn;

    one_argument( argument, buf );

    if ( buf[0] != '\0' )
    {
        MOB_INDEX_DATA *pMob;

        if ( ( sn = skill_lookup( buf ) ) > 0
          && ch->learned[sn] > 0
          && ch->learned[sn] < class_table[ch->class].skill_adept
          && ( col= ch->teacher[sn] ) != 0
          && ( pMob = get_mob_index( col ) ) != NULL )
             sprintf( buf, "You are currently an apprentice of %s to %s.\n\r",
                          skill_table[sn].name, pMob->short_descr );
        else sprintf( buf, "You are not an apprentice of that skill.\n\r" );
        send_to_char( buf, ch );
        return;
    }

    final[0] = '\0';
    col = 0;
    send_to_char( "Skills:\n\r", ch );
    for ( sn = 0; sn < MAX_SKILL; sn++ )
        {
            if ( skill_table[sn].name == NULL )
                break;
        if ( (ch->level < skill_table[sn].skill_level[ch->class])
          || (ch->learned[sn] == 0)
          || (skill_table[sn].spell_fun != spell_null) )
                continue;

        sprintf( buf, " %28s%10s", skill_table[sn].name,
                                   how_good(ch->learned[sn]) );
        strcat( final, buf );
        if ( ++col % 2 == 0 )
        strcat( final, "\n\r" );
    }
    page_to_char( final, ch );

    send_to_char( "\n\rWeapon proficiencies:\n\r", ch );
    for ( sn = 0; sn < WP_MAX; sn++ )
    {
    sprintf( buf, "Your %s performance is %s.\n\r", wp_name_array[sn],
             WP(sn) <= 1 ? "nominal"  :
             WP(sn) < 10 ? "beginner" :
             WP(sn) < 20 ? "intermediate" :
             WP(sn) < 30 ? "advanced" :
             WP(sn) < 40 ? "expert"   :  "mastered"    );
    send_to_char( buf, ch );
    }

    return;
}

#undef WP

void do_spells( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char final[2 * MAX_STRING_LENGTH];
    int col;
    int sn;

    one_argument( argument, buf );
    if ( buf[0] != '\0' )
    {
        MOB_INDEX_DATA *pMob;

        if ( ( sn = skill_lookup( buf ) ) > 0
          && ch->learned[sn] > 0
          && ch->learned[sn] < class_table[ch->class].skill_adept
          && ( col= ch->teacher[sn] ) != 0
          && ( pMob = get_mob_index( col ) ) != NULL )
             sprintf( buf, "You are currently an apprentice of %s to %s.\n\r",
                          skill_table[sn].name, pMob->short_descr );
        else sprintf( buf, "You are not an apprentice of that spell.\n\r" );
        send_to_char( buf, ch );
        return;
    }

    final[0] = '\0';
    col = 0;
    send_to_char( "Spells:\n\r", ch );
    for ( sn = 0; sn < MAX_SKILL; sn++ )
        {
        if ( skill_table[sn].name == NULL )
                break;

        if ( (ch->level < skill_table[sn].skill_level[ch->class])
          || (ch->learned[sn] == 0)
          || (skill_table[sn].spell_fun == spell_null) )
                continue;

        sprintf( buf, " %38s%10s %s\n\r", skill_table[sn].name,
                      how_good(ch->learned[sn]),
                      skill_table[sn].mana_type == MANA_AIR   ? "(air)   " :
                      skill_table[sn].mana_type == MANA_FIRE  ? "(fire)  " :
                      skill_table[sn].mana_type == MANA_WATER ? "(water) " :
                      skill_table[sn].mana_type == MANA_EARTH ? "(earth) " :
                      skill_table[sn].mana_type == MANA_ANY   ? "(any)   " :
                                                                "(other) " );
        strcat( final, buf );
    }
    page_to_char( final, ch );

    return;
}

void do_learn( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    CHAR_DATA *mob;
    int sn;
    int skl;

    if ( IS_NPC(ch) )
	return;

    for ( mob = ch->in_room->people; mob != NULL; mob = mob->next_in_room )
    {
        if ( IS_NPC(mob) && IS_SET(mob->act, ACT_PRACTICE) )
        break;
    }

    if ( mob == NULL )
    {
        send_to_char( "You can't do that here.\n\r", ch );
        return;
    }

    skl    = 0;
    for ( sn = 0; sn < MAX_SKILL; sn++ )
    {
	    if ( skill_table[sn].name == NULL )
		break;

        if ( ch->learned[sn] != 0 )  skl++;
    }

    if ( argument[0] == '\0' )
    {
	int col;

        col    = 0;
	for ( sn = 0; sn < MAX_SKILL; sn++ )
	{
        int sn2;
        bool KnowOther;

	    if ( skill_table[sn].name == NULL )
                break;

        sn2 = requires[sn];
        KnowOther = sn2 < 0
                    ? TRUE
                    : ch->learned[sn2] >= skill_table[sn].required_percent;
                
        if (  ch->level < skill_table[sn].skill_level[ch->class]
           || ch->learned[sn] != 0
           || (mob->learned[sn] <= 0)
           || !KnowOther )
                 continue;

        sprintf( buf, "%24s ", skill_table[sn].name );
	    send_to_char( buf, ch );
        if ( ++col % 3 == 0 )
		send_to_char( "\n\r", ch );
    }

	if ( col % 3 != 0 )
	    send_to_char( "\n\r", ch );

    sprintf( buf, "You may learn %s more skills or spells in your lifetime.\n\r",
             numberize( race_table[ch->race].max_skills - skl ) );
	send_to_char( buf, ch );
    }
    else
    {
	int adept;

	if ( !IS_AWAKE(ch) )
	{
	    send_to_char( "In your dreams, or what?\n\r", ch );
	    return;
	}


    if ( skl >= race_table[ch->race].max_skills 
     && ch->learned[skill_lookup( argument )] == 0 )
        {    
        sprintf( buf, "'%s' You have already learned the maxmimum skills for the %s race.",
                       STR(ch,name), race_table[ch->race].race_name );
        do_tell( mob, buf );
	    return;
	}

    if ( ch->learn_time > 0 )
    {
        sprintf( buf, "'%s' You are not yet ready to learn anything new.",
                      STR(ch,name) );
        do_tell( mob, buf );
        return;
    }


    if ( ( sn = skill_lookup( argument ) ) < 0
	|| ( !IS_NPC(ch)
        &&   ch->level < skill_table[sn].skill_level[ch->class] )
        || ( mob->learned[sn] <= 0 ) )
        {
        sprintf( buf, "'%s' You can't learn that from me.", STR(ch,name) );
        do_tell( mob, buf );
	    return;
	}

    if ( requires[sn] >= 0 )
    {
    int sn2;

    if ( ( sn2 = requires[sn] ) >= 0
      && skill_table[sn].required_percent > ch->learned[sn2] )
    {
        sprintf( buf, "'%s' You must learn more about %s before you apprentice %s.",
                      STR(ch,name), skill_table[sn2].name, skill_table[sn].name );
        do_tell( mob, buf );
    }
    }

	adept = IS_NPC(ch) ? 100 : class_table[ch->class].skill_adept;

    if ( ch->learned[sn] != 0
      && get_mob_index( ch->teacher[sn] ) != NULL
      && IS_SET( get_mob_index( ch->teacher[sn] )->act, ACT_PRACTICE ) )
	{
        sprintf( buf, "'%s' You already have begun learning about %s.", STR(ch,name),
                      skill_table[sn].name );
        do_tell( mob, buf );
	}
	else
	{
        ch->skill_time[sn] = 1;
        ch->learned[sn] = 1;
        ch->teacher[sn] = mob->pIndexData->vnum;
        act( "You are now an apprentice of $t to $N.", ch, skill_table[sn].name, mob, TO_CHAR );
        act( "$n is now an apprentice of $t to $N.", ch, skill_table[sn].name, mob, TO_ROOM );
	}
    }
    return;
}



void do_practice( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    char final[MAX_STRING_LENGTH];
    int sn;

    if ( IS_NPC(ch) )
	return;

    if ( argument[0] == '\0' )
    {
        final[0] = '\0';

	for ( sn = 0; sn < MAX_SKILL; sn++ )
	{
        char *p;

	    if ( skill_table[sn].name == NULL )
		break;
        if ( (ch->level < skill_table[sn].skill_level[ch->class])
          || (ch->learned[sn] == 0)
          || ch->learned[sn] >= class_table[ch->class].skill_adept )
		continue;

        sprintf( buf, "You are %s%s at %s, apprenticed to %s%s",
                 !IS_HERO(ch) ? how_good_2(ch->learned[sn])
                              : numberize( ch->skill_time[sn] ),
                 !IS_HERO(ch) ? ""
                              : " percent",
                 skill_table[sn].name,
                 get_mob_index( ch->teacher[sn] ) ?
                 get_mob_index( ch->teacher[sn] )->short_descr : "no teacher",
                 ch->skill_time[sn] > 0 ?
                    ", you are not yet ready to practice.\n\r" : ".\n\r" );

        p = format_string( str_dup( buf ) );
        strcat( final, p );
        free_string( p );
    }

    send_to_char( final, ch );
    return;
    }
    else
    {
	CHAR_DATA *mob;
	int adept;
    int cost;

	if ( !IS_AWAKE(ch) )
	{
	    send_to_char( "In your dreams, or what?\n\r", ch );
	    return;
    }

    sn = skill_lookup( argument );
	for ( mob = ch->in_room->people; mob != NULL; mob = mob->next_in_room )
	{
        if ( IS_NPC(mob)
           && IS_SET(mob->act, ACT_PRACTICE)
           && mob->pIndexData->vnum == ch->teacher[sn] )
		break;
	}

	if ( mob == NULL )
	{
        send_to_char( "There is no master here to teach you.\n\r", ch );
	    return;
	}

	if ( ( sn = skill_lookup( argument ) ) < 0
	|| ( !IS_NPC(ch)
    &&   (ch->level < skill_table[sn].skill_level[ch->class] ||
          ch->learned[sn] <= 0) ) )
	{
        sprintf( buf, "'%s' You can't practice that.\n\r",  STR(ch,name) );
        do_tell( mob, buf );
	    return;
	}

    if ( ch->skill_time[sn] > 0 )
    {
        sprintf( buf, "'%s' You are not yet ready to advance.",  STR(ch,name) );
        do_tell( mob, buf );
        return;
    }

    if ( tally_coins( ch ) < (cost = 10 * skill_table[sn].skill_level[ch->class]) )
    {
        sprintf( buf, "'%s' You don't have the %s to pay me.",  STR(ch,name),
                      name_amount( cost ) );
        do_tell( mob, buf );
	    return;
    }

	adept = IS_NPC(ch) ? 100 : class_table[ch->class].skill_adept;

    if ( ch->learned[sn] >= adept )
	{
        sprintf( buf, "'%s' I've taught you all I can of %s.",  STR(ch,name),
                       skill_table[sn].name );
        do_tell( mob, buf );
        return;
	}

    if ( skill_table[sn].learn_fun != NULL
    && !(*skill_table[sn].learn_fun) ( ch, mob, sn ) )
         return;

    ch->skill_time[sn] += skill_table[sn].learn_rate;
    ch->learned[sn] += UMIN(int_app[get_curr_int(ch)].learn,
                                    skill_table[sn].max_prac);

    act( "$N teaches you more about $t.", ch, skill_table[sn].name, mob, TO_CHAR );
    act( "$N teaches $n about $t.",  ch, skill_table[sn].name, mob, TO_ROOM );

    if ( ch->learned[sn] >= adept )
    {
        ch->learned[sn] = adept;
        sprintf( buf, "'%s' You are now an adept of %s, I can teach you no more.", STR(ch,name),
                skill_table[sn].name );
        do_tell( mob, buf );
    }

    sprintf( buf, "You receive %s in change.\n\r", sub_coins( cost, ch ) );
    if ( !str_cmp(buf, "You receive nothing in change.\n\r") )
    {
        send_to_char( buf, ch );
    } 

    return;
    }
}



void do_train( CHAR_DATA *ch, char *argument )
{
    char buf[MAX_STRING_LENGTH];
    CHAR_DATA *mob;
    sh_int *pAbility;
    char *pOutput;
    int cost;

    if ( IS_NPC(ch) )
	return;

    /*
     * Check for trainer.
     */
    for ( mob = ch->in_room->people; mob; mob = mob->next_in_room )
    {
	if ( IS_NPC(mob) && IS_SET(mob->act, ACT_TRAIN) )
	    break;
    }

    if ( mob == NULL )
    {
	send_to_char( "You can't do that here.\n\r", ch );
	return;
    }

    cost = 5;
    if ( !str_prefix( argument, "strength" ) )
    {
    pAbility    = &ch->perm_str;
	pOutput     = "strength";
    }
    else if ( !str_prefix( argument, "intelligence" ) )
    {
    pAbility    = &ch->perm_int;
	pOutput     = "intelligence";
    }
    else if ( !str_prefix( argument, "wisdom" ) )
    {
    pAbility    = &ch->perm_wis;
	pOutput     = "wisdom";
    }
    else if ( !str_prefix( argument, "dexterity" ) )
    {
    pAbility    = &ch->perm_dex;
	pOutput     = "dexterity";
    }
    else if ( !str_prefix( argument, "constitution" ) )
    {
    pAbility    = &ch->perm_con;
	pOutput     = "constitution";
    }
    else
    {
    sprintf( buf, "'%s' I can train you in", STR(ch,name) );
    if ( ch->perm_str < 18 ) strcat( buf, " strength" );
    if ( ch->perm_int < 18 ) strcat( buf, " intelligence" );
    if ( ch->perm_wis < 18 ) strcat( buf, " wisdom" );
    if ( ch->perm_dex < 18 ) strcat( buf, " dexterity" );
    if ( ch->perm_con < 18 ) strcat( buf, " constitution" );

    strcat( buf, "." );
    do_tell( mob, buf );
    return;
    }

    sprintf( buf, "'%s' Your %s is already at maximum.", STR(ch,name), pOutput );
    do_tell( mob, buf );
	return;

    if ( tally_coins( ch ) < 10 * ch->level * cost )
    {
        sprintf( buf, "'%s' You need %s to train that.\n\r",  STR(ch,name),
                      name_amount( 10 * ch->level * cost ) );
        do_tell( mob, buf );
        return;
    }

    sprintf( buf, "You pay %s to train %s.\n\r",  name_amount( 10 * ch->level * cost ),
                  pOutput );
    sub_coins( 10 * ch->level * cost, ch );
    send_to_char( buf, ch );

    *pAbility       += 1;
    act( "$n trains with $N in $t.", ch, pOutput, mob, TO_ROOM );
    return;
}






