
/*
 * Loader for old Merc/Diku file formats
 */ 




/*
 * Processes a Diku file; adding vnum_base to its vnums.
 */


int highestvnum( ) {
    ZONE_DATA *pZone;
    int hv = 0;

    for (pZone = zone_list;  pZone != NULL;  pZone = pZone->next ) {
        if ( pZone->uvnum > hv ) hv = pZone->uvnum;
    }

    return hv;
}

void load_diku( char *filename ) {
   FILE *fp;

   fp = fopen( filename, "r" );  
}
