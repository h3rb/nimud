# vi: ts=8 sw=8

package Tongues::Eesti;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Baltic CP1257 / ISO 8859-13 / Latin-7

# Alphabetical order
# A B (C �) D E F G H I J K L M N O P (Q) R S � Z � T U V (W) � � � � (X Y)
# a b (c �) d e f g h i j k l m n o p (q) r s � z � t u v (w) � � � � (x y)

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::BalticWin;

$charset = new Charsets::BalticWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 [ 'n',		'',	'(of) ',	'',	'n' ],	# genetive
 [ 'a',		'',	'(some) ',	'',	'n' ],	# partitive
 [ 'na',	'',	'(as) ',	'',	'n' ],	# essive
 [ 'ks',	'',	'(to) ',	'',	'n' ],	# translative
 [ 's',		'',	'(in) ',	'',	'n' ],	# inessive
 [ 'st',	'',	'(from) ',	'',	'n' ],	# elative
 [ 'sse',	'',	'(into) ',	'',	'n' ],	# illitive
 [ 'l',		'',	'(on) ',	'',	'n' ],	# adessive - at, with, by
 [ 'lt',	'',	'(from) ',	'',	'n' ],	# ablative
 [ 'le',	'',	'(to) ',	'',	'n' ],	# allative - onto, for
 [ 'ta',	'',	'(without) ',	'',	'n' ],	# abessive
 [ 'ga',	'',	'(with) ',	'',	'n' ],	# comitative
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 [ 'n',		'ma',	'(i) ',		'',	'v' ],	# 1s
 [ 'dan',	'tma',	'(i) ',		'',	'v' ],
 [ 'd',		'ma',	'(you) ',	'',	'v' ],	# 2s
 [ 'dad',	'tma',	'(you) ',	'',	'v' ],
 [ 'b',		'ma',	'(he) ',	's',	'v' ],	# 3s (he/she)
 [ 'dab',	'tma',	'(he) ',	's',	'v' ],
 [ 'me',	'ma',	'(we) ',	'',	'v' ],	# 1p
 [ 'dame',	'tma',	'(we) ',	'',	'v' ],
 [ 'te',	'ma',	'(you) ',	'',	'v' ],	# 2p
 [ 'date',	'tma',	'(you) ',	'',	'v' ],
 [ 'vad',	'ma',	'(they) ',	'',	'v' ],	# 3p - also v�t
 [ 'davad',	'tma',	'(they) ',	'',	'v' ],
 # Verb present subjunctive
 # Verb imperitive
 [ '',		'ma',	'',		'',	'v' ],
 [ 'da',	'tma',	'',		'',	'v' ],
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine		default for words ending in a
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative
#	g -> genitive
#	d -> dative
#	a -> accusative
#	inst -> instrumental
#	l -> locative

# Estonian to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'mina'		=> { 'x' => 'i',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'ma'		=> { 'x' => 'i',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 #   2nd person
 'sina'		=> { 'x' => 'you',
		     '#' => 'informal',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'sa'		=> { 'x' => 'you',
		     '#' => 'informal',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'teie'		=> { 'x' => 'you',
		     '#' => 'she, they' },
 'te'		=> { 'x' => 'you',
		     '#' => 'she, they' },
 #   3rd person
 'tema'		=> { 'x' => 'he',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
 'ta'		=> { 'x' => 'he',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
 'meie'		=> { 'x' => 'we',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 'me'		=> { 'x' => 'we',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 'mulle'	=> { 'x' => 'me' },
 'mind'		=> { 'x' => 'me' },
 'sulle'	=> { 'x' => 'you' },
 'sind'		=> { 'x' => 'you' },
 'talle'	=> { 'x' => 'him',
		     '#' => 'it' },
 'tema'		=> { 'x' => 'he/it',
		     '#' => 'gen.' },
 'nende'	=> { 'x' => 'her/their',
		     '#' => 'nom/acc fem/plural' },

 #  Other functional words
 'aga'		=> { 'x' => 'but' },
 'ainult'	=> { 'x' => 'only',
		     '#' => 'solely, merely, but' },
 'alates'	=> { 'x' => 'since',
 		     't' => 'p' },
 'alati'	=> { 'x' => 'always',
		     '#' => 'ever' },
 'all'		=> { 'x' => 'under',
		     '#' => 'beneath',
 		     't' => 'p' },
 'ees'		=> { 'x' => 'before',
		     '#' => 'in front of',
 		     't' => 'p' },
 'ei'		=> { 'x' => 'no',
		     '#' => 'interjection' },
 'et'		=> { 'x' => 'that' },
 'hoolimata'	=> { 'x' => 'in spite of',
 		     't' => 'p' },
 'iga'		=> { 'x' => 'every' },
 'ilma'		=> { 'x' => 'without',
 		     't' => 'p' },
 'ja'		=> { 'x' => 'and',
		     '#' => 'conjunction' },
 'jah'		=> { 'x' => 'yes',
		     '#' => 'interjection' },
 'jaoks'	=> { 'x' => 'for',
 		     't' => 'p' },
 'jooksul'	=> { 'x' => 'during',
		     '#' => 'while',
 		     't' => 'p' },
 'juures'	=> { 'x' => 'by',
		     '#' => 'at, near, while, during',
 		     't' => 'p' },
 'ka'		=> { 'x' => 'also',
		     '#' => 'as well, too' },
 'kelle'	=> { 'x' => 'whose',
		     '#' => 'pronoun/possessive adjective' },
 'kes'		=> { 'x' => 'who' },
 'koos'		=> { 'x' => 'with',
		     '#' => 'at, by',
 		     't' => 'p' },
 'kui'		=> { 'x' => 'as',
 		     't' => 'p' },
 'kui'		=> { 'x' => 'when',
		     '#' => 'while' },
 'kui'		=> { 'x' => 'when',
		     '#' => 'until, if' },
 'kui'		=> { 'x' => 'how',
		     '#' => 'as, like' },
 'kuni'		=> { 'x' => 'until',
 		     't' => 'p' },
 'kus'		=> { 'x' => 'where' },
 'l�bi'		=> { 'x' => 'through',
 		     't' => 'p' },
 'miks'		=> { 'x' => 'why' },
 'mis'		=> { 'x' => 'what',
		     '#' => 'interrogative/relative pronoun' },
 'missugune'	=> { 'x' => 'which',
		     '#' => 'interrogative/relative pronoun' },
 'mitte keegi'	=> { 'x' => 'nobody',
		     '#' => 'noone',
 		     't' => 'pro' },
 'm�nikord'	=> { 'x' => 'sometimes' },
 'nii et'	=> { 'x' => 'so that',
		     '#' => 'in order to' },
 'ning'		=> { 'x' => 'and' },
 'n��d'		=> { 'x' => 'now',
 		     't' => 'adv' },
 'palju'		=> { 'x' => 'much',
		     '#' => 'many' },
 'peal'		=> { 'x' => 'on',
 		     't' => 'p' },
 'piki'		=> { 'x' => 'along',
 		     't' => 'p' },
 'seal'		=> { 'x' => 'there',
		     '#' => 'here then as when since' },
 'see'		=> { 'x' => 'that' },
 'sees'		=> { 'x' => 'in',
 		     't' => 'p' },
 'seest'	=> { 'x' => 'out',
		     '#' => 'out of',
 		     't' => 'p' },
 'sellep�rast et'	=> { 'x' => 'because of',
		     '#' => 'owing to',
 			     't' => 'p' },
 'sest'		=> { 'x' => 'because' },
 'siin'		=> { 'x' => 'here' },
 'siis'		=> { 'x' => 'then' },
 'tagasi'	=> { 'x' => 'back',
		     '#' => 'backwards, behind' },
 'umbes'	=> { 'x' => 'about',
		     '#' => 'nearly, perhaps' },
 'vahel'	=> { 'x' => 'between',
 		     't' => 'p' },
 'vastas'	=> { 'x' => 'opposite',
 		     't' => 'p' },
 'vastu'	=> { 'x' => 'towards',
		     '#' => 'against',
 		     't' => 'p' },
 'veel'		=> { 'x' => 'still',
		     '#' => 'yet, besides' },
 'v�i'		=> { 'x' => 'or' },
 'v�lja arvatud'	=> { 'x' => 'except' },
 '�le'		=> { 'x' => 'over' },
 '�mber'	=> { 'x' => 'around' },

 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'null'		=> { 'x' => 'zero' },
 'esimene'	=> { 'x' => 'first' },
 '�kskord'	=> { 'x' => 'once',
		     '#' => 'adverb?' },
 'kaks'		=> { 'x' => 'two' },
 'kolm'		=> { 'x' => 'three' },
 'neli'		=> { 'x' => 'four' },
 'viis'		=> { 'x' => 'five' },
 'kuus'		=> { 'x' => 'six' },
 'seitse'	=> { 'x' => 'seven' },
 'kaheksa'	=> { 'x' => 'eight' },
 '�heksa'	=> { 'x' => 'nine' },
 'k�mme'	=> { 'x' => 'ten' },
 'kaksk�mmend'	=> { 'x' => 'twenty' },
 'kolmk�mmend'	=> { 'x' => 'thirty' },
 'nelik�mmend'	=> { 'x' => 'forty' },
 'viisk�mmend'	=> { 'x' => 'fifty' },
 'kuusk�mmend'	=> { 'x' => 'sixty' },
 'seitsek�mmend'	=> { 'x' => 'seventy' },
 'kaheksak�mmend'	=> { 'x' => 'eighty' },
 '�heksak�mmend'	=> { 'x' => 'ninety' },
 'sada'		=> { 'x' => 'hundred' },
 'tuhat'	=> { 'x' => 'thousand' },
 'miljon'	=> { 'x' => 'million' },

 # Days and months
 'p�hap�ev'	=> { 'x' => 'sunday' },
 'esmasp�ev'	=> { 'x' => 'monday' },
 'teisip�ev'	=> { 'x' => 'tuesday' },
 'kolmap�ev'	=> { 'x' => 'wednesday' },
 'neljap�ev'	=> { 'x' => 'thursday',
		     '#' => 'inv.' },
 'reede'	=> { 'x' => 'friday',
		     't' => 'n' },
 'laup�ev'	=> { 'x' => 'saturday',
		     't' => 'n' },
 'jaanuar'	=> { 'x' => 'january' },
 'veebruar'	=> { 'x' => 'february' },
 'm�rts'	=> { 'x' => 'march' },
 'aprill'	=> { 'x' => 'april' },
 'mai'		=> { 'x' => 'may' },
 'juuni'	=> { 'x' => 'june' },
 'juuli'	=> { 'x' => 'july' },
 'august'	=> { 'x' => 'august' },
 'september'	=> { 'x' => 'september' },
 'oktoober'	=> { 'x' => 'october' },
 'november'	=> { 'x' => 'november' },
 'detsember'	=> { 'x' => 'december' },

 # Key verbs
 'omama'	=> { 'x' => 'have',
		     '#' => 'KEY aux',
 		     't' => 'v' },
 'on'		=> { 'x' => 'have',
		     '#' => 'KEY aux',
		     'r' => 'omama',
 		     't' => 'v',
		     'c' => 'p',
		     'p' => '3',
		     'n' => 's' },
 'oli'		=> { 'x' => 'had',
		     '#' => 'KEY aux',
		     'r' => 'omama',
 		     't' => 'v',
		     'c' => 's',
		     'p' => '3',
		     'n' => 's' },

 #  olema
 'olema'	=> { 'x' => 'be',
		     '#' => 'also pron. his/its masc/neut',
 		     't' => 'v' },
 'olen'		=> { 'x' => 'am',
 		     'r' => 'olema',
		     't' => 'v',
		     'c' => 'p',
		     'p' => '1',
		     'n' => 's' },
 'oled'		=> { 'x' => 'are',
 		     'r' => 'olema',
		     't' => 'v',
		     'c' => 'p',
		     'p' => '2',
		     'n' => 's' },
 'on'		=> { 'x' => 'is',
		     'r' => 'olema',
 		     't' => 'v',
		     'c' => 'p',
		     'p' => '3',
		     'n' => 's' },
 'oleme'	=> { 'x' => 'are',
		     'r' => 'olema',
 		     't' => 'v',
		     'c' => 'p',
		     'p' => '3',
		     '#' => '1 they/we',
		     'n' => 'p' },
 'oleme'	=> { 'x' => 'are',
		     'r' => 'olema',
 		     't' => 'v',
		     'c' => 'p',
		     'p' => '2',
		     'n' => 'p' },
 'oli'		=> { 'x' => 'was',
 		     'r' => 'olema',
 		     't' => 'v',
		     'c' => 's',
		     'p' => '3',
		     'n' => 's' },
 'olnud'	=> { 'x' => 'been',
 		     'r' => 'olema',
 		     't' => 'v',
		     'c' => 'pp' },

 #  minema
 'minema'	=> { 'x' => 'go',
		     't' => 'v' },
  'l�hema'	=> { 'x' => 'go',
		     '#' => 'virtual base pres.',
  		     'r' => 'minama',
		     't' => 'v' },
   'l�hen'	=> { 'x' => '(i) go',
		     't' => 'v',
		     'r' => 'minema',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'p' },
   'l�hed'	=> { 'x' => '(you) go',
		     't' => 'v',
		     'r' => 'minema',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'p' },
  'l�ks'	=> { 'x' => '(he) went',
		     '#' => 'i, he/she/it',
		     't' => 'v',
		     'r' => 'ir',
		     'n' => 's',
		     'c' => 'i' },
  'l�ksid'	=> { 'x' => '(you) went',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'i' },
  'l�ksime'	=> { 'x' => '(we) went',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'i' },
  'l�ksite'	=> { 'x' => '(you) went',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'i' },
  'l�ksid'	=> { 'x' => '(they) went',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'i' },

 #  tegema
 'tegema'	=> { 'x' => 'do',
		     '#' => 'KEY WORD, also we/they do',
 		     't' => 'v' },
 'teen'		=> { 'x' => '(I) do',
 		     'r' => 'tegema',
		     't' => 'v' },
 'teed'		=> { 'x' => '(you) do',
 		     'r' => 'tegema',
		     't' => 'v' },
 'teeb'		=> { 'x' => '(he/you) does',
 		     'r' => 'tegema',
		     't' => 'v' },
 'tegi'		=> { 'x' => '(he) did',
		     '#' => 'past',
 		     'r' => 'tegema',
		     't' => 'v' },
 'tehtud'	=> { 'x' => 'done',
		     '#' => 'past participle',
 		     'r' => 'tegema',
		     't' => 'v' },


 # Vocabulary
 'aitama'	=> { 'x' => 'help',
 		     't' => 'v' },
 'aken'		=> { 'x' => 'window',
 		     't' => 'n' },
 'armastama'	=> { 'x' => 'love',
 		     't' => 'v' },
 'artikkel'	=> { 'x' => 'article',
 		     't' => 'n' },
 'avama'	=> { 'x' => 'open',
 		     't' => 'v' },
 'elama'	=> { 'x' => 'live',
 		     't' => 'v' },
 'elekter'	=> { 'x' => 'electricity',
 		     't' => 'n' },
 'istuma'	=> { 'x' => 'sit',
 		     't' => 'v' },
 'jooma'	=> { 'x' => 'drink',
 		     't' => 'v' },
 'j��ma'	=> { 'x' => 'stay',
 		     't' => 'v' },
 'kodu'		=> { 'x' => 'home',
 		     't' => 'n' },
 'kirjutama'	=> { 'x' => 'write',
 		     't' => 'v' },
 'k�sima'	=> { 'x' => 'ask',
 		     't' => 'v' },
 'lahkuma'	=> { 'x' => 'leave',
 		     't' => 'v' },
 'loll'		=> { 'x' => 'fool',
		     't' => 'n' },
 'lugema'	=> { 'x' => 'read',
		     '#' => 'count',
 		     't' => 'v' },
 'maja'		=> { 'x' => 'house',
 		     't' => 'n' },
 'minut'	=> { 'x' => 'minute',
 		     't' => 'n' },
 'm��ma'	=> { 'x' => 'sell',
 		     't' => 'v' },
 'ostma'	=> { 'x' => 'buy',
 		     't' => 'v' },
 'otsima'	=> { 'x' => 'seek',
		     '#' => 'look for',
 		     't' => 'v' },
 'r��kima'	=> { 'x' => 'speak',
 		     't' => 'v' },
 'suudlema'	=> { 'x' => 'kiss',
 		     't' => 'v' },
 'suur'		=> { 'x' => 'big',
 		     't' => 'a' },
 's��ma'	=> { 'x' => 'eat',
 		     't' => 'v' },
 'tark'		=> { 'x' => 'clever',
		     't' => 'n' },
 'teade'	=> { 'x' => 'message',
 		     't' => 'n' },
 'tooma'	=> { 'x' => 'bring',
 		     't' => 'v' },
 'tool'		=> { 'x' => 'chair',
 		     't' => 'n' },
 'tulema'	=> { 'x' => 'come',
 		     't' => 'v' },
 'tund'		=> { 'x' => 'hour',
 		     't' => 'n' },
 'tundma'	=> { 'x' => 'feel',
 		     't' => 'v' },
 'ujuma'	=> { 'x' => 'swim',
 		     't' => 'v' },
 'vaatama'	=> { 'x' => 'look at',
 		     't' => 'v' },
 'v�tma'	=> { 'x' => 'take',
 		     't' => 'v' },
 'v�ike'	=> { 'x' => 'small',
 		     't' => 'a' },
 '�ppima'	=> { 'x' => 'learn',
 		     't' => 'v' },
 '�ppima'	=> { 'x' => 'study',
 		     't' => 'v' },
 '�mbrik'	=> { 'x' => 'envelope',
 		     't' => 'n' },
 '�tlema'	=> { 'x' => 'say',
 		     't' => 'v' },
);
}

1;

