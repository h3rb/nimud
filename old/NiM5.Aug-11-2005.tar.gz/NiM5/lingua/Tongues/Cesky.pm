# vi: ts=8 sw=8 sts=8

package Tongues::Cesky;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Central European code page 1250
# not ISO 8859-2

# Alphabetical order
# A B C � D E F G H CH I J K L M N O P Q R � S � T U V W X Y Z �
# a b c � d e f g h ch i j k l m n o p q r � s � t u v w x y z �
# Variant letters
# � � � � � � � � � � �
# � � � � � � � � � � �

# Soft consonants: c � � j � � � �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::CentralEuroWin;

$charset = new Charsets::CentralEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun
 #  Noun gender
 [ 'ka',	'',	'',		'',	'n' ],	# fem.
 [ 'nice',	'n�k',	'',		'',	'n' ],	# fem.
 [ '�ka',	'ch',	'',		'',	'n' ],	# fem.
 [ 'ka',	'ec',	'',		'',	'n' ],	# fem.
 [ 'kyn�',	'ce',	'',		'',	'n' ],	# fem.
 [ 'ov�',	'',	'',		'',	'n' ],	# fem. surname
 [ 'kov�',	'ek',	'',		'',	'n' ],	# fem. surname
 [ 'cov�',	'ec',	'',		'',	'n' ],	# fem. surname
 [ 'lov�',	'el',	'',		'',	'n' ],	# fem. surname
 #  Noun plural
 [ 'ovi',	'',	'',		's',	'n' ],	# surname plur.
 # Adjective
 # Verb
 [ 'ne-',	'',	'not ',		'',	'v' ],	# negating prefix
 #  Verb present
 #   a-conjugation
 [ '�m',	'�t',	'(i) ',		'',	'v' ],	# 1s
 [ '�',	'�t',	'(you) ',	'',	'v' ],	# 2s
 [ '�',		'�t',	'(he) ',	's',	'v' ],	# 3s
 [ '�me',	'�t',	'(we) ',	'',	'v' ],	# 1p
 [ '�te',	'�t',	'(you) ',	'',	'v' ],	# 2p
 [ 'aj�',	'�t',	'(they) ',	'',	'v' ],	# 3p
 #   i-conjugation
 [ '�m',	'it',	'(i) ',		'',	'v' ],	# 1s
 [ '�',	'it',	'(you) ',	'',	'v' ],	# 2s
 [ '�',		'it',	'(he) ',	's',	'v' ],	# 3s
 [ '�me',	'it',	'(we) ',	'',	'v' ],	# 1p
 [ '�te',	'it',	'(you) ',	'',	'v' ],	# 2p
 [ '�',		'it',	'(they) ',	'',	'v' ],	# 3p
 #   e-conjugation (based on 3ps!)
 [ 'u',		'e',	'(i) ',		'',	'v' ],	# 1s
 [ 'e�',	'e',	'(you) ',	'',	'v' ],	# 2s
 [ 'e',		'e',	'(he) ',	's',	'v' ],	# 3s
 [ 'eme',	'e',	'(we) ',	'',	'v' ],	# 1p
 [ 'ete',	'e',	'(you) ',	'',	'v' ],	# 2p
 [ 'ou',	'e',	'(they) ',	'',	'v' ],	# 3p
 #   uje-conjunction
 [ 'uju',	'ovat',	'(i) ',		'',	'v' ],	# 1s
 [ 'uji',	'ovat',	'(i) ',		'',	'v' ],	# 1s
 [ 'uje�',	'ovat',	'(you) ',	'',	'v' ],	# 2s
 [ 'uje',	'ovat',	'(he) ',	's',	'v' ],	# 3s
 [ 'ujeme',	'ovat',	'(we) ',	'',	'v' ],	# 1p
 [ 'ujete',	'ovat',	'(you) ',	'',	'v' ],	# 2p
 [ 'ujou',	'ovat',	'(they) ',	'',	'v' ],	# 3p
 [ 'uj�',	'ovat',	'(they) ',	'',	'v' ],	# 3p
 #  Verb past
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translation		all words
# r -> root			irregular declensions, conjugations
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
#	interj -> interjection
# g -> gender:			nouns, pronouns, adjectives, articles
#	m -> masculine		default for words ending in hard consonant
#	f -> feminine		default for words ending in a
#	n -> neuter		default for words ending in o
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person
# c -> conjugation:
#	inf -> infinitive		default
#	p -> present
#	t -> past
#	pp -> past participle
#	imp -> imperative
# c -> case:
#	n -> nominative 			default
#	g -> genitive 
#	d -> dative 
#	a -> accusative 
#	v -> vocative 
#	l -> locative 
#	inst -> instrumental 

# Czech to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #    1st person singular
 'j�'		=> { 'x' => 'i',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'm�'		=> { 'x' => 'me',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'm�j'		=> { 'x' => 'my',
		     '#' => 'masc',
 		     'p' => '1',
		     'n' => 's' },
 'moje'		=> { 'x' => 'my',
		     '#' => 'fem',
 		     'p' => '1',
		     'n' => 's' },
 'moji'		=> { 'x' => 'my',
 		     'p' => '1',
		     'n' => 's' },
 #    1st person plural
 'my'		=> { 'x' => 'we',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 'n�'		=> { 'x' => 'our',
		     '#' => 'masc',
 		     'p' => '1',
		     'n' => 'p' },
 'na�e'		=> { 'x' => 'our',
		     '#' => 'fem',
 		     'p' => '1',
		     'n' => 'p' },
 #   2nd person
 #    2nd person singular
 'ty'		=> { 'x' => 'you',
		     '#' => 'sing. familiar',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'v�'		=> { 'x' => 'your',
		     '#' => 'masc',
 		     'p' => '2',
		     'n' => 's' },
 'va�e'		=> { 'x' => 'your',
		     '#' => 'fem',
 		     'p' => '2',
		     'n' => 's' },
 #    2nd person plural
 'vy'		=> { 'x' => 'you',
		     '#' => 'sing. and plural.; gram. plural',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 #   3rd person
 #    3rd person singular
 'on'		=> { 'x' => 'he' },
 'ona'		=> { 'x' => 'she',
		     '#' => 'also they' },
 'ono'		=> { 'x' => 'it' },
 'ji'		=> { 'x' => 'her',
		     '#' => 'obj. pron. or poss. adj.?' },
 #    3rd person plural
 'oni'		=> { 'x' => 'they' },
 'ony'		=> { 'x' => 'they' },
 #'ona'		=> { 'x' => 'they' },
 #   Demonstrative
 'to'		=> { 'x' => 'this',
		     '#' => 'sing. & plur.',
 		     't' => 'pro' },
 'ten'		=> { 'x' => 'that',
		     '#' => 'sing. & plur.',
 		     't' => 'pro' },
 #   Interrogative
 'co'		=> { 'x' => 'what',
		     '#' => 'sing. & plur.',
 		     't' => 'pro' },
 'kdo'		=> { 'x' => 'who',
		     '#' => 'person',
 		     't' => 'pro',
		     '#' => 'sing. & plur.' },
 #   Reflexive
 'se'		=> { 'x' => 'self',
		     '#' => 'invariant' },
 #  Other functional words
 'a'		=> { 'x' => 'and',
 		     't' => 'conj' },
 'aby'		=> { 'x' => 'for',
		     '#' => 'for, to, in order to, per',
		     't' => 'p' },
 'ale'		=> { 'x' => 'but',
 		     't' => 'conj' },
 'ani'		=> { 'x' => 'nor',
		     '#' => 'neither',
 		     't' => 'conj' },
 'ano'		=> { 'x' => 'yes',
 		     't' => 'interj' },
 'a�'		=> { 'x' => 'when',
		     '#' => 'not until, as many as' },
 'dnes'		=> { 'x' => 'today',
		     '#' => 'also noun?',
 		     't' => 'adv' },
 'do'		=> { 'x' => 'to',
		     '#' => 'into, until, by',
 		     't' => 'p',
		     '#' => 'gen.' },
 'doma'		=> { 'x' => 'home',
		     '#' => 'at home',
 		     't' => 'adv' },
 'dom�'		=> { 'x' => 'home',
		     '#' => 'homeward; of the houses',
 		     't' => 'adv' },
 'i'		=> { 'x' => 'and',
		     '#' => 'also, even',
 		     't' => 'conj' },
 'jak'		=> { 'x' => 'how',
		     '#' => 'interrogative' },
 'jako'		=> { 'x' => 'as',
		     '#' => 'like; prep. or adv.?' },
 'jen'		=> { 'x' => 'only',
		     '#' => 'just' },
 'je�t�'	=> { 'x' => 'else',
		     '#' => 'still, (not) yet' },
 'jenom'	=> { 'x' => 'only',
		     '#' => 'just' },
 'je�t�e'	=> { 'x' => 'it\'s a good thing',
		     '#' => 'multiword' },
 'jinak'	=> { 'x' => 'otherwise' },
 'k'		=> { 'x' => 'to',
		     '#' => 'towards, up to; for (purpose of)',
 		     't' => 'p',
		     '#' => 'dat.' },
 'ka�d�'	=> { 'x' => 'everybody',
		     '#' => 'each ,every, everone' },
 'kde'		=> { 'x' => 'where',
		     '#' => 'interrogative adv.?' },
 'kdy�'		=> { 'x' => 'when',
		     '#' => 'since, if; adv. or conj.?' },
 'kone�n�'	=> { 'x' => 'at last',
		     '#' => 'finally?',
 		     't' => 'adv' },
 'kter�'	=> { 'x' => 'which',
		     '#' => 'interrogative adj. or pron.?' },
 'mimochodem'	=> { 'x' => 'by the way' },
 'moc'		=> { 'x' => 'much',
		     '#' => 'a lot' },
 'na'		=> { 'x' => 'on',
		     '#' => 'upon, at, beside, with; to',
		     't' => 'p',
		     '#' => 'loc.' },
 'naproti'	=> { 'x' => 'opposite',
		     '#' => 'adj. or prep.?' },
 'ne'		=> { 'x' => 'no',
 		     't' => 'interj' },
 'nebo'		=> { 'x' => 'or',
 		     't' => 'conj' },
 'n�co'		=> { 'x' => 'something' },
 'n�kdy'	=> { 'x' => 'sometimes',
 		     't' => 'adv' },
 'nic'		=> { 'x' => 'nothing' },
 'o'		=> { 'x' => 'about',
		     '#' => 'loc. concerning',
 		     't' => 'p' },
 'od'		=> { 'x' => 'from',
		     '#' => 'gen. away from',
 		     't' => 'p' },
 'ov�em'	=> { 'x' => 'of course',
		     '#' => 'multiword' },
 'po'		=> { 'x' => 'up',
		     '#' => 'down, along, all over; after',
 		     't' => 'p',
		     '#' => 'loc.' },
 'proto�e'	=> { 'x' => 'because',
 		     't' => 'conj' },
 'samoz�ejm�'	=> { 'x' => 'of course',
		     '#' => 'naturally?' },
 'sle�na'	=> { 'x' => 'miss',
		     '#' => 'title' },
 'tady'		=> { 'x' => 'here',
		     '#' => 'cf. tam',
 		     't' => 'adv' },
 'tak�'		=> { 'x' => 'also',
		     '#' => 'too' },
 'taky'		=> { 'x' => 'also',
		     '#' => 'too' },
 'tak'		=> { 'x' => 'so',
		     '#' => 'entonces or tan?' },
 'tam'		=> { 'x' => 'there',
		     '#' => 'cf. tady',
 		     't' => 'adv' },
 'toti�'	=> { 'x' => 'namely',
		     '#' => 'you see' },
 'tu'		=> { 'x' => 'here',
		     '#' => 'cf. tam',
 		     't' => 'adv' },
 'u'		=> { 'x' => 'at',
		     '#' => 'gen.',
 		     't' => 'p' },
 'v'		=> { 'x' => 'in',
		     '#' => 'a, in, inside, into, on, per, within',
 		     't' => 'p',
		     '#' => 'loc.' },
 've'		=> { 'x' => 'in',
		     '#' => 'a, in, inside, into, on, per, within',
 		     't' => 'p' },
 'velmi'	=> { 'x' => 'very',
 		     't' => 'adv' },
 'vlastn�'	=> { 'x' => 'own',
		     '#' => 'one\'s own' },
 'z'		=> { 'x' => 'from',
 		     't' => 'p' },
 'za'		=> { 'x' => 'for',
		     '#' => 'acc. in exchange for',
 		     't' => 'p',
		     '#' => 'inst./acc. beyond, behind' },
 'zase'		=> { 'x' => 'again' },
 'zde'		=> { 'x' => 'here',
		     '#' => 'cf. tam',
 		     't' => 'adv' },
 'z�tra'	=> { 'x' => 'tomorrow',
		     '#' => 'also noun?',
 		     't' => 'adv' },
 'znova'	=> { 'x' => 'again',
 		     't' => 'adv' },
 '�e'		=> { 'x' => 'that',
		     '#' => 'also question tag:',
 		     't' => 'conj',
		     '#' => 'isn\'t it?; desu ne?; no?' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 't�i'		=> { 'x' => 'three' },
 'deset'	=> { 'x' => 'ten' },
 # Days and months
 'ned�le'	=> { 'x' => 'sunday' },
 'pond�l�'	=> { 'x' => 'monday' },
 '�ter�'	=> { 'x' => 'tuesday' },
 'st�eda'	=> { 'x' => 'wednesday' },
 '�tvrtek'	=> { 'x' => 'thursday' },
 'p�tek'	=> { 'x' => 'friday' },
 'sobota'	=> { 'x' => 'saturday' },
 'leden'	=> { 'x' => 'january' },
 '�nor'		=> { 'x' => 'february' },
 'b�ezen'	=> { 'x' => 'march' },
 'duben'	=> { 'x' => 'april' },
 'kv�ten'	=> { 'x' => 'may' },
 '�erven'	=> { 'x' => 'june' },
 '�ervenec'	=> { 'x' => 'july' },
 'srpen'	=> { 'x' => 'august' },
 'z���'		=> { 'x' => 'september' },
 '��jen'	=> { 'x' => 'october' },
 'listopad'	=> { 'x' => 'november' },
 'prosinec'	=> { 'x' => 'december' },
 # Key verbs
 #  b�t - to be
 'b�t'		=> { 'x' => 'be',
 		     't' => 'v' },
 'jsem'		=> { 'x' => 'am',
 		     'r' => 'b�t',
		     't' => 'v',
		     'p' => '1',
		     'n' => 's' },
 'jsi'		=> { 'x' => 'are',
 		     'r' => 'b�t',
		     't' => 'v',
		     'p' => '2',
		     'n' => 's' },
 'je'		=> { 'x' => 'is',
 		     'r' => 'b�t',
		     't' => 'v',
		     'p' => '3',
		     'n' => 's' },
 'nen�'		=> { 'x' => 'is not',
		     '#' => 'isn\'t; irreg. neg. form!!',
 		     'r' => 'b�t',
		     't' => 'v',
		     'p' => '3',
		     'n' => 's' },
 'jsme'		=> { 'x' => 'are',
 		     'r' => 'b�t',
		     't' => 'v',
		     'p' => '1',
		     'n' => 'p' },
 'jste'		=> { 'x' => 'are',
 		     'r' => 'b�t',
		     't' => 'v',
		     'p' => '2',
		     'n' => 'p' },
 'jsou'		=> { 'x' => 'are',
 		     'r' => 'b�t',
		     't' => 'v',
		     'p' => '3',
		     'n' => 'p' },
 #  m�t - to have
 'm�t'		=> { 'x' => 'have',
 		     't' => 'v' },
 'maj�'		=> { 'x' => 'have',
 		     'r' => 'm�t',
		     't' => 'v',
		     'p' => '3',
		     'n' => 'p' },
 #  d�lat - to do, to make
 'd�lat'	=> { 'x' => 'do',
		     '#' => 'make',
 		     't' => 'v' },
 #  j�t - to go
 'j�t'		=> { 'x' => 'go',
 		     't' => 'v' },
 #  moct - can, to be able
 'moct'		=> { 'x' => 'can',
 		     't' => 'v' },
 'moci'		=> { 'x' => 'can',
		     '#' => 'formal infinitive',
 		     'r' => 'moct',
		     't' => 'v' },
 'm��e'		=> { 'x' => 'can',
		     '#' => 'paradigm based on this form!',
 		     'r' => 'moct',
		     't' => 'v' },
 'mohu'		=> { 'x' => 'can',
		     '#' => 'formal 1ps',
 		     'r' => 'moct',
		     't' => 'v' },
 'mohou'	=> { 'x' => 'can',
		     '#' => 'formal 3pp',
 		     'r' => 'moct',
		     't' => 'v' },
 # Vocabulary
 #  Verbs ... infinitive
 #  Nouns ... nominative
 #  Adjectives ... masculine nominitive
 'ahoj'		=> { 'x' => 'hello',
		     '#' => 'goodbye',
 		     't' => 'interj' },
 'anglicky'	=> { 'x' => 'english',
		     '#' => 'in english' },
 'auto'		=> { 'x' => 'car',
 		     't' => 'n' },
 'autobus'	=> { 'x' => 'bus',
 		     't' => 'n' },
 'banka'	=> { 'x' => 'bank',
 		     't' => 'n' },
 'blb�'		=> { 'x' => 'stupid',
 		     't' => 'a' },
 'bohud�k'	=> { 'x' => 'fortunately',
 		     't' => 'adv' },
 'bohu�el'	=> { 'x' => 'unfortunately',
 		     't' => 'adv' },
 'byt'		=> { 'x' => 'apartment',
 		     't' => 'n' },
 'cizinec'	=> { 'x' => 'foreigner',
		     '#' => 'person',
 		     't' => 'n' },
 'cukr'		=> { 'x' => 'sugar',
 		     't' => 'n' },
 '�ech'		=> { 'x' => 'czech',
 		     't' => 'n' },
 '�esky'	=> { 'x' => 'czech',
		     '#' => 'in czech' },
 '�esk�'	=> { 'x' => 'czech',
 		     't' => 'a' },
 '�ip'		=> { 'x' => 'chip',
		     '#' => 'microchip',
 		     't' => 'n' },
 '�l�nek'	=> { 'x' => 'article',
 		     't' => 'n' },
 '�okol�da'	=> { 'x' => 'chocolate',
 		     't' => 'n' },
 '��bel'	=> { 'x' => 'devil',
 		     't' => 'n' },
 'dcera'	=> { 'x' => 'daughter',
		     '#' => 'person',
 		     't' => 'n' },
 'dialog'	=> { 'x' => 'dialogue',
 		     't' => 'n' },
 'divn�'	=> { 'x' => 'strange',
 		     't' => 'a' },
 'dobr�'	=> { 'x' => 'good',
		     '#' => 'dobr�, dobrou',
 		     't' => 'a' },
 'dob�e'	=> { 'x' => 'well',
 		     't' => 'adv' },
 'dom�cnost'	=> { 'x' => 'household',
 		     't' => 'n' },
 'doufat'	=> { 'x' => 'hope',
 		     't' => 'v' },
 'emigrant'	=> { 'x' => 'immigrant',
		     '#' => '�migr�',
 		     't' => 'n' },
 'farmacie'	=> { 'x' => 'pharmacy',
 		     't' => 'n' },
 'gar�'	=> { 't' => 'n',
 		     'g' => 'f' },
 'hlad'		=> { 'x' => 'hunger',
 		     't' => 'n' },
 'honem'	=> { 'x' => 'in a hurry',
		     '#' => 'multiword',
 		     't' => 'adv' },
 'hotel'	=> { 'x' => 'hotel',
 		     't' => 'n' },
 'h�m�'		=> { 'x' => 'thunder',
		     '#' => 'impersonal verb',
 		     't' => 'v' },
 'chalupa'	=> { 'x' => 'cottage',
		     '#' => 'chalet',
 		     't' => 'n' },
 'charakter'	=> { 'x' => 'character',
 		     't' => 'n' },
 'chata'	=> { 'x' => 'cottage',
		     '#' => 'chalet',
 		     't' => 'n' },
 'chr�m'	=> { 'x' => 'chrome',
 		     't' => 'n' },
 'chud�'	=> { 'x' => 'poor',
 		     't' => 'a' },
 'chu�'		=> { 'x' => 'appetite',
 		     't' => 'n' },
 'jablo�'	=> { 'x' => 'apple tree',
		     '#' => 'multiword',
 		     't' => 'n' },
 'jmenovat'	=> { 'x' => 'be called',
		     '#' => 'name; also refl.',
 		     't' => 'v' },
 'jogurt'	=> { 'x' => 'yoghurt',
 		     't' => 'n' },
 'kabelka'	=> { 'x' => 'handbag',
 		     't' => 'n' },
 'kancel��'	=> { 'x' => 'office',
 		     't' => 'n',
		     'g' => 'f' },
 'kluk'		=> { 'x' => 'boy',
 		     't' => 'n' },
 'koberec'	=> { 'x' => 'carpet',
 		     't' => 'n',
		     'g' => 'm' },
 'kolo'		=> { 'x' => 'wheel',
		     '#' => 'bicycle',
 		     't' => 'n' },
 'konference'	=> { 'x' => 'conference',
 		     't' => 'n' },
 'kosmonaut'	=> { 'x' => 'astronaut',
		     '#' => 'cosmonaut',
 		     't' => 'n' },
 'koup�'	=> { 'x' => 'purchase',
 		     't' => 'v' },
 'krk'		=> { 'x' => 'throat',
 		     't' => 'n' },
 'letadlo'	=> { 'x' => 'aeroplane',
 		     't' => 'n' },
 'm�sto'	=> { 'x' => 'town',
 		     't' => 'n' },
 'man�el'	=> { 'x' => 'husband',
		     '#' => 'person',
 		     't' => 'n' },
 'man�elka'	=> { 'x' => 'wife',
		     '#' => 'person',
 		     't' => 'n' },
 'man�el�'	=> { 'x' => 'couple',
		     '#' => 'person; married couple',
 		     't' => 'n',
		     '#' => 'mr & mrs' },
 'matka'	=> { 'x' => 'mother',
		     '#' => 'person',
 		     't' => 'n' },
 'mile'		=> { 'x' => 'kindly',
		     '#' => 'adv?' },
 'mil�'		=> { 'x' => 'kind',
 		     't' => 'a' },
 'm�le'		=> { 'x' => 'mile',
 		     't' => 'n' },
 'm�sto'	=> { 'x' => 'place',
		     '#' => 'job',
 		     't' => 'n' },
 'mluvit'	=> { 'x' => 'speak',
 		     't' => 'v' },
 'mu�'		=> { 'x' => 'man',
		     '#' => 'husband; person',
 		     't' => 'n',
		     'g' => 'm' },
 'mysl'		=> { 'x' => 'mind',
 		     't' => 'n' },
 'nakl�dat'	=> { 'x' => 'load',
 		     't' => 'v' },
 'nakonec'	=> { 'x' => 'ultimately',
		     '#' => 'in the end' },
 'noc'		=> { 'x' => 'night',
 		     't' => 'n' },
 'norm�ln�'	=> { 'x' => 'normally',
 		     't' => 'adv' },
 'novin��'	=> { 't' => 'n',
 		     'g' => 'm' },
 'ob�an'	=> { 'x' => 'citizen',
 		     't' => 'n' },
 'ob�d'		=> { 'x' => 'lunch',
 		     't' => 'n' },
 'ocet'		=> { 'x' => 'vinegar',
 		     't' => 'n' },
 'od�v'		=> { 'x' => 'clothing',
 		     't' => 'n' },
 'omlouvat'	=> { 'x' => 'apologise',
		     '#' => 'apologize',
 		     't' => 'v',
		     '#' => 'also refl.' },
 'otec'		=> { 'x' => 'father',
		     '#' => 'person',
 		     't' => 'n' },
 'p�n'		=> { 'x' => 'gentleman',
		     '#' => 'man',
 		     't' => 'n' },
 'pan�'		=> { 'x' => 'lady',
 		     't' => 'n' },
 'pas'		=> { 'x' => 'passport',
 		     't' => 'n' },
 'pero'		=> { 'x' => 'pen',
 		     't' => 'n' },
 'pneumatika'	=> { 'x' => 'tyre',
 		     't' => 'n' },
 'podnik'	=> { 'x' => 'business',
		     '#' => 'enterprise, firm',
 		     't' => 'n' },
 'poch�zet'	=> { 'x' => 'come from',
		     '#' => 'multiword',
 		     't' => 'v' },
 'pom�hat'	=> { 'x' => 'help',
 		     't' => 'v' },
 'pr�ce'	=> { 'x' => 'work',
 		     't' => 'n',
		     'g' => 'f' },
 'praha'	=> { 'x' => 'prague',
		     '#' => 'proper, place',
 		     't' => 'n' },
 'pr�vo'	=> { 'x' => 'right',
 		     't' => 'n' },
 'p�edstavit'	=> { 'x' => 'introduce',
		     '#' => 'also refl.',
 		     't' => 'v' },
 'prst'		=> { 'x' => 'finger',
 		     't' => 'n' },
 'pr�vodce'	=> { 'x' => 'guide',
 		     't' => 'n',
		     'g' => 'm' },
 'p�vodn�'	=> { 'x' => 'originally',
 		     't' => 'adv' },
 'ragby'	=> { 'x' => 'rugby',
 		     't' => 'n' },
 'rodina'	=> { 'x' => 'family',
 		     't' => 'n' },
 'rychle'	=> { 'x' => 'quickly',
 		     't' => 'adv' },
 'rychl�'	=> { 'x' => 'quick',
 		     't' => 'a' },
 '�ada'		=> { 'x' => 'line',
		     '#' => 'row, series',
 		     't' => 'n' },
 'sendvi�'	=> { 'x' => 'sandwich',
 		     't' => 'n' },
 'sly�et'	=> { 'x' => 'hear',
		     '#' => '(sly��)',
 		     't' => 'v' },
 'smysl'	=> { 'x' => 'sense',
		     '#' => 'noun or verb?' },
 'soud'		=> { 'x' => 'court',
 		     't' => 'n' },
 'sp�t'		=> { 'x' => 'sleep',
 		     't' => 'v' },
 'sp�chat'	=> { 'x' => 'hurry',
 		     't' => 'v' },
 'student'	=> { 'x' => 'student',
		     '#' => 'person',
 		     't' => 'n' },
 'syn'		=> { 'x' => 'son',
		     '#' => 'person',
 		     't' => 'n' },
 '�ek'		=> { 'x' => 'cheque',
 		     't' => 'n' },
 '�kola'	=> { 'x' => 'school',
 		     't' => 'n' },
 '�patn�'	=> { 'x' => 'badly',
 		     't' => 'adv' },
 '���va'	=> { 'x' => 'juice',
 		     't' => 'n' },
 'tlumo�n�k'	=> { 'x' => 'interpreter',
		     '#' => 'person',
 		     't' => 'n' },
 'tov�rna'	=> { 'x' => 'factory',
 		     't' => 'n' },
 'tramvaj'	=> { 'x' => 'tram',
 		     't' => 'n',
		     'g' => 'f' },
 'tuna'		=> { 'x' => 'tonne',
 		     't' => 'n' },
 'turista'	=> { 'x' => 'tourist',
		     '#' => 'person',
 		     't' => 'n' },
 '�hel'		=> { 'x' => 'coal',
 		     't' => 'n' },
 'umo��ovat'	=> { 'x' => 'make possible',
		     '#' => 'multiword',
 		     't' => 'v' },
 'univerzita'	=> { 'x' => 'university',
 		     't' => 'n' },
 '��edn�k'	=> { 'x' => 'office-worker',
		     '#' => 'person',
 		     't' => 'n' },
 'vejce'	=> { 'x' => 'egg',
 		     't' => 'n',
		     'g' => 'n' },
 'v�kend'	=> { 'x' => 'weekend',
 		     't' => 'n' },
 'v�tr'		=> { 'x' => 'wind',
 		     't' => 'n' },
 'vlastn�'	=> { 'x' => 'actually',
		     '#' => 'adv.?' },
 'vlk'		=> { 'x' => 'wolf',
		     '#' => 'animate',
 		     't' => 'n' },
 'vlna'		=> { 'x' => 'wave',
		     '#' => 'wool',
 		     't' => 'n' },
 'voda'		=> { 'x' => 'water',
 		     't' => 'n' },
 'zam�stn�n�'	=> { 'x' => 'employment',
 		     't' => 'n' },
 'zn�t'		=> { 'x' => 'know',
 		     't' => 'v' },
 'zub'		=> { 'x' => 'tooth',
 		     't' => 'n' },
 '�ena'		=> { 'x' => 'woman',
		     '#' => 'wife; person',
 		     't' => 'n' },
 '�irafa'	=> { 'x' => 'giraffe',
		     '#' => 'animate',
 		     't' => 'n' },
 '�urnalista'	=> { 'x' => 'journalist',
		     '#' => 'person',
 		     't' => 'n' },
);
}

1;

