# vi: ts=8 sw=8

package Tongues::Hanguk;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set EUC-KR

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::EUC_KR;

$charset = new Charsets::EUC_KR;

# Table for converting words to root form
$grammar = [
 # Nouns
 [ '��',	'',	'as for ',	',',	'm' ],	# topic marker?
 [ '����',	'in ',	'',		'',	'n' ],
 [ '��',	'',	'as for ',	',',	'n' ],	# topic marker particle after vowel
 [ '��',	'',	'as for ',	',',	'n' ],	# topic marker particle after vowel
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 [ '��',	'��',	'',		'',	'v' ],	# inf. cas. ind. pres.
 [ '��',	'��',	'',		'',	'v' ],	# inf. int. ind. pres.
 # Verb past
 [ '�',	'��',	'',		'ed',	'v' ],	# inf. int. ind. past
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine		default for words ending in a
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative

# Korean to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 #  Other functional words
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 '�Ͽ���'	=> { 'x' => 'sunday' },
 '������'	=> { 'x' => 'monday' },
 'ȭ����'	=> { 'x' => 'tuesday' },
 '������'	=> { 'x' => 'wednesday' },
 '�����'	=> { 'x' => 'thursday' },
 '�ݿ���'	=> { 'x' => 'friday' },
 '�����'	=> { 'x' => 'saturday' },
 '1��'		=> { 'x' => 'january' },
 '2��'		=> { 'x' => 'february' },
 '3��'		=> { 'x' => 'march' },
 '4��'		=> { 'x' => 'april' },
 '5��'		=> { 'x' => 'may' },
 '6��'		=> { 'x' => 'june' },
 '7��'		=> { 'x' => 'july' },
 '8��'		=> { 'x' => 'august' },
 '9��'		=> { 'x' => 'september' },
 '10��'		=> { 'x' => 'october' },
 '11��'		=> { 'x' => 'november' },
 '12��'		=> { 'x' => 'december' },
 # Key verbs
 '�ִ�'		=> { 'x' => 'be',
		     '#' => 'exist',
 		     't' => 'v' },
 # Vocabulary
 '���̳ʸ�'	=> { 'x' => 'binary',
 		     't' => 'a' },
 '�ѱ�'		=> { 'x' => 'korean',
		     '#' => 'adjective or noun?' },
 'Ȩ������'	=> { 'x' => 'homepage',
 		     't' => 'n' },
 '���ڵ�'	=> { 'x' => 'encoding',
 		     't' => 'n' },
 '���ͳ�'	=> { 'x' => 'internet',
 		     't' => 'n' },
 '����'		=> { 'x' => 'same' },
 '�ݽ�������'	=> { 'x' => 'netscape',
 		     't' => 'n' },
 '����'		=> { 'x' => 'mail',
 		     't' => 'n' },
 '�޽���'	=> { 'x' => 'message',
 		     't' => 'n' },
 '�����׷�'	=> { 'x' => 'newsgroup',
 		     't' => 'n' },
 '����Ʈ'	=> { 'x' => 'site',
 		     't' => 'n' },
 '���'		=> { 'x' => 'person',
 		     't' => 'n' },
 '�����̽�'	=> { 'x' => 'space' },
 '�ٸ�'		=> { 'x' => 'another',
		     '#' => 'different',
 		     't' => 'a' },
 '���ڵ�'	=> { 'x' => 'decoding',
 		     't' => 'n' },
 '����'	=> { 'x' => 'follow',
 		     't' => 'v' },
 '��'		=> { 'x' => 'web',
 		     't' => 'n' },
);
}

1;

