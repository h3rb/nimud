# vi: ts=8 sw=8

package Tongues::Hrvatski;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Central European CP1250
# not ISO 8859-2

# Alphabetical order
# A B C � � D D� � E F G H I J K L Lj M N Nj O P R S � T U V Z �
# a b c � � d d� � e f g h i j k l lj m n nj o p r s � t u v z �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::CentralEuroWin;

$charset = new Charsets::CentralEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# Hrvatski to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 'de'	=> { 'x' => 'of',
	     't' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 'nedjelja'	=> { 'x' => 'sunday' },
 'ponedjeljak'	=> { 'x' => 'monday' },
 'utorak'	=> { 'x' => 'tuesday' },
 'srijeda'	=> { 'x' => 'wednesday' },
 '�etvrtak'	=> { 'x' => 'thursday' },
 'petak'	=> { 'x' => 'friday' },
 'subota'	=> { 'x' => 'saturday' },
 'sije�anj'	=> { 'x' => 'january' },
 'velja�a'	=> { 'x' => 'february' },
 'o�ujak'	=> { 'x' => 'march' },
 'travanj'	=> { 'x' => 'april' },
 'svibanj'	=> { 'x' => 'may' },
 'lipanj'	=> { 'x' => 'june' },
 'srpanj'	=> { 'x' => 'july' },
 'kolovoz'	=> { 'x' => 'august' },
 'rujan'	=> { 'x' => 'september' },
 'listopad'	=> { 'x' => 'october' },
 'studeni'	=> { 'x' => 'november' },
 'prosinac'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 '�lanak'	=> { 'x' => 'article',
		     't' => 'n' },
);
}

1;

