#! /usr/bin/perl

# Convert UTF-8 text to HTML entities

use strict;

my $state = 0;
my $len = 0;
my $u;

while ((my $c = getc) ne undef) {
	my $o = ord($c);
	if ($state == 0) {
		if ($o >= 0xc0) {
			$state = 1;
			if ($o >= 0xfe) {
				die "** Invalid initial byte\n";
			} elsif ($o >= 0xfc) {
				$len = 6;
			} elsif ($o >= 0xf8) {
				$len = 5;
			} elsif ($o >= 0xf0) {
				$len = 4;
			} elsif ($o >= 0xe0) {
				$len = 3;
			} else {
				$len = 2;
			}
			$u = $o & ((1 << (7 - $len)) - 1);
		} else {
			print "$c";
		}
	} else {
		if (($o & 0xc0) != 0x80) {
			die "** Invalid follow-up byte\n";
		} else {
			$u <<= 6;
			$u += ($o & 0x3f);
			--$len;
			if ($len <= 1) {
				$state = 0;
				print "&#$u;";
			}
		}
	}
}
