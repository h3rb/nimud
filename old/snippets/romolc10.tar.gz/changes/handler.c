Hans Birkeland
Apr 12 1995

This file contains modifications needed to handler.c.


Add after material_lookup():

/* returns material name -- ROM OLC temp patch */
char *material_name( sh_int num )
{
    return "unknown";
}

