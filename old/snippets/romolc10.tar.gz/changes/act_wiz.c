Jason Dinkel
Mar. 27 1995

Modified for ROM OLC
Hans Birkeland
Apr 14 1995

This file contains modifications needed to act_wiz.c.

---- do_mstat
Just the 2 OLC lines, the others are there for you to get your bearings.

    sprintf( buf, "Master: %s.  Leader: %s.  Affected by: %s.\n\r",
	    victim->master      ? victim->master->name   : "(none)",
	    victim->leader      ? victim->leader->name   : "(none)",
	    affect_bit_name( victim->affected_by ) );
    send_to_char( buf, ch );

    sprintf( buf, "Security: %d.\n\r", ch->pcdata->security );	/* OLC */
    send_to_char( buf, ch );					/* OLC */

    sprintf( buf, "Short description: %s.\n\rLong  description: %s",
	    victim->short_descr,
	    victim->long_descr[0] != '\0' ? victim->long_descr
	                                  : "(none).\n\r" );

---- do_mset
At the beginning:
	send_to_char( "  thirst drunk full security",		 ch );	/* OLC */

At the end:
    if ( !str_cmp( arg2, "security" ) )	/* OLC */
    {
        if ( IS_NPC( victim ) )
        {
            send_to_char( "Not on NPC's.\n\r", ch );
            return;
        }

	if ( value > ch->pcdata->security || value < 0 )
	{
	    if ( ch->pcdata->security != 0 )
	    {
		sprintf( buf, "Valid security is 0-%d.\n\r",
		    ch->pcdata->security );
		send_to_char( buf, ch );
	    }
	    else
	    {
		send_to_char( "Valid security is 0 only.\n\r", ch );
	    }
	    return;
	}
	victim->pcdata->security = value;
	return;
    }

