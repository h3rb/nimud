Jason Dinkel
Mar. 27 1995

Modified for ROM OLC
Hans Birkeland
Apr 14 1995

This file contains modifications needed to interp.c.

----cmd_table

    /*
     * OLC
     */
    { "edit",		do_olc,		POS_DEAD,    0,  LOG_NORMAL, 1 },
    { "asave",          do_asave,	POS_DEAD,    0,  LOG_NORMAL, 1 },
    { "alist",		do_alist,	POS_DEAD,    0,  LOG_NORMAL, 1 },
    { "resets",		do_resets,	POS_DEAD,    0,  LOG_NORMAL, 1 },

