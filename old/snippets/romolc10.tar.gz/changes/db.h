Hans Birkeland
Apr 12 1995

This file contains modifications needed to db.h

Add these lines:

/* func from db.c */
extern void assign_area_vnum( int vnum );                    /* OLC */



/* from db2.c */
 
void convert_mobile( MOB_INDEX_DATA *pMobIndex );            /* OLC ROM */
void convert_objects( void );                                /* OLC ROM */
void convert_object( OBJ_INDEX_DATA *pObjIndex );            /* OLC ROM */

