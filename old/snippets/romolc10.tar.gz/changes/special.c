Jason Dinkel
Mar. 27 1995

Modified for ROM OLC
Hans Birkeland
Apr 14 1995

This file contains modifications needed to special.c.

Single change to this file.

This code doesn't change any workings in the actual game but it sure
does make OLC much nicer.  Drop this stuff in in place of the old
spec_lookup.

/*
 * Special Functions Table.	OLC
 */
const	struct	spec_type	spec_table	[ ] =
{
    /*
     * Special function commands.
     */
    { "spec_breath_any",	spec_breath_any		},
    { "spec_breath_acid",	spec_breath_acid	},
    { "spec_breath_fire",	spec_breath_fire	},
    { "spec_breath_frost",	spec_breath_frost	},
    { "spec_breath_gas",	spec_breath_gas		},
    { "spec_breath_lightning",	spec_breath_lightning	},
    { "spec_cast_adept",	spec_cast_adept		},
    { "spec_cast_cleric",	spec_cast_cleric	},
/*  { "spec_cast_ghost",	spec_cast_ghost		}, removed ROM OLC */
    { "spec_cast_judge",	spec_cast_judge		},
    { "spec_cast_mage",		spec_cast_mage		},
/*  { "spec_cast_psionicist",	spec_cast_psionicist	}, removed ROM OLC */
    { "spec_cast_undead",	spec_cast_undead	},
    { "spec_executioner",	spec_executioner	},
    { "spec_fido",		spec_fido		},
    { "spec_guard",		spec_guard		},
    { "spec_janitor",		spec_janitor		},
    { "spec_mayor",		spec_mayor		},
    { "spec_poison",		spec_poison		},
/*  { "spec_repairman",		spec_repairman		}, removed ROM OLC */
    { "spec_thief",		spec_thief		},
    { "spec_puff",      	spec_puff		},      /* ROM OLC */
    
    /*
     * End of list.
     */
    { "",			0	}
};



/*****************************************************************************
 Name:		spec_string
 Purpose:	Given a function, return the appropriate name.
 Called by:	<???>
 ****************************************************************************/
char *spec_string( SPEC_FUN *fun )	/* OLC */
{
    int cmd;
    
    for ( cmd = 0; spec_table[cmd].spec_fun[0] != '\0'; cmd++ )
	if ( fun == spec_table[cmd].spec_fun )
	    return spec_table[cmd].spec_name;

    return 0;
}



/*****************************************************************************
 Name:		spec_lookup
 Purpose:	Given a name, return the appropriate spec fun.
 Called by:	do_mset(act_wiz.c) load_specials,reset_area(db.c)
 ****************************************************************************/
SPEC_FUN *spec_lookup( const char *name )	/* OLC */
{
    int cmd;
    
    for ( cmd = 0; spec_table[cmd].spec_name[0] != '\0'; cmd++ )
	if ( !str_cmp( name, spec_table[cmd].spec_name ) )
	    return spec_table[cmd].spec_fun;

    return 0;
}
