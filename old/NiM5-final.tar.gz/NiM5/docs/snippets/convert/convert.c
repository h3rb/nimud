/******************************************************************************
 * Locke's   __ -based on merc v2.2-____        NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5.1a  Version 5.1a (ALPHA)          *
 * |  /   \  __|  \__/  |  | |  |      |        unreleased+revamped 2004      *
 * |       ||  |        |  \_|  | ()   |                                      *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/

/*
 * These routines are for saving area files (renumbered), and can be attached
 * to other mud softwares to convert their files to NiM5 format.
 *
 * You will have to tweak it a bit to make sure all the values are being used
 * properly.  Good luck!
 */

#if defined(BSD)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


#include "mud.h"
#include "comm.h"


void save_actors( FILE *fp, ZONE_DATA *pZone )
{
    int iHash;
    ACTOR_INDEX_DATA *pActorIndex;
    TRIGGER_DATA *script;
    ATTACK_DATA *attack;
    int iTrade;
    int iAttack;
    int sn;

    fprintf( fp, "#ACTORS\n" );
    for( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for( pActorIndex = actor_index_hash[iHash]; pActorIndex != NULL; pActorIndex = pActorIndex->next )
        {
            if ( pActorIndex != NULL && pActorIndex->zone == pZone )
            {
                fprintf( fp, "#%d\n",     pActorIndex->vnum );
                fprintf( fp, "N %s~\n",   fix_string( pActorIndex->name ) );
                fprintf( fp, "SD %s~\n",  fix_string( pActorIndex->short_descr ) );
                fprintf( fp, "LD\n %s~\n", fix_string( pActorIndex->long_descr ) );
                fprintf( fp, "D\n %s~\n",  fix_string( pActorIndex->description ) );
                fprintf( fp, "A %d\n",    pActorIndex->act );
                fprintf( fp, "AB %d\n",   pActorIndex->bonuses );
                fprintf( fp, "M %d\n",    pActorIndex->money );
                fprintf( fp, "S %d\n",    pActorIndex->sex );
                fprintf( fp, "Sz %d\n",   pActorIndex->size );
                fprintf( fp, "K %d E %d\n", pActorIndex->karma, pActorIndex->exp );
            
                {
                  SPELL_BOOK_DATA *pSpellBook;
                  for ( pSpellBook = pActorIndex->pSpells;  pSpellBook != NULL;  pSpellBook = pSpellBook->next )
                  fprintf( fp, "Spell %d\n", pSpellBook->vnum );
                }     

                fprintf( fp, "AP %d %d %d %d %d\n",
                    pActorIndex->perm_str,
                    pActorIndex->perm_int,
                    pActorIndex->perm_wis,
                    pActorIndex->perm_dex,
                    pActorIndex->perm_con );

                if ( pActorIndex->pShop != NULL )
                {
                     fprintf( fp, "Shop\n" );

                     fprintf( fp, " T " );
                     for( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
                     fprintf( fp, " %d", pActorIndex->pShop->buy_type[iTrade] );
                     fprintf( fp, "\n" );

                     fprintf( fp, " P %d %d\n", pActorIndex->pShop->profit_buy,
                                                pActorIndex->pShop->profit_sell );
                     fprintf( fp, " H %d %d\n", pActorIndex->pShop->open_hour,
                                                pActorIndex->pShop->close_hour  );
                     fprintf( fp, " F %d\n",    pActorIndex->pShop->shop_flags  );
                     fprintf( fp, " R %d\n",    pActorIndex->pShop->repair_rate );
                     fprintf( fp, " BI %d ",  pActorIndex->pShop->buy_index   );
                     fprintf( fp, " CI %d ",  pActorIndex->pShop->comp_index  );
                     fprintf( fp, " SI %d\n", pActorIndex->pShop->sell_index  );
                     fprintf( fp, " Str1\n %s~\n", fix_string( pActorIndex->pShop->no_such_item ) );
                     fprintf( fp, " Str2\n %s~\n", fix_string( pActorIndex->pShop->cmd_not_buy ) );
                     fprintf( fp, " Str3\n %s~\n", fix_string( pActorIndex->pShop->list_header ) );
                     fprintf( fp, " Str4\n %s~\n", fix_string( pActorIndex->pShop->hours_excuse ) );
                     fprintf( fp, "EndShop\n" );
                }

                for ( script = pActorIndex->triggers;  script != NULL;  script = script->next )
                    fprintf( fp, "Sc %d\n", script->script->vnum );

                for ( iAttack = 0;  iAttack < MAX_ATTACK_DATA; iAttack++ )
                {
                    if ( pActorIndex->attacks[iAttack] != NULL )
                    {
                        attack = pActorIndex->attacks[iAttack];
                        fprintf( fp, "At %d %d %d %d\n",
                          iAttack,
                          attack->dam1,
                          attack->dam2,
                          attack->idx );
                    }
                }

                for ( sn = 0; sn < MAX_SKILL; sn++ )
                {
                    if ( skill_table[sn].name == NULL )
                    break;
                    if ( pActorIndex->learned[sn] > 0 )
                    {
							fprintf( fp, "Sk %d '%s'\n",
                                pActorIndex->learned[sn], skill_table[sn].name );
                    }
                }

                fprintf( fp, "End\n\n" );
            }
        }
    }
    fprintf( fp, "#0\n\n\n\n" );
    return;
}



void save_props( FILE *fp, ZONE_DATA *pZone )
{
    int iHash;
    PROP_INDEX_DATA *pPropIndex;
    BONUS_DATA *pAf;
    EXTRA_DESCR_DATA *pEd;

    fprintf( fp, "#OBJDATA\n" );
    for( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for( pPropIndex = prop_index_hash[iHash]; pPropIndex != NULL; pPropIndex = pPropIndex->next )
        {
            if ( pPropIndex != NULL && pPropIndex->zone == pZone )
            {
                fprintf( fp, "#%d\n",     pPropIndex->vnum );
                fprintf( fp, "N %s~\n",   fix_string( pPropIndex->name ) );
                fprintf( fp, "SD %s~\n",  fix_string( pPropIndex->short_descr ) );
                fprintf( fp, "D\n%s~\n",  fix_string( pPropIndex->description ) );
                fprintf( fp, "A\n%s~\n",  fix_string( pPropIndex->action_descr ) );
                fprintf( fp, "DR\n%s~\n", fix_string( pPropIndex->real_description ) );
                fprintf( fp, "L %d\n",    pPropIndex->level );
                fprintf( fp, "T %d\n",    pPropIndex->item_type );
                fprintf( fp, "E %d\n",    pPropIndex->extra_flags );
                fprintf( fp, "W %d\n",    pPropIndex->wear_flags);
                fprintf( fp, "Sz %d\n",   pPropIndex->size );
                fprintf( fp, "Ti %d\n",   pPropIndex->timer );
                fprintf( fp, "Wt %d\n",   pPropIndex->weight );
                fprintf( fp, "C %d\n",    pPropIndex->cost );

                switch ( pPropIndex->item_type )
                {
                default:
                fprintf( fp, "V %d %d %d %d\n",  pPropIndex->value[0],
                                                 pPropIndex->value[1],
                                                 pPropIndex->value[2],
                                                 pPropIndex->value[3] );
                    break;

                case ITEM_PILL:
                case ITEM_POTION:
                case ITEM_SCROLL:
                case ITEM_FOUNTAIN:
                fprintf( fp, "V %d %d %d %d\n",  pPropIndex->value[0],
                                        SKILLSN( pPropIndex->value[1] ),
                                        SKILLSN( pPropIndex->value[2] ),
                                        SKILLSN( pPropIndex->value[3] ) );
                    break;

                case ITEM_STAFF:
                case ITEM_WAND:
                fprintf( fp, "V %d %d %d %d\n",  pPropIndex->value[0],
                                                 pPropIndex->value[1],
                                                 pPropIndex->value[2],
                                        SKILLSN( pPropIndex->value[3] ) );
                    break;
                }

                for( pAf = pPropIndex->bonus; pAf != NULL; pAf = pAf->next )
                {
                fprintf( fp, "Af %d %d %d %d %d\n",  pAf->location,
                                                     pAf->modifier,
                                                     pAf->type,
                                                     pAf->duration,
                                                     pAf->bitvector );
                }

                for( pEd = pPropIndex->extra_descr; pEd != NULL; pEd = pEd->next )
                {
				fprintf( fp, "ED %s~\n%s~\n", pEd->keyword,
										 fix_string( pEd->description ) );
                }

                fprintf( fp, "End\n\n" );
            }
        }
    }
    fprintf( fp, "#0\n\n\n\n" );
    return;
}



void save_scenes( FILE *fp, ZONE_DATA *pZone )
{
    int iHash;
    SCENE_INDEX_DATA *pSceneIndex;
    EXTRA_DESCR_DATA *pEd;
    SPAWN_DATA *pSpawn;
    EXIT_DATA *pExit;
    int door;

    fprintf( fp, "#SCENES\n" );
    for( iHash = 0; iHash < MAX_KEY_HASH; iHash++ )
    {
        for( pSceneIndex = scene_index_hash[iHash]; pSceneIndex != NULL; pSceneIndex = pSceneIndex->next )
        {
            if ( pSceneIndex->zone == pZone )
            {
                fprintf( fp, "#%d\n",    pSceneIndex->vnum );
                fprintf( fp, "N %s~\n",  fix_string( pSceneIndex->name ) );
                fprintf( fp, "Ref %d\n", pSceneIndex->template );
                fprintf( fp, "D\n%s~\n", fix_string( pSceneIndex->description ) );
		fprintf( fp, "C\n%s~\n", fix_string( pSceneIndex->client ) );
                REMOVE_BIT(pSceneIndex->scene_flags, SCENE_MARK);
                fprintf( fp, "F %d\n",   pSceneIndex->scene_flags  );
                fprintf( fp, "S %d\n",   pSceneIndex->sector_type );
                fprintf( fp, "M %d\n",   pSceneIndex->max_people  );
                fprintf( fp, "W %d\n",   pSceneIndex->wagon       );
                fprintf( fp, "T %d\n",   pSceneIndex->terrain     );

                for ( pEd = pSceneIndex->extra_descr; pEd != NULL;
                      pEd = pEd->next )
                {
					fprintf( fp, "ED %s~\n%s~\n",   pEd->keyword,
                                              fix_string( pEd->description ) );
                }

                for( pSpawn = pSceneIndex->spawn_first; pSpawn != NULL; pSpawn = pSpawn->next )
                {
                    if ( pSpawn != NULL )
                    {
                      fprintf( fp, "R %c %d %d %d %d\n", pSpawn->command,
                                                         pSpawn->rs_vnum,
                                                         pSpawn->loc,
                                                         pSpawn->percent,
                                                         pSpawn->num );
                    }
                }

                for( door = 0; door < MAX_DIR; door++ )
                {
                    if ( (pExit = pSceneIndex->exit[door] ) != NULL
                          && pExit->vnum > 0
                          && get_scene_index( pExit->vnum ) != NULL )
                    {
                        fprintf( fp, "Dr %d %d %d %d\n", door,
                                                        pExit->rs_flags,
                                                        pExit->key,
                                                        pExit->vnum );

                        fprintf( fp, "%s~\n", fix_string( pExit->description ) );
                        if ( pExit->keyword != NULL )
                        fprintf( fp, "%s~\n", fix_string( pExit->keyword ) );
                        else fprintf( fp, "~\n" );

                    }
                }
                fprintf( fp, "End\n\n" );
            }
        }
    }
    fprintf( fp, "#0\n\n\n\n" );
    return;
}



void save_zone( ZONE_DATA *pZone )
{
    FILE *fp;

    REMOVE_BIT( pZone->zone_flags, ZONE_CHANGED );
    if ( ( fp = fopen( pZone->filename, "w" ) ) == NULL )
    {
    bug( "Open_zone: fopen", 0 );
    perror( pZone->filename );
    }

    fprintf( fp, "#ZONE \n" );
    fprintf( fp, "N %s~\n",        fix_string( pZone->name ) );
    if ( !MTD(pZone->repop) )
    fprintf( fp, "R %s~\n",        fix_string( pZone->repop ) );
    fprintf( fp, "B %s~\n",        fix_string( pZone->builders ) );
    fprintf( fp, "V %d %d\n",      pZone->lvnum, pZone->uvnum );
    fprintf( fp, "S %d\n",         pZone->security );
    if ( IS_SET(pZone->zone_flags, ZONE_STATIC) )
    fprintf( fp, "Static\n" );
    fprintf( fp, "End\n\n\n\n" );

    save_scripts( fp, pZone );
    save_actors( fp, pZone );
    save_props( fp, pZone );
    save_scenes( fp, pZone );

    fprintf( fp, "#$\n" );

    fclose( fp );
    return;
}

/*          zsave zone
 */
void cmd_zsave( PLAYER_DATA *ch, char *argument )
{
    char arg1 [MAX_INPUT_LENGTH];
    ZONE_DATA *pZone;
    FILE *fp;
    int value;

    fp = NULL;

    if ( ch == NULL )       /* Do an autosave */
    {
        save_zone_list();
        for( pZone = zone_first; pZone != NULL; pZone = pZone->next )
        {
            save_zone( pZone );
            REMOVE_BIT( pZone->zone_flags, ZONE_CHANGED );
        }

        save_config();
        save_contents();
        return;
    }

    smash_tilde( argument );
    strcpy( arg1, argument );

    if ( arg1[0] == '\0' )
    {
        send_to_char( "Syntax:\n\r", ch );
        send_to_char( "  zsave list     - saves the zone.lst file\n\r",    ch );
        send_to_char( "  zsave zone     - saves the zone your in\n\r",     ch );
        send_to_char( "  zsave changed  - saves all changed zones\n\r",    ch );
        send_to_char( "  zsave world    - saves the world! (db dump)\n\r", ch );
        send_to_char( "  zsave helps    - saves the help files\n\r", ch );
        send_to_char( "\n\r", ch );
        send_to_char( "\n\r", ch );
        cmd_zsave( ch, "changed" );
        return;
    }

    /*
     * Snarf the value (which need not be numeric).
     */
    value = atoi( arg1 );

    if ( ( pZone = get_zone_data( value ) ) == NULL && is_number( arg1 ) )
    {
        send_to_char( "That zone does not exist.\n\r", ch );
        return;
    }

    if ( is_number( arg1 ) )
    {
        save_zone_list();
        save_zone( pZone );
        return;
    }

    if ( !str_cmp( "world", arg1 ) || !str_cmp( "all", arg1 ) )
    {
        save_zone_list();
        for( pZone = zone_first; pZone != NULL; pZone = pZone->next )
        {
            save_zone( pZone );
        }

        save_config();
        save_contents();
        save_helps();

        send_to_char( "You saved the world.\n\r", ch );
        return;
    }

    if ( !str_prefix( arg1, "changed" ) )
    {
        char buf[WORK_STRING_LENGTH];

        save_zone_list();


        send_to_char( "Saved zones:\n\r", ch );
        sprintf( buf, "None.\n\r" );


        for( pZone = zone_first; pZone != NULL; pZone = pZone->next )
        {
            if ( IS_SET(pZone->zone_flags, ZONE_CHANGED) )
            {
                if ( !IS_SET(pZone->zone_flags, ZONE_STATIC) )
                save_zone( pZone );
                sprintf( buf, "%24s - '%s'%s\n\r", pZone->name, pZone->filename,
                      IS_SET(pZone->zone_flags, ZONE_STATIC) ?
                          " - static zone, not saved" : "" );
                send_to_char( buf, ch );
            }
        }
        if ( !str_cmp( buf, "None.\n\r" ) )
             send_to_char( buf, ch );
        return;
    }

    if ( !str_prefix( arg1, "list" ) )
    {
      save_zone_list();
      return;
    }

    /* Save Help File */
    if(!str_prefix(arg1, "helps"))
    {
        save_helps();
        send_to_char( "Helps Saved.\n\r", ch);
        return;
    }

    if ( !str_prefix( arg1, "zone" ) )
    {
      save_zone_list();
      save_zone( ch->in_scene->zone );
      send_to_char( "Zone saved.\n\r", ch );
      return;
    }

    cmd_zsave( ch, "" );
    return;
}








/****************************************************************************
 * Locke's   __                      __         NIM Server Software         *
 * ___ ___  (__)__    __ __   __ ___|  | v5     Version 5 (ALPHA)           *
 * |  /   \  __|  \__/  |  | |  |      |        unreleased+revamped 2004    *
 * |       ||  |        |  \_|  | ()   |                                    *
 * |    |  ||  |  |__|  |       |      |                                    *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud  *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool     *
 ****************************************************************************/

/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
 *  God Wars Mud improvements copyright (C) 1994, 1995, 1996 by Richard    *
 *  Woolcock.  This mud is NOT to be copied in whole or in part, or to be  *
 *  run without the permission of Richard Woolcock.  Nobody else has       *
 *  permission to authorise the use of this code.                          *
 ***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "merc.h"

#if !defined(macintosh)
extern	int	_filbuf		args( (FILE *) );
#endif


/*
 * Snarf an 'area' header line.
 */
void load_area( FILE *fp )
{
    AREA_DATA *pArea;

    pArea		= alloc_perm( sizeof(*pArea) );
    pArea->reset_first	= NULL;
    pArea->reset_last	= NULL;
    pArea->name		= fread_string( fp );
    pArea->area_flags	= AREA_LOADING;		/* OLC */
    pArea->security	= 1;			/* OLC */
    pArea->builders	= str_dup( "None" );	/* OLC */
    pArea->lvnum	= 0;			/* OLC */
    pArea->uvnum	= 0;			/* OLC */
    pArea->vnum		= 0;			/* OLC */
    pArea->filename	= str_dup( strArea );	/* OLC */
    pArea->age		= 15;
    pArea->nplayer	= 0;

    if ( area_first == NULL )
	area_first = pArea;
    if ( area_last  != NULL )
    {
	area_last->next = pArea;
	REMOVE_BIT(area_last->area_flags, AREA_LOADING);	/* OLC */
    }
    area_last	= pArea;
    pArea->next	= NULL;

    top_area++;
    return;
}

void gw_load_area( FILE *fp )
{
    AREA_DATA *pArea;
    char      *word;
    bool      fMatch;

    pArea               = alloc_perm( sizeof(*pArea) );
    pArea->age          = 15;
    pArea->nplayer      = 0;
    pArea->filename     = str_dup( strArea );
    pArea->vnum         = top_area;
    pArea->name         = str_dup( "New Area" );
    pArea->builders     = str_dup( "" );
/*    pArea->repop        = str_dup( "Tock.\n\r" ); */
    pArea->security     = 1;
    pArea->lvnum        = 0;
    pArea->uvnum        = 0;
    pArea->area_flags   = 0;

    for ( ; ; )
    {
       word   = feof( fp ) ? "End" : fread_word( fp );
       fMatch = FALSE;

       switch ( UPPER(word[0]) )
       {
           case 'N':
            SKEY( "Name", pArea->name );
            break;
           case 'S':
             KEY( "Security", pArea->security, fread_number( fp ) );
            break;
           case 'V':
            if ( !str_cmp( word, "VNUMs" ) )
            {
                pArea->lvnum = fread_number( fp );
                pArea->uvnum = fread_number( fp );
            }
            break;
           case 'E':
             if ( !str_cmp( word, "End" ) )
             {
                 fMatch = TRUE;
                 if ( area_first == NULL )
                    area_first = pArea;
                 if ( area_last  != NULL )
                    area_last->next = pArea;
                 area_last   = pArea;
                 pArea->next = NULL;
                 top_area++;
                 return;
            }
            break;
           case 'B':
            SKEY( "Builders", pArea->builders );
            break;
           case 'R':
/*            SKEY( "Repop",  pArea->repop ); */
            if ( !str_cmp( word, "Reset" ) )
            {
                fread_to_eol( fp );
                fMatch = TRUE;
            }
            break;
       }
    }

}



/*
 * Sets vnum range for area using OLC protection features.
 */
void assign_area_vnum( int vnum )
{
    if ( area_last->lvnum == 0 || area_last->uvnum == 0 )
	area_last->lvnum = area_last->uvnum = vnum;
    if ( vnum != URANGE( area_last->lvnum, vnum, area_last->uvnum ) )
	if ( vnum < area_last->lvnum )
	    area_last->lvnum = vnum;
	else
	    area_last->uvnum = vnum;
    return;
}


/*
 * Snarf a mob section.
 */
void gw_load_mobiles( FILE *fp )
{
    MOB_INDEX_DATA *pMobIndex;

    if ( area_last == NULL )	/* OLC */
    {
	bug( "Load_mobiles: no #AREA seen yet.", 0 );
	exit( 1 );
    }
    for ( ; ; )
    {
	sh_int vnum;
	char letter;
	int iHash;

	letter				= fread_letter( fp );
	if ( letter != '#' )
	{
	    bug( "Load_mobiles: # not found.", 0 );
	    exit( 1 );
	}

	vnum				= fread_number( fp );
	if ( vnum == 0 )
	    break;

	fBootDb = FALSE;
	if ( get_mob_index( vnum ) != NULL )
	{
	    bug( "Load_mobiles: vnum %d duplicated.", vnum );
	    exit( 1 );
	}
	fBootDb = TRUE;

	pMobIndex			= alloc_perm( sizeof(*pMobIndex) );
	pMobIndex->vnum			= vnum;
	pMobIndex->area			= area_last;	/* OLC */
	pMobIndex->player_name		= fread_string( fp );
	pMobIndex->short_descr		= fread_string( fp );
	pMobIndex->long_descr		= fread_string( fp );
	pMobIndex->description		= fread_string( fp );

	pMobIndex->long_descr[0]	= UPPER(pMobIndex->long_descr[0]);
	pMobIndex->description[0]	= UPPER(pMobIndex->description[0]);

	pMobIndex->act			= fread_number( fp ) | ACT_IS_NPC;
	pMobIndex->affected_by		= fread_number( fp );
	pMobIndex->itemaffect		= 0;
	pMobIndex->pShop		= NULL;
	pMobIndex->alignment		= fread_number( fp );
	letter				= fread_letter( fp );
	pMobIndex->level		= number_fuzzy( fread_number( fp ) );

	/*
	 * The unused stuff is for imps who want to use the old-style
	 * stats-in-files method.
	 */
	pMobIndex->hitroll		= fread_number( fp );	/* Unused */
	pMobIndex->ac			= fread_number( fp );	/* Unused */
	pMobIndex->hitnodice		= fread_number( fp );	/* Unused */
	/* 'd'		*/		  fread_letter( fp );	/* Unused */
	pMobIndex->hitsizedice		= fread_number( fp );	/* Unused */
	/* '+'		*/		  fread_letter( fp );	/* Unused */
	pMobIndex->hitplus		= fread_number( fp );	/* Unused */
	pMobIndex->damnodice		= fread_number( fp );	/* Unused */
	/* 'd'		*/		  fread_letter( fp );	/* Unused */
	pMobIndex->damsizedice		= fread_number( fp );	/* Unused */
	/* '+'		*/		  fread_letter( fp );	/* Unused */
	pMobIndex->damplus		= fread_number( fp );	/* Unused */
	pMobIndex->gold			= fread_number( fp );	/* Unused */
	/* xp can't be used! */		  fread_number( fp );	/* Unused */
	/* position	*/		  fread_number( fp );	/* Unused */
	/* start pos	*/		  fread_number( fp );	/* Unused */

	/*
	 * Back to meaningful values.
	 */
	pMobIndex->sex			= fread_number( fp );

	if ( letter != 'S' )
	{
	    bug( "Load_mobiles: vnum %d non-S.", vnum );
	    exit( 1 );
	}

	iHash			= vnum % MAX_KEY_HASH;
	pMobIndex->next		= mob_index_hash[iHash];
	mob_index_hash[iHash]	= pMobIndex;
	top_mob_index++;
	top_vnum_mob = top_vnum_mob < vnum ? vnum : top_vnum_mob; /* OLC */
	assign_area_vnum( vnum );	/* OLC */
	kill_table[URANGE(0, pMobIndex->level, MAX_LEVEL-1)].number++;
    }

    return;
}



/*
 * Snarf an obj section.
 */
void gw_load_objects( FILE *fp )
{
    OBJ_INDEX_DATA *pObjIndex;

    if ( area_last == NULL )	/* OLC */
    {
	bug( "Load_objects: no #AREA seen yet.", 0 );
	exit( 1 );
    }
    for ( ; ; )
    {
	sh_int vnum;
	char letter;
	int iHash;

	letter				= fread_letter( fp );
	if ( letter != '#' )
	{
	    bug( "Load_objects: # not found.", 0 );
	    exit( 1 );
	}

	vnum				= fread_number( fp );
	if ( vnum == 0 )
	    break;

	fBootDb = FALSE;
	if ( get_obj_index( vnum ) != NULL )
	{
	    bug( "Load_objects: vnum %d duplicated.", vnum );
	    exit( 1 );
	}
	fBootDb = TRUE;

	pObjIndex			= alloc_perm( sizeof(*pObjIndex) );
	pObjIndex->vnum			= vnum;
	pObjIndex->area			= area_last;	/* OLC */
	pObjIndex->name			= fread_string( fp );
	pObjIndex->short_descr		= fread_string( fp );
	pObjIndex->description		= fread_string( fp );
	/* Action description */	  fread_string( fp );

	pObjIndex->short_descr[0]	= LOWER(pObjIndex->short_descr[0]);
	pObjIndex->description[0]	= UPPER(pObjIndex->description[0]);

	pObjIndex->item_type		= fread_number( fp );
	pObjIndex->extra_flags		= fread_number( fp );
	pObjIndex->wear_flags		= fread_number( fp );
	pObjIndex->value[0]		= fread_number( fp );
	pObjIndex->value[1]		= fread_number( fp );
	pObjIndex->value[2]		= fread_number( fp );
	pObjIndex->value[3]		= fread_number( fp );
	pObjIndex->weight		= fread_number( fp );
	pObjIndex->cost			= fread_number( fp );	/* Unused */
	pObjIndex->affected		= NULL;
	pObjIndex->extra_descr		= NULL;
	pObjIndex->chpoweron		= NULL;
	pObjIndex->chpoweroff		= NULL;
	pObjIndex->chpoweruse		= NULL;
	pObjIndex->victpoweron		= NULL;
	pObjIndex->victpoweroff		= NULL;
	pObjIndex->victpoweruse		= NULL;
	pObjIndex->spectype		= 0;
	pObjIndex->specpower		= 0;
	/* Cost per day */		  fread_number( fp );
/*
	if ( pObjIndex->item_type == ITEM_POTION )
	    SET_BIT(pObjIndex->extra_flags, ITEM_NODROP);
*/
	for ( ; ; )
	{
	    char letter;

	    letter = fread_letter( fp );

	    if ( letter == 'A' )
	    {
		AFFECT_DATA *paf;

		paf			= alloc_perm( sizeof(*paf) );
		paf->type		= -1;
		paf->duration		= -1;
		paf->location		= fread_number( fp );
		paf->modifier		= fread_number( fp );
		paf->bitvector		= 0;
		paf->next		= pObjIndex->affected;
		pObjIndex->affected	= paf;
		top_affect++;
	    }

	    else if ( letter == 'E' )
	    {
		EXTRA_DESCR_DATA *ed;

		ed			= alloc_perm( sizeof(*ed) );
		ed->keyword		= fread_string( fp );
		ed->description		= fread_string( fp );
		ed->next		= pObjIndex->extra_descr;
		pObjIndex->extra_descr	= ed;
		top_ed++;
	    }

	    else if ( letter == 'Q' )
	    {
		pObjIndex->chpoweron	= fread_string( fp );
		pObjIndex->chpoweroff	= fread_string( fp );
		pObjIndex->chpoweruse	= fread_string( fp );
		pObjIndex->victpoweron	= fread_string( fp );
		pObjIndex->victpoweroff	= fread_string( fp );
		pObjIndex->victpoweruse	= fread_string( fp );
		pObjIndex->spectype	= fread_number( fp );
		pObjIndex->specpower	= fread_number( fp );
	    }

	    else
	    {
		ungetc( letter, fp );
		break;
	    }
	}

	/*
	 * Translate spell "slot numbers" to internal "skill numbers."
	 */
	switch ( pObjIndex->item_type )
	{
	case ITEM_PILL:
	case ITEM_POTION:
	case ITEM_SCROLL:
	    pObjIndex->value[1] = slot_lookup( pObjIndex->value[1] );
	    pObjIndex->value[2] = slot_lookup( pObjIndex->value[2] );
	    pObjIndex->value[3] = slot_lookup( pObjIndex->value[3] );
	    break;

	case ITEM_STAFF:
	case ITEM_WAND:
	    pObjIndex->value[3] = slot_lookup( pObjIndex->value[3] );
	    break;
	}

	iHash			= vnum % MAX_KEY_HASH;
	pObjIndex->next		= obj_index_hash[iHash];
	obj_index_hash[iHash]	= pObjIndex;
	top_obj_index++;
	top_vnum_obj = top_vnum_obj < vnum ? vnum : top_vnum_obj; /* OLC */
	assign_area_vnum( vnum );	/* OLC */
    }

    return;
}



/*
 * Snarf a reset section.
 */
void load_resets( FILE *fp )	/* OLC */
{
    RESET_DATA *pReset = NULL;
    int mvn = 0;

    if ( area_last == NULL )
    {
	bug( "Load_resets: no #AREA seen yet.", 0 );
	exit( 1 );
    }

    for ( ; ; )
    {
/*
	EXIT_DATA	*pexit;
*/
	ROOM_INDEX_DATA *pRoomIndex;
	char             letter;
	int arg1, arg2, arg3;

	if ( ( letter = fread_letter( fp ) ) == 'S' )
	    break;

	if ( letter == '*' )
	{
	    fread_to_eol( fp );
	    continue;
	}

	/* if_flag */	  fread_number( fp );
	arg1	= fread_number( fp );
	arg2	= fread_number( fp );
	arg3	= (letter == 'G' || letter == 'R')
			    ? 0 : fread_number( fp );
			  fread_to_eol( fp );

	/*
	 * Validate parameters.
	 * We're calling the index functions for the side effect.
	 */
	switch ( letter )
	{
	default:
	    bug( "Load_resets: bad command '%c'.", letter );
	    exit( 1 );
	    break;

	case 'M':
	    get_mob_index  ( arg1 );
	    get_room_index ( arg3 );

	    pReset		= alloc_perm( sizeof(*pReset) );
	    pReset->arg1	= arg1;
	    pReset->arg2	= arg2;
	    pReset->arg3	= arg3;
	    pReset->command	= letter;
	    mvn = arg3;

	    break;

	case 'O':
	    get_obj_index  ( arg1 );
	    get_room_index ( arg3 );

	    pReset		= alloc_perm( sizeof(*pReset) );
	    pReset->arg1	= arg1;
	    pReset->arg2	= arg2;
	    pReset->arg3	= arg3;
	    pReset->command	= letter;

	    break;

	case 'P':
	    get_obj_index  ( arg1 );
	    get_obj_index  ( arg3 );

	    pReset		= alloc_perm( sizeof(*pReset) );
	    pReset->arg1	= arg1;
	    pReset->arg2	= arg2;
	    pReset->arg3	= arg3;
	    pReset->command	= letter;

	    break;

	case 'G':
	case 'E':
	    get_room_index ( mvn );
	    get_obj_index  ( arg1 );

	    pReset		= alloc_perm( sizeof(*pReset) );
	    pReset->arg1	= arg1;
	    pReset->arg2	= arg2;
	    pReset->arg3	= arg3;
	    pReset->command	= letter;

	    break;

	case 'D':
/* kavirp
	    pRoomIndex = get_room_index( arg1 );

	    if ( arg2 < 0
	    ||   arg2 > MAX_DIR
	    || ( pexit = pRoomIndex->exit[arg2] ) == NULL
	    || !IS_SET( pexit->rs_flags, EX_ISDOOR ) )
	    {
		bug( "Load_resets: 'D': exit %d not door.", arg2 );
		exit( 1 );
	    }

	    switch ( arg3 )
	    {
		default:
		    bug( "Load_resets: 'D': bad 'locks': %d.", arg3 );
		    exit( 1 ); break;
		case 0: break;
		case 1: SET_BIT( pexit->exit_info, EX_CLOSED ); break;
		case 2: SET_BIT( pexit->exit_info, EX_CLOSED );
			SET_BIT( pexit->exit_info, EX_LOCKED ); break;
	    }
*/
	    break;

	case 'R':
	    pRoomIndex		= get_room_index( arg1 );

	    if ( arg2 < 0 || arg2 > MAX_DIR )
	    {
		bug( "Load_resets: 'R': bad exit %d.", arg2 );
		exit( 1 );
	    }

	    pReset		= alloc_perm( sizeof(*pReset) );
	    pReset->arg1	= arg1;
	    pReset->arg2	= arg2;
	    pReset->arg3	= arg3;
	    pReset->command	= letter;

	    break;
	}

	if ( pReset )
	{
	    if ( area_last->reset_first == NULL )
		area_last->reset_first	= pReset;
	    if ( area_last->reset_last  != NULL )
		area_last->reset_last->next	= pReset;
	    
	    area_last->reset_last	= pReset;
	    pReset->next		= NULL;
	    top_reset++;
	}
    }

    return;
}



/*
 * Snarf a room section.
 */
void load_rooms( FILE *fp )
{
    ROOM_INDEX_DATA *pRoomIndex;

    if ( area_last == NULL )
    {
	bug( "Load_resets: no #AREA seen yet.", 0 );	/* OLC */
	exit( 1 );
    }

    for ( ; ; )
    {
	sh_int vnum;
	char letter;
	int door;
	int iHash;

	letter				= fread_letter( fp );
	if ( letter != '#' )
	{
	    bug( "Load_rooms: # not found.", 0 );
	    exit( 1 );
	}

	vnum				= fread_number( fp );
	if ( vnum == 0 )
	    break;

	fBootDb = FALSE;
	if ( get_room_index( vnum ) != NULL )
	{
	    bug( "Load_rooms: vnum %d duplicated.", vnum );
	    exit( 1 );
	}
	fBootDb = TRUE;

	pRoomIndex			= alloc_perm( sizeof(*pRoomIndex) );
	pRoomIndex->people		= NULL;
	pRoomIndex->contents		= NULL;
	pRoomIndex->to_obj		= NULL;
	pRoomIndex->extra_descr		= NULL;
	pRoomIndex->area		= area_last;
	pRoomIndex->vnum		= vnum;
	pRoomIndex->name		= fread_string( fp );
	pRoomIndex->description		= fread_string( fp );
	/* Area number */		  fread_number( fp );
	pRoomIndex->room_flags		= fread_number( fp );
	pRoomIndex->added_flags		= 0;
	pRoomIndex->sector_type		= fread_number( fp );
	pRoomIndex->light		= 0;
	pRoomIndex->blood		= 0;
	pRoomIndex->passed		= 0;
	pRoomIndex->roomtext		= NULL;
	for ( door = 0; door <= 4; door++ )
	{
	    pRoomIndex->track[door] 	= str_dup( "" );
	    pRoomIndex->track_dir[door] = 0;
	}
	for ( door = 0; door <= 5; door++ )
	    pRoomIndex->exit[door] = NULL;

	for ( ; ; )
	{
	    letter = fread_letter( fp );

	    if ( letter == 'S' )
		break;

	    if ( letter == 'D' )
	    {
		EXIT_DATA *pexit;
		int locks;

		door = fread_number( fp );
		if ( door < 0 || door > 5 )
		{
		    bug( "Fread_rooms: vnum %d has bad door number.", vnum );
		    exit( 1 );
		}

		pexit			= alloc_perm( sizeof(*pexit) );
		pexit->description	= fread_string( fp );
		pexit->keyword		= fread_string( fp );
		pexit->exit_info	= 0;
		pexit->rs_flags		= 0;	/* OLC */
		locks			= fread_number( fp );
		pexit->key		= fread_number( fp );
		pexit->vnum		= fread_number( fp );

		switch ( locks )
		{
		case 1: pexit->exit_info = EX_ISDOOR;                break;
		case 2: pexit->exit_info = EX_ISDOOR | EX_PICKPROOF; break;
		}

		pRoomIndex->exit[door]	= pexit;
		top_exit++;
	    }
	    else if ( letter == 'E' )
	    {
		EXTRA_DESCR_DATA *ed;

		ed			= alloc_perm( sizeof(*ed) );
		ed->keyword		= fread_string( fp );
		ed->description		= fread_string( fp );
		ed->next		= pRoomIndex->extra_descr;
		pRoomIndex->extra_descr	= ed;
		top_ed++;
	    }
	    else if ( letter == 'T' )
	    {
		ROOMTEXT_DATA *rt;

		rt			= alloc_perm( sizeof(*rt) );
		rt->input		= fread_string( fp );
		rt->output		= fread_string( fp );
		rt->choutput		= fread_string( fp );
		rt->name		= fread_string( fp );
		rt->type		= fread_number( fp );
		rt->power		= fread_number( fp );
		rt->mob			= fread_number( fp );
		rt->next		= pRoomIndex->roomtext;
		pRoomIndex->roomtext	= rt;
		top_rt++;
	    }
	    else
	    {
		bug( "Load_rooms: vnum %d has flag not 'DES'.", vnum );
		exit( 1 );
	    }
	}

	iHash			= vnum % MAX_KEY_HASH;
	pRoomIndex->next	= room_index_hash[iHash];
	room_index_hash[iHash]	= pRoomIndex;
	top_room++;
	top_vnum_room = top_vnum_room < vnum ? vnum : top_vnum_room; /* OLC */
	assign_area_vnum( vnum );	/* OLC */
    }

    return;
}



/*
 * Snarf a shop section.
 */
void load_shops( FILE *fp )
{
    SHOP_DATA *pShop;

    for ( ; ; )
    {
	MOB_INDEX_DATA *pMobIndex;
	int iTrade;

	pShop			= alloc_perm( sizeof(*pShop) );
	pShop->keeper		= fread_number( fp );
	if ( pShop->keeper == 0 )
	    break;
	for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
	    pShop->buy_type[iTrade]	= fread_number( fp );
	pShop->profit_buy	= fread_number( fp );
	pShop->profit_sell	= fread_number( fp );
	pShop->open_hour	= fread_number( fp );
	pShop->close_hour	= fread_number( fp );
				  fread_to_eol( fp );
	pMobIndex		= get_mob_index( pShop->keeper );
	pMobIndex->pShop	= pShop;

	if ( shop_first == NULL )
	    shop_first = pShop;
	if ( shop_last  != NULL )
	    shop_last->next = pShop;

	shop_last	= pShop;
	pShop->next	= NULL;
	top_shop++;
    }

    return;
}



/*
 * Snarf spec proc declarations.
 */
void load_specials( FILE *fp )
{
    for ( ; ; )
    {
	char letter;

	switch ( letter = fread_letter( fp ) )
	{
	default:
	    exit( 1 );

	case 'S':
	    return;

	case '*':
	    break;

	case 'M':
            fread_number ( fp );
            fread_word ( fp );
	    break;
	}

	fread_to_eol( fp );
    }
}


char fread_letter( FILE *fp );
    char c;

    do
    {
	c = getc( fp );
    }
    while ( isspace(c) );

    return c;
}



/*
 * Read a number from a file.
 */
int fread_number( FILE *fp )
{
    int number;
    bool sign;
    char c;

    do
    {
	c = getc( fp );
    }
    while ( isspace(c) );

    number = 0;

    sign   = FALSE;
    if ( c == '+' )
    {
	c = getc( fp );
    }
    else if ( c == '-' )
    {
	sign = TRUE;
	c = getc( fp );
    }

    if ( !isdigit(c) )
    {
	bug( "Fread_number: bad format.", 0 );
	exit( 1 );
    }

    while ( isdigit(c) )
    {
	number = number * 10 + c - '0';
	c      = getc( fp );
    }

    if ( sign )
	number = 0 - number;

    if ( c == '|' )
	number += fread_number( fp );
    else if ( c != ' ' )
	ungetc( c, fp );

    return number;
}



/*
 * Read and allocate space for a string from a file.
 * These strings are read-only and shared.
 * Strings are hashed:
 *   each string prepended with hash pointer to prev string,
 *   hash code is simply the string length.
 * This function takes 40% to 50% of boot-up time.
 */
char *fread_string( FILE *fp )
{
    char *plast;
    char c;

    plast = top_string + sizeof(char *);
    if ( plast > &string_space[MAX_STRING - MAX_STRING_LENGTH] )
    {
	bug( "Fread_string: MAX_STRING %d exceeded.", MAX_STRING );
	exit( 1 );
    }

    /*
     * Skip blanks.
     * Read first char.
     */
    do
    {
	c = getc( fp );
    }
    while ( isspace(c) );

    if ( ( *plast++ = c ) == '~' )
	return &str_empty[0];

    for ( ;; )
    {
	/*
	 * Back off the char type lookup,
	 *   it was too dirty for portability.
	 *   -- Furey
	 */
	switch ( *plast = getc( fp ) )
	{
	default:
	    plast++;
	    break;

	case EOF:
	    bug( "Fread_string: EOF", 0 );
	    exit( 1 );
	    break;

	case '\n':
	    plast++;
	    *plast++ = '\r';
	    break;

	case '\r':
	    break;

	case '~':
	    plast++;
	    {
		union
		{
		    char *	pc;
		    char	rgc[sizeof(char *)];
		} u1;
		int ic;
		int iHash;
		char *pHash;
		char *pHashPrev;
		char *pString;

		plast[-1] = '\0';
		iHash     = UMIN( MAX_KEY_HASH - 1, plast - 1 - top_string );
		for ( pHash = string_hash[iHash]; pHash; pHash = pHashPrev )
		{
		    for ( ic = 0; ic < sizeof(char *); ic++ )
			u1.rgc[ic] = pHash[ic];
		    pHashPrev = u1.pc;
		    pHash    += sizeof(char *);

		    if ( top_string[sizeof(char *)] == pHash[0]
		    &&   !strcmp( top_string+sizeof(char *)+1, pHash+1 ) )
			return pHash;
		}

		if ( fBootDb )
		{
		    pString		= top_string;
		    top_string		= plast;
		    u1.pc		= string_hash[iHash];
		    for ( ic = 0; ic < sizeof(char *); ic++ )
			pString[ic] = u1.rgc[ic];
		    string_hash[iHash]	= pString;

		    nAllocString += 1;
		    sAllocString += top_string - pString;
		    return pString + sizeof(char *);
		}
		else
		{
		    return str_dup( top_string + sizeof(char *) );
		}
	    }
	}
    }
}



/*
 * Read to end of line (for comments).
 */
void fread_to_eol( FILE *fp )
{
    char c;

    do
    {
	c = getc( fp );
    }
    while ( c != '\n' && c != '\r' );

    do
    {
	c = getc( fp );
    }
    while ( c == '\n' || c == '\r' );

    ungetc( c, fp );
    return;
}



/*
 * Read one word (into static buffer).
 */
char *fread_word( FILE *fp )
{
    static char word[MAX_INPUT_LENGTH];
    char *pword;
    char cEnd;

    do
    {
	cEnd = getc( fp );
    }
    while ( isspace( cEnd ) );

    if ( cEnd == '\'' || cEnd == '"' )
    {
	pword   = word;
    }
    else
    {
	word[0] = cEnd;
	pword   = word+1;
	cEnd    = ' ';
    }

    for ( ; pword < word + MAX_INPUT_LENGTH; pword++ )
    {
	*pword = getc( fp );
	if ( cEnd == ' ' ? isspace(*pword) : *pword == cEnd )
	{
	    if ( cEnd == ' ' )
		ungetc( *pword, fp );
	    *pword = '\0';
	    return word;
	}
    }

    bug( "Fread_word: word too long.", 0 );
    exit( 1 );
    return NULL;
}



/*
 * Allocate some ordinary memory,
 *   with the expectation of freeing it someday.
 */
void *alloc_mem( int sMem )
{
    void *pMem;
    int iList;

    for ( iList = 0; iList < MAX_MEM_LIST; iList++ )
    {
	if ( sMem <= rgSizeList[iList] )
	    break;
    }

    if ( iList == MAX_MEM_LIST )
    {
	bug( "Alloc_mem: size %d too large.", sMem );
	exit( 1 );
    }

    if ( rgFreeList[iList] == NULL )
    {
	pMem		  = alloc_perm( rgSizeList[iList] );
    }
    else
    {
	pMem              = rgFreeList[iList];
	rgFreeList[iList] = * ((void **) rgFreeList[iList]);
    }

    return pMem;
}



/*
 * Free some memory.
 * Recycle it back onto the free list for blocks of that size.
 */
void free_mem( void *pMem, int sMem )
{
    int iList;

    for ( iList = 0; iList < MAX_MEM_LIST; iList++ )
    {
	if ( sMem <= rgSizeList[iList] )
	    break;
    }

    if ( iList == MAX_MEM_LIST )
    {
	bug( "Free_mem: size %d too large.", sMem );
	exit( 1 );
    }

    * ((void **) pMem) = rgFreeList[iList];
    rgFreeList[iList]  = pMem;

    return;
}



/*
 * Allocate some permanent memory.
 * Permanent memory is never freed,
 *   pointers into it may be copied safely.
 */
void *alloc_perm( int sMem )
{
    static char *pMemPerm;
    static int iMemPerm;
    void *pMem;

    while ( sMem % sizeof(long) != 0 )
	sMem++;
    if ( sMem > MAX_PERM_BLOCK )
    {
	bug( "Alloc_perm: %d too large.", sMem );
	exit( 1 );
    }

    if ( pMemPerm == NULL || iMemPerm + sMem > MAX_PERM_BLOCK )
    {
	iMemPerm = 0;
	if ( ( pMemPerm = calloc( 1, MAX_PERM_BLOCK ) ) == NULL )
	{
	    perror( "Alloc_perm" );
	    exit( 1 );
	}
    }

    pMem        = pMemPerm + iMemPerm;
    iMemPerm   += sMem;
    nAllocPerm += 1;
    sAllocPerm += sMem;
    return pMem;
}



/*
 * Duplicate a string into dynamic memory.
 * Fread_strings are read-only and shared.
 */
char *str_dup( const char *str )
{
    char *str_new;

    if ( str[0] == '\0' )
	return &str_empty[0];

    if ( str >= string_space && str < top_string )
	return (char *) str;

    str_new = alloc_mem( strlen(str) + 1 );
    strcpy( str_new, str );
    return str_new;
}



/*
 * Free a string.
 * Null is legal here to simplify callers.
 * Read-only shared strings are not touched.
 */
void free_string( char *pstr )
{
    if ( pstr == NULL
    ||   pstr == &str_empty[0]
    || ( pstr >= string_space && pstr < top_string ) )
	return;

    free_mem( pstr, strlen(pstr) + 1 );
    return;
}



/*
 * Stick a little fuzz on a number.
 */
int number_fuzzy( int number )
{
    switch ( number_bits( 2 ) )
    {
    case 0:  number -= 1; break;
    case 3:  number += 1; break;
    }

    return UMAX( 1, number );
}



/*
 * Generate a random number.
 */
int number_range( int from, int to )
{
    int power;
    int number;

    if ( ( to = to - from + 1 ) <= 1 )
	return from;

    for ( power = 2; power < to; power <<= 1 )
	;

    while ( ( number = number_mm( ) & (power - 1) ) >= to )
	;

    return from + number;
}



/*
 * Generate a percentile roll.
 */
int number_percent( void )
{
    int percent;

    while ( ( percent = number_mm( ) & (128-1) ) > 99 )
	;

    return 1 + percent;
}



/*
 * Generate a random door.
 */
int number_door( void )
{
    int door;

    while ( ( door = number_mm( ) & (8-1) ) > 5 )
	;

    return door;
}



int number_bits( int width )
{
    return number_mm( ) & ( ( 1 << width ) - 1 );
}



/*
 * I've gotten too many bad reports on OS-supplied random number generators.
 * This is the Mitchell-Moore algorithm from Knuth Volume II.
 * Best to leave the constants alone unless you've read Knuth.
 * -- Furey
 */
static	int	rgiState[2+55];

void init_mm( )
{
    int *piState;
    int iState;

    piState	= &rgiState[2];

    piState[-2]	= 55 - 55;
    piState[-1]	= 55 - 24;

    piState[0]	= ((int) current_time) & ((1 << 30) - 1);
    piState[1]	= 1;
    for ( iState = 2; iState < 55; iState++ )
    {
	piState[iState] = (piState[iState-1] + piState[iState-2])
			& ((1 << 30) - 1);
    }
    return;
}



int number_mm( void )
{
    int *piState;
    int iState1;
    int iState2;
    int iRand;

    piState		= &rgiState[2];
    iState1	 	= piState[-2];
    iState2	 	= piState[-1];
    iRand	 	= (piState[iState1] + piState[iState2])
			& ((1 << 30) - 1);
    piState[iState1]	= iRand;
    if ( ++iState1 == 55 )
	iState1 = 0;
    if ( ++iState2 == 55 )
	iState2 = 0;
    piState[-2]		= iState1;
    piState[-1]		= iState2;
    return iRand >> 6;
}




/*
 * Simple linear interpolation.
 */
int interpolate( int level, int value_00, int value_32 )
{
    return value_00 + level * (value_32 - value_00) / 32;
}



/*
 * Removes the tildes from a string.
 * Used for player-entered strings that go into disk files.
 */
void smash_tilde( char *str )
{
    for ( ; *str != '\0'; str++ )
    {
	if ( *str == '~' )
	    *str = '-';
    }

    return;
}



/*
 * Compare strings, case insensitive.
 * Return TRUE if different
 *   (compatibility with historical functions).
 */
bool str_cmp( const char *astr, const char *bstr )
{
    if ( astr == NULL )
    {
	bug( "Str_cmp: null astr.", 0 );
	return TRUE;
    }

    if ( bstr == NULL )
    {
	bug( "Str_cmp: null bstr.", 0 );
	return TRUE;
    }

    for ( ; *astr || *bstr; astr++, bstr++ )
    {
	if ( LOWER(*astr) != LOWER(*bstr) )
	    return TRUE;
    }

    return FALSE;
}



/*
 * Compare strings, case insensitive, for prefix matching.
 * Return TRUE if astr not a prefix of bstr
 *   (compatibility with historical functions).
 */
bool str_prefix( const char *astr, const char *bstr )
{
    if ( astr == NULL )
    {
	bug( "Strn_cmp: null astr.", 0 );
	return TRUE;
    }

    if ( bstr == NULL )
    {
	bug( "Strn_cmp: null bstr.", 0 );
	return TRUE;
    }

    for ( ; *astr; astr++, bstr++ )
    {
	if ( LOWER(*astr) != LOWER(*bstr) )
	    return TRUE;
    }

    return FALSE;
}



/*
 * Compare strings, case insensitive, for match anywhere.
 * Returns TRUE is astr not part of bstr.
 *   (compatibility with historical functions).
 */
bool str_infix( const char *astr, const char *bstr )
{
    int sstr1;
    int sstr2;
    int ichar;
    char c0;

    if ( ( c0 = LOWER(astr[0]) ) == '\0' )
	return FALSE;

    sstr1 = strlen(astr);
    sstr2 = strlen(bstr);

    for ( ichar = 0; ichar <= sstr2 - sstr1; ichar++ )
    {
	if ( c0 == LOWER(bstr[ichar]) && !str_prefix( astr, bstr + ichar ) )
	    return FALSE;
    }

    return TRUE;
}



/*
 * Compare strings, case insensitive, for suffix matching.
 * Return TRUE if astr not a suffix of bstr
 *   (compatibility with historical functions).
 */
bool str_suffix( const char *astr, const char *bstr )
{
    int sstr1;
    int sstr2;

    sstr1 = strlen(astr);
    sstr2 = strlen(bstr);
    if ( sstr1 <= sstr2 && !str_cmp( astr, bstr + sstr2 - sstr1 ) )
	return FALSE;
    else
	return TRUE;
}



/*
 * Returns an initial-capped string.
 */
char *capitalize( const char *str )
{
    static char strcap[MAX_STRING_LENGTH];
    int i;

    for ( i = 0; str[i] != '\0'; i++ )
	strcap[i] = LOWER(str[i]);
    strcap[i] = '\0';
    strcap[0] = UPPER(strcap[0]);
    return strcap;
}


/*
 * Returns an completely capitalized string.
 */
char *upper_cap( const char *str )
{
    static char strcap[MAX_STRING_LENGTH];
    int i;

    for ( i = 0; str[i] != '\0'; i++ )
	strcap[i] = UPPER(str[i]);
    strcap[i] = '\0';
    return strcap;
}



/*
 * Append a string to a file.
 */
void append_file( CHAR_DATA *ch, char *file, char *str )
{
    FILE *fp;

    if ( IS_NPC(ch) || str[0] == '\0' )
	return;

    fflush( fpReserve );
    fclose( fpReserve );
    if ( ( fp = fopen( file, "a" ) ) == NULL )
    {
	perror( file );
	send_to_char( "Could not open the file!\n\r", ch );
    }
    else
    {
	fprintf( fp, "[%5d] %s: %s\n",
	    ch->in_room ? ch->in_room->vnum : 0, ch->name, str );
	fflush( fp );
	fclose( fp );
    }

    fpReserve = fopen( NULL_FILE, "r" );
    return;
}


/*
 * This function is here to aid in debugging.
 * If the last expression in a function is another function call,
 *   gcc likes to generate a JMP instead of a CALL.
 * This is called "tail chaining."
 * It hoses the debugger call stack for that call.
 * So I make this the last call in certain critical functions,
 *   where I really need the call stack to be right for debugging!
 *
 * If you don't understand this, then LEAVE IT ALONE.
 * Don't remove any calls to tail_chain anywhere.
 *
 * -- Furey
 */
void tail_chain( void )
{
    return;
}
