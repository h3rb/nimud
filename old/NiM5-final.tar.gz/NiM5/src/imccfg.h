/*
 * IMC2 MUD-Net versions 4.20 through 4.24b developed by Alsherok.
 * Copyright (c)2002-2003 Roger Libiez ( Samson )
 * Contributions to the 4.22b client Copyright (c)2003 by Xorith
 * Registered with the United States Copyright Office
 * TX 5-555-584
 * Version number for 4.2x series artificially raised to indicate the true nature of upgrades
 * made to the 3.10 client. If the Continuum developers won't correct their version number to
 * reflect THEIR true nature, then we need to raise ours to compensate for their error.
 *
 * IMC2 MUD-Net versions 3.00 and 3.10 developed by Asherok and Crimson Oracles.
 * Copyright (c)2002-2003 Roger Libiez ( Samson )
 * Additional code Copyright (c)2002 by Orion Elder.
 * Registered with the United States Copyright Office
 * TX 5-555-584
 *
 * IMC2 Gold versions 1.00 though 2.00 are developed by MudWorld.
 * Copyright (C) 1999 - 2002 Haslage Net Electronics (Anthony R. Haslage)
 *
 * IMC2 version 0.10 - an inter-mud communications protocol
 * Copyright (C) 1996 & 1997 Oliver Jowett <oliver@randomly.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING); if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

   #define first_descriptor connection_list
   #define IMCMAXPLAYERS 0
   #define CH_IMCDATA(ch)           ((ch)->userdata->imcchardata)
   #define CH_IMCLEVEL(ch)          ((ch)->userdata->level)
   #define CH_IMCNAME(ch)           ((ch)->name)
   #define CH_IMCTITLE(ch)          ((ch)->userdata->title)
   #define CH_IMCSEX(ch)            ((ch)->sex)

   #define IMCWIZINVIS(ch)         (IS_IMMORTAL((ch)) && (ch)->userdata->wizinvis > 0)
   #define CH_IMCRANK(ch)        ( IS_IMMORTAL(ch) ? "Immortal" : "Player" )

   #include "net.h"
   #include "defaults.h"

