/******************************************************************************
 * Locke's   __                      __         NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5     Version 5 (ALPHA)             *
 * |  /   \  __|  \__/  |  | |  |      |        unreleased+revamped 2004      *
 * |       ||  |        |  \_|  | ()   |                                      *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************
 *                                                                           *
 * Within this code you will find a lot of variables that seem to be setting *
 * a pointer only to use the pointer and throw it away.  (See func_dream)    *
 *                                                                           *
 * This happens because the compile requires us to dereference only once,and *
 * it causes itself confusion because the compiler aren't able tell if you are 
 * referring to its original void * or some void * down a chain of -> ->'s   *
 *                                                                           *
 * Wierd, huh?  -locke                                                       *
 *                                                                           *
 *****************************************************************************/

#if defined(BSD)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "nimud.h"
#include "net.h"
#include "script.h"
#include "defaults.h"

#define PARM(var, vtype)         ( !var || (var->type != vtype) )

int gotoloops;
char func_buff[MAX_STRING_LENGTH];

void parse_assign			  args( ( TRIGGER_DATA *trig, char *line,
						  void * owner, int type ) );
char *translate_variables      	          args( ( void * owner, int type, char *exp ) );
VARIABLE_DATA * get_variable              args( ( VARIABLE_DATA **vlist, char *name ) );
VARIABLE_DATA * find_variable             args( ( void * owner, int type, char *name ) );
VARIABLE_DATA ** varlist	          args( ( void * owner, int type ) );
void assign_var                           args( ( void * owner, int type,
                                                  VARIABLE_DATA *var, char *name ) );
int trigger                               args( ( void * owner, int type, TRIGGER_DATA *trig ) );



/*
 * Return a trigger of supplied name on supplied owner.
 */
TRIGGER_DATA *get_trigger( void * owner, int type, char *trigname )
{
	TRIGGER_DATA *trig;

	switch( type )
	{
        case TYPE_ACTOR:   trig = ((PLAYER_DATA *)owner)->triggers;        break;
        case TYPE_PROP:   trig = ((PROP_DATA *)owner)->triggers;         break;
        case TYPE_SCENE:  trig = ((SCENE_INDEX_DATA *)owner)->triggers;  break;
         default: bug( "Get_trigger: invalid type %d.", type ); return NULL;
	}

	for ( ; trig != NULL;  trig = trig->next )
	{
        if ( !str_cmp( trig->script->name, trigname ) )
		return trig;
	}

	return trig;
}



/*
 * Return a target owner information based on vnum and type,
 * such that for scenes you would have R340 and props O514 etc.
 */
void * get_target( void * owner, int type, int * target_type, char *exp )
{
    int vnum;

	switch (  *exp	)
	{
		case 'r':
        case 'R': *target_type = TYPE_SCENE;
				  if ( type == TYPE_SCENE ) return owner;
                  if ( type == TYPE_ACTOR  ) return ((PLAYER_DATA *)owner)->in_scene;
                  if ( type == TYPE_PROP  ) return ((PROP_DATA *)owner)->in_scene;
				  break;
		case 'o':
        case 'O': *target_type = TYPE_PROP;  break;
		case 'm':
        case 'M': *target_type = TYPE_ACTOR;  break;
		 default: return NULL;
	}

	exp++;

	vnum = atoi(exp);

	if ( type == TYPE_PROP )
	{
		PROP_DATA *cprop = (PROP_DATA *) owner;

        if ( *target_type == TYPE_PROP )
		{
			PROP_DATA *prop;

			for ( prop = cprop->in_prop;
				  prop != NULL && prop->pIndexData->vnum != vnum;
				  prop = prop->next_content );

			if ( prop != NULL ) return prop;

			for ( prop = cprop->in_scene->contents;
				  prop != NULL && prop->pIndexData->vnum != vnum;
				  prop = prop->next_content );

			if ( prop != NULL ) return prop;

			for ( prop = cprop->contains;
				  prop != NULL && prop->pIndexData->vnum != vnum;
				  prop = prop->next_content );

			if ( prop != NULL ) return prop;

			for ( prop = prop_list;
				  prop != NULL && prop->pIndexData->vnum != vnum;
				  prop = prop->next );

			return prop;
		}

        if ( *target_type == TYPE_ACTOR )
		{
			PLAYER_DATA *actor;

			for ( actor = cprop->carried_by->in_scene->people;
				  actor != NULL && IS_NPC(actor) && actor->pIndexData->vnum != vnum;
				  actor = actor->next_in_scene );

            if ( actor != NULL ) return actor;

			for ( actor = actor_list;
				  actor != NULL && IS_NPC(actor) && actor->pIndexData->vnum != vnum;
				  actor = actor->next );

			return actor;
		}
	}

	if ( type == TYPE_ACTOR )
	{
        PLAYER_DATA *cactor = (PLAYER_DATA *) owner;

        if ( *target_type == TYPE_PROP )
		{
			PROP_DATA *prop;

			for ( prop = cactor->carrying;
				  prop != NULL && prop->pIndexData->vnum != vnum;
				  prop = prop->next_content );

			if ( prop != NULL ) return prop;

			for ( prop = cactor->in_scene->contents;
				  prop != NULL && prop->pIndexData->vnum != vnum;
				  prop = prop->next_content );

			if ( prop != NULL ) return prop;

			for ( prop = prop_list;
				  prop != NULL && prop->pIndexData->vnum != vnum;
				  prop = prop->next );

			return prop;
		}

        if ( *target_type == TYPE_ACTOR )
		{
			PLAYER_DATA *actor;

			for ( actor = cactor->in_scene->people;
				  actor != NULL && IS_NPC(actor) && actor->pIndexData->vnum != vnum;
				  actor = actor->next_in_scene );

            if ( actor != NULL ) return actor;

			for ( actor = actor_list;
				  actor != NULL && IS_NPC(actor) && actor->pIndexData->vnum != vnum;
				  actor = actor->next );

			return actor;
		}
	}

	return NULL;
}




/*
 * For the in-line parser.
 */
void mini_parse_script( void * owner, int type, char *exp )
{
    char buf[MAX_STRING_LENGTH];
    char *commands;

    while ( *exp != '\0' )
    {
        /*
         * Advance a line.
         */
        exp = one_line( exp, buf );
        commands = skip_spaces( buf );

        if ( *commands == '*' || *commands == '\0' )
        continue;

        if ( *commands == '%' )
        parse_assign( curtrig(owner,type), commands, owner, type );
        else
        {
            VARIABLE_DATA *value;

            value = eval_function( owner, type, commands );
            free_variable( value );
        }
    }

    return;
}






/*
 * Goto a specified label.
 */
VARIABLE_DATA *func_goto( void * owner, int type, VARIABLE_DATA *label )
{
    TRIGGER_DATA *trig = curtrig(owner,type);
    char buf[MAX_STRING_LENGTH];
    char *exp;
    char *line;
    char *slabel;

    if (PARM(label,TYPE_STRING)) return NULL;

    slabel = translate_variables( owner, type, (char *)label->value );

    line = trig->script->commands;
    while ( !MTD(line) )
    {
        /*
         * Advance a line.
         */
        line = one_line( line, buf );
        exp = skip_spaces( buf );

        if ( LOWER(*exp) == 'l' )
        {
            int param_paren = 0;
            char name[MAX_STRING_LENGTH];
            char *point;

            /*
             * Grab the function name.
             * func(param, .... )
             * ^
             */
            point = name;
            while ( *exp != '('
                 && *exp != ' '
                 && *exp != '\0' ) *point++ = *exp++;
            *point = '\0';
            exp = skip_spaces( exp );
            if ( *exp != '\0' ) exp++;

            if ( str_cmp( name, "label" ) )
            continue;

            point = name;
            while( *exp != '\0' )
            {
                /*
                 * Ok, get the hell out of here, we're done.
                 * func(param, .... )
                 *           ^
                 */
                if ( param_paren == 0 )
                    if ( *exp == ','
                      || *exp == ')'
                      || *exp == '\0' )
                    {
                        if ( *exp == ',' || *exp == ')' ) exp++;
                        break;
                    }


                if ( *exp == '(' ) param_paren++;
                else
                if ( *exp == ')' ) param_paren--;

                if ( *exp == ' ' ) exp++;
                else *point++ = *exp++;
            }
            *point = '\0';

            point = translate_variables(owner, type, name);
            if ( !str_cmp( point, slabel ) )
            {
                trig->location = line;
                free_string(point);
                break;
            }
            free_string(point);
        }
    }

    free_string(slabel);

    if ( ++gotoloops > MAX_LOOPS )
    {
        NOTIFY( "Notify>  Exceeded maximum gotos per script (Halted).\n\r", LEVEL_IMMORTAL, WIZ_NOTIFY_SCRIPT );
        trig->location = NULL;
    }
    return NULL;
}




/*
 * Do a conditional.
 * Returns evaluated function calls based on condition.
 * Watch for recursion.
 */
VARIABLE_DATA *func_if( void * owner, int type,
                        VARIABLE_DATA *exp,
                        VARIABLE_DATA *iftrue,
                        VARIABLE_DATA *iffalse )
{
    int val;
    char *_exp;
    char *_iftrue, *__iftrue;
    char *_iffalse, *__iffalse;
    char *commands;
    TRIGGER_DATA *trig = curtrig(owner,type);
    VARIABLE_DATA *pVar;
    char buf[MAX_STRING_LENGTH];

    if( PARM(exp,TYPE_STRING) )
    {
        _exp = !exp ? str_dup( "" ) : (exp->value ? str_dup( "1" )
                                                  : str_dup( "0" ));
    }
    else
    _exp = translate_variables( owner, type, strip_curlies((char *)exp->value) );

    val = atoi(_exp);
    trig->last_conditional = val;

    if ( val > 0 )
    {
        /*
         * Evaluates as true.
         */
        if( PARM(iftrue, TYPE_STRING) ) _iftrue = str_dup( "" );
        else
        _iftrue  = translate_variables( owner, type, (char *)iftrue->value );

        __iftrue = strip_curlies( _iftrue );

        while ( !IS_SET(trig->bits, SCRIPT_HALT)
             && !MTD(__iftrue) )
        {
            /*
             * Advance a line.
             */
            __iftrue = one_line( __iftrue, buf );
            commands = skip_spaces( buf );

            if ( *commands == '\0' ) continue;

            if ( *commands == '%' )
            parse_assign( trig, commands, owner, type );
            else
            {
                VARIABLE_DATA *value;

                value = eval_function( owner, type, commands );
                free_variable( value );
            }

            if ( trig->autowait) trig->wait = trig->autowait;
        }

        free_string( _iftrue );
    }
    else
    {
        if( PARM(iffalse, TYPE_STRING) ) _iffalse = str_dup( "" );
        else
        _iffalse = translate_variables( owner, type, (char *)iffalse->value );

        __iffalse = strip_curlies( _iffalse );

        while ( !IS_SET(trig->bits, SCRIPT_HALT)
             && !MTD(__iffalse) )
        {
            /*
             * Advance a line.
             */
            __iffalse = one_line( __iffalse, buf );
            commands = skip_spaces( buf );

            if ( *commands == '\0' ) continue;

            if ( *commands == '%' )
            parse_assign( trig, commands, owner, type );
            else
            {
                VARIABLE_DATA *value;

                value = eval_function( owner, type, commands );
                free_variable( value );
            }

            if ( trig->autowait) trig->wait = trig->autowait;
        }

        free_string( _iffalse );
    }

    pVar = new_variable();
    pVar->type = TYPE_STRING;
    pVar->value = str_dup( _exp );
    free_string( _exp );
    return pVar;
}




/*
 * Don't do anything, but supply a place for goto to go to.
 */
VARIABLE_DATA *func_label( void * owner, int type )
{
    return NULL;
}


/*
 * time()
 *
 * return the current game hour
 */
VARIABLE_DATA *func_time( void * owner, int type )
{
    VARIABLE_DATA *pVar;
    char buf[MAX_STRING_LENGTH];

    sprintf( buf, "%d", weather_info.hour );
    
    pVar = new_variable();
    pVar->type = TYPE_STRING;
    pVar->value = str_dup ( buf );
    return pVar;
}

/*
 * day()
 *
 * return the current game day (of month, not of week)
 */
VARIABLE_DATA *func_day( void * owner, int type )
{
    VARIABLE_DATA *pVar;
    char buf[MAX_STRING_LENGTH];

    sprintf( buf, "%d", weather_info.day );
    
    pVar = new_variable();
    pVar->type = TYPE_STRING;
    pVar->value = str_dup ( buf );
    return pVar;
}


/*
 * month()
 *
 * return the current game month
 */
VARIABLE_DATA *func_month( void * owner, int type )
{
    VARIABLE_DATA *pVar;
    char buf[MAX_STRING_LENGTH];

    sprintf( buf, "%d", weather_info.month );
    
    pVar = new_variable();
    pVar->type = TYPE_STRING;
    pVar->value = str_dup ( buf );
    return pVar;
}


/*
 * dayofweek()
 *
 * return the current game day of week
 */
VARIABLE_DATA *func_dayofweek( void * owner, int type )
{
    VARIABLE_DATA *pVar;
    char buf[MAX_STRING_LENGTH];

    sprintf( buf, "%d", weather_info.day % 7 );
    
    pVar = new_variable();
    pVar->type = TYPE_STRING;
    pVar->value = str_dup ( buf );
    return pVar;
}



/*
 * year()
 *
 * return the current game year
 */
VARIABLE_DATA *func_year( void * owner, int type )
{
    VARIABLE_DATA *pVar;
    char buf[MAX_STRING_LENGTH];

    sprintf( buf, "%d", weather_info.year );
    
    pVar = new_variable();
    pVar->type = TYPE_STRING;
    pVar->value = str_dup ( buf );
    return pVar;
}



/*
 * weather()
 *
 * return the current game weather (sky)
 */
VARIABLE_DATA *func_weather( void * owner, int type )
{
    VARIABLE_DATA *pVar;
    char buf[MAX_STRING_LENGTH];

    sprintf( buf, "%d", weather_info.sky );
    
    pVar = new_variable();
    pVar->type = TYPE_STRING;
    pVar->value = str_dup ( buf );
    return pVar;
}


/*
 * moon()
 *
 * return the current game moon phase
 */
VARIABLE_DATA *func_moon( void * owner, int type )
{
    VARIABLE_DATA *pVar;
    char buf[MAX_STRING_LENGTH];

    sprintf( buf, "%d", weather_info.moon_phase );
    
    pVar = new_variable();
    pVar->type = TYPE_STRING;
    pVar->value = str_dup ( buf );
    return pVar;
}




/*
 * return(#)
 *
 * Set the value returned by the function.
 */
VARIABLE_DATA *func_return( void * owner, int type, VARIABLE_DATA *value )
{
    TRIGGER_DATA *trig = curtrig( owner, type );
    int x;
    char *_value;

    if( PARM(value,TYPE_STRING) )
    {
        _value = !value ? str_dup( "" ) : (value->value ? str_dup( "1" )
                                                        : str_dup( "0" ));
    }
    else
    _value = translate_variables( owner, type, strip_curlies((char *)value->value) );

    x = atoi(_value);
    trig->returned = x;

    free_string( _value );
    return NULL;
}



/*
 * halt(#)
 *
 * halts a script, optionally sets the return value
 */
VARIABLE_DATA *func_halt( void * owner, int type, VARIABLE_DATA *value )
{
    TRIGGER_DATA *trig = curtrig( owner, type );
    VARIABLE_DATA *pVar, *pVar_next;
    int x;
    char *_value;

    if( PARM(value,TYPE_STRING) )
    {
        _value = !value ? str_dup( "" ) : (value->value ? str_dup( "1" )
                                                        : str_dup( "0" ));
    }
    else
    _value = translate_variables( owner, type, strip_curlies((char *)value->value) );

    x = atoi(_value);
    trig->returned = x;

    for ( pVar = trig->locals;  pVar != NULL; pVar = pVar_next )
    {
        pVar_next = pVar->next;
        free_variable( pVar );
    }

    trig->locals = NULL;
    trig->location = NULL;

    free_string( _value );
    return NULL;
}



/*
 * permhalt()
 *
 * Halt without prettiness (for debugging purposes).
 */
VARIABLE_DATA *func_permhalt( void * owner, int type )
{
    TRIGGER_DATA *trig = curtrig(owner,type);

    trig->location = NULL;
    SET_BIT(trig->bits, SCRIPT_HALT);
    return NULL;
}



/*
 * wait(pulses)
 *
 * Set the wait state.
 */
VARIABLE_DATA *func_wait( void * owner, int type, VARIABLE_DATA *value )
{
    TRIGGER_DATA *trig = curtrig(owner,type);
    char *_value;
    int x;

    if( PARM(value,TYPE_STRING) )
    {
        _value = !value ? str_dup( "" ) : (value->value ? str_dup( "1" )
                                                        : str_dup( "0" ));
    }
    else
    _value = translate_variables( owner, type, strip_curlies((char *)value->value) );

    x = atoi(_value);
    trig->wait = x;

    free_string( _value );
    return NULL;
}




/*
 * autowait(value)
 *
 * Set the autowait state.
 */
VARIABLE_DATA *func_autowait( void * owner, int type, VARIABLE_DATA *value )
{
    TRIGGER_DATA *trig = curtrig(owner,type);
    char *_value;
    int x;

    if( PARM(value,TYPE_STRING) )
    {
        _value = !value ? str_dup( "" ) : (value->value ? str_dup( "1" )
                                                        : str_dup( "0" ));
    }
    else
    _value = translate_variables( owner, type, strip_curlies((char *)value->value) );

    x = atoi(_value);
    trig->autowait = x;

    free_string( _value );
    return NULL;
}



/*
 * Call another trigger.
 */
VARIABLE_DATA *func_call( void * owner, int type, VARIABLE_DATA *trigname,
                          VARIABLE_DATA *target )
{
    VARIABLE_DATA *newvar;
	char buf[MAX_STRING_LENGTH];
	TRIGGER_DATA *trig;
	void * target_owner;
	int target_type;
    char *_trigname;

    if( PARM(trigname,TYPE_STRING) )
    {
        _trigname = !trigname ? str_dup( "" ) : (trigname->value
                                                        ? str_dup( "1" )
                                                        : str_dup( "0" ));
    }
    else
    _trigname = translate_variables( owner, type, strip_curlies((char *)trigname->value) );

	target_owner = owner;
	target_type   = type;

    if ( PARM(target,TYPE_STRING) )
	{
        target_owner = get_target( owner, type, &target_type, (char *) target->value );
        if ( target_owner == NULL ) return NULL;
	}

    trig = get_trigger( target_owner, target_type, _trigname );

    free_string( _trigname );

    if ( trig == NULL || trig == curtrig(owner,type) ) return NULL;

    sprintf( buf, "%d", trigger( owner, type, trig ) );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}




/*
 * Return a pointer to one-self.
 */
VARIABLE_DATA *func_self( void * owner, int type )
{
    VARIABLE_DATA *self;

    self = new_variable( );
    self->value = owner;
    self->type = type;
    return self;
}



/*
 * Compare two numerics.
 */
VARIABLE_DATA *func_cmp( void * owner, int type, VARIABLE_DATA *astr,
                         VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    if ( is_number(_astr) && is_number(_bstr) ) {
       sprintf( buf, "%d", atoi(_astr) == atoi(_bstr) ? 1 : 0 );
    }
    else
    sprintf( buf, "%d", (int) !str_cmp( _astr, _bstr ) );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Use a boolean NOT.
 */
VARIABLE_DATA *func_not( void * owner, int type, VARIABLE_DATA *value )
{
    static char buf[MAX_STRING_LENGTH];
    int x;
    VARIABLE_DATA *newvar;
    char *_value;

    if( PARM(value,TYPE_STRING) )
    {
        _value = !value ? str_dup( "" ) : (value->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _value = translate_variables( owner, type, strip_curlies((char *)value->value) );

    x = atoi(_value);

    sprintf( buf, "%d", !x );

    free_string( _value );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Perform a boolean OR.
 */
VARIABLE_DATA *func_or( void * owner, int type, VARIABLE_DATA *astr,
                                                 VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x || y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Perform a boolean AND.
 */
VARIABLE_DATA *func_and( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x && y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}




/*
 * Perform a boolean < check.
 */
VARIABLE_DATA *func_less( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );


    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x < y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Perform a boolean > check.
 */
VARIABLE_DATA *func_greater( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x > y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}

VARIABLE_DATA *func_range( void * owner, int type, VARIABLE_DATA *astr, 
                             VARIABLE_DATA *val, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y, testval;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr, *_val;
    
    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(val,TYPE_STRING) )
    {
        _val = !val ? str_dup( "" ) : (bstr->value ? str_dup( "1" )
                                                   : str_dup( "0" ));
    }
    else
    _val = translate_variables( owner, type, strip_curlies((char *)val->value ) );
    
    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);
    testval = atoi(_val);
    
    sprintf( buf, "%d", x <= testval && testval <= y );
    
    free_string( _astr );
    free_string( _bstr );
    free_string( _val  );
     
    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Str_prefix.
 */
VARIABLE_DATA *func_pre( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );


    sprintf( buf, "%d", !str_prefix( _astr, _bstr ) );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Str_infix.
 */
VARIABLE_DATA *func_in( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    char buf[MAX_STRING_LENGTH];
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    sprintf( buf, "%d", ( int ) strstr( _astr, _bstr ) );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Strstr.
 */
VARIABLE_DATA *func_strstr( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    char buf[MAX_STRING_LENGTH];
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    sprintf( buf, "%d", (int) strstr( _astr, _bstr ) );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Pointer compare.
 */
VARIABLE_DATA *func_pcmp( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    VARIABLE_DATA *v1, *v2, *newvar;
    char buf[MAX_STRING_LENGTH];

    if( PARM(astr,TYPE_STRING) )
    v1 = astr;
    else
    v1 = find_variable( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    v2 = bstr;
    else
    v2 = find_variable( owner, type, strip_curlies((char *)bstr->value) );


    buf[0] = '\0';
    if ( v1 == v2 )               buf[0] = '1';
    if ( v1->type != v2->type )   buf[0] = '0';
    if ( v1->value == v2->value ) buf[0] = '1';
    buf[1] = '\0';

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Add two numerics.
 */
VARIABLE_DATA *func_add( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x + y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Subtract two numerics.
 */
VARIABLE_DATA *func_sub( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );


    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x - y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Multiply two numerics.
 */
VARIABLE_DATA *func_mult( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );


    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x * y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Divide two numerics.
 */
VARIABLE_DATA *func_div( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x / y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Modula two numerics.
 */
VARIABLE_DATA *func_mod( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", x % y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Return a random numeric in the range A-B.
 */
VARIABLE_DATA *func_random( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

    sprintf( buf, "%d", number_range( x, y ) );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Perform a binary AND.
 */
VARIABLE_DATA *func_band( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );


    x = atoi(_astr);
    y = atoi(_bstr);

	sprintf( buf, "%d", x & y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Perform a binary OR.
 */
VARIABLE_DATA *func_bor( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

	sprintf( buf, "%d", x | y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Perform a binary XOR.
 */
VARIABLE_DATA *func_bxor( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    int x, y;
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    x = atoi(_astr);
    y = atoi(_bstr);

	sprintf( buf, "%d", x ^ y );

    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Concatenate two strings.
 */
VARIABLE_DATA *func_cat( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    static char buf[MAX_STRING_LENGTH];
    VARIABLE_DATA *newvar;
    char *_astr, *_bstr;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    sprintf( buf, "%s", strip_curlies(_astr) );
    sprintf( buf, "%s%s", buf, strip_curlies(_bstr) );
    free_string( _astr );
    free_string( _bstr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * One_arg with a number.
 */
VARIABLE_DATA *func_word( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *value )
{
    static char buf[MAX_STRING_LENGTH];
    char *_astr, *_value, *spoint;
    VARIABLE_DATA *newvar;
    int x;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    if( PARM(value,TYPE_STRING) )
    {
        _value = !value ? str_dup( "" ) : (value->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _value = translate_variables( owner, type, strip_curlies((char *)value->value) );

    spoint = _astr;
    x = atoi(_value);

    while( x-- > 0 ) spoint = one_argument(spoint, buf);

    free_string( _astr );
    free_string( _value );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * Act()
 */
VARIABLE_DATA * func_act( void * owner, int type, VARIABLE_DATA *out,
                          VARIABLE_DATA *ch, VARIABLE_DATA *arg1,
                          VARIABLE_DATA *arg2, VARIABLE_DATA *act_type )
{
    VARIABLE_DATA *var1 = NULL, *var2, *var3;
    char *_out = NULL, *_act_type = NULL;
    char *_ch = NULL;
    int num_act_type = TO_ALL;

    if( PARM(out,TYPE_STRING) )
    {
        _out = !out ? str_dup( "" ) : (out->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _out = translate_variables( owner, type, strip_curlies((char *)out->value) );

    if( PARM(act_type,TYPE_STRING) )
    {
        _act_type = !act_type ? str_dup( "" ) : (act_type->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _act_type = translate_variables( owner, type, strip_curlies((char *)act_type->value) );

    if( PARM(ch,TYPE_STRING) )
    { _ch = translate_variables( owner, type, strip_curlies((char *)ch->value) );
    
    var1->value = get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *) owner : actor_list, _ch);
    } else
/*    var1 = find_variable( owner, type, strip_curlies((char *)ch->value) 
);*/
    if ( ch->type == TYPE_ACTOR ) var1 = ch->value; 
    else var1 = NULL;

    if( PARM(arg1,TYPE_STRING) )
    var2 = arg1;
    else
    var2 = find_variable( owner, type, strip_curlies((char *)arg1->value) );

    if( PARM(arg2,TYPE_STRING) )
    var3= arg2;
    else
    var3 = find_variable( owner, type, strip_curlies((char *)arg2->value) );

    if ( !str_prefix( _act_type, "scene" ) )  num_act_type = TO_SCENE;
    if ( !str_prefix( _act_type, "char" ) )  num_act_type = TO_CHAR;
    if ( !str_prefix( _act_type, "all"  ) )  num_act_type = TO_ALL;

    if ( var1 != NULL )
    act( _out, (PLAYER_DATA *)var1->value, var2->value, var3->value, num_act_type );

    free_string( _act_type );
    free_string( _out );
    free_string( _ch );
    return NULL;
}

/*
 * Act()
 */
VARIABLE_DATA *func_recho( void * owner, int type, VARIABLE_DATA *target, VARIABLE_DATA *out )
{
    char *_out, *_target;
    SCENE_INDEX_DATA *pScene;
    PLAYER_DATA *rch;

    if( PARM(out,TYPE_STRING) )
    {
        _out = !out ? str_dup( "" ) : (out->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _out = translate_variables( owner, type, strip_curlies((char *)out->value) );

    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    pScene = get_scene_index( atoi(_target) );

    if ( pScene != NULL ) {
           for ( rch = pScene->people;
                 rch != NULL;
                 rch = rch->next_in_scene )
             send_to_actor( _out, rch );
    }

    free_string( _target );
    free_string( _out );

    return NULL;
}

/*
 * Transform from one prop into another
 */
VARIABLE_DATA *func_transform( void * owner, int type, VARIABLE_DATA *target )
{
    char *_target;
    int vnum;
    PROP_INDEX_DATA *pPropIndex;
    PROP_DATA *pMe;

    if ( type != TYPE_PROP ) return NULL;

    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );
    vnum = atoi(_target);

    pPropIndex = get_prop_index( vnum );
    if ( !pPropIndex ) return NULL;

    pMe = (PROP_DATA *)owner;

    if ( pPropIndex->item_type == ITEM_LIST )
    {
        PROP_INDEX_DATA *pIndex;
        char *scanarg;
        char buf[20];
        int num;
        int d;

        scanarg    = pPropIndex->description;
        num        = number_range( 1, arg_count( pPropIndex->description ) );
        buf[0]     = '\0';

        for ( d = 0; d < num; d++ )
        {
            scanarg = one_argument( scanarg, buf );
        }

        num       = atoi( buf );
        num        = number_range( 1, arg_count( pPropIndex->description ) );
        buf[0]     = '\0';

        for ( d = 0; d < num; d++ )
        {
            scanarg = one_argument( scanarg, buf );
        }

        num       = atoi( buf );
        pIndex = get_prop_index( num );
        if ( pIndex != NULL ) pPropIndex = pIndex;
    }

    pMe->pIndexData     = pPropIndex;


    /*
     * Copy triggers onto the prop.
     */
    if ( pPropIndex->triggers != NULL )
    {
    TRIGGER_DATA *trig, *pTrig;

    for ( pTrig = pPropIndex->triggers;  pTrig != NULL;  pTrig = pTrig->next )
    {
        trig               = new_trigger( );

        trig->script       = pTrig->script;
        trig->location     = NULL;

        trig->next       = pMe->triggers;
        pMe->triggers    = trig;
    }
    }

    pMe->item_type      = pPropIndex->item_type;
    pMe->extra_flags    = pPropIndex->extra_flags;
    pMe->wear_flags     = pPropIndex->wear_flags;
    pMe->value[0]       = pPropIndex->value[0];
    pMe->value[1]       = pPropIndex->value[1];
    pMe->value[2]       = pPropIndex->value[2];
    pMe->value[3]       = pPropIndex->value[3];
    pMe->size           = pPropIndex->size;
    pMe->weight         = pPropIndex->weight;

    if (pPropIndex->cost == 0)
     pMe->cost          = number_fuzzy( 10 )
                        * number_fuzzy( 1 ) * number_fuzzy( 1 );
    else pMe->cost      = number_range( pPropIndex->cost - pPropIndex->cost/8,
                                        pPropIndex->cost + pPropIndex->cost/8 );

    /*
     * Mess with prop properties.
     */
    switch ( pMe->item_type ) {
    default:
    if ( pMe->item_type >= ITEM_MAX )
        bug( "Read_prop: vnum %d bad type.", pPropIndex->vnum );
        break;

    case ITEM_SCROLL:
        pMe->value[0]   = number_fuzzy( pMe->value[0] );
        break;

    case ITEM_WAND:
    case ITEM_STAFF:
        pMe->value[0]   = number_fuzzy( pMe->value[0] );
        pMe->value[1]   = number_fuzzy( pMe->value[1] );
        pMe->value[2]   = pMe->value[1];
        break;

    case ITEM_WEAPON:
    if ( pMe->value[1] != 0 && pMe->value[2] != 0 )
    {
         pMe->value[1]   = number_fuzzy( pMe->value[1] );
         pMe->value[2]   = number_fuzzy( pMe->value[2] );
    }
    else
    {
         pMe->value[1]   = number_fuzzy( number_fuzzy( 1 * 2 / 4 + 2 ) );
         pMe->value[2]   = number_fuzzy( number_fuzzy( 3 * 2 / 4 + 6 ) );
    }
    break;
    case ITEM_ARMOR:
    if ( pMe->value[0] != 0 )
    {
         pMe->value[0]   = number_fuzzy( pMe->value[0] );
    }
    else    pMe->value[0]   = number_fuzzy( 1 / 4 + 2 );

    if ( pMe->value[2] != 0 )
    {
         pMe->value[2]   = number_fuzzy( pMe->value[2] );
         pMe->value[1]   = pMe->value[2];
    }
        break;

    case ITEM_POTION:
    case ITEM_PILL:
        pMe->value[0]   = number_fuzzy( number_fuzzy( pMe->value[0] ) );
        break;

        pMe->value[0]   = pMe->cost;
        break;
    }

    /*
     *  Randomize color, size, and anything else we want! (do the strings)
     */
    free_string( pMe->name );               pMe->name               = NULL;
    free_string( pMe->short_descr );        pMe->short_descr        = NULL;
    free_string( pMe->description );        pMe->description        = NULL;
    free_string( pMe->action_descr );       pMe->action_descr       = NULL;
    free_string( pMe->short_descr_plural ); pMe->short_descr_plural = NULL;
    free_string( pMe->description_plural ); pMe->description_plural = NULL;
    free_string( pMe->real_description );   pMe->real_description   = NULL;

    prop_strings( pMe );

    free_string( _target );

    return NULL;
}

/*
 * Emits text from a prop.
 * If called on a room-type, echos to the interior.
 */
VARIABLE_DATA *func_emit( void * owner, int type, VARIABLE_DATA *out )
{
    char *_out;
    PROP_DATA *p;
    PLAYER_DATA *rch;
    SCENE_INDEX_DATA *pScene=NULL;

    if( PARM(out,TYPE_STRING) )
    {
        _out = !out ? str_dup( "" ) : (out->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _out = translate_variables( owner, type, strip_curlies((char *)out->value) );

    if ( type == TYPE_SCENE ) {
        pScene = (SCENE_INDEX_DATA *)owner;
        if ( pScene == NULL ) return NULL;
        
        for ( rch = pScene->people;
              rch != NULL;
              rch = rch->next_in_scene )
        send_to_actor( _out, rch );
        send_to_actor( "\n\r", rch );        
        free_string( _out );
        return NULL;
    } else
    if ( type != TYPE_PROP )
    return NULL;  /* catch for scripts running on other things */


    p = (PROP_DATA *)owner;

    if ( p == NULL ) return NULL;

    if ( p->carried_by != NULL ) {
         send_to_actor( _out, p->carried_by );
         return NULL;
    }

    pScene = p->in_scene;
    if ( pScene != NULL ) {
           for ( rch = pScene->people;
                 rch != NULL;
                 rch = rch->next_in_scene )
         send_to_actor( _out, rch );
         send_to_actor( "\n\r", rch );
    }

    free_string( _out );
    return NULL;
}

/*
 * Emits text from all props with a matching vnum.
 */
VARIABLE_DATA *func_reverb( void * owner, int type, VARIABLE_DATA *out )
{
    char *_out;
    PROP_DATA *p;
    PLAYER_DATA *rch;
    SCENE_INDEX_DATA *pScene=NULL;
    int vnum;

    if ( type != TYPE_PROP ) return NULL;  /* catch for scripts running on other things */

    if( PARM(out,TYPE_STRING) )
    {
        _out = !out ? str_dup( "" ) : (out->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _out = translate_variables( owner, type, strip_curlies((char *)out->value) );

    p = (PROP_DATA *)owner;

    if ( p == NULL ) return NULL;

    vnum = p->pIndexData->vnum;

    for ( p = prop_list;  p != NULL;  p = p->next ) {

    if ( p->pIndexData->vnum != vnum ) continue;

    if ( p->carried_by != NULL ) {
         send_to_actor( _out, p->carried_by );
         return NULL;
    }

    pScene = p->in_scene;
    if ( pScene != NULL ) {
           for ( rch = pScene->people;
                 rch != NULL;
                 rch = rch->next_in_scene )
             send_to_actor( _out, rch );
    }

    }

    free_string( _out );

    return NULL;
}

/*
 * For the history command.
 */
VARIABLE_DATA *func_history( void * owner, int type, VARIABLE_DATA *target, 
VARIABLE_DATA *out )
{
    char buf[MAX_STRING_LENGTH];
    char *_out, *_target;

    if ( type != TYPE_ACTOR) return NULL;

    if( PARM(out,TYPE_STRING) )
    {
        _out = !out ? str_dup( "" ) : (out->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _out = translate_variables( owner, type, strip_curlies((char *)out->value) );

    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    {
       PLAYER_DATA *ch;

    ch = get_actor_world( (PLAYER_DATA *)owner, _target );
    if ( !IS_NPC(ch) ) {
    sprintf( buf, "%s\n\r%s\n\r", PC(ch,history),  _out );
    free_string( PC(ch,history) );
    PC(ch,history) = str_dup( buf );
    }    
    }

    free_string( _target );
    free_string( _out );

    return NULL;
}

/*
 * Act()
 */
VARIABLE_DATA *func_dream( void * owner, int type, VARIABLE_DATA *out )
{
    ZONE_DATA *pZone;
    PLAYER_DATA *ch;
    SCENE_INDEX_DATA *pScene;
    PROP_DATA *pProp;
    char *_out;

    if( PARM(out,TYPE_STRING) )
    {
        _out = !out ? str_dup( "" ) : (out->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _out = translate_variables( owner, type, strip_curlies((char *)out->value) );


    switch( type ) {

      case TYPE_ACTOR: ch = (PLAYER_DATA *)owner; 
                  pZone = ch->in_scene->zone; 
break;
      case TYPE_PROP: pProp = (PROP_DATA *)owner; 
           if ( pProp->in_scene != NULL ) pZone = pProp->in_scene->zone;
           else pZone = pProp->pIndexData->zone;
break;
     case TYPE_SCENE: pScene = (SCENE_INDEX_DATA *)owner;
                     pZone = pScene->zone; 
break;
          default: pZone = NULL; break;
    }

    if ( pZone == NULL ) return NULL;

{
    CONNECTION_DATA *d;

    for ( d = connection_list; d; d = d->next )
    {
        if ( d->connected == CON_PLAYING
          && d->character->in_scene != NULL
          && d->character->in_scene->zone == pZone 
          && d->character->position == POS_SLEEPING )
        {
            send_to_actor( _out, d->character );
            send_to_actor( "\n\r",   d->character );
        }
    }
}
  
    free_string( _out ); 

    return NULL;
}


/*
 * Numberize()
 */
VARIABLE_DATA * func_numw( void * owner, int type, VARIABLE_DATA *astr )
{
    VARIABLE_DATA *newvar;
    char *_astr;
    int v;

    if( PARM(astr,TYPE_STRING) )
    {
        _astr = !astr ? str_dup( "" ) : (astr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _astr = translate_variables( owner, type, strip_curlies((char *)astr->value) );

    v = atoi(_astr);
    free_string( _astr );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( numberize(v) );
    return newvar;
}



/*
 * String_replace().
 */
VARIABLE_DATA * func_strp( void * owner, int type, VARIABLE_DATA *value,
                           VARIABLE_DATA *old, VARIABLE_DATA *new )
{
    char buf[MAX_STRING_LENGTH];
    char *_value, *_old, *_new;
    VARIABLE_DATA *newvar;

    if( PARM(value,TYPE_STRING) )
    {
        _value = !value ? str_dup( "" ) : (value->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _value = translate_variables( owner, type, strip_curlies((char *)value->value) );

    if( PARM(old,TYPE_STRING) )
    {
        _old = !old ? str_dup( "" ) : (old->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _old = translate_variables( owner, type, strip_curlies((char *)old->value) );

    if( PARM(new,TYPE_STRING) )
    {
        _new = !new ? str_dup( "" ) : (new->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _new = translate_variables( owner, type, strip_curlies((char *)new->value) );

    if ( *_value == '\0' || *_old == '\0' )
    {
        free_string( _value );
        free_string( _old );
        free_string( _new );
        return NULL;
    }

    while ( strstr( _value, _old ) )
    {
        _value = string_replace( _value, _old, _new );

        if ( *_value == '\0' || *_old == '\0' )
        {
            sprintf( buf, "%s", _value );
            free_string( _value );
            free_string( _old );
            free_string( _new );
            return NULL;
        }
    }

    sprintf( buf, "%s", _value );
    free_string( _value );
    free_string( _old );
    free_string( _new );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}






/*
 * Self-Interpret.
 */
VARIABLE_DATA * func_do( void * owner, int type,
                         VARIABLE_DATA *exp0,
                         VARIABLE_DATA *exp1,
                         VARIABLE_DATA *exp2,
                         VARIABLE_DATA *exp3,
                         VARIABLE_DATA *exp4,
                         VARIABLE_DATA *exp5 )
{
    char *_exp0, *_exp1, *_exp2, *_exp3, *_exp4, *_exp5;

    if ( type != TYPE_ACTOR )
        return NULL;



    if( PARM(exp0,TYPE_STRING) )
    {
        _exp0 = !exp0 ? str_dup( "" ) : (exp0->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp0 = translate_variables( owner, type, strip_curlies((char *)exp0->value) );

    if( PARM(exp1,TYPE_STRING) )
    {
        _exp1 = !exp1 ? str_dup( "" ) : (exp1->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp1 = translate_variables( owner, type, strip_curlies((char *)exp1->value) );

    if( PARM(exp2,TYPE_STRING) )
    {
        _exp2 = !exp2 ? str_dup( "" ) : (exp2->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp2 = translate_variables( owner, type, strip_curlies((char *)exp2->value) );

    if( PARM(exp3,TYPE_STRING) )
    {
        _exp3 = !exp3 ? str_dup( "" ) : (exp3->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp3 = translate_variables( owner, type, strip_curlies((char *)exp3->value) );

    if( PARM(exp4,TYPE_STRING) )
    {
        _exp4 = !exp4 ? str_dup( "" ) : (exp4->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp4 = translate_variables( owner, type, strip_curlies((char *)exp4->value) );

    if( PARM(exp5,TYPE_STRING) )
    {
        _exp5 = !exp5 ? str_dup( "" ) : (exp5->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp5 = translate_variables( owner, type, strip_curlies((char *)exp5->value) );

    interpret( (PLAYER_DATA *)owner, _exp0 );
    free_string(_exp0);

    interpret( (PLAYER_DATA *)owner, _exp1 );
    free_string(_exp1);

    interpret( (PLAYER_DATA *)owner, _exp2 );
    free_string(_exp2);

    interpret( (PLAYER_DATA *)owner, _exp3 );
    free_string(_exp3);

    interpret( (PLAYER_DATA *)owner, _exp4 );
    free_string(_exp4);

    interpret( (PLAYER_DATA *)owner, _exp5 );
    free_string(_exp5);

    return NULL;
}


VARIABLE_DATA * func_jump( void * owner, int type, VARIABLE_DATA *location )
{
    PLAYER_DATA *actor;
    char *_loc;
    int rvnum;

    actor = (PLAYER_DATA *)owner;

    if ( PARM(location,TYPE_STRING) )
    {
        _loc = !location ? str_dup( "" ) : (location->value
                                                ? str_dup( "1" )
                                                : str_dup( "0" ));
    }
    else
    _loc = translate_variables( owner, type, 
                                strip_curlies( (char *)location->value 
));

    
    rvnum = atoi(_loc);

    actor_from_scene( actor );
    actor_to_scene( actor, get_scene_index( rvnum ) );
    return NULL;
}


/*
 * Interpret.
 */
VARIABLE_DATA * func_interpret( void * owner, int type,
                         VARIABLE_DATA *who,
                         VARIABLE_DATA *exp1,
                         VARIABLE_DATA *exp2,
                         VARIABLE_DATA *exp3,
                         VARIABLE_DATA *exp4 )
{
    char *_exp1, *_exp2, *_exp3, *_exp4;
    PLAYER_DATA *actor;

    if ( !who || who->type != TYPE_ACTOR )
        return NULL;

    actor = (PLAYER_DATA *)who->value;

    if( PARM(exp1,TYPE_STRING) )
    {
        _exp1 = !exp1 ? str_dup( "" ) : (exp1->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp1 = translate_variables( owner, type, strip_curlies((char *)exp1->value) );

    if( PARM(exp2,TYPE_STRING) )
    {
        _exp2 = !exp2 ? str_dup( "" ) : (exp2->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp2 = translate_variables( owner, type, strip_curlies((char *)exp2->value) );

    if( PARM(exp3,TYPE_STRING) )
    {
        _exp3 = !exp3 ? str_dup( "" ) : (exp3->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp3 = translate_variables( owner, type, strip_curlies((char *)exp3->value) );

    if( PARM(exp4,TYPE_STRING) )
    {
        _exp4 = !exp4 ? str_dup( "" ) : (exp4->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _exp4 = translate_variables( owner, type, strip_curlies((char *)exp4->value) );

    interpret( actor, _exp1 );
    free_string(_exp1);

    interpret( actor, _exp2 );
    free_string(_exp2);

    interpret( actor, _exp3 );
    free_string(_exp3);

    interpret( actor, _exp4 );
    free_string(_exp4);

    return NULL;
}



VARIABLE_DATA *func_ms( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    return NULL;
}


VARIABLE_DATA *func_os( void * owner, int type, VARIABLE_DATA *astr, VARIABLE_DATA *bstr )
{
    char buf[MAX_STRING_LENGTH];
    PROP_DATA *prop;
    char *p = "";
    VARIABLE_DATA *newvar;
    char *_bstr;

    if( PARM(astr,TYPE_PROP) )
    return NULL;

    if( PARM(bstr,TYPE_STRING) )
    {
        _bstr = !bstr ? str_dup( "" ) : (bstr->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _bstr = translate_variables( owner, type, strip_curlies((char *)bstr->value) );

    prop = (PROP_DATA *)astr->value;

    if ( !str_cmp( _bstr, "short"       ) ) p = prop->short_descr;
    if ( !str_cmp( _bstr, "long"        ) ) p = prop->description;
    if ( !str_cmp( _bstr, "name"        ) ) p = prop->name;
    if ( !str_cmp( _bstr, "description" ) ) p = prop->real_description;
    if ( !str_cmp( _bstr, "plural"      ) ) p = pluralize( prop->short_descr );
    if ( !str_cmp( _bstr, "vnum"        ) )
    {
        sprintf( buf, "%d", prop->pIndexData->vnum );
        p = buf;
    }
    if ( !str_cmp( _bstr, "scene" ) )
    {
        sprintf( buf, "%d", prop->in_scene->vnum );
        p = buf;
    }

    free_string( _bstr );

    newvar = new_variable( );
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( p );
    return newvar;
}


VARIABLE_DATA *func_heal( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *gain )
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_gain = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(gain,TYPE_STRING) )
    {
        _gain = !gain ? str_dup( "" ) : (gain->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _gain = translate_variables( owner, type, strip_curlies((char *)gain->value) );
    
    if ( ch == NULL ) return NULL;

    ch->hit += atoi( _gain );
    if ( ch->hit > MAXHIT(ch) ) ch->hit = MAXHIT(ch);
    if ( ch->hit <= 0 ) ch->hit = 1;

    free_string( _gain);
    free_string( _target);
    return NULL;
}

/*
 * You have been hurt.
 * Can kill you.
 */
VARIABLE_DATA *func_hurt( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *gain )
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_gain = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(gain,TYPE_STRING) )
    {
        _gain = !gain ? str_dup( "" ) : (gain->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _gain = translate_variables( owner, type, strip_curlies((char *)gain->value) );
    
    if ( ch == NULL ) return NULL;

    ch->hit -= atoi( _gain );
    if ( ch->hit > MAXHIT(ch) ) ch->hit = MAXHIT(ch);
    if ( ch->hit <= 0 ) raw_kill( ch );

    free_string( _gain);
    free_string( _target);
    return NULL;
}

/*
 * You have been bombed.  Everyone in the scene, limited exceptions.
 * Can kill you.
 */
VARIABLE_DATA *func_bomb( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *gain )
{
    PLAYER_DATA *ch;
    SCENE_INDEX_DATA *scene = NULL;
    char *_target = NULL;
    char *_gain = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    scene = (get_scene_index( atoi(_target) ));

     if ( scene != NULL ){ scene =  (type == TYPE_SCENE ? 
                   (SCENE_INDEX_DATA *)owner
                       : ((PLAYER_DATA *)owner)->in_scene );
    }
    }

    if( PARM(gain,TYPE_STRING) )
    {
        _gain = !gain ? str_dup( "" ) : (gain->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _gain = translate_variables( owner, type, strip_curlies((char *)gain->value) );
    
    
     
    if ( scene == NULL ) return NULL;

    for ( ch = scene->people; ch != NULL; ch = ch->next_in_scene ) {  
    ch->hit -= atoi( _gain );
    if ( ch->hit > MAXHIT(ch) ) ch->hit = MAXHIT(ch);
    if ( ch->hit <= 0 ) raw_kill( ch );
    }

    free_string( _gain);
    free_string( _target);
    return NULL;
}


/*
 * Change in mana.
 */
VARIABLE_DATA *func_mana( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *gain )
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_gain = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(gain,TYPE_STRING) )
    {
        _gain = !gain ? str_dup( "" ) : (gain->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _gain = translate_variables( owner, type, strip_curlies((char *)gain->value) );
    
    if ( ch == NULL ) return NULL;

    ch->mana += atoi( _gain );
    if ( ch->mana > MAXMANA(ch) ) ch->mana = MAXMANA(ch);
    if ( ch->mana <= 0 ) ch->mana = 0;

    free_string( _gain);
    free_string( _target);
    return NULL;
}

/*
 * Returns TRUE if a player has everything required for a spell.
 */
VARIABLE_DATA *func_reagents( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *list, VARIABLE_DATA *quantity )
{
    PLAYER_DATA *ch;
    VARIABLE_DATA *newvar;
    char *_target = NULL;
    char *_list = NULL;
    char *_quantity = NULL;
    char *point, *point2;
    char buf[MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];
    bool fOk = TRUE;

    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(list,TYPE_STRING) )
    {
        _list = !list ? str_dup( "" ) : (list->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _list = translate_variables( owner, type, strip_curlies((char *)list->value) );

    if( PARM(quantity,TYPE_STRING) )
    {
        _quantity = !quantity ? str_dup( "" ) : (quantity->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _quantity = translate_variables( owner, type, strip_curlies((char *)quantity->value) );
    
    if ( ch == NULL ) return NULL;

    point = _list;
    point2 = _quantity;
    for ( point = one_argument( point, buf );  buf[0] != '\0' && fOk;  )
    {
        PROP_DATA *pProp, *pPropNext, *pProp2, *pPropNext2;
        int quant;

        point2 = one_argument( point, buf2 );
        if ( buf2[0] == '\0' ) quant = 1;
	else quant = atoi(buf2);

        for( pProp = ch->carrying;  pProp != NULL;  pProp = pPropNext )
        {
            pPropNext = pProp->next;
            if ( pProp->item_type == ITEM_CONTAINER ) {
                 for ( pProp2 = pProp->contains;  pProp2 != NULL;  pProp2 = pPropNext2 )
                 {
                     pPropNext2 = pProp2->next;
                     if ( pProp->item_type == ITEM_COMPONENT 
                       && pProp->value[0] == atoi(buf2) )
                         quant--;
                 }
            }

            if ( pProp->item_type == ITEM_COMPONENT
              && pProp->value[0] == atoi(buf2) ) 
                 quant--;                         
        }

        if (quant > 0) fOk = FALSE;
    }

    free_string( _list );
    free_string( _target);
    free_string( _quantity );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = fOk ? str_dup( "1" ) : str_dup( "0" );
    return newvar;
}

/*
 * Used by spell functions.
 * Mixes reagents.
 */
VARIABLE_DATA *func_mix( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *list, VARIABLE_DATA *quantity )
{
    PLAYER_DATA *ch;
    VARIABLE_DATA *newvar;
    char *_target = NULL;
    char *_list = NULL;
    char *_quantity = NULL;
    char *point, *point2;
    char buf[MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];
    bool fOk = TRUE;

    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(list,TYPE_STRING) )
    {
        _list = !list ? str_dup( "" ) : (list->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _list = translate_variables( owner, type, strip_curlies((char *)list->value) );

    if( PARM(quantity,TYPE_STRING) )
    {
        _quantity = !quantity ? str_dup( "" ) : (quantity->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _quantity = translate_variables( owner, type, strip_curlies((char *)quantity->value) );
    
    if ( ch == NULL ) return NULL;

    point = _list;
    point2 = _quantity;
    for ( point = one_argument( point, buf );  buf[0] != '\0' && fOk;  )
    {
        PROP_DATA *pProp, *pPropNext, *pProp2, *pPropNext2;
        int quant;

        point2 = one_argument( point, buf2 );
        if ( buf2[0] == '\0' ) quant = 1;
	else quant = atoi(buf2);

        for( pProp = ch->carrying;  pProp != NULL;  pProp = pPropNext )
        {
            pPropNext = pProp->next_content;
            if ( pProp->item_type == ITEM_CONTAINER ) {
                 for ( pProp2 = pProp->contains;  pProp2 != NULL;  pProp2 = pPropNext2 )
                 {
                     pPropNext2 = pProp2->next;
                     if ( pProp->item_type == ITEM_COMPONENT 
                       && pProp->value[0] == atoi(buf2) )
                       {
                         extract_prop( pProp2 );
                         quant--;
                       }
                 }
            }

            if ( pProp->item_type == ITEM_COMPONENT
              && pProp->value[0] == atoi(buf2) ) 
               {
                 extract_prop( pProp );
                 quant--;            
               }             
        }

        if (quant > 0) fOk = FALSE;
    }

    free_string( _list );
    free_string( _target);
    free_string( _quantity );

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = fOk ? str_dup( "1" ) : str_dup( "0" );
    return newvar;
}

/*
 * You have been paid.
 */
VARIABLE_DATA *func_pay( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *gain )
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_gain = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(gain,TYPE_STRING) )
    {
        _gain = !gain ? str_dup( "" ) : (gain->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _gain = translate_variables( owner, type, strip_curlies((char *)gain->value) );
    
    if ( ch == NULL ) return NULL;

    /*
     * Pay a character.  Rounds to nearest gold.
     */  
    prop_to_char( create_money( atoi(_gain), COIN_GOLD ), ch );
    merge_money( ch );
    

    free_string( _gain);
    free_string( _target);
    return NULL;
}

/*
 * You have been position.
 */
VARIABLE_DATA *func_pos( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *gain )
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_gain = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(gain,TYPE_STRING) )
    {
        _gain = !gain ? str_dup( "" ) : (gain->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _gain = translate_variables( owner, type, strip_curlies((char *)gain->value) );
    
    if ( ch == NULL ) return NULL;

    ch->position = atoi(_gain);

    free_string( _gain);
    free_string( _target);
    return NULL;
}


/*
 * You have been stripped of all your worldly possessions (except money).
 */
VARIABLE_DATA *func_strip( void * owner, int type, VARIABLE_DATA *target )
{
    PLAYER_DATA *ch;
    PROP_DATA *pProp, *pPropNext;
    char *_target = NULL;
    int count_coins;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if ( ch == NULL ) return NULL;

    count_coins =   tally_coins( ch );

    for ( pProp = ch->carrying;  pProp != NULL;  pProp = pPropNext ) {

        pPropNext = pProp->next_content;
        prop_from_char( pProp );
        extract_prop( pProp );
    }

    create_amount( count_coins, ch, NULL, NULL );

    free_string( _target);
    return NULL;
}

/*
 * Removes all weapons from player top level.
 */
VARIABLE_DATA *func_disarm( void * owner, int type, VARIABLE_DATA *target )
{
    PLAYER_DATA *ch;
    PROP_DATA *pProp, *pPropNext;
    char *_target = NULL;

    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if ( ch == NULL ) return NULL;


    for ( pProp = ch->carrying;  pProp != NULL;  pProp = pPropNext ) {

        pPropNext = pProp->next_content;
        if ( pProp->item_type == ITEM_WEAPON 
          || pProp->item_type == ITEM_RANGED_WEAPON ) {
		prop_from_char( pProp );
        	extract_prop( pProp );
        }
    }  

    free_string( _target);
    return NULL;
}


/*
 * Checks verse a skill, 0=fail
 */
VARIABLE_DATA *func_skill( void * owner, int type, VARIABLE_DATA *target,
                           VARIABLE_DATA *sn, VARIABLE_DATA *v ) 
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_sn = NULL;
    char *_value = NULL;
    VARIABLE_DATA *newv;
    int vsn;
    int check;

    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if ( ch == NULL ) return NULL;

    if( PARM(sn,TYPE_STRING) )
    {
        _sn = !sn ? str_dup( "" ) : (sn->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _sn = translate_variables( owner, type, strip_curlies((char *)sn->value) );
    vsn = skill_lookup(_sn);

    if( PARM(v,TYPE_STRING) )
    {
        _value = !v ? str_dup( "" ) : (v->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _value = translate_variables( owner, type, strip_curlies((char *)v->value) );
    check = atoi(_value);

    newv=new_variable();
    newv->type = TYPE_STRING;
    if ( number_range(0,check) <= PC(ch,learned)[vsn] ) newv->value = str_dup("1");
    else newv->value = str_dup("0");

    free_string( _target);
    free_string( _value);
    free_string( _sn);
    return newv;
}

/*
 * Sets the value of a skill on a player.
 */
VARIABLE_DATA *func_setskill( void * owner, int type, VARIABLE_DATA *target,
                           VARIABLE_DATA *sn, VARIABLE_DATA *v ) 
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_sn = NULL;
    char *_value = NULL;
    int vsn;
    int check;

    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if ( ch == NULL ) return NULL;

    if( PARM(sn,TYPE_STRING) )
    {
        _sn = !sn ? str_dup( "" ) : (sn->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _sn = translate_variables( owner, type, strip_curlies((char *)sn->value) );
    vsn = skill_lookup(_sn);

    if( PARM(v,TYPE_STRING) )
    {
        _value = !v ? str_dup( "" ) : (v->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _value = translate_variables( owner, type, strip_curlies((char *)v->value) );
    check = atoi(_value);

    PC(ch,learned)[vsn] = check;

    free_string( _target);
    free_string( _value);
    free_string( _sn);
    return NULL;
}


VARIABLE_DATA *func_spawn( void * owner, int type, VARIABLE_DATA *dest )
{
    SCENE_INDEX_DATA *pScene;
    char *_dest = NULL;

    if( PARM(dest,TYPE_STRING) )
    {
        _dest = !dest ? str_dup( "" ) : (dest->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _dest = translate_variables( owner, type, strip_curlies((char *)dest->value) );
    
       pScene = get_scene_index( atoi( _dest ) );
       if ( pScene != NULL ) {
          spawn_scene( pScene );
       }

    free_string( _dest);
    return NULL;
}


VARIABLE_DATA *func_purge( void * owner, int type, VARIABLE_DATA *dest )
{
    char *_dest = NULL;

    if( PARM(dest,TYPE_STRING) )
    {
        _dest = !dest ? str_dup( "" ) : (dest->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _dest = translate_variables( owner, type, strip_curlies((char *)dest->value) );

    cmd_purge( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, _dest );    

    free_string( _dest);
    return NULL;
}

VARIABLE_DATA *func_force( void * owner, int type, VARIABLE_DATA *dest )
{
    char *_dest = NULL;

    if( PARM(dest,TYPE_STRING) )
    {
        _dest = !dest ? str_dup( "" ) : (dest->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _dest = translate_variables( owner, type, strip_curlies((char *)dest->value) );

    cmd_force( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, _dest );    

    free_string( _dest);
    return NULL;
}


VARIABLE_DATA *func_elude( void * owner, int type )
{
    if ( type != TYPE_ACTOR ) return NULL;
    else
    {
       PLAYER_DATA *pActor = (PLAYER_DATA *)owner;
       PLAYER_DATA *pFollow;

       for ( pFollow = actor_list;  pFollow != NULL;  pFollow = pFollow->next )
       {
		if ( pFollow->master == pActor ) cmd_follow( pFollow, "self" );
       }
    }

    return NULL;
}


VARIABLE_DATA *func_move( void * owner, int type, VARIABLE_DATA *target, 
VARIABLE_DATA *dest )
{
    SCENE_INDEX_DATA *pScene;
    PLAYER_DATA *ch, *och;
    char *_dest = NULL;
    char *_target;

    if( PARM(dest,TYPE_STRING) )
    {
        _dest = !dest ? str_dup( "" ) : (dest->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _dest = translate_variables( owner, type, strip_curlies((char *)dest->value) );

    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );
    
    och = type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list;

    if ( target != NULL )
    ch = target->type == TYPE_ACTOR ? target->value
                                  : get_actor_world( och, _target );
    else
    ch = get_actor_world( och, _target );

    if ( ch == NULL ) return NULL;

    pScene = get_scene_index( atoi( _dest ) );
       if ( pScene != NULL ) {
	     actor_from_scene( ch );
	     actor_to_scene( ch, pScene );
                cmd_look( ch, "" ); /* debatable */
       }

    free_string( _target );
    free_string( _dest);
    return NULL;
}


VARIABLE_DATA *func_here( void *owner, int type )
{
   char buf[MAX_STRING_LENGTH];
   SCENE_INDEX_DATA *pScene;
   VARIABLE_DATA *newvar;

   switch( type ) {
       case TYPE_STRING: pScene = NULL; break;
       case TYPE_ACTOR: pScene = ((PLAYER_DATA *)owner)->in_scene; break;
       case TYPE_PROP:
              {   PROP_DATA *pProp;

                      pProp = (PROP_DATA *)owner;
                      pScene = pProp->in_scene;
                      if ( !pScene && pProp->carried_by )
                             pScene = pProp->carried_by->in_scene;
                      if ( !pScene && pProp->in_prop )
                             pScene = pProp->in_prop->in_scene;
              }
       case TYPE_SCENE:
                 pScene = (SCENE_INDEX_DATA *)owner;
              break;
       default: pScene = NULL; break;
   }

   if ( pScene == NULL ) return NULL;

   newvar = new_variable();
   newvar->type = TYPE_STRING;
   sprintf( buf, "%d", pScene->vnum );
   newvar->value = str_dup( buf );
   return newvar;
}


/*
 * Moves all players from one location to another.
 */
VARIABLE_DATA *func_moveall( void * owner, int type, VARIABLE_DATA *from,
                          VARIABLE_DATA *dest, VARIABLE_DATA *cmd )
{
    PLAYER_DATA *ch, *ch_next;
    SCENE_INDEX_DATA *pScene, *pDest;
    char *_from = NULL;
    char *_dest = NULL;
     char *_cmd = NULL;


    if( PARM(from,TYPE_STRING) )
    {
        _from = !from ? str_dup( "" ) : (from->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _from = translate_variables( owner, type, strip_curlies((char *)from->value) );

    pScene = 
    get_scene_index( atoi( _from ) );


    if( PARM(dest,TYPE_STRING) )
    {
        _dest = !dest ? str_dup( "" ) : (dest->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _dest = translate_variables( owner, type, strip_curlies((char *)dest->value) );

    pDest = 
    get_scene_index( atoi( _dest ) );

    if( PARM(cmd,TYPE_STRING) )
    {
        _cmd = !cmd ? str_dup( "" ) : (cmd->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _cmd = translate_variables( owner, type, strip_curlies((char *)cmd->value) );

    if ( pScene == NULL || pDest == NULL || pScene==pDest ) return NULL;
    
    for ( ch = pScene->people;  ch != NULL;  ch = ch_next ) {

	ch_next = ch->next_in_scene;
          if ( IS_NPC(ch) /* Add check for mounts and followers. */ ) 
		continue;

          actor_from_scene( ch );
          actor_to_scene( ch, pDest );
          if ( !MTD(_cmd) ) interpret( ch, _cmd );
          ch = pScene->people;
    }

    free_string( _dest);
    free_string( _from);
    free_string( _cmd);
    return NULL;
}



VARIABLE_DATA *func_home( void * owner, int type, VARIABLE_DATA *target,
                          VARIABLE_DATA *dest )
{
    PLAYER_DATA *ch;
    SCENE_INDEX_DATA *pScene;
    char *_target = NULL;
    char *_dest = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(dest,TYPE_STRING) )
    {
        _dest = !dest ? str_dup( "" ) : (dest->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _dest = translate_variables( owner, type, strip_curlies((char *)dest->value) );
    
    if ( ch != NULL && !IS_NPC(ch) ) {
       pScene = get_scene_index( atoi( _dest ) );
       if ( pScene != NULL ) {
          PC(ch,home) = atoi( _dest );
       }
    }

    free_string( _dest);
    free_string( _target);
    return NULL;
}


VARIABLE_DATA *func_death( void * owner, int type, VARIABLE_DATA *target,
                           VARIABLE_DATA *dest )
{
    PLAYER_DATA *ch;
    SCENE_INDEX_DATA *pScene;
    char *_target = NULL;
    char *_dest = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(dest,TYPE_STRING) )
    {
        _dest = !dest ? str_dup( "" ) : (dest->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _dest = translate_variables( owner, type, strip_curlies((char *)dest->value) );
    
    if ( ch != NULL && !IS_NPC(ch) ) {
       pScene = get_scene_index( atoi( _dest ) );
       if ( pScene != NULL ) {
          PC(ch,death) = atoi( _dest );
       }
    }

    free_string( _dest);
    free_string( _target);
    return NULL;
}

VARIABLE_DATA *func_open( void * owner, int type, VARIABLE_DATA *loc,
                          VARIABLE_DATA *dir )
{
    SCENE_INDEX_DATA *pScene;
    char *_loc = NULL;
    char *_dir = NULL;
    int direction;


    if( PARM(loc,TYPE_STRING) )
    {
        _loc = !loc ? str_dup( "" ) : (loc->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _loc = translate_variables( owner, type, strip_curlies((char *)loc->value) );

    if( PARM(dir,TYPE_STRING) )
    {
        _dir = !dir ? str_dup( "" ) : (dir->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _dir = translate_variables( owner, type, strip_curlies((char *)dir->value) );
    
    pScene = get_scene_index( atoi( _loc ) );
    direction = atoi( _dir );

    free_string( _loc );
    free_string( _dir );
    return NULL;
}

VARIABLE_DATA *func_close( void * owner, int type, VARIABLE_DATA *loc,
                           VARIABLE_DATA *dir )
{
    SCENE_INDEX_DATA *pScene;
    char *_loc = NULL;
    char *_dir = NULL;
    int direction;


    if( PARM(loc,TYPE_STRING) )
    {
        _loc = !loc ? str_dup( "" ) : (loc->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _loc = translate_variables( owner, type, strip_curlies((char *)loc->value) );

    if( PARM(dir,TYPE_STRING) )
    {
        _dir = !dir ? str_dup( "" ) : (dir->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _dir = translate_variables( owner, type, strip_curlies((char *)dir->value) );
    
    pScene = get_scene_index( atoi( _loc ) );
    direction = atoi( _dir );

    free_string( _loc );
    free_string( _dir );
    return NULL;
}


VARIABLE_DATA *func_dispense( void * owner, int type, VARIABLE_DATA *target,
                              VARIABLE_DATA *disp )
{
    PLAYER_DATA *ch;
    PROP_DATA *pProp;
    char *_target = NULL;
    char *_disp = NULL;

    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(disp,TYPE_STRING) )
    {
        _disp = !disp ? str_dup( "" ) : (disp->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _disp = translate_variables( owner, type, strip_curlies((char *)disp->value) );
    
    if ( ch != NULL ) {
       PROP_INDEX_DATA *pIndex;
       pIndex = get_prop_index( atoi( _disp ) );
       pProp = create_prop( pIndex, 1 );
       if ( pProp != NULL ) prop_to_char( pProp, ch );
    }

    free_string( _disp );
    free_string( _target);
    return NULL;
}

VARIABLE_DATA *func_create( void * owner, int type, VARIABLE_DATA *vnum, VARIABLE_DATA *loc )
{
    PLAYER_DATA *ch;
    SCENE_INDEX_DATA *pScene, *pLoc;
    char *_loc    = NULL;
    char *_vnum   = NULL;

    if( PARM(vnum,TYPE_STRING) )
    {
        _vnum = !vnum ? str_dup( "" ) : (vnum->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _vnum = translate_variables( owner, type, strip_curlies((char *)vnum->value) );

    if( PARM(loc,TYPE_STRING) )
    {
        _loc = !loc ? str_dup( "" ) : (loc->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _loc = translate_variables( owner, type, strip_curlies((char *)loc->value) );

    pScene = NULL;

    if ( type == TYPE_ACTOR ) {
        ch = (PLAYER_DATA *)owner;
        if ( ch != NULL ) pScene = ch->in_scene;
    }
    else if ( type == TYPE_SCENE ) pScene = (SCENE_INDEX_DATA *)owner;
    else if ( type == TYPE_PROP  ) pScene = ((PROP_DATA *)owner)->in_scene;
    
    if ( (pLoc = get_scene_index( atoi(_loc) )) != NULL ) {
        pScene = pLoc;
    }
    
    if ( pScene != NULL ) {
       ACTOR_INDEX_DATA *pIndex;
       pIndex = get_actor_index( atoi( _vnum ) );
       ch = create_actor( pIndex );
       if ( ch != NULL ) actor_to_scene( ch, pScene );
    }

    free_string( _vnum );
    free_string( _loc );
    return NULL;
}


        

VARIABLE_DATA *func_eat( void * owner, int type, VARIABLE_DATA *target )
{
    PROP_DATA *prop;
    char *_target = NULL;


    if ( (target->type == TYPE_ACTOR) )
    return NULL;
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    prop = type == TYPE_ACTOR ? 
    get_prop_here( (PLAYER_DATA *)owner, _target ) :
    (target->type == TYPE_PROP ? (PROP_DATA *)target : NULL);
    }
    
    if ( prop == NULL ) return NULL;

    extract_prop(prop);

    free_string( _target);
    return NULL;
}
        
    

VARIABLE_DATA *func_samescene( void * owner, int type, VARIABLE_DATA *var )
{
    char buf[MAX_STRING_LENGTH];
    int val;
    VARIABLE_DATA *newvar;

    if ( var == NULL ) val = 0;
    else
    switch ( type )
    {
        case TYPE_PROP:
          if ( var->type == TYPE_PROP )
           val = ((PROP_DATA *)var->value)->in_scene == ((PROP_DATA *)owner)->in_scene;
          if ( var->type == TYPE_ACTOR )
           val = ((PLAYER_DATA *)var->value)->in_scene == ((PROP_DATA *)owner)->in_scene;
          if ( var->type == TYPE_SCENE )
           val = (SCENE_INDEX_DATA *)var->value == ((PROP_DATA *)owner)->in_scene;
           val = 0;
         break;
        case TYPE_ACTOR:
          if ( var->type == TYPE_PROP )
           val = ((PROP_DATA *)var->value)->in_scene == ((PLAYER_DATA *)owner)->in_scene;
          if ( var->type == TYPE_ACTOR )
           val = ((PLAYER_DATA *)var->value)->in_scene == ((PLAYER_DATA *)owner)->in_scene;
          if ( var->type == TYPE_SCENE )
           val = (SCENE_INDEX_DATA *)var->value == ((PLAYER_DATA *)owner)->in_scene;
           val = 0;
         break;
        case TYPE_SCENE:
          if ( var->type == TYPE_PROP )
           val = ((PROP_DATA *)var->value)->in_scene == (SCENE_INDEX_DATA *)owner;
          if ( var->type == TYPE_ACTOR )
           val = ((PLAYER_DATA *)var->value)->in_scene == (SCENE_INDEX_DATA *)owner;
          if ( var->type == TYPE_SCENE )
           val = (SCENE_INDEX_DATA *)var->value == (SCENE_INDEX_DATA *)owner;
           val = 0;
         break;
        default: val = 0;
    }

    sprintf( buf, "%d", val );
    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



VARIABLE_DATA *func_alert( void * owner, int type, VARIABLE_DATA *name, VARIABLE_DATA *limits )
{
    return NULL;
}


VARIABLE_DATA *func_tname( void * owner, int type, VARIABLE_DATA *var )
{
    VARIABLE_DATA *find_var;
    char *value;

    if( PARM(var,TYPE_STRING) )
    {
        value = !var ? str_dup( "" ) : (var->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    value = translate_variables( owner, type, strip_curlies((char *)var->value) );

    find_var = find_variable( owner, type, value );
    free_string( value );

    switch ( find_var->type ) {
        case TYPE_STRING: 
            value = str_dup( (char *)find_var->value );
          break;
        case TYPE_ACTOR:
            value = str_dup( STR(((PLAYER_DATA *)find_var->value),name) );
          break;
        case TYPE_PROP:
            value = str_dup( STR(((PROP_DATA *)find_var->value),short_descr) );
          break;
        case TYPE_SCENE:
            value = str_dup( ((SCENE_INDEX_DATA *)find_var->value)->name );
          break;
        default: value = str_dup( "" ); break;
    }

    find_var = new_variable();
    find_var->type = TYPE_STRING;
    find_var->value = value;
    return find_var;
}


VARIABLE_DATA *func_eval( void * owner, int type, VARIABLE_DATA *value )
{
    VARIABLE_DATA *newvar;
    char buf[MAX_STRING_LENGTH];
    char *_value;

    if( PARM(value,TYPE_STRING) )
    {
        _value = !value ? str_dup( "" ) : (value->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else
    _value = translate_variables( owner, type, strip_curlies((char *)value->value) );

    sprintf( buf, "%s", _value );
    free_string(_value);

    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}


/*
 * Returns the name of a random player in the scene.
 * format: rndplr( )
 */
VARIABLE_DATA *func_rndplr( void * owner, int type, VARIABLE_DATA *from )
{
    VARIABLE_DATA *newvar;
    SCENE_INDEX_DATA *pScene;
    char buf[MAX_STRING_LENGTH];
    PLAYER_DATA *och, *rch = NULL;
    PLAYER_DATA *ch;
    char *p = "";
    char *_from;

    if( PARM(from,TYPE_STRING) )
    {
        _from = !from ? str_dup( "" ) : (from->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _from = translate_variables( owner, type, strip_curlies((char *)from->value) );

    pScene = 
    get_scene_index( atoi( _from ) );
    free_string( _from );

    och = actor_list;

    if ( pScene == NULL )
    switch ( type )
    {
        case TYPE_PROP: pScene = ((PROP_DATA *)owner)->in_scene;
                       och = NULL;
         break;
        case TYPE_ACTOR: pScene = ((PLAYER_DATA *)owner)->in_scene;
                       och = (PLAYER_DATA *)owner;
         break;
        case TYPE_SCENE: pScene = (SCENE_INDEX_DATA *)owner;
                       och = NULL;
         break;
        default: pScene = NULL;  och = NULL;
    }

    if (pScene == NULL)
    {
        sprintf( buf, "me" );
    }
    else
    {
        int count;

        count = 0;
        for ( ch = pScene->people; ch != NULL; ch = ch->next_in_scene )
        {
            if ( IS_NPC(ch) )
            continue;

            if ( och != NULL )
            {
                if ( !can_see( och, ch ) )
                continue;
            }

            count++;
        }

        if ( count > 1 )
        count -= number_range(0,count-1);

        for( ch = pScene->people; count > 0 && ch != NULL; ch = ch->next_in_scene )
        {
            if ( IS_NPC(ch) )
            continue;

            /*
             * Check for invisible players or blinded actors.
             * (applies to TYPE_ACTOR owners only)
             */
            if ( och != NULL )
            {
                if ( !can_see( och, ch ) )
                continue;
            }


            if ( --count == 0 )
            {
                rch = ch;
            }
        }


        if ( rch == NULL )
        {
            sprintf( buf, "me" );
        }
        else
        {
            sprintf( buf, "%s", STR(rch, name) );
        }
    }

    p = buf;
    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( p );
    return newvar;
}



/*
 * Digs an exit in the world.
 * format: dig( scene, direction )
 */
VARIABLE_DATA *func_dig( void * owner, int type, VARIABLE_DATA *loc, 
                                                 VARIABLE_DATA *dir,
	                                         VARIABLE_DATA *dest )
{
    SCENE_INDEX_DATA *pScene;
    SCENE_INDEX_DATA *toScene;
    char *_loc;
    char *_dest;
    char *_dir;
    int door;

    if( PARM(loc,TYPE_STRING) )
    {
        _loc = !loc ? str_dup( "" ) : (loc->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _loc = translate_variables( owner, type, strip_curlies((char *)loc->value) );

    pScene =     get_scene_index( atoi( _loc ) );
    free_string( _loc );


    if( PARM(dest,TYPE_STRING) )
    {
        _dest = !dest ? str_dup( "" ) : (dest->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _dest = translate_variables( owner, type, strip_curlies((char *)dest->value) );

    toScene =     get_scene_index( atoi( _dest ) );
    free_string( _dest );


    if( PARM(dir,TYPE_STRING) )
    {
        _dir = !dir ? str_dup( "" ) : (dir->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _dir = translate_variables( owner, type, strip_curlies((char *)dir->value) );

    door = get_dir( _dir );
    free_string( _dir );


    if ( pScene != NULL && toScene != NULL ) {

    /* dig the exit */
         if ( pScene->exit[door] == NULL )
		 pScene->exit[door] = new_exit();

		 pScene->exit[door]->to_scene = toScene;
		 pScene->exit[door]->vnum =toScene->vnum;

	 door                           = rev_dir[door];

    /* dig the exit */
         if( toScene->exit[door]== NULL )
	 toScene->exit[door]             = new_exit();

	 toScene->exit[door]->to_scene    = pScene;
	 toScene->exit[door]->vnum       = pScene->vnum;
    }

    return NULL;
}

/*
 * Removes an exit (unlink)
 * format: undig( scene, direction )
 */
VARIABLE_DATA *func_undig( void * owner, int type, VARIABLE_DATA *loc, 
                                                 VARIABLE_DATA *dir )
{
    SCENE_INDEX_DATA *pScene;
    char *_loc;
    char *_dir;
    int door;

    if ( (loc->type == TYPE_SCENE) )
    pScene = (SCENE_INDEX_DATA *)(loc->value);
    else
    {
    if( PARM(loc,TYPE_STRING) )
    {
        _loc = !loc ? str_dup( "" ) : (loc->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _loc = translate_variables( owner, type, strip_curlies((char *)loc->value) );

    pScene = 
    get_scene_index( atoi( _loc ) );
    free_string( _loc );
    }

    if( PARM(dir,TYPE_STRING) )
    {
        _dir = !dir ? str_dup( "" ) : (dir->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _dir = translate_variables( owner, type, strip_curlies((char *)dir->value) );

    door = get_dir( _dir );

    /* dig the exit */
    if ( pScene != NULL 
      && pScene->exit[door] != NULL )
    {
        EXIT_DATA *oexit;
        oexit = pScene->exit[door]->to_scene 
             && pScene->exit[door]->to_scene->exit[rev_dir[door]] 
             ? pScene->exit[door]->to_scene->exit[rev_dir[door]] : NULL;

	if ( oexit != NULL )
	{
	    free_exit( oexit );
	    pScene->exit[door]->to_scene->exit[rev_dir[door]] = NULL;
	}

	free_exit( pScene->exit[door] );
	pScene->exit[door] = NULL;
    }

    free_string( _dir );
    return NULL;
}

/*
 * Changes the title of a scene.
 * format: undig( scene, new )
 */
VARIABLE_DATA *func_rtitle( void * owner, int type, VARIABLE_DATA *loc, 
                                                 VARIABLE_DATA *dir )
{
    SCENE_INDEX_DATA *pScene;
    char *_loc;
    char *_dir;

    if ( (loc->type == TYPE_SCENE) )
    pScene = (SCENE_INDEX_DATA *)(loc->value);
    else
    {
    if( PARM(loc,TYPE_STRING) )
    {
        _loc = !loc ? str_dup( "" ) : (loc->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _loc = translate_variables( owner, type, strip_curlies((char *)loc->value) );

    pScene = 
    get_scene_index( atoi( _loc ) );
    free_string( _loc );
    }

    if( PARM(dir,TYPE_STRING) )
    {
        _dir = !dir ? str_dup( "" ) : (dir->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _dir = translate_variables( owner, type, strip_curlies((char *)dir->value) );

    if ( pScene != NULL )
    {
	free_string( pScene->name );
        pScene->name = str_dup( _dir );
    }

    free_string( _dir );
    return NULL;
}


VARIABLE_DATA *func_addowed( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *gain )
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_gain = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(gain,TYPE_STRING) )
    {
        _gain = !gain ? str_dup( "" ) : (gain->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _gain = translate_variables( owner, type, strip_curlies((char *)gain->value) );
    
    if ( ch == NULL ) return NULL;

    ch->owed += atoi( _gain );

    free_string( _gain);
    free_string( _target);
    return NULL;
}


VARIABLE_DATA *func_addbounty( void * owner, int type, VARIABLE_DATA *target, 
                          VARIABLE_DATA *gain )
{
    PLAYER_DATA *ch;
    char *_target = NULL;
    char *_gain = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    if( PARM(gain,TYPE_STRING) )
    {
        _gain = !gain ? str_dup( "" ) : (gain->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
      
    }
    else
    _gain = translate_variables( owner, type, strip_curlies((char *)gain->value) );
    
    if ( ch == NULL ) return NULL;

    ch->bounty += atoi( _gain );

    free_string( _gain);
    free_string( _target);
    return NULL;
}


VARIABLE_DATA *func_bounty( void * owner, int type, VARIABLE_DATA *target )
{
    char buf[MAX_STRING_LENGTH];
    int val;
    VARIABLE_DATA *newvar;
    PLAYER_DATA *ch;
    char *_target = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    val = ch == NULL ? -1 : ch->bounty;

    sprintf( buf, "%d", val );
    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



VARIABLE_DATA *func_owed( void * owner, int type, VARIABLE_DATA *target )
{
    char buf[MAX_STRING_LENGTH];
    int val;
    VARIABLE_DATA *newvar;
    PLAYER_DATA *ch = NULL;
    char *_target = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    val = ch == NULL ? -1 : ch->owed;

    sprintf( buf, "%d", val );
    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}

VARIABLE_DATA *func_level( void * owner, int type, VARIABLE_DATA *target )
{
    char buf[MAX_STRING_LENGTH];
    int val;
    VARIABLE_DATA *newvar;
    PLAYER_DATA *ch;
    char *_target = NULL;


    if ( (target->type == TYPE_ACTOR) )
    ch = (PLAYER_DATA *)(target->value);
    else 
    {
    if( PARM(target,TYPE_STRING) )
    {
        _target = !target ? str_dup( "" ) : (target->value
                                         ? str_dup( "1" )
                                         : str_dup( "0" ));
    }
    else   
    _target = translate_variables( owner, type, strip_curlies((char *)target->value) );

    ch = 
    get_actor_world( type == TYPE_ACTOR ? (PLAYER_DATA *)owner : actor_list, 
                   _target );
    }

    val = ch == NULL ? -1 : ch->exp_level;

    sprintf( buf, "%d", val );
    newvar = new_variable();
    newvar->type = TYPE_STRING;
    newvar->value = str_dup( buf );
    return newvar;
}



/*
 * From COOCOO Server.
 * (c)2002 Herb Gilliland.
 *
 * This section of the source is bound under 
 * an agreement with  its original author.
 * (me)
 */


/*
 * List and stack functions.
 */

VARIABLE_DATA *func_push( void* owner, int type,  VARIABLE_DATA *stack,
                          VARIABLE_DATA *value )
{
    VARIABLE_DATA *vd;
    char *_stack;
    char *_value;
    char newvalue[MAX_STRING_LENGTH];

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies((char *)stack->value) );

    if( PARM(value,TYPE_STRING) ) _value = str_dup( "" );
    else
    _value = translate_variables( owner , type, strip_curlies((char *)value->value) );

    sprintf( newvalue, "%s;%s", _value, _stack );

    vd = new_variable( );
    vd->value = str_dup( newvalue );

    free_string( _stack );
    free_string( _value );
    return vd;
}


VARIABLE_DATA *func_pop( void * owner, int type, VARIABLE_DATA *stack )
{
    VARIABLE_DATA *vd;
    char buf[MAX_STRING_LENGTH];
    char *_stack;
    char *argument;

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies((char *)stack->value) );

    if ( _stack[0] == '\0' ) return NULL;

    argument = one_line( _stack, buf );

    vd = new_variable( );
    vd->value = str_dup( argument );

    free_string( _stack );
    return vd;
}


/*
 * Removes a value from a list.
 */
VARIABLE_DATA *func_lrem( void * owner, int type, VARIABLE_DATA *stack,
                          VARIABLE_DATA *value )
{
    VARIABLE_DATA *vd;
    char *_stack;
    char *_value;
    char buf[MAX_STRING_LENGTH];
    
    buf[0] = '\0';

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies((char *)stack->value) );

    if( PARM(value,TYPE_STRING) ) _value = str_dup( "" );
    else
    _value = translate_variables( owner , type, strip_curlies((char *)value->value) );

    sprintf( buf, "%s;", _value );
    while ( strstr( buf, _stack ) )
    {
        _value = string_replace( buf, _stack, "" );
                                         
        if ( buf[0] == '\0' || *_stack == '\0' )
        {
            free_string( _value );
    free_string( _stack );
    free_string( _stack );
            free_string( _stack );
            return NULL;
        }
    }

    sprintf( buf, "%s", _value );
    vd = new_variable( );
    vd->value = str_dup( buf );

    free_string( _stack );
    free_string( _value );
    return vd;
}


/*
 * Sorts a list.
 * Masks=A-Z, Z-A, 0-9, 9-0
 */
VARIABLE_DATA *func_sort( void * owner, int type, VARIABLE_DATA *stack,
                          VARIABLE_DATA *mask )
{
    char *_stack;
    char *_mask;

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies((char *)stack->value) );

    if( PARM(mask,TYPE_STRING) ) _mask = str_dup( "" );
    else
    _mask = translate_variables( owner , type, strip_curlies((char *)mask->value) );

    free_string( _stack );
    free_string( _mask );
    return NULL;
}


/*
 * Returns a random value from a list stack.
 */
VARIABLE_DATA *func_lrnd( void * owner, int type, VARIABLE_DATA *stack )
{
    VARIABLE_DATA *vd; 
    char argument[MAX_STRING_LENGTH];
    char *_stack;
    char *p;
    int x;

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies((char *)stack->value) );

    p=_stack;
    for ( x = 0; argument != '\0'; x++ ) p= one_line( p, argument );

    p=_stack;
    for ( x = number_range(0,x);  x > 0;  x-- ) p=one_line(p,argument);

    vd= new_variable();
    vd->value = str_dup( argument );
    vd->type = TYPE_STRING;
    free_string( _stack );
    return vd;
}



/*
 * Moves last to first. (shifts right)
 */
VARIABLE_DATA *func_lshift( void * owner, int type,VARIABLE_DATA *stack )
{
    VARIABLE_DATA *vd;
    char buf[MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];
    char *_stack;
    char *argument;

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies((char *)stack->value) );

    argument = one_line( _stack, buf );
    sprintf( buf2, "%s;%s;", argument, buf );
    
    vd = new_variable( );
    vd->value = str_dup( buf2 );

    free_string( _stack );
    return vd;
}



/*
 * Moves first to last. (shifts left)
 */
VARIABLE_DATA *func_rshift( void * owner, int type, VARIABLE_DATA *stack 
)
{
    VARIABLE_DATA *vd;
    char buf[MAX_STRING_LENGTH];
    char buf2[MAX_STRING_LENGTH];
    char *_stack;
    char *argument;

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies((char *)stack->value) );

    argument = one_argument( stack->value, buf );

    sprintf( buf2, "%s %s", argument, buf );

    vd = new_variable( );
    vd->value = str_dup( buf2 );

    free_string( _stack );
    return vd;
}


/*
 * List functions.
 * These function return list stacks.
 * Empty set is returned if nothing found.
 * Check for this using the empty() function.
 */

VARIABLE_DATA *func_empty( void * owner, int type, VARIABLE_DATA *stack )
{
    VARIABLE_DATA *vd = NULL;
    char *_stack;

    if ( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies( (char *)stack->value ) );

    free_string( _stack );
    return vd;
}

/*
 * Returns a list stack of users currently online.
 * Masking not yet implemented.
 */
VARIABLE_DATA *func_users( void * owner, int type,  VARIABLE_DATA *mask )
{
    VARIABLE_DATA *vd;
    PLAYER_DATA *ch;
    char buf[MAX_STRING_LENGTH];
    char *_mask;

    if( PARM(mask,TYPE_STRING) ) _mask = str_dup( "" );
    else
    _mask = translate_variables( owner , type, strip_curlies((char *)mask->value) );

    buf[0] = '\0';
    for ( ch = actor_list;  ch != NULL;  ch = ch->next ) 
        if ( ch->desc != NULL ) 
            sprintf( buf, "%s;%s", buf, NAME(ch) );
        
    vd = new_variable( );
    vd->value = str_dup( buf );
    free_string( _mask );
    return vd;
}


/* this version is not ideal..
 * ideal version: gives you a random valid direction
 */
VARIABLE_DATA *func_rnddir( void * owner, int type )
{
    VARIABLE_DATA *newvar;

    newvar = new_variable( );
    newvar->value = str_dup( dir_name[number_range(0,MAX_DIR-1)] );
    newvar->type = TYPE_STRING;
    return newvar;
}

/*
 * Returns the vnum to the direction by name or by number.
 */
VARIABLE_DATA *func_getdir( void * owner, int type, VARD *loc, VARD *dir ) {
    VARIABLE_DATA *newvar;
    SCENE_INDEX_DATA *pScene;
    char buf[MAX_STRING_LENGTH];
    char *_dir, *_loc;
    int door;
 
    if( PARM(loc,TYPE_STRING) ) _loc = str_dup( "" );
    else
    _loc = translate_variables( owner , type, strip_curlies((char *)loc->value) );

    pScene = get_scene_index( atoi(_loc) );
    if ( pScene ) {

    if( PARM(dir,TYPE_STRING) ) _dir = str_dup( "" );
    else
    _dir = translate_variables( owner , type, strip_curlies((char *)dir->value) );

    door = is_number(_dir) ? atoi(_dir) : get_dir( _dir );

    if ( pScene->exit[door] && pScene->exit[door]->to_scene ) {
        int vnum = pScene->exit[door]->to_scene->vnum;

        newvar = new_variable( );
        sprintf( buf, "%d", vnum );
        newvar->type = TYPE_STRING;
        newvar->value = str_dup( buf );
    } else newvar=NULL;

    free_string( _dir );

    } else newvar=NULL;

    free_string( _loc );
    return (newvar);
}

/*
 * Returns a list stack of the event queue names.
VARIABLE_DATA *func_queue( VARIABLE_DATA *mask )
{
    VARIABLE_DATA *vd = NULL;
    QUEUE_DATA *qd;
    char buf[MAX_STRING_LENGTH];
    char *_mask;

    if( PARM(mask) ) _mask = str_dup( "" );
    else
    _mask = translate_variables( owner , type, strip_curlies((char *)mask->value) );

    buf[0] = '\0';
    for ( qd = event_queue; qd != NULL;  qd = qd->next ) 
            sprintf( buf, "%s;%s", buf, qd->name );
        
    vd = new_variable( );
    vd->value = str_dup( buf );
    free_string( _mask );
    return vd;
}
	 */



/*
 * Returns a list stack of the prop names in the database.
 * (huge)
VARIABLE_DATA *func_props( VARIABLE_DATA *mask )
{
    VARIABLE_DATA *vd;
    PROP_DATA *prop;
    char buf[MAX_STRING_LENGTH];
    char *_mask;

    if( PARM(mask) ) _mask = str_dup( "" );
    else
    _mask = translate_variables( owner , type, strip_curlies((char *)mask->value) );

    buf[0] = '\0';
        
    vd = new_variable( );
    vd->value = str_dup( buf );
    free_string( _mask );
    return vd;
}
 */




/*
 * Returns a list stack of the command list names.
VARIABLE_DATA *func_commands( VARIABLE_DATA *mask )
{
    COMMAND_DATA *cd;
    VARIABLE_DATA *vd;
    char buf[MAX_STRING_LENGTH];
    char *_mask;

    if( PARM(mask) ) _mask = str_dup( "" );
    else
    _mask = translate_variables( owner , type, strip_curlies((char *)mask->value) );

    buf[0] = '\0';
    for ( cd = command_list; cd != NULL;  cd = cd->next ) 
            sprintf( buf, "%s;%s", buf, cd->name );
        
    vd = new_variable( );
    vd->value = str_dup( buf );
    free_string( _mask );
    return NULL;
}
 */


/*
 * Iterates through each value in a list stack.
 * Sets a list of variables equal to the supplied value.
 */
VARIABLE_DATA *func_foreach( void * owner, int type, VARIABLE_DATA 
*stack, VARIABLE_DATA *code )
{
    char var_name[MAX_STRING_LENGTH];
    char *_stack;
    char *_code;
    char *argument;

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = translate_variables( owner , type, strip_curlies((char *)stack->value) );

    if( PARM(code,TYPE_STRING) ) _code = str_dup( "" );
    else
    _code = translate_variables( owner , type, strip_curlies((char *)code->value) );

    argument = _stack;
    while ( *argument != '\0' ) {
        argument = one_line( argument, var_name );
/*
        set_variable( var_name, _code );
 */
    }

    free_string( _code  );
    free_string( _stack );
    return NULL;
}



/*
 * Iterates through each value in a list stack.
 * Returns a list of variables equal to the stack.
 */
VARIABLE_DATA *func_each( void * owner, int type, VARIABLE_DATA *stack )
{
#if defined (NEVER)
    VARIABLE_DATA *vd;
    char var_name[MAX_STRING_LENGTH];
    ch/r astr[MAX_STRING_LENGTH];
    char bstr[MAX_STRING_LENGTH];
    char *_stack;
    char *_code;
    char *argument;

    if( PARM(stack,TYPE_STRING) ) _stack = str_dup( "" );
    else
    _stack = strip_curlies((char *)stack->value);

    final[0] = '\0';
    argument = _stack;
    while ( *argument != '\0' ) {
        argument = one_argument( argument, var_name );
        vd = find_variable( var_name );

        if ( vd == NULL ) continue;
        sprintf( buf, "%s;%s", buf, vd->value );
    }

    vd = new_variable( );
    vd->value = str_dup( buf );

    free_string( _stack );
    return vd;
#endif
   return NULL;
}

