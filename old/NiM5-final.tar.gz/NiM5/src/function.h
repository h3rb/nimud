/*
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___| G| v4.0   Version 4.0 GOLD EDITION      *
* |  /   \  __|  \__/  |  | |  |     O|        documentation release         *
* |       ||  |        |  \_|  | ()  L|        Hallow's Eve 1999             *
* |    |  ||  |  |__|  |       |     D|                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 */


/*
 * Internal stuff.
 */
extern int gotoloops;

#define  VD    VARIABLE_DATA

/*
 * Reserved functions for internal parsing.
 */
VARD * func_goto     args( ( void * owner, int type, VARD *label ) );
VARD * func_if       args( ( void * owner, int type, VARD *exp, VARD *iftrue, VARD *iffalse ) );
VARD * func_label    args( ( void * owner, int type ) );
VARD * func_return   args( ( void * owner, int type, VARD *value ) );
VARD * func_halt     args( ( void * owner, int type, VARD *value ) );
VARD * func_permhalt args( ( void * owner, int type ) );
VARD * func_wait     args( ( void * owner, int type, VARD *value ) );
VARD * func_autowait args( ( void * owner, int type, VARD *value ) );
VARD * func_call     args( ( void * owner, int type, VARD *trigname, VARD *target ) );
VARD * func_vget     args( ( void * owner, int type, VARD *newvar, VARD *varname, VARD *trigname, VARD *target ) );
VARD * func_vset     args( ( void * owner, int type, VARD *varname, VARD *ourvar, VARD *trigname, VARD *target ) );

/*
 * Further stuff.
 */
VARD * func_vcpy     args( ( void * owner, int type, VARD *old, VARD *new, VARD *trigname ) );
VARD * func_self     args( ( void * owner, int type, VARD *varname ) );

/*
 * "Constants."
 */

VARD * func_null     args( ( void * owner, int type ) );

/*
 * Boolean conditionals.
 */
VARD * func_cmp      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_not      args( ( void * owner, int type, VARD *value ) );
VARD * func_or       args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_and      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_xor      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_less     args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_greater  args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_pre      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_in       args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_strstr   args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_pcmp     args( ( void * owner, int type, VARD *astr, VARD *bstr ) );

VARD * func_range    args( ( void * owner, int type, VARD *astr, VARD *val, VARD *bstr ) );

/*
 * Mathematics.
 */
VARD * func_add      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_sub      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_mult     args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_div      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_mod      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_random   args( ( void * owner, int type, VARD *astr, VARD *bstr ) );

VARD * func_band     args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_bor      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_bxor     args( ( void * owner, int type, VARD *astr, VARD *bstr ) );

VARD * func_eq       args( ( void * owner, int type, VARD *astr, VARD *bstr ) );


/*
 * String things.
 */
VARD * func_cat      args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_word     args( ( void * owner, int type, VARD *astr, VARD *value ) );

/*
 * Output functions.
 */
VARD * func_act      args( ( void * owner, int type, VARD *out, VARD *ch, VARD *arg1, VARD *arg2, VARD *act_type ) );
VARD * func_recho    args( ( void * owner, int type, VARD *target, VARD *out ) );
VARD * func_echo     args( ( void * owner, int type, VARD *str ) );
VARD * func_dream    args( ( void * owner, int type, VARD *out ) );
VARD * func_history  args( ( void * owner, int type, VARD *target, VARD *out ) );

/*
VARD * func_pecho    args( ( void * owner, int type, VARD *target, VARD *str ) );
VARD * func_oecho    args( ( void * owner, int type, VARD *target, VARD *str ) );
 */
VARD * func_numw     args( ( void * owner, int type, VARD *astr ) );
VARD * func_strp     args( ( void * owner, int type, VARD *value, VARD *old, VARD *new ) );

/*
 * Game-related functions for actors.
 */
VARD * func_do       args( ( void * owner, int type, VARD *exp0, VARD *exp1, VARD *exp2, VARD *exp3, VARD *exp4, VARD *exp5 ) );
VARD * func_step     args( ( void * owner, int type, VARD *value ) );
VARD * func_ms       args( ( void * owner, int type, VARD *astr, VARD *bstr ) );
VARD * func_jump     args( ( void * owner, int type, VARD *location ) );
VARD * func_samescene  args( ( void * owner, int type, VARD *value ) );

/*
 * Game-related functions for props.
 */
VARD *func_os        args( ( void * owner, int type, VARD *astr, VARD *bstr ) );

/*
 * Game-related functions for scenes.
 */
VARD *func_open      args( ( void * owner, int type, VARD *loc, VARD *dir ) );
VARD *func_close     args( ( void * owner, int type, VARD *loc, VARD *dir ) );

/*
 * General use functions.
 */

VARD *func_here      args( ( void * owner, int type ) );
VARD *func_purge     args( ( void * owner, int type, VARD *target ) );
VARD *func_force     args( ( void * owner, int type, VARD *target ) );
VARD *func_disarm    args( ( void * owner, int type, VARD *target ) );
VARD *func_strip     args( ( void * owner, int type, VARD *target ) );
VARD *func_pos       args( ( void * owner, int type, VARD *target, VARD *gain ) );
VARD *func_pay       args( ( void * owner, int type, VARD *target, VARD *gain ) );
VARD *func_elude     args( ( void * owner, int type ) );
VARD *func_spawn     args( ( void * owner, int type, VARD *target ) );
VARD *func_move      args( ( void * owner, int type, VARD *target, VARD *dest) );
VARD *func_moveall   args( ( void * owner, int type, VARD *from, VARD *dest, VARD *cmd ) );

VARD *func_home      args( ( void * owner, int type, VARD *target, VARD *dest) );
VARD *func_death     args( ( void * owner, int type, VARD *target, VARD *dest) );

VARD *func_heal      args( ( void * owner, int type, VARD *target, VARD *gain) );
VARD *func_hurt      args( ( void * owner, int type, VARD *target, VARD *gain) );
VARD *func_bomb      args( ( void * owner, int type, VARD *target, VARD *gain) );

VARD *func_dig       args ( ( void * owner, int type, VARD *loc, VARD *dir, VARD *dest ) );
VARD *func_undig     args ( ( void * owner, int type, VARD *loc, VARD *dir ) );
VARD *func_rtitle    args ( ( void * owner, int type, VARD *loc, VARD *dir ) );

VARD *func_dispense  args( ( void * owner, int type, VARD *target, VARD *disp) );

VARD *func_create    args( ( void * owner, int type, VARD *vnum, VARD *loc) );
VARD *func_eat       args( ( void * owner, int type, VARD *target )  );
VARD *func_eval      args( ( void * owner, int type, VARD *value ) );

VARD *func_rndplr    args( ( void * owner, int type, VARD *from ) );
VARD *func_rnddir    args( ( void * owner, int type ) );
VARD *func_getdir    args( ( void * owner, int type, VARD *loc, VARD *dir ) );

VARD *func_players   args( ( void * owner, int type ) );
VARD *func_addbounty args( ( void * owner, int type, VARD *target, VARD *gain) );
VARD *func_bounty    args( ( void * owner, int type, VARD *target ) );
VARD *func_addowed   args( ( void * owner, int type, VARD *target, VARD *gain) );
VARD *func_owed      args( ( void * owner, int type, VARD *target ) );
VARD *func_level     args( ( void * owner, int type, VARD *target ) );

/*
 * Functions for creating and manipulating objects.
 */

VARD *func_transform  args( ( void * owner, int type, VARD *new ) );
VARD *func_emit      args( ( void *owner, int type, VARD *out ) );
VARD *func_reverb    args( ( void * owner, int type, VARD *out ) );

/*
 * Time, date and weather functions. (world-state functions)
 */
VARD *func_time      args( ( void * owner, int type ) );
VARD *func_weather   args( ( void * owner, int type ) );
VARD *func_moon      args( ( void * owner, int type ) );
VARD *func_day       args( ( void * owner, int type ) );
VARD *func_dayofweek args( ( void * owner, int type ) );
VARD *func_month     args( ( void * owner, int type ) );
VARD *func_year      args( ( void * owner, int type ) );

VARD *func_skill     args( ( void * owner, int type, VARD *target, VARD *sn, VARD *v ) );
VARD *func_setskill  args( ( void * owner, int type, VARD *target, VARD *sn, VARD *v ) );
VARD *func_alert     args( ( void * owner, int type, VARD *name, VARD *limits ) );

VARD *func_tname     args( ( void * owner, int type, VARD *var ) );

/* 
 * Magic. (Spell-related)
 */
VARD *func_mana      args( ( void * owner, int type, VARD *target, VARD *gain) );
VARD *func_mix       args( ( void * owner, int type, VARD *target, VARD *list, VARD *quantity ) );
VARD *func_reagents  args( ( void * owner, int type, VARD *target, VARD *list, VARD *quantity ) );

/*
 * List and stack functions.
 * Imported from COO2 and subject to a seperate license.
 * See: http://www.nationwideinteractive.com/coocoo
 */

VARD *func_push     args ( ( void * owner, int type, VARD *stack, VARD *value ) );
VARD *func_pop      args ( ( void * owner, int type, VARD *stack ) );
VARD *func_lrem     args ( ( void * owner, int type, VARD *stack, VARD *value ) );
VARD *func_sort     args ( ( void * owner, int type, VARD *stack, VARD *mask ) );
VARD *func_lrnd     args ( ( void * owner, int type, VARD *stack ) ); 
VARD *func_lshift   args ( ( void * owner, int type, VARD *stack ) );
VARD *func_rshift   args ( ( void * owner, int type, VARD *stack ) );
VARD *func_empty    args ( ( void * owner, int type, VARD *stack ) );
VARD *func_users    args ( ( void * owner, int type, VARD *mask ) );

/*
VARD *func_queue    args ( ( void * owner, int type, VARD *mask ) );
VARD *func_props  args ( ( void * owner, int type, VARD *mask ) );
VARD *func_commands args ( ( void * owner, int type, VARD *mask ) );
 */

/*
 * These don't work.
 */
VARD *func_foreach  args ( ( void * owner, int type, VARD *stack, VARD *code ) );
VARD *func_each     args ( ( void * owner, int type, VARD *stack )  );





#undef  VD
