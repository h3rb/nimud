

#include "nimud.h"


void cmd_smoke( PLAYER_DATA *ch, char *argument ){
}

void cmd_snort( PLAYER_DATA *ch, char *argument ){
}

void cmd_sniff( PLAYER_DATA *ch, char *argument ){
}

void cmd_taste( PLAYER_DATA *ch, char *argument ){
}

void cmd_ingest( PLAYER_DATA *ch, char *argument ){
}

/*
void cmd_inject( PLAYER_DATA *ch, char *argument ){
}
 */

