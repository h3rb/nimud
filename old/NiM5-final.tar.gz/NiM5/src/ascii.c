/*
 * Locke's ANSI/ASCII Graphics routines.
 * 
 */


int goto_xy(  int x, int y )
{



}



int horizline( int length );

