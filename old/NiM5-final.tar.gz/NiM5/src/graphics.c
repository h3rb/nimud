/******************************************************************************
 * Locke's   __                      __         NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5     Version 5 (ALPHA)             *
 * |  /   \  __|  \__/  |  | |  |      |        unreleased+revamped 2004      *
 * |       ||  |        |  \_|  | ()   |                                      *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/


/*
 * Locke's ANSI/ASCII Graphics routines.
 * Part of NiMUD Version 5.1a
 */




#if defined(BSD)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "nimud.h"
#include "defaults.h"



/*
 * Codes for the Full Screen ANSI Client
 */

/* "\x1b[#,#H"
   "\x1b[#,#f"  move cursor
   "\x
 */
#define CLEAR_SCR "\x1b[2J"
#define CLEAR_EOL "\x1b[K"
#define SAVE_CURS "\x1b[s"
#define LOAD_CURS "\x1b[u"

int goto_xy                 args(( PLAYER_DATA *ch, int x, int y ));


int goto_xy( PLAYER_DATA *ch, int x, int y )
{

   char buf[MAX_STRING_LENGTH];

   sprintf( buf, "\x1b[%d,%dH", x, y );
/* sprintf( buf, "\x1b[%d,%df", x, y ); */
   send_to_actor( buf, ch ); 
}

/*
int horizline( PLAYER_DATA *ch, int length, char c ) {

     for ( ; length > 0; length-- )
     send_to_actor( c, ch ); 
}

int vertline( PLAYER_DATA *ch, int length, char c ) {
     for ( ; length > 0; length++ ) {
     send_to_actor( c, ch )
     send_to_actor( "\x1b[1A", ch ); 
     }
}
*/

int draw_window( PLAYER_DATA *ch, int x, int y, int w, int h ) {

}



void cmd_map( PLAYER_DATA *ch, char *argument ) {

     SCENE_INDEX_DATA *pScene;

     char map_buf[25*75];
     int x, y;

     pScene = ch->in_scene;
     if ( pScene == NULL ) return;

     /* 
      * Init map buf.
      */
     for ( x = 0; x < 25;  x++ ) {
         for ( y = 0;  y < 78;  y++ ) {
              map_buf[x*25 + y] = ' ';
         }
     }          

}
