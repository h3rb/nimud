/*
 * IMC2 version 0.10 - an inter-mud communications protocol
 * Copyright (C) 1996 & 1997 Oliver Jowett <oliver@randomly.org>
 *
 * IMC2 Gold versions 1.00 though 2.00 were developed by MudWorld.
 * Copyright (C) 1999 - 2002 Haslage Net Electronics (Anthony R. Haslage)
 *
 * IMC2 MUD-Net version 3.10 was developed by Alsherok and Crimson Oracles
 * Copyright (C) 2002 Roger Libiez ( Samson )
 * Additional code Copyright (C) 2002 Orion Elder
 * Registered with the United States Copyright Office
 * TX 5-555-584
 *
 * IMC2 Hermes R01-R04 were developed by Rogel
 * Copyright (C) 2003-2004 by Rogel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING); if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/file.h>
#include <signal.h>
#include "imc.h"

#ifndef __FreeBSD__
char *strcasestr( const char *haystack, const char *needle );
#endif

time_t imc_now;  /* current time */
time_t imc_boot; /* current time */
imc_event *imc_event_list, *imc_event_free;
static int event_freecount;
static int control;
char *imc_name;			      /* our IMC name */
unsigned short imc_port;              /* our port; 0=disabled */
unsigned long imc_bind;               /* IP to bind to */
imc_siteinfo_struct imc_siteinfo;

/* sequence memory */
_imc_memory imc_memory[IMC_MEMORY];

unsigned long imc_sequencenumber;	  /* sequence# for outgoing packets */

imc_statistics imc_stats;

IMC_CHANNEL *first_imc_channel;
IMC_CHANNEL *last_imc_channel;
CONNECTION *first_connection;
CONNECTION *last_connection;
INFO *first_info;
INFO *last_info;
REMINFO *first_reminfo;
REMINFO *last_reminfo;
IMC_BLACKLIST *first_blacklist;
IMC_BLACKLIST *last_blacklist;

static void graceful_exit( int sig )
{
   Log( "%s killed from shell.", IMC_VERSIONID );
   imc_shutdown();
}

int main( void )
{
   struct timeval	  last_time;

   gettimeofday( &last_time, NULL );

   signal( SIGPIPE, SIG_IGN );
   signal( SIGTERM, graceful_exit );

   imc_startup( );

   hub_loop(last_time);

   /* Never reaches this point - hub_loop is recursive */
   exit(0);
}

void hub_loop( struct timeval  last_time )
{
    struct timeval now_time;
    long secDelta;
    long usecDelta;
         
    imc_idle( imc_get_event_timeout());

	/*
	 * Synchronize to a clock - make sure that it takes at least a second plus a 1/4 second
     * delay time to go through the loop. Keeps sequence numbers from increasing too fast.
	 * Sleep( last_time + 1/PULSE_PER_SECOND - now ).
	 * Careful here of signed versus unsigned arithmetic.
	 */

    gettimeofday( &now_time, NULL );
      
    usecDelta = ((int) last_time.tv_usec) - ((int) now_time.tv_usec) + 1000000 / 4;
    secDelta  = ((int) last_time.tv_sec ) - ((int) now_time.tv_sec );
	   
    while ( usecDelta < 0 )
    {
        usecDelta += 1000000;
        secDelta  -= 1;
    }

	   
    while ( usecDelta >= 1000000 )
    {
        usecDelta -= 1000000;
        secDelta  += 1;
    }

	   
    if ( secDelta >= 0 && usecDelta >= 0 )
    {
        struct timeval stall_time;

        stall_time.tv_usec = usecDelta;
        stall_time.tv_sec  = secDelta;
		
        if ( select( 0, NULL, NULL, NULL, &stall_time ) < 0 && errno != EINTR )
        {
            perror( "main: select: stall" );
            exit( 1 );
        }
    }

	gettimeofday( &last_time, NULL );
    
    hub_loop(last_time);
    return;
}

// License for strlcpy located at ftp://ftp.openbsd.org/pub/OpenBSD/src/lib/libc/string/strlcpy.c
#ifndef HAVE_STRLCPY
/*
 * Copy src to string dst of size siz.  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz == 0).
 * Returns strlen(src); if retval >= siz, truncation occurred.
 */
size_t strlcpy( char *dst, const char *src, size_t siz )
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;

	/* Copy as many bytes as will fit */
	if (n != 0 && --n != 0) {
		do {
			if ((*d++ = *s++) == 0)
				break;
		} while (--n != 0);
	}

	/* Not enough room in dst, add NUL and traverse rest of src */
	if (n == 0) {
		if (siz != 0)
			*d = '\0';		/* NUL-terminate dst */
		while (*s++)
			;
	}

	return(s - src - 1);	/* count does not include NUL */
}

#endif /* !HAVE_STRLCPY */

// License for strlcat located at ftp://ftp.openbsd.org/pub/OpenBSD/src/lib/libc/string/strlcat.c

#ifndef HAVE_STRLCAT
/*
 * Appends src to string dst of size siz (unlike strncat, siz is the
 * full size of dst, not space left).  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz <= strlen(dst)).
 * Returns strlen(initial dst) + strlen(src); if retval >= siz,
 * truncation occurred.
 */
size_t strlcat( char *dst, const char *src, size_t siz )
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;
	size_t dlen;

	/* Find the end of dst and adjust bytes left but don't go past end */
	while (n-- != 0 && *d != '\0')
		d++;
	dlen = d - dst;
	n = siz - dlen;

	if (n == 0)
		return(dlen + strlen(s));
	while (*s != '\0') {
		if (n != 1) {
			*d++ = *s;
			n--;
		}
		s++;
	}
	*d = '\0';

	return(dlen + (s - src));	/* count does not include NUL */
}

#endif /* !HAVE_STRLCAT */

/*
 *  Error logging
 */
void Log( const char *format, ... )
{
   char buf[LSS];
   struct timeval proper_time;
   time_t current_time;
   char *strtime;
   va_list ap;

   va_start( ap, format );
   vsnprintf( buf, LSS, format, ap );
   va_end( ap );

   gettimeofday( &proper_time, NULL );
   current_time = proper_time.tv_sec;

   strtime                    = ctime( &current_time );
   strtime[strlen(strtime)-1] = '\0';
   fprintf( stderr, "%s :: %s\n", strtime, buf );

   return;
}

/* escape2: escape " -> \", \ -> \\, CR -> \r, LF -> \n */

static const char *escape2(const char *data)
{
   static char buf[IMC_DATA_LENGTH];
   unsigned int i = 0, j = 0;

   buf[0] = '\0';

   if ( !data || data[0] == '\0' )
       return buf;

   for ( i = 0, j = 0; i < IMC_DATA_LENGTH && data[j] != '\0'; i++, j++ ) 
   {
       if ( data[j] == '\n' || data[j] == '\r' || data[j] == '\\' || data[j] == '"' )
       {
           if ( i + 1 == IMC_DATA_LENGTH )
               break;

           buf[i++] = '\\';

           if ( data[j] == '\n' )
               buf[i] = 'n';
           else if ( data[j] == '\r' )
               buf[i] = 'r';
           else if ( data[j] == '\\' )
               buf[i] = '\\';
           else
               buf[i] = '\"';
       }
       else
           buf[i] = data[j];
   }

   buf[i] = '\0';

   return buf;
}

/* printkeys: print key-value pairs, escaping values */
static const char *printkeys( PACKET *data )
{
   static char buf[IMC_DATA_LENGTH];
   char temp[IMC_DATA_LENGTH];
   unsigned char i;

   buf[0] = '\0';

   if ( !data )
       return buf;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( !data->key[i] )
         continue;

      if( !strchr( data->value[i], ' ' ) )
         snprintf( temp, IMC_DATA_LENGTH, "%s=%s ", data->key[i], escape2( data->value[i] ) );
      else
         snprintf( temp, IMC_DATA_LENGTH, "%s=\"%s\" ", data->key[i], escape2( data->value[i] ) );

      strlcat( buf, temp, IMC_DATA_LENGTH );
   }

   return buf;
}

/* add "key=value" to "p" */
void imc_addkey( PACKET *p, const char *key, const char *value )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( p->key[i] && STR_CEQL( key, p->key[i] ) )
      {
         DISPOSE( p->key[i] );
         DISPOSE( p->value[i] );
         break;
      }
   }
   if( !value || value[0] == '\0' )
      return;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( !p->key[i] )
      {
         p->key[i]   = strdup( key );
         p->value[i] = strdup( value );
         return;
      }
   }
}

/* add "key=value" for an integer value */
void imc_addkeyi( PACKET *p, const char *key, int value )
{
   char temp[20];

   snprintf( temp, 20, "%d", value );
   imc_addkey( p, key, temp );
}

/* parsekeys: extract keys from string */
static void parsekeys( const char *string, PACKET *data )
{
   const char *p1;
   char *p2;
   char k[IMC_DATA_LENGTH], v[IMC_DATA_LENGTH];
   bool quote;

   p1 = string;

   while (*p1)
   {
      while( *p1 && isspace(*p1) )
         p1++;

      p2 = k;
      while( *p1 && *p1 != '=' && p2-k < IMC_DATA_LENGTH-1 )
         *p2++=*p1++;
      *p2=0;

      if( !k[0] || !*p1 )		/* no more keys? */
         break;

      p1++;			/* skip the '=' */

      if( *p1 == '"' )
      {
         p1++;
         quote = TRUE;
      }
      else
         quote = FALSE;

      p2 = v;
      while( *p1 && (!quote || *p1 != '"') && (quote || *p1 != ' ') && p2-v < IMC_DATA_LENGTH+1 )
      {
         if( *p1 == '\\' )
         {
	      switch( *(++p1) )
	      {
	         case '\\':
	            *p2++='\\';
	         break;
	         case 'n':
	            *p2++='\n';
	         break;
	         case 'r':
	            *p2++='\r';
	         break;
	         case '"':
	            *p2++='"';
	         break;
	         default:
	            *p2++=*p1;
	         break;
	      }
	      if( *p1 )
	         p1++;
         }
         else
	      *p2++ = *p1++;
      }

      *p2 = 0;

      if( !v[0] )
         continue;

      imc_addkey( data, k, v );

      if( quote && *p1 )
         p1++;
   }
}

/* clear all keys in "p" */
void imc_initdata( PACKET *p )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      p->key[i]   = NULL;
      p->value[i] = NULL;
   }
}

/* free all the keys in "p" */
void imc_freedata( PACKET *p )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( p->key[i] )
         DISPOSE( p->key[i] );
      if( p->value[i] )
         DISPOSE( p->value[i] );
   }
}

/*  imc_getarg: extract a single argument (with given max length) from
 *  argument to arg; if arg==NULL, just skip an arg, don't copy it out
 */
const char *imc_getarg(const char *argument, char *arg, unsigned int length)
{
  unsigned int len = 0;

  if ( !argument || argument[0] == '\0' )
  {
      if ( arg )
          arg[0] = '\0';

      return argument;
  }

  while (*argument && isspace(*argument))
    argument++;

  if (arg)
    while (*argument && !isspace(*argument) && len < length-1)
      *arg++=*argument++, len++;
  else
    while (*argument && !isspace(*argument))
      argument++;

  while (*argument && !isspace(*argument))
    argument++;

  while (*argument && isspace(*argument))
    argument++;

  if (arg)
    *arg = '\0';

  return argument;
}

char *generate2( PACKET *p )
{
   static char temp[IMC_PACKET_LENGTH];
   char newpath[IMC_PATH_LENGTH];

   if( !p->type[0] || !p->i.from[0] || !p->i.to[0] )
   {
      Log( "generate2: bad packet - type: %s from: %s to: %s path %s data: %s", p->type, p->i.from,
        p->i.to, p->i.path, printkeys(p) );
      return NULL;		/* catch bad packets here */
   }

   if( !p->i.path[0] )
      strlcpy( newpath, imc_name, IMC_PATH_LENGTH );
   else
      snprintf( newpath, IMC_PATH_LENGTH, "%s!%s", p->i.path, imc_name );

   snprintf( temp, IMC_PACKET_LENGTH, "%s %lu %s %s %s %s", 
           p->i.from, p->i.sequence, newpath, p->type, p->i.to, printkeys( p ) );
   return temp;
}

PACKET *interpret2( const char *argument )
{
   char seq[20];
   static PACKET out;

   imc_initdata( &out );
   argument = imc_getarg( argument, out.i.from, IMC_NAME_LENGTH );
   argument = imc_getarg( argument, seq, 20 );
   argument = imc_getarg( argument, out.i.path, IMC_PATH_LENGTH );
   argument = imc_getarg( argument, out.type, IMC_TYPE_LENGTH );
   argument = imc_getarg( argument, out.i.to, IMC_NAME_LENGTH );

   if( !out.i.from[0] || !seq[0] || !out.i.path[0] || !out.type[0] || !out.i.to[0] )
   {
      Log( "interpret2: bad packet received and discarded" );
      return NULL;
   }

   parsekeys( argument, &out );

   out.i.sequence = strtoul( seq, NULL, 10 );
   return &out;
}

_imc_vinfo imc_vinfo[] =
{
  { 0, NULL, NULL },
  { 1, NULL, NULL },
  { 2, generate2, interpret2 }
};

/*
 * Key/value manipulation
 */

/* get the value of "key" from "p"; if it isn't present, return "def" */
const char *imc_getkey( const PACKET *p, const char *key, const char *def )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
      if( p->key[i] && STR_CEQL(p->key[i], key))
         return p->value[i];

   return def;
}

/* identical to imc_getkey, except get the integer value of the key */
int imc_getkeyi( const PACKET *p, const char *key, int def )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
      if( p->key[i] && STR_CEQL(p->key[i], key))
         return atoi( p->value[i] );

   return def;
}

/*
 *  String manipulation functions, mostly exported
 */

/* return 'mud' from 'player@mud' */
const char *imc_mudof(const char *fullname)
{
   static char buf[IMC_MNAME_LENGTH];
   char *where;

   buf[0] = '\0';

   if ( !fullname || fullname[0] == '\0' )
       return fullname;

   snprintf( buf, IMC_MNAME_LENGTH, "%s", (where = strchr( fullname, '@' )) != NULL ? where + 1 : fullname );
   return buf;
}

/* return 'player' from 'player@mud' */
const char *imc_nameof(const char *fullname)
{
   static char buf[IMC_PNAME_LENGTH];
   unsigned char i = 0, j = 0;

   buf[0] = '\0';

   if ( !fullname || fullname[0] == '\0' )
       return buf;

   for ( i = 0, j = 0; i < IMC_PNAME_LENGTH && fullname[j] != '\0' && fullname[j] != '@'; i++, j++ )
       buf[i] = fullname[j];

   buf[i] = '\0';
   return buf;
}

/* return 'player@mud' from 'player' and 'mud' */
const char *imc_makename(const char *player, const char *mud)
{
  static char buf[IMC_NAME_LENGTH];

  if ( !player || !mud )
      return NULL;

  snprintf( buf, IMC_NAME_LENGTH, "%s@%s", player, mud );
  return buf;
}

/* return 'e' from 'a!b!c!d!e' */
char *imc_lastinpath( const char *path )
{
   const char *where;
   static char buf[IMC_NAME_LENGTH];

   where = path + strlen(path)-1;
   while( *where != '!' && where >= path )
      where--;

   strlcpy( buf, where+1, IMC_NAME_LENGTH );
   return buf;
}

/* return 'b' from 'a!b!c!d!e' */
char * imc_hubinpath( char *path )
{
    const char *separator, *where;
    static char buf[IMC_NAME_LENGTH];
    unsigned int i = 1;

    if ( !path || path[0] == '\0')
        return NULL;

    if ( (separator = strchr( path, '!' ) ) == NULL )
       return imc_name;

    for ( where = separator + 1; *where != '!' && *where != '\0'; where++ )
        i++;

    strlcpy( buf, separator + 1, i );
    return buf;
}

/* return 'a' from 'a!b!c!d!e' */
char *imc_firstinpath( const char *path )
{
   static char buf[IMC_NAME_LENGTH];
   char *p;

   for( p = buf; *path && *path != '!'; *p++=*path++ )
    ;

   *p = 0;
   return buf;
}

/* Check for a name in a list */
int imc_hasname(const char *list, const char *name)
{
    const char *p;
    char arg[IMC_NAME_LENGTH];

    if(!list)
	return(0);

    p=imc_getarg(list, arg, IMC_NAME_LENGTH);
    while (arg[0])
    {
      if (STR_CEQL(name, arg))
        return 1;
      p=imc_getarg(p, arg, IMC_NAME_LENGTH);
    }

    return 0;
}

/* Add a name to a list */
void imc_addname(char **list, const char *name)
{
  char buf[IMC_DATA_LENGTH];

  if (imc_hasname(*list, name))
    return;

  if ( (*list) && (*list)[0] != '\0' )
    snprintf(buf, IMC_DATA_LENGTH, "%s %s", *list, name);
  else
    strlcpy(buf, name, IMC_DATA_LENGTH);
  
  DISPOSE(*list);
  *list=strdup(buf);
}

/* Remove a name from a list */
void imc_removename(char **list, const char *name)
{
  char buf[MSS];
  char arg[IMC_NAME_LENGTH];
  const char *p;
  
  buf[0]=0;
  p=imc_getarg(*list, arg, IMC_NAME_LENGTH);
  while (arg[0])
  {
    if (!STR_CEQL(arg, name))
    {
      if (buf[0])
          strlcat(buf, " ", MSS);

      strlcat(buf, arg, MSS);
    }
    p=imc_getarg(p, arg, IMC_NAME_LENGTH);
  }

  DISPOSE(*list);
  *list=strdup(buf);
}

/* get some IMC stats, return a string describing them */
char *imc_getstats( char *choice )
{
   static char buf[IMC_DATA_LENGTH];
   unsigned int evcount = 0;
   imc_event *ev = imc_event_list;

   if ( !choice || choice[0] == '\0' || STR_CEQL( choice, "network" ))
   {

   
       while( ev )
       {
          evcount++;
          ev = ev->next;
       }

       snprintf( buf, IMC_DATA_LENGTH,
                               "~WGeneral IMC Statistics\n\r"
                               "~cReceived packets   : ~C%ld\n\r"
                               "~cReceived bytes     : ~C%ld\n\r"
                               "~cTransmitted packets: ~C%ld\n\r"
                               "~cTransmitted bytes  : ~C%ld\n\r"
                               "~cMaximum packet size: ~C%d\n\r"
                               "~cPending events     : ~C%d\n\r"
                               "~cSequence drops     : ~C%d\n\r"
                               "~cLast IMC Boot      : ~C%s\n\r",
            imc_stats.rx_pkts, imc_stats.rx_bytes, imc_stats.tx_pkts, imc_stats.tx_bytes,
            imc_stats.max_pkt, evcount, imc_stats.sequence_drops, ctime( &imc_boot ) );

       return buf;
   }  

   if (STR_CEQL( choice, "general"))
   {
      snprintf( buf, IMC_DATA_LENGTH,
                              "~WSite Information:\n\r"
                              "~cName           ~W:~C %s\n\r"
                              "~cIMC Version    ~W:~C %s\n\r"
                              "~cWebpage        ~W:~C %s\n\r",
         imc_name, IMC_VERSIONID, imc_siteinfo.web );

      return buf;
   }

   return "Bad invocation of imc_getstats."; 
}
/*
 *  imc_reminfo handling
 */

/* find an info entry for "name" */
REMINFO *imc_find_reminfo( const char *name )
{
   REMINFO *p;

   if ( !name )
       return NULL;

   for( p = first_reminfo; p; p = p->next )
   {
      if( STR_CEQL( name, p->name ))
         return p;
   }
   return NULL;
}

/* create a new info entry, insert into list */
REMINFO *imc_new_reminfo( char *mud )
{
   REMINFO *p, *mud_prev;

   CREATE( p, REMINFO, 1 );

   p->name    = strdup( mud );
   p->netname = NULL;
   p->web = NULL;
   p->version = NULL;
   p->path   = NULL;
   p->top_sequence = 0;

   for( mud_prev = first_reminfo; mud_prev; mud_prev = mud_prev->next )
      if( strcasecmp( mud_prev->name, mud ) >= 0 )
         break;

   if( !mud_prev )
      LINK( p, first_reminfo, last_reminfo, next, prev );
   else
      INSERT( p, mud_prev, first_reminfo, next, prev );

   return p;
}

/* delete the info entry "p" */
void imc_delete_reminfo( REMINFO *p )
{
   if( !first_reminfo || !p )
      return;

   UNLINK( p, first_reminfo, last_reminfo, next, prev );

   if ( p->name )
      DISPOSE( p->name );
   if ( p->netname )
      DISPOSE( p->netname );
   if ( p->web )
      DISPOSE( p->web );
   if ( p->version )
      DISPOSE( p->version );
   if ( p->path )
      DISPOSE( p->path );

   imc_cancel_event( NULL, p );
   DISPOSE( p );
}

/* get info struct for given mud */
INFO *imc_getinfo( const char *mud )
{
   INFO *p;

   for( p = first_info; p; p = p->next )
      if( STR_CEQL( mud, p->name ) )
         return p;

   return NULL;
}

/* get name of a connection */
const char *imc_getconnectname( const CONNECTION *c )
{
   static char buf[IMC_NAME_LENGTH];
   const char *n;

   if( c->info )
      n = c->info->name;
   else
      n = "unknown";

   snprintf( buf, IMC_NAME_LENGTH, "%s[%d]", n, c->desc );
   return buf;
}

/* set up for a reconnect */
void imc_setup_reconnect( INFO *i )
{
   time_t temp;
   int t;

   /*  add a bit of randomness so we don't get too many simultaneous reconnects */
   /*  attempts a reconnect in two minutes plus random amount */
   temp = (2*60) + (rand()%21) - 20;
   t = imc_next_event( ev_reconnect, i );

   if( t >= 0 && t < temp)
       return;

   if ( t >= 0 )
   {
       imc_cancel_event( ev_reconnect, i );
   }

   imc_add_event( temp, ev_reconnect, i );
   return;
}

const char *ice_mudof(const char *fullname)
{
  static char buf[IMC_MNAME_LENGTH];
  char *where=buf;
  unsigned int count = 0;

  while (*fullname && *fullname != ':' && count < IMC_MNAME_LENGTH - 1)
    *where++=*fullname++, count++;

  *where = 0;
  return buf;
}

/* see if someone can talk on a channel - lots of string stuff here! */
bool ice_audible(IMC_CHANNEL *c, const char *who)
{

  if ( !c || !who || who[0] == '\0' )
    return FALSE;

  /* owners and operators always can */
  if (STR_CEQL(c->owner, who) || imc_hasname(c->operators, who))
    return TRUE;

  /* ICE locally can use any channel */
  if (STR_CEQL(imc_nameof(who), "ICE") && STR_CEQL(imc_mudof(who), imc_name))
    return TRUE;
  
  if (c->open)
  {
    /* open policy. default yes. override with excludes, then invites */
    if ((imc_hasname(c->excluded, who) || imc_hasname(c->excluded, imc_mudof(who))) &&
	!imc_hasname(c->invited, who) && !imc_hasname(c->invited, imc_mudof(who)))
      return FALSE;
      
    return TRUE;
  }

  /* closed or private. default no, override with invites, then excludes */
  
  if ((imc_hasname(c->invited, who) || imc_hasname(c->invited, imc_mudof(who))) &&
      !imc_hasname(c->excluded, who) && !imc_hasname(c->excluded, imc_mudof(who)))
    return TRUE;
    
  return FALSE;
}

/* set up a new imc_connect struct, and link it into imc_connect_list */
CONNECTION *imc_new_connect( void )
{
   CONNECTION *c;

   CREATE( c, CONNECTION, 1 );

   c->state    = CONN_NONE;
   c->desc     = -1;
   c->insize   = IMC_MINBUF;
   CREATE( c->inbuf, char, c->insize );
   c->outsize  = IMC_MINBUF;
   CREATE( c->outbuf, char, c->outsize );
   c->inbuf[0] = c->outbuf[0] = '\0';
   c->info     = NULL;
   c->ip       = NULL;
   c->newoutput = 0;

   LINK( c, first_connection, last_connection, next, prev );
   return c;
}

/*  free buffers and extract 'c' from imc_connect_list
 *  called from imc_idle_select when we're done with a connection with
 *  c->state==CONN_NONE
 */
void imc_extract_connect( CONNECTION *c )
{
   if( c->state != CONN_NONE )
   {
      Log( "imc_extract_connect: non-closed connection" );
      return;
   }

   DISPOSE( c->inbuf );
   DISPOSE( c->outbuf );

   if ( c->ip )
       DISPOSE( c->ip );

   UNLINK( c, first_connection, last_connection, next, prev );
   imc_cancel_event( NULL, c );
   DISPOSE( c );
}

/* update our routing table based on a packet received with path "path" */
static void updateroutes( char *path )
{
   REMINFO *p;
   char *sender;
   char *temp;

   /* loop through each item in the path, and update routes to there */

   temp = path;
   while( temp && temp[0] )
   {
      sender = imc_firstinpath( temp );

      if( !STR_CEQL( sender, imc_name ) )
      {
         /* not from us */
         /* check if its in the list already */

         p = imc_find_reminfo( sender );
         if( !p )			/* not in list yet, create a new entry */
         {
             p = imc_new_reminfo( sender );

             p->netname = strdup("unknown");
             p->web     = strdup("unknown");
             p->version = strdup("unknown");
         }

         if (p->path)
             DISPOSE(p->path);
         p->path = strdup( temp );
      }
      /* get the next item in the path */
      temp = strchr( temp, '!' );
      if( temp )
        temp++;			/* skip to just after the next '!' */
   }
}

/* return 1 if 'name' is a part of 'path'  (internal) */
bool inpath(const char *path, const char *name)
{
  char buf[IMC_MNAME_LENGTH+3];

  if ( !path || path[0] == '\0' || !name || name[0] == '\0' )
      return FALSE;

  if (STR_CEQL(path, name))
      return TRUE;

  snprintf(buf, IMC_MNAME_LENGTH+3, "%s!", name);
  if (STRN_CEQL(path, buf, strlen(buf)))
      return TRUE;

  snprintf(buf, IMC_MNAME_LENGTH+3, "!%s", name);
  if (strlen(buf) < strlen(path) &&
      STR_CEQL(path + strlen(path) - strlen(buf), buf))
      return TRUE;

  snprintf(buf, IMC_MNAME_LENGTH+3, "!%s!", name);
  if (strcasestr(path, buf))
      return TRUE;

  return FALSE;
}

/*
 *  Core functions (all internal)
 */

/* accept a connection on the control port */
static void do_accept( void )
{
   int d;
   CONNECTION *c;
   struct sockaddr_in sa;
   unsigned int size = sizeof(sa);
   int r;

   d = accept( control, (struct sockaddr *) &sa, &size );
   if( d < 0 )
   {
      Log( "do_accept: accept call failed" );
      return;
   }

   r = fcntl( d, F_GETFL, 0 );
   if( r < 0 || fcntl( d, F_SETFL, O_NONBLOCK | r ) < 0 )
   {
      Log( "do_accept: fcntl call failed" );
      close(d);
      return;
   }

   c = imc_new_connect();
   c->state    = CONN_WAITCLIENTPWD;
   c->desc     = d;
   c->ip       = strdup( inet_ntoa(sa.sin_addr) );

   imc_add_event( IMC_LOGIN_TIMEOUT, ev_login_timeout, c );
   Log( "New connection from %s:%d on descriptor %d.", c->ip, ntohs(sa.sin_port), d );
}

/* notify everyone of the closure - shogar */
void imc_close_notify( INFO *i )
{
   PACKET out;

   if ( !i || !i->name || i->name[0] == '\0' )
       return;

   imc_initdata( &out );
   strlcpy( out.type, "close-notify", IMC_TYPE_LENGTH );
   strlcpy( out.from, "*", IMC_NAME_LENGTH );
   strlcpy( out.to, "*@*", IMC_NAME_LENGTH );
   imc_addkey( &out, "versionid", IMC_VERSIONID );
   imc_addkey( &out, "host", i->name );
   imc_send( &out );
   /* log and announce if closed via event - shogar 2/26/2000 */
   Log( "%s: closing link(sending close-notify)", i->name );
   imc_freedata( &out );
}

/* close given connection */
void do_close( CONNECTION *c )
{
   REMINFO *r;

   if( c->state == CONN_NONE )
      return;

   c->state = CONN_NONE;

   if ( c->desc )
   {
       close( c->desc );
       c->desc = 0;
   }

   if ( c->info )
   {
       c->info->connection = NULL;

       /* dont announce a simple reboot  - shogar - 2/2/2000 */ 
       imc_add_event( 60, ev_close_notify, c->info );

       /* Handle reconnects */
       if ( c->info->port > 0 )
           imc_setup_reconnect( c->info );

       if ( (r = imc_find_reminfo( c->info->name ) ) != NULL )
           imc_delete_reminfo( r );

       c->info = NULL;
   }
   else
       Log( "%s: closing link", imc_getconnectname( c ) );

   c->inbuf[0] = '\0';
   c->outbuf[0] = '\0';
}

/* read waiting data from descriptor.
 * read to a temp buffer to avoid repeated allocations
 */
static void do_read( CONNECTION *c )
{
   unsigned int size;
   int r;
   char temp[IMC_MAXBUF];
   char *newbuf;
   unsigned int newsize;

   r = read( c->desc, temp, IMC_MAXBUF-1 );
   if( !r || ( r < 0 && errno != EAGAIN && errno != EWOULDBLOCK ) )
   {
       if( r < 0 )                    /* read error */
           Log( "%s: do_read: %s", imc_getconnectname( c ), strerror(errno) );
       else                        /* socket was closed */
           Log( "%s: do_read: connection closed from other side", imc_getconnectname( c ) );

      do_close( c );
      return;
   }
  
   if( r < 0 )			/* EAGAIN error */
      return;

   temp[r] = '\0';

   size = strlen( c->inbuf ) + r + 1;

   if( size >= c->insize )
   {
      newsize = c->insize;
      while( newsize < size )
         newsize *= 2;

      CREATE( newbuf, char, newsize );
      strlcpy( newbuf, c->inbuf, newsize );
      DISPOSE( c->inbuf );
      c->inbuf = newbuf;
      c->insize = newsize;
   }

   if( size < c->insize/2 && size >= IMC_MINBUF )
   {
      newsize = c->insize;
      newsize /= 2;

      CREATE( newbuf, char, newsize );
      strlcpy( newbuf, c->inbuf, newsize );
      DISPOSE( c->inbuf );
      c->inbuf = newbuf;
      c->insize = newsize;
   }

   strlcat( c->inbuf, temp, c->insize );

   imc_stats.rx_bytes += r;
}

/* write to descriptor */
static void do_write( CONNECTION *c )
{
   unsigned int size = 0;
   int w = 0;

   if( c->state == CONN_SERVERCONNECT )
   {
      /* Wait for server password */
      c->state = CONN_WAITSERVERPWD;
      return;
   }

   size = strlen( c->outbuf );
   if( size == 0 ) /* nothing to write */
      return;

   w = write( c->desc, c->outbuf, size );
   if( !w || ( w < 0 && errno != EAGAIN && errno != EWOULDBLOCK ) )
   {
       if( w < 0 )			/* write error */
           Log( "%s: do_write: %s", imc_getconnectname( c ), strerror(errno) );
       else			/* socket was closed */
           Log( "%s: do_write: connection closed from other side", imc_getconnectname( c ) );

      do_close( c );
      return;
   }

   if( w < 0 )			/* EAGAIN */
      return;

   strlcpy( c->outbuf, c->outbuf + w, c->outsize );

   imc_stats.tx_bytes += w;

}

/* put a line onto descriptors output buffer */
static void do_send( CONNECTION *c, const char *line )
{
   unsigned int len;
   char *newbuf;
   unsigned int newsize = c->outsize;

   if( c->state == CONN_NONE )
      return;

   if( !c->outbuf[0] )
      c->newoutput = 1;

   len = strlen( c->outbuf ) + strlen( line ) + 3;

   if( len > c->outsize )
   {
      while( newsize < len )
         newsize *= 2;

      CREATE( newbuf, char, newsize );
      strlcpy( newbuf, c->outbuf, newsize );
      DISPOSE( c->outbuf );
      c->outbuf = newbuf;
      c->outsize = newsize;
   }
   if( len < c->outsize/2 && len >= IMC_MINBUF )
   {
      newsize = c->outsize/2;

      CREATE( newbuf, char, newsize );
      strlcpy( newbuf, c->outbuf, newsize );
      DISPOSE( c->outbuf );
      c->outbuf = newbuf;
      c->outsize = newsize;
   }
   strlcat( c->outbuf, line, c->outsize  );

   strlcat( c->outbuf, "\n\r", c->outsize );
}

/*  try to read a line from the input buffer, NULL if none ready
 *  all lines are \n\r terminated in theory, but take other combinations
 */
static const char *getline(char *buffer, int len)
{
  unsigned int i;
  static char buf[IMC_PACKET_LENGTH];

  /* copy until \n, \r, end of buffer, or out of space */
  for (i=0; buffer[i] && buffer[i] != '\n' && buffer[i] != '\r' && i+1 < IMC_PACKET_LENGTH; i++)
    buf[i] = buffer[i];

  /* end of buffer and we haven't hit the maximum line length */
  if (!buffer[i] && i+1 < IMC_PACKET_LENGTH)
  {
    buf[0]='\0';
    return NULL;		/* so no line available */
  }

  /* terminate return string */
  buf[i]=0;

  /* strip off extra control codes */
  while (buffer[i] && (buffer[i] == '\n' || buffer[i] == '\r'))
    i++;

  /* remove the line from the input buffer */
  strlcpy(buffer,buffer+i, len);

  return buf;
}

static int memory_head; /* next entry in memory table to use, wrapping */

/* checkrepeat: check for repeats in the memory table */
bool checkrepeat(const char *mud, unsigned long seq)
{
  unsigned int i;

  for (i=0; i<IMC_MEMORY; i++)
    if (imc_memory[i].from && seq == imc_memory[i].sequence && STR_CEQL(mud, imc_memory[i].from))
      return TRUE;

  /* not a repeat, so log it */

  if (imc_memory[memory_head].from)
    DISPOSE(imc_memory[memory_head].from);

  imc_memory[memory_head].from     = strdup(mud);
  imc_memory[memory_head].sequence = seq;
  
  memory_head++;
  if (memory_head==IMC_MEMORY)
    memory_head=0;

  return FALSE;
}

/* send a packet to a mud using the right version */
static void do_send_packet( CONNECTION *c, PACKET *p )
{
   const char *output;
   unsigned char v;

   v = c->version;
   
   if( v > IMC_VERSION )
      v = IMC_VERSION;

   output = ( *imc_vinfo[v].generate )(p);

   if( output )
   {
      imc_stats.tx_pkts++;

      if( strlen( output ) > imc_stats.max_pkt )
         imc_stats.max_pkt = strlen( output );

      do_send( c, output );
   }
}

bool can_forward( const PACKET *p )
{
   if( STR_CEQL( p->type, "chat" ) || STR_CEQL( p->type, "emote" ) )
   {
      unsigned char chan = imc_getkeyi( p, "channel", 0 );
    
      if( chan == 0 || chan == 1 || chan == 3 )
         return FALSE;
   }
   else if ( STR_CEQL( p->type, "keepalive-request" ) )
   {
       if ( !STR_CEQL( imc_mudof(p->from), imc_name ) )
           return FALSE;
   }
   else if ( STR_CEQL( p->type, "ice-refresh" ) )
   {
       bool relay = imc_getkeyi( p, "relayed", 0 );

       if ( !relay && !STR_CEQL( imc_mudof( p->i.from), imc_name ) )
           return FALSE;
   }

   return TRUE;
}

/* forward a packet - main routing function, all packets pass through here */
static void forward( PACKET *p )
{
   REMINFO *route = NULL;
   INFO *i = NULL, *direct = NULL;
   const char *to;
   bool isbroadcast = FALSE;

   /* check for duplication, and register the packet in the sequence memory */
   if( p->i.sequence && checkrepeat( imc_mudof( p->i.from ), p->i.sequence ) )
      return;

   /* check for packets we've already forwarded */
   if( inpath( p->i.path, imc_name ))
      return;

   /* update our routing info */
   updateroutes( p->i.path );

   /* check for really old packets */
   if( (route = imc_find_reminfo( imc_mudof( p->i.from ) )) != NULL )
   {
      if( ( p->i.sequence+IMC_PACKET_LIFETIME ) < route->top_sequence )
      {
         imc_stats.sequence_drops++;
         return;
      }
      if( p->i.sequence > route->top_sequence )
         route->top_sequence = p->i.sequence;
   }

   to = imc_mudof( p->i.to );
   isbroadcast = STR_EQL( to, "*"); /* broadcasts are, well, broadcasts */

   /* forward to our mud if it's for us */
   if( isbroadcast || STR_CEQL( to, imc_name ) )
   {
      strlcpy( p->to, imc_nameof( p->i.to ), IMC_NAME_LENGTH );    /* strip the name from the 'to' */
      strlcpy( p->from, p->i.from, IMC_NAME_LENGTH );

      imc_recv(p);

      /* if its only to us (ie. not broadcast) don't forward it */
      if ( !isbroadcast )
          return;
   }

   /* check if we should just drop it (policy rules) */
   if( !can_forward(p) )
      return;

   /* convert 'to' fields that we have a route for to a hop along the route */
  
   if( !isbroadcast && ( route = imc_find_reminfo( to ) ) != NULL 
           && route->path != NULL && !inpath( p->i.path, imc_lastinpath(route->path) ) )
   /* avoid circular routing */
   {
      /*  check for a direct connection: if we find it, and the route isn't
       *  to it, then the route is a little suspect.. also send it direct
       */
      if( !STR_CEQL( to, imc_lastinpath(route->path) )  
              &&  (i = imc_getinfo(to)) != NULL && i->connection )
         direct = i;

      to = imc_lastinpath(route->path);
   }

   /* check for a direct connection */
  
   if( !isbroadcast && ((i = imc_getinfo(to)) == NULL || !i->connection) 
	   && ( !direct || !direct->connection ))
   {
	 Log( "No path available for packet sent from %s to %s of type %s.", 
             imc_mudof(p->i.from), p->i.to, p->type );
	 return;
   }

   if( isbroadcast )
   {	
      CONNECTION *c = NULL;

      for( c = first_connection; c; c = c->next )
      {
         if( c->state == CONN_COMPLETE )
         {
	      /* don't forward to sites that have already received it, or sites that don't need this packet */
	      if( inpath( p->i.path, c->info->name ) )
	         continue;
	      /* end SPAM fix */
	      do_send_packet( c, p );
         }
      }
   }
   else
      /* forwarding to a specific connection */
   {
      /* but only if they haven't seen it (sanity check) */
      if( i && i->connection && !inpath( p->i.path, i->name ) )
         do_send_packet( i->connection, p );

      /* send on direct connection, if we have one */
      if( direct && direct != i && direct->connection && !inpath( p->i.path, direct->name ) )
         do_send_packet( direct->connection, p );
   }
}

IMC_BLACKLIST *imc_find_blacklist( char *ip )
{
    IMC_BLACKLIST *bld = NULL;

    if ( !ip || ip[0] == '\0' )
        return NULL;

    for ( bld = first_blacklist; bld; bld = bld->next )
        if ( STR_CEQL( bld->ip, ip ) )
            break;

    return bld;
}

bool add_to_blacklist( char *ip )
{
    IMC_BLACKLIST *nble = NULL;

    if ( !ip || ip[0] == '\0' )
        return FALSE;

    if ( (nble = imc_find_blacklist( ip ) ) != NULL )
        return FALSE;

    CREATE( nble, IMC_BLACKLIST, 1 );
    nble->ip = strdup( ip );

    LINK( nble, first_blacklist, last_blacklist, next, prev );
    return TRUE;
}

bool rem_from_blacklist( char *ip )
{
    IMC_BLACKLIST *tbl = NULL;

    if ( !ip || ip[0] == '\0' )
        return FALSE;

    if ( (tbl = imc_find_blacklist( ip ) ) == NULL )
        return FALSE;

    if ( tbl->ip )
        DISPOSE( tbl->ip );

    UNLINK( tbl, first_blacklist, last_blacklist, next, prev );
    DISPOSE(tbl);

    return TRUE;
}

bool imc_readblacklist( void )
{
    char ip[24];
    FILE *bl;

    if ( !(bl = fopen( IMC_BLACKLIST_FILE, "r" )) )
    {
        Log( "Blacklist file could not be opened for reading." );
        return FALSE;
    }

    while ( fscanf( bl, "%23[^\n]\n", ip ) == 1 )
        add_to_blacklist( ip );

    SFCLOSE( bl );
    return TRUE;
}

bool imc_saveblacklist( void )
{
    FILE *bl;
    IMC_BLACKLIST *nble = NULL;

    if ( !(bl = fopen( IMC_BLACKLIST_FILE, "w" )) )
    {
        Log( "Blacklist file could not be opened for writing." );
        return FALSE;
    }

    for( nble = first_blacklist; nble; nble = nble->next )
        if ( nble->ip && nble->ip[0] != '\0' )
            fprintf( bl, "%s\n", nble->ip );

    fprintf( bl, "\n" );

    SFCLOSE( bl );
    return TRUE;
}

/* handle a password from a client */
static void clientpassword( CONNECTION *c, const char *argument )
{
   char type[3], name[IMC_MNAME_LENGTH], pw[IMC_PW_LENGTH], version[20];
   char command[IMC_PW_LENGTH], carg1[IMC_PW_LENGTH];
   INFO *i;
   char response[IMC_PACKET_LENGTH];

   return;
}

   if( !imc_vinfo[c->version].generate || !imc_vinfo[c->version].interpret )
   {
      Log( "%s: unsupported version %d on connect", imc_getconnectname(c), c->version );
      do_close( c );
      return;
   }

   Log( "%s: connected (version %d)", imc_getconnectname(c), c->version );

   c->info->last_connected = imc_now;
   imc_cancel_event( ev_login_timeout, c );
   imc_cancel_event( ev_reconnect, c->info );
   /* if reconnecting on simple reboot don't - shogar - 2/1/2000 */
   imc_cancel_event( ev_close_notify, c->info );

   imc_request_keepalive();
   imc_send_keepalive( NULL, "*" );
}

/* start up listening port */
bool imc_startup_port(void)
{
  int i;
  struct sockaddr_in sa;

  Log("Binding port %d for incoming connections.", imc_port);
      
  control = socket(AF_INET, SOCK_STREAM, 0);
  if (control<0)
  {
    Log("imc_startup_port: socket call failure");
    return FALSE;
  }
    
  i=1;
  if (setsockopt(control, SOL_SOCKET, SO_REUSEADDR, (void *)&i, sizeof(i))<0)
  {
    Log("imc_startup_port: SO_REUSEADDR unable to be set");
    close(control);
    return FALSE;
  }
  
  if ((i=fcntl(control, F_GETFL, 0))<0)
  {
    Log("imc_startup_port: fcntl(F_GETFL) call failure");
    close(control);
    return FALSE;
  }

  if (fcntl(control, F_SETFL, i | O_NONBLOCK)<0)
  {
    Log("imc_startup_port: fcntl(F_SETFL) call failure");
    close(control);
    return FALSE;
  }

  sa.sin_family      = AF_INET;
  sa.sin_port        = htons(imc_port);
  sa.sin_addr.s_addr = imc_bind; /* already in network order */
  
  if (bind(control, (struct sockaddr *)&sa, sizeof(sa))<0)
  {
    Log("imc_startup_port: bind call failure");
    close(control);
    return FALSE;
  }
  
  if (listen(control, 3)<0)
  {
    Log("imc_startup_port: listen call failure");
    close(control);
    return FALSE;
  }
  
  return TRUE;
}

/* shut down listening port */
void imc_shutdown_port(void)
{
  Log("Closing listening port.");
  close(control);
}

/* start up IMC */
bool imc_startup_network( void )
{
   INFO *info = NULL;

   control = -1;
      
   if( !imc_startup_port() )
       return FALSE;

   imc_stats.rx_pkts  = 0;
   imc_stats.tx_pkts  = 0;
   imc_stats.rx_bytes = 0;
   imc_stats.tx_bytes = 0;
   imc_stats.sequence_drops = 0;

   /* Allow updating mud connections list without reboot */
   if ( imc_siteinfo.updatefile )
       imc_add_event( 15, ev_mudconnections, NULL );

   /* Start regular imclist publication */
   if ( imc_siteinfo.htmlmudlist )
       imc_add_event( 10, ev_htmlmudlist, NULL );

   /* Start regular statistics publication */
   if ( imc_siteinfo.htmlstats )
       imc_add_event( 10, ev_htmlstats, NULL );

   /* Send channel information to everyone */
   imc_add_event( 5, ev_iced_update, NULL );

   /* Clear out any cached imclists */
   for ( info = first_info; info; info = info->next )
       imc_add_event( 60, ev_close_notify, info );

   /* do autoconnects */
   for( info = first_info; info; info = info->next )
       if ( info->port > 0 )
           imc_connect_to( info->name );

   return TRUE;
}

void imc_startup( void )
{
  imc_now=time(NULL);                  /* start our clock */
  imc_boot=imc_now;

  Log("%s initializing.", IMC_VERSIONID);

  imc_sequencenumber=imc_now;
  imc_readblacklist();
  iced_load_channels();

  if (!imc_readconfig() || !imc_startup_network())
  {
      Log( "hub: giving up" );
      exit(1);
  }

}

void imc_shutdown_network( void )
{
   imc_event *ev, *ev_next;
   CONNECTION *c, *c_next;
   REMINFO *p, *pnext;

   imc_shutdown_port();

   Log( "Received %ld bytes(%ld packets) total.", imc_stats.rx_bytes, imc_stats.rx_pkts );
   Log( "Received %d age-dropped packets.", imc_stats.sequence_drops );
   Log( "Sent %ld bytes(%ld packets) total.", imc_stats.tx_bytes, imc_stats.tx_pkts );
   Log( "The largest packet sent or received was %d bytes.", imc_stats.max_pkt );

   for( c = first_connection; c; c = c_next )
   {
      c_next = c->next;
      do_close( c );
      imc_extract_connect( c );
   }

   for( p = first_reminfo; p; p = pnext )
   {
      pnext = p->next;
      imc_delete_reminfo( p );
   }

   for( ev = imc_event_list; ev; ev = ev_next )
   {
      ev_next = ev->next;
      ev->next = NULL;
      DISPOSE( ev );
   }
   for( ev = imc_event_free; ev; ev = ev_next )
   {
      ev_next = ev->next;
      ev->next = NULL;
      DISPOSE( ev );
   }
   imc_event_list = imc_event_free = NULL;
}

void imc_delete_info( INFO *i )
{
   CONNECTION *c;

   for( c = first_connection; c; c = c->next )
      if( c->info == i )
         do_close( c );

   UNLINK( i, first_info, last_info, next, prev );

   if( i->name )
      DISPOSE( i->name );
   if( i->host )
      DISPOSE( i->host );
   if( i->clientpw )
      DISPOSE( i->clientpw );
   if( i->serverpw )
      DISPOSE( i->serverpw );

   imc_cancel_event( NULL, i );
   DISPOSE( i );

   imc_siteinfo.conncount--;
}

/* close down imc */
void imc_shutdown( void )
{
   INFO *info, *info_next;

   Log( "Shutting down %s.", IMC_VERSIONID );

   for( info = first_info; info; info = info_next )
   {
      info_next = info->next;
      imc_delete_info( info );
   }

   imc_shutdown_network();

   DISPOSE( imc_name );

   exit(0);
}

/* interpret an incoming packet using the right version */
static PACKET *do_interpret_packet( CONNECTION *c, const char *line )
{
   unsigned char v;
   PACKET *p;

   if( !line[0] )
      return NULL;

   v = c->version;
   if( v > IMC_VERSION )
      v = IMC_VERSION;

   p = ( *imc_vinfo[v].interpret )( line );

   return p;
}

unsigned int imc_fill_fdsets( unsigned int maxfd, fd_set *sread, fd_set *swrite, fd_set *exc )
{
   CONNECTION *c;

   /* set up fd_sets for select */

      
   if( maxfd < control )
       maxfd = control;
      
   FD_SET( control, sread );

   for( c = first_connection; c; c = c->next )
   {
      if( maxfd < c->desc )
         maxfd = c->desc;

      if ( c->state == CONN_NONE )
          continue;

      if ( c->state == CONN_SERVERCONNECT )
      {
          FD_SET( c->desc, swrite );
          continue;
      }

      FD_SET( c->desc, sread );

      if( c->outbuf[0] )
          FD_SET( c->desc, swrite );
   }
   return maxfd;
}

/* shell around imc_idle_select */
void imc_idle(unsigned int s)
{
  fd_set sread, swrite, exc;
  unsigned int maxfd;
  struct timeval timeout;
  int i;

  FD_ZERO(&sread);
  FD_ZERO(&swrite);
  FD_ZERO(&exc);

  maxfd=imc_fill_fdsets(0, &sread, &swrite, &exc);
  timeout.tv_sec = s;
  timeout.tv_usec = 0;

  if (maxfd)
    while ((i=select(maxfd+1, &sread, &swrite, &exc, &timeout)) < 0 && errno == EINTR)	/* loop, ignoring signals */
      ;
  else
    while ((i=select(0, NULL, NULL, NULL, &timeout)) < 0 && errno == EINTR)
      ;

  if (i<0)
  {
    Log("imc_idle: select");
    imc_shutdown();
    return;
  }

  imc_idle_select(&sread, &swrite, &exc, time(NULL));
}

/*
 * Events
 */ 

/* time out a login */
void ev_login_timeout( void *data )
{
   CONNECTION *c = (CONNECTION *)data;

   Log( "%s: login timeout", imc_getconnectname( c ) );
   do_close( c );
}

/* make it an event, dont announce a simple reboot - shogar - 2/1/2000 */
void ev_close_notify( void *data )
{
  INFO *info = (INFO *)data;

  imc_close_notify(info);
}

/* try a reconnect to the given imc_info */
void ev_reconnect( void *data )
{
   INFO *info = (INFO *)data;

   if( !info->connection && info->port > 0 )
	   imc_connect_to( info->name ); 
}
/* low-level idle function: read/write buffers as needed, etc */
void imc_idle_select( fd_set *sread, fd_set *swrite, fd_set *exc, time_t now )
{
   const char *command;
   PACKET *p;
   CONNECTION *c, *c_next;

   if( imc_sequencenumber < (unsigned long)imc_now )
      imc_sequencenumber = (unsigned long)imc_now;

   imc_run_events(now);

   /* handle results of the select */

   if( FD_ISSET( control, sread ) )
      do_accept();

   for( c = first_connection; c; c = c_next )
   {
      c_next = c->next;

      if( c->state != CONN_NONE && FD_ISSET( c->desc, exc ) )
         do_close( c );

      if( c->state != CONN_NONE && FD_ISSET( c->desc, sread ) )
         do_read( c );

      while( c->state != CONN_NONE && ( command = getline( c->inbuf, c->insize ) ) != NULL )
      {
         if( strlen( command ) > imc_stats.max_pkt )
	      imc_stats.max_pkt = strlen( command );

         switch( c->state )
         {
            case CONN_DISCONNECT:
                break;
            case CONN_WAITCLIENTPWD:
	         clientpassword( c, command );
	         break;
            case CONN_WAITSERVERPWD:
	         serverpassword( c, command );
	         break;
            case CONN_COMPLETE:
	         p = do_interpret_packet( c, command );
	         if( p )
	         {
                 /* check the last entry in the path is the same as the
                  * sending mud. Also check the first entry to see that it matches
                  * the sender.
                  */
                 imc_stats.rx_pkts++;

		 if ( STR_CEQL( p->type, "ice-refresh" ) )
		     snprintf( p->i.to, IMC_NAME_LENGTH, "ICE@%s", imc_name );

                 /* Does not route packets */
                 if ( !c->info->router )
                 {
                     if ( !STR_CEQL( imc_mudof(p->i.from), c->info->name ) )
                     {
                         Log( "ALERT: Packet from %s forged to look like it was from %s.",
                                 c->info->name, imc_mudof(p->i.from) );
                     }
                     else if ( STR_CEQL( p->type, "close-notify" ) )
                     {
                         Log( "ALERT: %s attempted to send a close-notify packet.", c->info->name );
                     }
                     else
                     {
                         /* Overwrite routes from non-routers */
                         strlcpy( p->i.path, imc_mudof(p->i.from), IMC_MNAME_LENGTH );
                         forward(p);        /* only forward if its a valid packet! */
                     }
                 }
                 else
                 {
                     if( !STR_CEQL( c->info->name, imc_lastinpath( p->i.path ) ) )
                     {
                         Log( "ALERT: Packet passed through %s forged to look like it was passed through %s.", 
                                 c->info->name, imc_lastinpath( p->i.path ) );
                     }
                     else if( !STR_CEQL( imc_mudof( p->i.from ), imc_firstinpath( p->i.path ) ) )
                     {
                         Log( "ALERT: Packet originally from %s forged to look like it was originally from %s", 
                                 p->i.from, imc_firstinpath( p->i.path ) );
                     }
                     else 
                         forward(p);		/* only forward if its a valid packet! */
                 }

                 imc_freedata( p );
	         }
	      break;
         }
      }
   }

   for( c = first_connection; c; c = c_next )
   {
      c_next = c->next;
    
      if( c->state != CONN_NONE && ( FD_ISSET( c->desc, swrite ) || c->newoutput ) )
      {
         do_write( c );
         c->newoutput = c->outbuf[0];

         if ( c->state == CONN_DISCONNECT )
             do_close(c);
      }
   }

   for( c = first_connection; c; c = c_next )
   {
      c_next = c->next;

      if( c->state == CONN_NONE )
         imc_extract_connect( c );
   }
}

/* connect to given mud */
bool connect_to( const char *mud )
{
   CONNECTION *c;
   int desc;
   struct sockaddr_in sa;
   char buf[IMC_DATA_LENGTH];
   int r;

   Log( "imc_connect_to: connecting to %s", mud );

   /*  warning: this blocks. It would be better to farm the query out to
    *  another process, but that is difficult to do without lots of changes
    *  to the core mud code. You may want to change this code if you have an
    *  existing resolver process running.
    */

   if( ( sa.sin_addr.s_addr = inet_addr( i->host ) ) == INADDR_NONE )
   {
      struct hostent *hostinfo;

      if( NULL == ( hostinfo = gethostbyname( "mugs.net" ) ) )
      {
         Log( "connect_to: hostname could not be resolved" );
         return 0;
      }
      sa.sin_addr.s_addr = *(unsigned long *) hostinfo->h_addr;
   }
   sa.sin_port   = htons( 2000 );
   sa.sin_family = AF_INET;

   desc = socket( AF_INET, SOCK_STREAM, 0 );
   if( desc < 0 )
   {
      Log( "imc_connect_to: socket call failure" );
      return 0;
   }

   r = fcntl( desc, F_GETFL, 0 );
   if( r < 0 || fcntl( desc, F_SETFL, O_NONBLOCK | r ) < 0 )
   {
      Log( "imc_connect_to: fcntl call failure" );
      close( desc );
      return 0;
   }

   if( connect( desc, ( struct sockaddr * )&sa, sizeof( sa ) ) < 0 )
   {
      if( errno != EINPROGRESS )
      {
         Log( "connect_to: connection could not be established" );
         close( desc );
         return 0;
      }
   }
   c = new_connect();

   c->desc     = desc;
   c->state    = CONN_SERVERCONNECT;
   c->info     = i;
   c->ip       = strdup( inet_ntoa( sa.sin_addr ) );
   do_send( c, buf );

   return 1;
}

void send(PACKET *p)
{
  /* initialize packet fields that the caller shouldn't/doesn't set */

  p->i.path[0]  = 0;
  
  p->i.sequence = imc_sequencenumber++;
  if (!imc_sequencenumber)
    imc_sequencenumber++;
  
  strlcpy(p->i.to, p->to, IMC_NAME_LENGTH);
  snprintf( p->i.from, IMC_NAME_LENGTH, "%s@%s", p->from, imc_name );
  
  forward(p);
}

void iced_send_destroy( const char *cname, const char *to )
{
   PACKET out;

   strlcpy( out.from, "ICE", IMC_NAME_LENGTH );
   strlcpy( out.to, to ? to : "*", IMC_NAME_LENGTH );
   strlcpy( out.type, "ice-destroy", IMC_TYPE_LENGTH );
   imc_initdata( &out );
   imc_addkey( &out, "channel", cname );
   imc_send( &out );
   imc_freedata( &out );
}

/* called when a keepalive has been received */
void imc_recv_keepalive( const char *from, const char *version, const char *networkname, const char *web  )
{
   REMINFO *p;

   if( STR_CEQL( from, imc_name ) )
      return;
  
}

/* called when a ping request is received */
void imc_recv_ping(const char *from, const char *path)
{
  /* ping 'em back */
  imc_send_pingreply(from, path);
}

/* handle a packet destined for us, or a broadcast */
void imc_recv( const PACKET *p )
{
   /* who: receive a who request */
   if( STR_CEQL( p->type, "who" ) || STR_CEQL( p->type, "wHo" ) )
   {
      imc_recv_who( p->from, imc_getkey( p, "type", "who" ) );
   }

   /* is-alive: receive a keepalive (broadcast) */
   else if( STR_CEQL( p->type, "is-alive" ) )
   {
       Log( "Received is-alive from %s.", imc_mudof( p->from ) );
       imc_recv_keepalive( imc_mudof( p->from ), imc_getkey( p, "versionid", "unknown" ),
               imc_getkey( p, "networkname", "unknown"), imc_getkey( p, "url", "unknown") );
   }

   /* ping: receive a ping request */
   else if( STR_CEQL( p->type, "ping" ) )
   {
      imc_recv_ping( imc_mudof( p->from ), p->i.path );
   }

   /* Handle channel refresh requests from muds */
   else if( STR_CEQL( p->type, "ice-refresh" ) )
   {
       IMC_CHANNEL *c = NULL;

       /* Send channel updates from local config */
       for ( c = first_imc_channel; c; c = c->next )
           iced_update( c, imc_mudof( p->from ) );

       /* Send out to other hubs */
       relay_ice_refresh( p );
   }

   /* handle keepalive requests - shogar */
   else if( STR_CEQL( p->type, "keepalive-request" ) )
   {
       struct imc_keepalive *k = NULL;

       Log( "Keepalive request received from %s.", imc_mudof(p->from) );

       CREATE( k, struct imc_keepalive, 1 );
       strlcpy( k->destination, imc_mudof(p->from), IMC_MNAME_LENGTH );
       k->count = 0;
       k->remote = first_reminfo;

       imc_add_event( 1, ev_send_isalive, k );
   }

   /* expire closed hubs - shogar */
   else if( STR_CEQL( p->type, "close-notify" ) )
   {
      INFO *i = NULL;
      REMINFO *r = NULL;

      if ( ( i = imc_getinfo( imc_mudof( p->from ) ) ) == NULL )
          return;

      Log( "Close-notify packet for %s received from %s.", imc_getkey( p, "host", "unknown" ), p->from );

      if ((r = imc_find_reminfo(imc_getkey(p, "host", "") )) != NULL )
      {
          REMINFO *o, *o_next;

          /* if it's a hub, silently delete muds on it from cache */
          for ( o = first_reminfo; o; o = o_next )
          {
              o_next = o->next;

              if ( STR_CEQL( r->name, imc_hubinpath( o->path ) ) )
                  imc_delete_reminfo( o );
          }

          imc_delete_reminfo(r);
      }
   }

   /* call catch-all fn if present */
   else
   {
      iced_recv( p );
   }

   return;
}

/* Commands called by the interface layer */

/* send an emote out on a channel */
void imc_send_emote( const char *argument )
{
   PACKET out;

   imc_initdata(&out);

   strlcpy( out.from, "ICE", IMC_NAME_LENGTH );
   strlcpy( out.to, "*@*", IMC_NAME_LENGTH );
   strlcpy( out.type, "emote", IMC_TYPE_LENGTH );
   imc_addkeyi( &out, "channel", 15 );
   imc_addkeyi( &out, "level", -1 );
   imc_addkey( &out, "text", argument );

   imc_send( &out );
   imc_freedata( &out );
}

/* send a tell to a remote player */
void imc_send_tell( const char *to, const char *argument )
{
   PACKET out;

   if( STR_EQL( imc_mudof(to), "*" ) )
      return; /* don't let them do this */

  
   imc_initdata(&out);
   strcpy( out.from, "ICE" );
   strcpy( out.to, to  );
   strcpy( out.type, "tell"  );
   imc_addkey( &out, "text", argument );
   imc_addkeyi( &out, "isreply", 1 );
   imc_addkeyi( &out, "level", -1 );

   imc_send( &out );
   imc_freedata( &out );
}

/* respond to a who request with the given data */
void imc_send_whoreply( const char *to, const char *data )
{
   PACKET out;

   if( STR_EQL( imc_mudof(to), "*" ) )
      return; /* don't let them do this */

   imc_initdata( &out );

   strlcpy( out.to, to, IMC_NAME_LENGTH );

   strlcpy( out.type, "who-reply", IMC_TYPE_LENGTH );
   strlcpy( out.from, "*", IMC_NAME_LENGTH );

   imc_addkey( &out, "text", data );

   imc_send( &out );
   imc_freedata( &out );
}

void ev_send_isalive( void *data )
{
    REMINFO *r = NULL;
    struct imc_keepalive *k = (struct imc_keepalive *) data;
    unsigned char count = 0;

    imc_cancel_event( ev_send_isalive, k);

    if ( !k )
        return;

    if ( k->count == 0 )
    {
        imc_send_keepalive( NULL, k->destination );
        count++;
    }

    for ( r = k->remote; r != NULL; r = r->next )
    {
        if ( STR_CEQL( k->destination, r->name ) || inpath(r->path, k->destination))
            continue;
            
        imc_send_keepalive( r, k->destination );
        count++;

        /* Don't want to send more than 15 is-alive packets at a time */
        if ( count >= 15 && r->next != NULL )
        {
            k->count += count;
            k->remote = r->next;
            imc_add_event( 3, ev_send_isalive, k );
            return;
        }
    }

    k->destination[0] = '\0';
    k->count = 0;
    k->remote = NULL;

    DISPOSE( k );
    return;
}

/* send a keepalive to everyone */
void imc_send_keepalive( REMINFO *r, char *destination )
{
   PACKET out;

   imc_initdata( &out );

   strlcpy( out.from, "*", IMC_NAME_LENGTH );
   strlcpy( out.type, "is-alive", IMC_TYPE_LENGTH );
   snprintf( out.to, IMC_NAME_LENGTH, "*@%s", destination );
   strlcpy( out.i.to, out.to, IMC_NAME_LENGTH );

   if ( !r )
   {
       snprintf( out.i.from, IMC_NAME_LENGTH, "%s@%s", out.from, imc_name );

       imc_addkey( &out, "versionid", IMC_VERSIONID );
       imc_addkey( &out, "networkname", imc_siteinfo.netname );
       imc_addkey( &out, "url", imc_siteinfo.web );

       out.i.sequence = imc_sequencenumber++;

       if ( !imc_sequencenumber )
           imc_sequencenumber++;

       out.i.path[0] = 0;
   }
   else
   {
       unsigned int used_sequence[IMC_MEMORY];
       unsigned int counter = 0, x = 0, new_sequence = r->top_sequence;

       snprintf( out.i.from, IMC_NAME_LENGTH, "%s@%s", out.from, r->name );

       if ( r->version && r->version[0] != '\0' && !STR_CEQL( r->version, "unknown" ) )
           imc_addkey( &out, "versionid", r->version );

       if ( r->netname && r->netname[0] != '\0' && !STR_CEQL( r->netname, "unknown" ) )
           imc_addkey( &out, "networkname", r->netname );

       if ( r->web && r->web[0] != '\0' && !STR_CEQL( r->web, "unknown" ) )
           imc_addkey( &out, "url", r->web );

       for( counter = 0; counter < IMC_MEMORY; counter++ )
           if ( imc_memory[counter].from && STR_CEQL( r->name, imc_memory[counter].from ) )
               used_sequence[x++] = imc_memory[counter].sequence;

       counter = 0;

       while ( counter < x )
       {
           new_sequence--;

           for ( counter = 0; counter < x; counter++ )
               if ( new_sequence == used_sequence[counter] )
                       break;
       }

       out.i.sequence = new_sequence;

       strlcpy( out.i.path, r->path, IMC_PATH_LENGTH );
   }


   forward( &out );

   imc_freedata( &out );
}

/* send a pingreply with the originating path */
void imc_send_pingreply( const char *to, const char *path )
{
   PACKET out;

   imc_initdata( &out );
   strlcpy( out.type, "ping-reply", IMC_TYPE_LENGTH );
   strlcpy( out.from, "*", IMC_NAME_LENGTH );
   snprintf( out.to, IMC_NAME_LENGTH, "*@%s", to );
   imc_addkey( &out, "path", path );

   imc_send( &out );
   imc_freedata( &out );
}

