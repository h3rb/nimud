/*
 * IMC2 MUD-Net versions 4.20 through 4.24b developed by Alsherok.
 * Copyright (c)2002-2003 Roger Libiez ( Samson )
 * Contributions to the 4.22b client Copyright (c)2003 by Xorith
 * Registered with the United States Copyright Office
 * TX 5-555-584
 * Version number for 4.2x series artificially raised to indicate the true nature of upgrades
 * made to the 3.10 client. If the Continuum developers won't correct their version number to
 * reflect THEIR true nature, then we need to raise ours to compensate for their error.
 *
 * IMC2 MUD-Net versions 3.00 and 3.10 developed by Asherok and Crimson Oracles.
 * Copyright (c)2002-2003 Roger Libiez ( Samson )
 * Additional code Copyright (c)2002 by Orion Elder.
 * Registered with the United States Copyright Office
 * TX 5-555-584
 *
 * IMC2 Gold versions 1.00 though 2.00 are developed by MudWorld.
 * Copyright (C) 1999 - 2002 Haslage Net Electronics (Anthony R. Haslage)
 *
 * IMC2 version 0.10 - an inter-mud communications protocol
 * Copyright (C) 1996 & 1997 Oliver Jowett <oliver@randomly.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING); if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/file.h>
#include <fnmatch.h>
#if defined(__OpenBSD__) || defined(__FreeBSD__)
#include <sys/types.h>
#endif

#include "nimud.h"

#define IMCKEY( literal, field, value )					\
				if ( !strcasecmp( word, literal ) )	\
				{					\
				      field = value;			\
				      fMatch = TRUE;			\
				      break;				\
				}

static char *wr_to;
static char wr_buf[IMC_DATA_LENGTH];
static int wr_sequence;

imc_statistics imc_stats;

int imc_active; /* Connection state */
time_t imc_now;          /* current time */
time_t imc_boot;          /* current time */
int imc_minlevel; /* Minumum level IMC will see players at, defaults to 10 */
int imc_immlevel; /* Immortal level - defaults to 103 */
int imc_adminlevel; /* Administrative level, defaults to 110 */
int imc_implevel;  /* Implementor level - defaults to 115 */
imc_siteinfo_struct imc_siteinfo;
static int memory_head; /* next entry in memory table to use, wrapping */
int imcwait; /* Reconnect timer */
int imcconnect_attempts; /* How many times have we tried to reconnect? */
unsigned long imc_sequencenumber;	  /* sequence# for outgoing packets */
bool imcpacketdebug = FALSE;

char *imc_name;			      /* our imc name */
static char lastping[IMC_MNAME_LENGTH];
static char pinger[100];
char *IMC_VERSIONID;

HUBINFO *this_imcmud;
IMC_CHANNEL *first_imc_channel;
IMC_CHANNEL *last_imc_channel;
REMOTEINFO *first_rinfo;
REMOTEINFO *last_rinfo;
IMC_IGN *first_imc_ignore;
IMC_IGN *last_imc_ignore;

/* sequence memory */
_imc_memory imc_memory[IMC_MEMORY];

char *imc_act_string( const char *format, PLAYER_DATA *ch, char *vname );
int (*imc_recv_chain)( PACKET *p, int bcast );
int (*imc_recv_hook)( PACKET *p, int bcast );
void imclog( const char *format, ... ) __attribute__ ( ( format( printf, 1, 2 ) ) );
void imcbug( const char *format, ... ) __attribute__ ( ( format( printf, 1, 2 ) ) );
void imc_printf( PLAYER_DATA *ch, const char *fmt, ... ) __attribute__ ( ( format( printf, 2, 3 ) ) );
void imcpager_printf( PLAYER_DATA *ch, const char *fmt, ... ) __attribute__ ( ( format( printf, 2, 3 ) ) );

/*
 * Copy src to string dst of size siz.  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz == 0).
 * Returns strlen(src); if retval >= siz, truncation occurred.
 *
 * Renamed so it can play itself system independent.
 * Samson 10-12-03
 */
size_t imcstrlcpy( char *dst, const char *src, size_t siz )
{
   register char *d = dst;
   register const char *s = src;
   register size_t n = siz;

   /* Copy as many bytes as will fit */
   if( n != 0 && --n != 0 )
   {
	do
      {
	   if( ( *d++ = *s++ ) == 0 )
		break;
	}
      while( --n != 0 );
   }

   /* Not enough room in dst, add NUL and traverse rest of src */
   if( n == 0 )
   {
	if( siz != 0 )
	   *d = '\0'; /* NUL-terminate dst */
	while( *s++ )
	   ;
   }
   return( s - src - 1 ); /* count does not include NUL */
}

/*
 * Appends src to string dst of size siz (unlike strncat, siz is the
 * full size of dst, not space left).  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz <= strlen(dst)).
 * Returns strlen(initial dst) + strlen(src); if retval >= siz,
 * truncation occurred.
 *
 * Renamed so it can play itself system independent.
 * Samson 10-12-03
 */
size_t imcstrlcat( char *dst, const char *src, size_t siz )
{
   register char *d = dst;
   register const char *s = src;
   register size_t n = siz;
   size_t dlen;

   /* Find the end of dst and adjust bytes left but don't go past end */
   while( n-- != 0 && *d != '\0' )
	d++;
   dlen = d - dst;
   n = siz - dlen;

   if( n == 0 )
	return( dlen + strlen(s) );
   while( *s != '\0' )
   {
	if( n != 1 )
      {
	   *d++ = *s;
	   n--;
	}
	s++;
   }
   *d = '\0';
   return( dlen + ( s - src ) ); /* count does not include NUL */
}

char *const imcperm_names[] =
{
   "Notset", "None", "Mort", "Imm", "Admin", "Imp"
};

int get_imcpermvalue( char *flag )
{
   unsigned int x;

   for ( x = 0; x < (sizeof(imcperm_names) / sizeof(imcperm_names[0])); x++ )
      if ( !strcasecmp(flag, imcperm_names[x]) )
         return x;
   return -1;
}

bool imcstr_prefix( const char *astr, const char *bstr )
{
    if ( !astr )
    {
	imcbug( "Strn_cmp: null astr." );
	return TRUE;
    }

    if ( !bstr )
    {
	imcbug( "Strn_cmp: null bstr." );
	return TRUE;
    }

    for ( ; *astr; astr++, bstr++ )
    {
	if ( LOWER(*astr) != LOWER(*bstr) )
	    return TRUE;
    }

    return FALSE;
}

/*
 * Returns an initial-capped string.
 */
char *imccapitalize( const char *str )
{
   static char strcap[LGST];
   int i;

   for( i = 0; str[i] != '\0'; i++ )
	strcap[i] = tolower( str[i] );
   strcap[i] = '\0';
   strcap[0] = toupper( strcap[0] );
   return strcap;
}

/*
 *  Error logging
 */
/* Generic log function which will route the log messages to the appropriate system logging function */
void imclog( const char *format, ... )
{
   char buf[LGST];
   va_list ap;

   va_start( ap, format );
   vsnprintf( buf, LGST, format, ap );
   va_end( ap );

#ifndef IMCCIRCLE
   log_string( buf );
#else
   basic_mud_log( buf );
#endif
   return;
}

/* Generic bug logging function which will route the message to the appropriate function that handles bug logs */
void imcbug( const char *format, ... )
{
   char buf[LGST];
   va_list ap;

   va_start( ap, format );
   vsnprintf( buf, LGST, format, ap );
   va_end( ap );

#if defined(IMCSMAUG)
   bug( "%s", buf );
#elif defined(IMCCIRCLE)
   basic_mud_log( buf );
#else
   bug( buf, 0 );
#endif
   return;
}

/* Generic substitute for write_to_buffer since not all codebases seem to have it */
void imcto_buffer( CONNECTION_DATA *d, const char *txt )
{
   write_to_buffer( d, txt, 0 );
   return;
}

/* You need to change the &, } and { tokens in the table below
 * to match what your mud uses to identify a color token with.
 *
 * & is the foreground text token.
 * } is the blink text token.
 * { is the background text token.
 */
#define IMCMAX_ANSI 56
/* Color codes added for backward compatibility do not conform to the existing standard.
 * Care should be taken to avoid using them if at all possible. This generally only refers
 * to the use of the older, incorrect, IMC2 color tags which are listed in the 3rd column.
 * Consider this a sort of M$IE band-aid fix for older non-compliant clients.
 */
const char *imcansi_conversion[IMCMAX_ANSI][3] =
{
   /* Color code symbols used in IMC must be carefully screened.
    * First three characters in second column are used for mud color parsing tests.
    * ~ is the color token used in the IMC mud standard.
    * All {, }, and & must be replaced with your mud's color tokens to convert the table
    * to your mud effectively. 'Doubling up' in this table is to escape color codes. If your
    * mud does not do this, then make these single characters. Most muds do escape.
    */

    { "&&", "&", "&"  },
    { "{{", "{", "{"  },
    { "}}", "}", "}"  },    
    {  "~", "~","~~"  }, 
    { "&-", "~", "~~" },

	/* Foreground Standard Colors */
	{ "&x", "\033[0;0;30m", "~x" }, // Black
	{ "&r", "\033[0;0;31m", "~r" }, // Dark Red
	{ "&g", "\033[0;0;32m", "~g" }, // Dark Green
	{ "&O", "\033[0;0;33m", "~y" }, // Orange/Brown
	{ "&b", "\033[0;0;34m", "~b" }, // Dark Blue
	{ "&p", "\033[0;0;35m", "~p" }, // Purple/Magenta
      { "&p", "\033[0;0;35m", "~m" }, // Duplicate for purple - Don't use this in your code. Retained for backward compatibility.
	{ "&c", "\033[0;0;36m", "~c" }, // Cyan
	{ "&w", "\033[0;0;37m", "~w" }, // Grey
      { "&w", "\033[0;0;37m", "~d" }, // Duplicate for grey - Don't use this in your code. Retained for backward compatibility.

	/* Foreground extended colors */
	{ "&z", "\033[0;1;30m", "~z" }, // Dark Grey
      { "&z", "\033[0;1;30m", "~D" }, // Duplicate of Dark Grey - - Don't use this in your code. Retained for backward compatibility.
	{ "&R", "\033[0;1;31m", "~R" }, // Red
	{ "&G", "\033[0;1;32m", "~G" }, // Green
	{ "&Y", "\033[0;1;33m", "~Y" }, // Yellow
	{ "&B", "\033[0;1;34m", "~B" }, // Blue
	{ "&P", "\033[0;1;35m", "~P" }, // Pink
      { "&P", "\033[0;1;35m", "~M" }, // Duplicate for Pink - Don't use this in your code. Retained for backward compatibility.
	{ "&C", "\033[0;1;36m", "~C" }, // Light Blue
	{ "&W", "\033[0;1;37m", "~W" }, // White

	/* Background colors */
	{ "{x", "\033[40m", "^x" }, // Black
	{ "{r", "\033[41m", "^r" }, // Red
	{ "{g", "\033[42m", "^g" }, // Green
	{ "{O", "\033[43m", "^O" }, // Orange
	{ "{B", "\033[44m", "^B" }, // Blue
	{ "{p", "\033[45m", "^p" }, // Purple/Magenta
	{ "{c", "\033[46m", "^c" }, // Cyan
	{ "{w", "\033[47m", "^w" }, // White

	/* Text Affects */
	{ "&d", "\033[0m", "~!" }, // Reset Text
	{ "&D", "\033[0m", "~!" }, // Reset Text - Support for Samson's custom ANSI snippet
	{ "&L", "\033[1m", "~L" }, // Bolden Text(Brightens it)
	{ "&u", "\033[4m", "~u" }, // Underline Text
	{ "&$", "\033[5m", "~$" }, // Blink Text
	{ "&i", "\033[6m", "~i" }, // Italic Text
	{ "&v", "\033[7m", "~v" }, // Reverse Background and Foreground Colors

	/* Blinking foreground standard color */
	{ "}x", "\033[0;5;30m", "`x" }, // Black
	{ "}r", "\033[0;5;31m", "`r" }, // Dark Red
	{ "}g", "\033[0;5;32m", "`g" }, // Dark Green
	{ "}O", "\033[0;5;33m", "`O" }, // Orange/Brown
	{ "}b", "\033[0;5;34m", "`b" }, // Dark Blue
	{ "}p", "\033[0;5;35m", "`p" }, // Magenta/Purple
	{ "}c", "\033[0;5;36m", "`c" }, // Cyan
	{ "}w", "\033[0;5;37m", "`w" }, // Grey
	{ "}z", "\033[1;5;30m", "`z" }, // Dark Grey
	{ "}R", "\033[1;5;31m", "`R" }, // Red
	{ "}G", "\033[1;5;32m", "`G" }, // Green
	{ "}Y", "\033[1;5;33m", "`Y" }, // Yellow
	{ "}B", "\033[1;5;34m", "`B" }, // Blue
	{ "}P", "\033[1;5;35m", "`P" }, // Pink
	{ "}C", "\033[1;5;36m", "`C" }, // Light Blue
	{ "}W", "\033[1;5;37m", "`W" }  // White
};

/*
 * Simple check to test if a particular code is a valid color. If not, then we can find
 * other things to do, in some cases. -Orion
 */
int imc_validcolor( char code[3], bool i2m )
{
   int c = 0, colmatch = -1;

   if( i2m )
   {
      if( code[0] && code[1] && ( code[0] == '~' || code[0] == '`' || code[0] == '^' ) )
      {
	   for( c = 0; c < IMCMAX_ANSI; c++ )
	   {
	      if( imcansi_conversion[c][2][0] == code[0] && imcansi_conversion[c][2][1] == code[1] )
	      {
		   colmatch = c;
		   break;
	      }
	   }
      }
   }
   else
   {
      if( code[0] && code[1] && ( code[0] == '&' || code[0] == '{' || code[0] == '}' ) )
      {
	   for( c = 0; c < IMCMAX_ANSI; c++ )
	   {
	      if( imcansi_conversion[c][0][0] == code[0] && imcansi_conversion[c][0][1] == code[1] )
	      {
		   colmatch = c;
		   break;
	      }
	   }
      }
   }
   return colmatch;
}

// Translates mud color codes into pure ANSI codes
char *tagtoansi( const char *txt, PLAYER_DATA *ch )
{
   int c, x, count = 0;
   static char tbuf[LGST];
   char code[3];

   if( !txt || *txt == '\0' )
	return "";

   tbuf[0] = '\0';

   for( count = 0; count < LGST; count++ )
   {	
	if( *txt == '\0' )
	   break;

      for( c = 0; c < 3; c++ )
      {
         if( *txt == imcansi_conversion[c][0][0] )
            break;
      }

      if( c == 3 )
      {
         tbuf[count] = *txt;
         txt++;
         continue;
      }

      code[0] = *txt;
	txt++;
		
	if( *txt == code[0] )
	{
	   tbuf[count] = *txt;
	   txt++;
	   continue;
	}

	code[1] = *txt;
      code[2] = '\0';

      if( IMCIS_SET( IMCFLAG(ch), IMC_COLOR ) )
      { 	
         for( c = 0; c < IMCMAX_ANSI; c++ )
         {
            if( imcansi_conversion[c][0][0] == code[0] && imcansi_conversion[c][0][1] == code[1] )
            {
               for( x = 0; imcansi_conversion[c][1][x] != '\0'; x++ )
               {
                  tbuf[count] = imcansi_conversion[c][1][x];
                  count++;
               }
               break;
            }
         }
      }
      count--;
	txt++;
   }

   tbuf[count] = '\0';
   return tbuf;
}

/* convert from imc color -> mud color */
char *color_itom( const char *txt )
{
   int c, x, count = 0;
   static char tbuf[IMC_DATA_LENGTH];
   char code[3];

   if( !txt || *txt == '\0' )
	return "";

   tbuf[0] = '\0';

   for( count = 0; count < IMC_DATA_LENGTH; count++, txt++ )
   {	
	if( *txt == '\0' )
	   break;

	if( *txt != '~' && *txt != '`' && *txt != '^' )
	{
	   tbuf[count] = *txt;
	}
	else
	{
	   code[0] = *txt;
	   code[1] = *(++txt);
	   code[2] = '\0';

	   if ( !code[1] || code[1] == '\0' )
	   {
		tbuf[count] = code[0];
		count++;
		break;
	   }
	   else if ( code[0] == code[1] )
	   {
		tbuf[count] = code[0];
	   }
	   else if( ( c = imc_validcolor( code, TRUE ) ) != -1 )
	   {
		for( x = 0; imcansi_conversion[c][0][x]; x++, count++ )
		{
		    tbuf[count] = imcansi_conversion[c][0][x];
		}
		count--;
	   }
	   else
	   {
		tbuf[count]   = code[0];
		tbuf[++count] = code[1];
	   }
	}
   }
   tbuf[count] = '\0';
   return tbuf;
}

/* convert from mud color -> imc color */
char *color_mtoi( const char *txt )
{
   int c, x, count = 0;
   static char tbuf[IMC_DATA_LENGTH];
   char code[3];

   if( !txt || *txt == '\0' )
	return "";

   tbuf[0] = '\0';

   for( count = 0; count < IMC_DATA_LENGTH; count++, txt++ )
   {	
	if( *txt == '\0' )
	   break;

	if( *txt != '&' && *txt != '{' && *txt != '}' )
	{
	   tbuf[count] = *txt;
	}
	else
	{
	   code[0] = *txt;
	   code[1] = *(++txt);
	   code[2] = '\0';

	   if ( !code[1] || code[1] == '\0' )
	   {
		tbuf[count] = code[0];
		count++;
		break;
	   }
	   else if ( code[0] == code[1] )
	   {
		tbuf[count] = code[0];
	   }
	   else if( ( c = imc_validcolor( code, FALSE ) ) != -1 )
	   {
		for( x = 0; imcansi_conversion[c][2][x]; x++, count++ )
		{
		   tbuf[count] = imcansi_conversion[c][2][x];
		}
		count--;
	   }
	   else
	   {
	      tbuf[count]   = code[0];
		tbuf[++count] = code[1];
	   }
	}
   }
   tbuf[count] = '\0';
   return tbuf;
}

/*
 * Returns a PLAYER_DATA structure which matches the string
 */
PLAYER_DATA *imc_find_user( char *name ) 
{
   CONNECTION_DATA *d;
   PLAYER_DATA *vch = NULL;

   for ( d = first_descriptor; d; d = d->next ) 
   {
	if( ( vch = d->character ? d->character : d->original ) != NULL && !strcasecmp( CH_IMCNAME(vch), name )
         && d->connected == CON_PLAYING ) 
	   return vch;
    }
    return NULL;
}

/* Modified version of Smaug's send_to_actor_color function */
void imc_to_char( const char *txt, PLAYER_DATA *ch )
{
   char buf[LGST*3];

   if( !ch )
   {
	imcbug( "%s", "imc_to_char: NULL ch!" );
	return;
   }

   if( IS_NPC( ch ) )
      return;

   if( !ch->desc )
   {
	imcbug( "imc_to_char: NULL descriptor for %s!", CH_IMCNAME(ch) );
	return;
   }

   snprintf( buf, LGST*3, "%s", tagtoansi( txt, ch ) );
   imcto_buffer( ch->desc, buf );
   imcto_buffer( ch->desc, "\033[0m" ); /* Reset color to stop bleeding */
   return;
}

/* Modified version of Smaug's ch_printf_color function */
void imc_printf( PLAYER_DATA *ch, const char *fmt, ... )
{
   char buf[LGST*2];
   va_list args;
 
   va_start( args, fmt );
   vsnprintf( buf, LGST*2, fmt, args );
   va_end( args );
 
   imc_to_char( buf, ch );
}

/* Generic send_to_pager type function to send to the proper code for each codebase */
void imc_to_pager( const char *txt, PLAYER_DATA *ch )
{
   char buf[LGST*3];

   snprintf( buf, LGST*3, "%s", tagtoansi( txt, ch ) );

#if defined(IMCSMAUG)
   send_to_pager( buf, ch );
#elif defined(IMCROM)
   page_to_char( buf, ch );
#else
   imc_to_char( buf, ch );
#endif
   return;
}

/* Generic pager_printf type function */
void imcpager_printf( PLAYER_DATA *ch, const char *fmt, ... )
{
   char buf[LGST*2];
   va_list args;
 
   va_start( args, fmt );
   vsnprintf( buf, LGST*2, fmt, args );
   va_end( args );

   imc_to_pager( buf, ch );
   return;
}

/* free all the keys in "p" */
void imc_freedata( PACKET *p )
{
   int i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      IMCSTRFREE( p->key[i] );
      IMCSTRFREE( p->value[i] );
   }
   return;
}

/* get the value of "key" from "p"; if it isn't present, return "def" */
char *imc_getkey( PACKET *p, char *key, char *def )
{
   int i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
      if( p->key[i] && !strcasecmp( p->key[i], key ) )
         return p->value[i];

   return def;
}

/* identical to imc_getkey, except get the integer value of the key */
int imc_getkeyi( PACKET *p, char *key, int def )
{
   int i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
      if( p->key[i] && !strcasecmp( p->key[i], key ) )
         return atoi( p->value[i] );

   return def;
}

/* add "key=value" to "p" */
void imc_addkey( PACKET *p, char *key, char *value )
{
   int i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( p->key[i] && !strcasecmp( key, p->key[i] ) )
      {
         IMCSTRFREE( p->key[i] );
         IMCSTRFREE( p->value[i] );
         break;
      }
   }
   if( !value )
      return;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( !p->key[i] )
      {
         p->key[i]   = IMCSTRALLOC( key );
         p->value[i] = IMCSTRALLOC( value );
         return;
      }
   }
}

/* add "key=value" for an integer value */
void imc_addkeyi( PACKET *p, char *key, int value )
{
   char temp[20];
   snprintf( temp, 20, "%d", value );
   imc_addkey( p, key, temp );
}

/* clone packet data */
void imc_clonedata( PACKET *p, PACKET *n )
{
   int i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( p->key[i] )
         n->key[i] = IMCSTRALLOC( p->key[i] );
      else
         n->key[i] = NULL;
    
      if( p->value[i] )
         n->value[i] = IMCSTRALLOC( p->value[i] );
      else
         n->value[i] = NULL;
   }
}

/* clear all keys in "p" */
void imc_initdata( PACKET *p )
{
   int i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      p->key[i]   = NULL;
      p->value[i] = NULL;
   }
}

/* checkrepeat: check for repeats in the memory table */
int checkrepeat( char *mud, unsigned long seq )
{
   int i;

   for( i = 0; i < IMC_MEMORY; i++ )
      if( imc_memory[i].from && !strcasecmp( mud, imc_memory[i].from ) && seq == imc_memory[i].sequence )
         return 1;

   /* not a repeat, so log it */
   IMCSTRFREE( imc_memory[memory_head].from );

   imc_memory[memory_head].from     = IMCSTRALLOC( mud );
   imc_memory[memory_head].sequence = seq;
  
   memory_head++;
   if( memory_head == IMC_MEMORY )
      memory_head = 0;

   return 0;
}

/* return 'mud' from 'player@mud' */
char *imc_mudof( char *fullname )
{
   static char buf[IMC_MNAME_LENGTH];
   char *where;

   where = strchr( fullname, '@' );
   if( !where )
      imcstrlcpy( buf, fullname, IMC_MNAME_LENGTH );
   else
      imcstrlcpy( buf, where+1, IMC_MNAME_LENGTH );

   return buf;
}

/* return 'player' from 'player@mud' */
char *imc_nameof( char *fullname )
{
   static char buf[IMC_PNAME_LENGTH];
   char *where = buf;
   int count = 0;

   while( *fullname && *fullname != '@' && count < IMC_PNAME_LENGTH-1 )
      *where++ = *fullname++, count++;

   *where = 0;
   return buf;
}

/* return 'player@mud' from 'player' and 'mud' */
char *imc_makename( char *player, char *mud, bool social )
{
   static char buf[IMC_NAME_LENGTH];

   imcstrlcpy( buf, player, IMC_PNAME_LENGTH );

   /* The social code gets wierd if "mud" isn't specified, so bypass it if it's not */
   if( mud && mud[0] != '\0' && !social )
   {
      imcstrlcat( buf, "@", IMC_NAME_LENGTH );
      imcstrlcpy( buf + strlen(buf), mud, IMC_MNAME_LENGTH );
   }
   return buf;
}

/*  imc_getarg: extract a single argument (with given max length) from
 *  argument to arg; if arg==NULL, just skip an arg, don't copy it out
 */
char *imc_getarg( char *argument, char *arg, int length )
{
   int len = 0;

   if( !argument || argument[0] == '\0' )
   {
      if( arg )
         arg[0] = '\0';

      return argument;
   }

   while( *argument && isspace( *argument ) )
      argument++;

   if( arg )
      while( *argument && !isspace( *argument ) && len < length-1 )
         *arg++ = *argument++, len++;
   else
      while( *argument && !isspace( *argument ) )
         argument++;

   while( *argument && !isspace( *argument ) )
      argument++;

   while( *argument && isspace( *argument ) )
      argument++;

   if( arg )
      *arg = '\0';

   return argument;
}

/* Check for a name in a list */
int imc_hasname( char *list, char *name )
{
   char *p;
   char arg[IMC_NAME_LENGTH];

   if( !list )
      return( 0 );

   p = imc_getarg( list, arg, IMC_NAME_LENGTH );
   while( arg[0] )
   {
      if( !strcasecmp( name, arg ) )
         return 1;
      p = imc_getarg( p, arg, IMC_NAME_LENGTH );
   }
   return 0;
}

/* Add a name to a list */
void imc_addname( char **list, char *name )
{
   char buf[IMC_DATA_LENGTH];

   if( imc_hasname( *list, name ) )
      return;

   if( (*list) && (*list)[0] != '\0' )
      snprintf( buf, IMC_DATA_LENGTH, "%s %s", *list, name );
   else
      imcstrlcpy( buf, name, IMC_DATA_LENGTH );

   IMCSTRFREE( *list );
   *list = IMCSTRALLOC( buf );
}

/* Remove a name from a list */
void imc_removename( char **list, char *name )
{
   char buf[1000];
   char arg[IMC_NAME_LENGTH];
   char *p;
  
   buf[0] = '\0';
   p = imc_getarg( *list, arg, IMC_NAME_LENGTH );
   while( arg[0] )
   {
      if( strcasecmp( arg, name ) )
      {
         if( buf[0] )
	      imcstrlcat( buf, " ", 1000 );
         imcstrlcat( buf, arg, 1000 );
      }
      p = imc_getarg( p, arg, IMC_NAME_LENGTH );
   }
   IMCSTRFREE( *list );
   *list = IMCSTRALLOC( buf );
}

/* escape2: escape " -> \", \ -> \\, CR -> \r, LF -> \n */
char *escape2( char *data )
{
   static char buf[IMC_DATA_LENGTH];
   char *p;

   for( p = buf; *data && ( p-buf < IMC_DATA_LENGTH-1 ); data++, p++ )
   {
      if( *data == '\n' )
      {
         *p++ = '\\';
         *p = 'n';
      }
      else if( *data == '\r' )
      {
         *p++ = '\\';
         *p = 'r';
      }
      else if( *data == '\\' )
      {
         *p++ = '\\';
         *p = '\\';
      }
      else if( *data == '"' )
      {
         *p++ = '\\';
         *p = '"';
      }
      else
         *p = *data;
   }
   *p = 0;

   return buf;
}

/* printkeys: print key-value pairs, escaping values */
char *printkeys( PACKET *data )
{
   static char buf[IMC_DATA_LENGTH];
   char temp[IMC_DATA_LENGTH];
   int len = 0;
   int i;

   buf[0] = '\0';

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( !data->key[i] )
         continue;
      imcstrlcpy( buf + len, data->key[i], IMC_DATA_LENGTH-len-1 );
      imcstrlcat( buf, "=", IMC_DATA_LENGTH );
      len = strlen( buf );

      if( !strchr( data->value[i], ' ' ) )
         imcstrlcpy( temp, escape2( data->value[i] ), IMC_DATA_LENGTH-1 );
      else
      {
         temp[0] = '"';
         imcstrlcpy( temp+1, escape2( data->value[i] ), IMC_DATA_LENGTH-3 );
         imcstrlcat( temp, "\"", IMC_DATA_LENGTH );
      }
      imcstrlcat( temp, " ", IMC_DATA_LENGTH );
      imcstrlcpy( buf + len, temp, IMC_DATA_LENGTH-len );
      len = strlen( buf );
   }
   return buf;
}

/* parsekeys: extract keys from string */
void parsekeys( const char *string, PACKET *data )
{
   const char *p1;
   char *p2;
   char k[IMC_DATA_LENGTH], v[IMC_DATA_LENGTH];
   int quote;

   p1 = string;

   while( *p1 )
   {
      while( *p1 && isspace( *p1 ) )
         p1++;

      p2 = k;
      while( *p1 && *p1 != '=' && p2-k < IMC_DATA_LENGTH-1 )
         *p2++ = *p1++;
      *p2=0;

      if( !k[0] || !*p1 ) /* no more keys? */
         break;

      p1++;			/* skip the '=' */

      if( *p1 == '"' )
      {
         p1++;
         quote = 1;
      }
      else
         quote = 0;

      p2 = v;
      while( *p1 && ( !quote || *p1 != '"' ) && ( quote || *p1 != ' ' ) && p2-v < IMC_DATA_LENGTH+1 )
      {
         if( *p1 == '\\' )
         {
	      switch( *(++p1) )
	      {
	         case '\\':
	            *p2++ = '\\';
	            break;
	         case 'n':
	            *p2++ = '\n';
	            break;
	         case 'r':
	            *p2++ = '\r';
	            break;
	         case '"':
	            *p2++ = '"';
	            break;
	         default:
	            *p2++ = *p1;
	            break;
	      }
	      if( *p1 )
	         p1++;
         }
         else
	      *p2++ = *p1++;
      }
      *p2 = 0;

      if( !v[0] )
         continue;

      imc_addkey( data, k, v );

      if( quote && *p1 )
         p1++;
   }
}

char *generate2( PACKET *p )
{
   static char temp[IMC_PACKET_LENGTH];
   char newpath[IMC_PATH_LENGTH];

   if( !p->type[0] || !p->i.from[0] || !p->i.to[0] )
   {
      imcbug( "%s", "generate2: bad packet!" );
      imcbug( "type: %s from: %s to: %s", p->type, p->i.from, p->i.to );
      imcbug( "path: %s data: %s", p->i.path, printkeys( p ) );
      return NULL;		/* catch bad packets here */
   }

   if( !p->i.path[0] )
      imcstrlcpy( newpath, imc_name, IMC_PATH_LENGTH );
   else
      snprintf( newpath, IMC_PATH_LENGTH, "%s!%s", p->i.path, imc_name );

   snprintf( temp, IMC_PACKET_LENGTH, "%s %lu %s %s %s %s", p->i.from, p->i.sequence, newpath, p->type, p->i.to, printkeys( p ) );
   return temp;
}

PACKET *interpret2( char *argument )
{
   char seq[20];
   static PACKET out;

   imc_initdata( &out );
   argument = imc_getarg( argument, out.i.from, IMC_NAME_LENGTH );
   argument = imc_getarg( argument, seq, 20 );
   argument = imc_getarg( argument, out.i.path, IMC_PATH_LENGTH );
   argument = imc_getarg( argument, out.type, IMC_TYPE_LENGTH );
   argument = imc_getarg( argument, out.i.to, IMC_NAME_LENGTH );

   if( !out.i.from[0] || !seq[0] || !out.i.path[0] || !out.type[0] || !out.i.to[0] )
   {
      imcbug( "%s", "interpret2: bad packet received, discarding" );
      return NULL;
   }

   parsekeys( argument, &out );

   out.i.sequence = strtoul( seq, NULL, 10 );
   return &out;
}

_imc_vinfo imc_vinfo[] =
{
  { 0, NULL, NULL },
  { 1, NULL, NULL },
  { 2, generate2, interpret2 }
};

/* return 1 if 'name' is a part of 'path'  (internal) */
int inpath( char *path, char *name )
{
   char buf[IMC_MNAME_LENGTH+3];
   char tempn[IMC_MNAME_LENGTH], tempp[IMC_PATH_LENGTH];

   imcstrlcpy( tempn, name, IMC_MNAME_LENGTH );
   imcstrlcpy( tempp, path, IMC_PATH_LENGTH );

   if( !strcasecmp( tempp, tempn ) )
      return 1;

   snprintf( buf, IMC_MNAME_LENGTH+3, "%s!", tempn );
   if( !strncmp( tempp, buf, strlen( buf ) ) )
      return 1;

   snprintf( buf, IMC_MNAME_LENGTH+3, "!%s", tempn );
   if( strlen(buf) < strlen(tempp) && !strcasecmp( tempp + strlen(tempp) - strlen(buf), buf ) )
      return 1;

   snprintf( buf, IMC_MNAME_LENGTH+3, "!%s!", tempn );
   if( strstr( tempp, buf ) )
      return 1;

   return 0;
}

/* find an info entry for "name" */
REMOTEINFO *imc_find_reminfo( char *name, int type )
{
   REMOTEINFO *p;

   for( p = first_rinfo; p; p = p->next )
   {
      if( !strcasecmp( name, p->name ) )
         return p;
   }
   return NULL;
}

/* return 'e' from 'a!b!c!d!e' */
char *imc_lastinpath( char *path )
{
   const char *where;
   static char buf[IMC_NAME_LENGTH];

   where = path + strlen(path)-1;
   while( *where != '!' && where >= path )
      where--;

   imcstrlcpy( buf, where+1, IMC_NAME_LENGTH );
   return buf;
}

/* return 'a' from 'a!b!c!d!e' */
char *imc_firstinpath( char *path )
{
   static char buf[IMC_NAME_LENGTH];
   char *p;

   for( p = buf; *path && *path != '!'; *p++ = *path++ )
      ;

   *p = 0;
   return buf;
}

/* create a new info entry, insert into list */
REMOTEINFO *imc_new_reminfo( char *mud )
{
   REMOTEINFO *p, *mud_prev;

   IMCCREATE( p, REMOTEINFO, 1 );

   p->name    = IMCSTRALLOC( mud );
   p->version = NULL;
   p->route   = NULL;
   p->path   = NULL;
   p->ping    = 0;
   p->top_sequence = 0;
   p->type    = IMC_REMINFO_NORMAL;

   for( mud_prev = first_rinfo; mud_prev; mud_prev = mud_prev->next )
      if( strcasecmp( mud_prev->name, mud ) >= 0 )
         break;

   if( !mud_prev )
      IMCLINK( p, first_rinfo, last_rinfo, next, prev );
   else
      IMCINSERT( p, mud_prev, first_rinfo, next, prev );

   return p;
}

/* update our routing table based on a packet received with path "path" */
void updateroutes( char *path )
{
   REMOTEINFO *p;
   char *sender, *last;
   char *temp;

   /* loop through each item in the path, and update routes to there */

   last = imc_lastinpath( path );
   temp = path;
   while( temp && temp[0] != '\0' )
   {
      sender = imc_firstinpath( temp );

      if( strcasecmp( sender, imc_name ) )
      {
         /* not from us */
         /* check if its in the list already */

         p = imc_find_reminfo( sender, 1 );
         if( !p )			/* not in list yet, create a new entry */
         {
	      p = imc_new_reminfo( sender );

	      p->ping    = 0;
	      p->route   = IMCSTRALLOC( last );
	      p->version = IMCSTRALLOC( "unknown" );
	      p->type    = IMC_REMINFO_NORMAL;
            p->network = IMCSTRALLOC( "unknown" );
         }
         else
         {				/* already in list, update the entry */
	      if( strcasecmp( last, p->route ) )
	      {
	         IMCSTRFREE( p->route );
	         p->route = IMCSTRALLOC( last );
	      }
	      p->type = IMC_REMINFO_NORMAL;
         }
      }

      /* get the next item in the path */

      temp = strchr( temp, '!' );
      if( temp )
         temp++;			/* skip to just after the next '!' */
   }
}

/* imc_actor_data representation:
 *
 *  Levels are simplified: >0 is a mortal, <0 is an immortal. The 'see' and
 *  'invis' fields are no longer used.
 *
 *  d->level is the level of the character (-1=imm, 1=mortal)
 *
 *  also checks rignores for a 'notrust' flag which makes that person a
 *  level 1 mortal for the purposes of wizi visibility checks, etc
 *
 *  Default behavior is now: trusted.
 *  If there's a notrust flag, untrusted. If there's also a trust flag, trusted
 */

/* convert from the char data in 'p' to an internal representation in 'd' */
void getdata( PACKET *p, imc_actor_data *d )
{
   imcstrlcpy( d->name, p->from, IMC_NAME_LENGTH );
   d->level = imc_getkeyi( p, "level", 0 );
}

/* check if a packet from a given source should be ignored */
bool imc_isignored( char *who )
{
   IMC_IGN *mud;

   for( mud = first_imc_ignore; mud; mud = mud->next )
   {
	if( !strcasecmp( mud->name, imc_mudof( who ) ) )
	   return TRUE;
   }
   return FALSE;
}

static struct 
{
    int number;
    const char *name;
    const char *chatstr;
    const char *emotestr;
    int perm;
    char *to;
} imc_channels[]=
{
    {
        2,
        "imcinfo",
        /* why didn't I think of this? :) */
        "~p[~GIMCinfo~p] %s announces '%s'\n\r",
        "~p[~GIMCinfo~p] %s %s\n\r",
        TRUE,
        "*",
    },

    {
        15,
        "imc",
        "~p[~GIMC~p] %s %s\n\r",
        "~p[~GIMC~p] %s %s\n\r",
        TRUE,
        "*"
    }
};

#define numchannels ( sizeof( imc_channels ) / sizeof( imc_channels[0] ) )

imc_actor_data *imc_getdata( PLAYER_DATA *ch )
{
   imc_actor_data *d;

   IMCCREATE( d, imc_actor_data, 1 );
   if( !ch ) /* fake system character */
   {
      d->level = IMCPERM_NONE;
      imcstrlcpy( d->name, "*", IMC_NAME_LENGTH );
      return d;
   }

   d->level = IMCPERM(ch);
   imcstrlcpy( d->name, CH_IMCNAME(ch), IMC_NAME_LENGTH );

   return d;
}

char *getname( PLAYER_DATA *ch, imc_actor_data *vict )
{
   static char buf[IMC_NAME_LENGTH];
   char *mud, *name;
   imc_actor_data *chdata = imc_getdata( ch );

   mud = imc_mudof( vict->name );
   name = imc_nameof( vict->name );

   if( !strcasecmp( mud, imc_name ) )
	snprintf( buf, IMC_NAME_LENGTH, "%s", imc_nameof( name ) );
   else
      imcstrlcpy( buf, vict->name, IMC_NAME_LENGTH );
   IMCDISPOSE( chdata );
   return buf;
}

void do_imcchannel( imc_actor_data *from, int number, char *argument, int emote )
{
   CONNECTION_DATA *d;
   PLAYER_DATA *victim;
   char str[LGST], arg[LGST];
   char buf[IMC_DATA_LENGTH];
   unsigned int chan;

   for( chan = 0; chan < numchannels; chan++ )
      if( imc_channels[chan].number == number )
         break;

   if( chan == numchannels )
      return;

   snprintf( str, LGST, "%s", color_itom( emote ? imc_channels[chan].emotestr : imc_channels[chan].chatstr ) );
   snprintf( arg, LGST, "%s", color_itom( argument ) );

   for( d = first_descriptor; d; d = d->next )
   {
	char cbuf[LGST];

      if( d->connected == CON_PLAYING && ( victim = d->original ? d->original : d->character ) != NULL 
	 && IMCPERM(victim) >= imc_channels[chan].perm )
      {
	   snprintf( cbuf, LGST, "%s", getname( victim, from ) );
         snprintf( buf, IMC_DATA_LENGTH, str, cbuf, arg );
         imc_to_char( buf, victim );
      }
   }
}

void imc_recv_chat( imc_actor_data *from, int channel, char *argument )
{
   do_imcchannel( from, channel, argument, 0 );
}

void imc_recv_emote( imc_actor_data *from, int channel, char *argument )
{
   do_imcchannel( from, channel, argument, 1 );
}

/* convert back from 'd' to 'p' */
void setdata( PACKET *p, imc_actor_data *d )
{
   imc_initdata( p );

   if( !d )
   {
      imcstrlcpy( p->from, "*", IMC_NAME_LENGTH );
      imc_addkeyi( p, "level", -1 );
      return;
   }

   imcstrlcpy( p->from, d->name, IMC_NAME_LENGTH );
   imc_addkeyi( p, "level", d->level );
}

/* send a tell to a remote player */
void imc_send_tell( imc_actor_data *from, char *to, char *argument, int isreply )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;

   if( !strcasecmp( imc_mudof( to ), "*" ) )
      return; /* don't let them do this */

   setdata( &out, from );

   imcstrlcpy( out.to, to, IMC_NAME_LENGTH );
   imcstrlcpy( out.type, "tell", IMC_TYPE_LENGTH );
   imc_addkey( &out, "text", argument );
   if( isreply )
      imc_addkeyi( &out, "isreply", isreply );

   imc_send( &out );
   imc_freedata( &out );
}

/* send a standard 'you are being ignored' rtell */
void imc_sendignore( char *to )
{
   char buf[IMC_DATA_LENGTH];

   if( strcasecmp( imc_nameof( to ), "*" ) )
   {
      snprintf( buf, IMC_DATA_LENGTH, "%s is blocking packets from your mud.", imc_name );
      imc_send_tell( NULL, to, buf, 1 );
   }
}

/* Beefed up to include wildcard ignores. */
bool imc_isignoring( PLAYER_DATA *ch, const char *ignore )
{
   IMC_IGNORE *temp;

   /* Wildcard support thanks to Xorith */
   for( temp = FIRST_IMCIGNORE(ch); temp; temp = temp->next )
   {
	if( !fnmatch( temp->name, ignore, 0 ) )
	   return TRUE;
   }
   return FALSE;
}

void imc_recv_tell( imc_actor_data *from, char *to, char *argument, int isreply )
{
   PLAYER_DATA *victim = NULL;
   char buf[IMC_DATA_LENGTH];

   if( !strcasecmp( to, "*" ) ) /* ignore messages to system */
      return;

   victim = imc_find_user( to );

   if( victim )
   {
	char cbuf1[LGST], cbuf2[LGST], cbuf3[LGST];

      if( IMCPERM(victim) < FALSE )
      {
         if( strcasecmp( imc_nameof( from->name ), "*" ) )
         {
	      snprintf( buf, IMC_DATA_LENGTH, "%s is not yet able to use IMC2.", to );
	      imc_send_tell( NULL, from->name, buf, 1 );
         }
         return;
      }

      if( strcasecmp( imc_nameof( from->name ), "ICE" ) )
      {
         if( IMCISINVIS(victim) )
         {
            if( strcasecmp( imc_nameof( from->name ), "*" ) )
            {
	         snprintf( buf, IMC_DATA_LENGTH, "%s is not receiving tells.", to );
	         imc_send_tell( NULL, from->name, buf, 1 );
            }
            return;
         }

         if( imc_isignoring( victim, from->name ) )
         {
            if( strcasecmp( imc_nameof( from->name ), "*" ) )
            {
	         snprintf( buf, IMC_DATA_LENGTH, "%s is not receiving tells.", to );
	         imc_send_tell( NULL, from->name, buf, 1 );
            }
            return;
         }

         if( IMCIS_SET( IMCFLAG(victim), IMC_TELL ) || IMCIS_SET( IMCFLAG(victim), IMC_DENYTELL ) )
         {
            if( strcasecmp( imc_nameof( from->name ), "*" ) )
            {
	         snprintf( buf, IMC_DATA_LENGTH, "%s is not receiving tells.", to );
	         imc_send_tell( NULL, from->name, buf, 1 );
            }
            return;
         }

         if( IMCAFK(victim) )
         {
            if( strcasecmp( imc_nameof( from->name ), "*" ) )
            {
	         snprintf( buf, IMC_DATA_LENGTH, "%s is currently AFK. Try back later.", to );
	         imc_send_tell( NULL, from->name, buf, 1 );
            }
            return;
         }

         if( strcasecmp( imc_nameof( from->name ), "*" ) )     /* not a system message */
         {
	      IMCSTRFREE( IMC_RREPLY(victim) );
	      IMCSTRFREE( IMC_RREPLY_NAME(victim) );
            IMC_RREPLY(victim) = IMCSTRALLOC( from->name );
            IMC_RREPLY_NAME(victim) = IMCSTRALLOC( getname( victim, from ) );
         }
      }
	snprintf( cbuf1, LGST, "%s", color_itom( "~C%s ~cimctells you ~c'~W%s~c'~!\n\r" ) );
	snprintf( cbuf2, LGST, "%s", color_itom( argument ) );
	snprintf( cbuf3, LGST, "%s", getname( victim, from ) );
      snprintf( buf, IMC_DATA_LENGTH, cbuf1, cbuf3, cbuf2 );
      imc_to_char( buf, victim );
   }
   else
   {
      snprintf( buf, IMC_DATA_LENGTH, "No player named %s exists here.", to );
      imc_send_tell( NULL, from->name, buf, 1 );
   }
}

void imc_recv_whoreply( char *to, char *text, int sequence, int inlen )
{
   PLAYER_DATA *victim;

   if( ( victim = imc_find_user( to ) ) == NULL )
      return;

   imc_to_pager( color_itom(text), victim );
   return;
}

char *channel_mudof( char *fullname )
{
   static char buf[IMC_PNAME_LENGTH];
   char *where = buf;
   int count=0;

   while( *fullname && *fullname != ':' && count < IMC_PNAME_LENGTH-1 )
      *where++ = *fullname++, count++;

   *where = 0;
   return buf;
}

void update_imchistory( IMC_CHANNEL *channel, char *message )
{
   char msg[LGST], buf[LGST];
   struct tm *local;
   time_t t;
   int x;

   if( !channel )
   {
	imcbug( "%s", "update_imchistory: NULL channel received!" );
	return;
   }

   if( !message || message[0] == '\0' )
   {
	imcbug( "%s", "update_imchistory: NULL message received!" );
	return;
   }

   imcstrlcpy( msg, message, LGST );
   for( x = 0; x < MAX_IMCHISTORY; x++ )
   {
      if( channel->history[x] == NULL )
      {
         t = time( NULL );
         local = localtime( &t );
         snprintf( buf, LGST, "&R[%-2.2d/%-2.2d %-2.2d:%-2.2d] &G%s\n\r",
		local->tm_mon+1, local->tm_mday, local->tm_hour, local->tm_min, msg );
         channel->history[x] = IMCSTRALLOC( buf );
         break;
      }

      if( x == MAX_IMCHISTORY - 1 )
      {
         int y;

         for( y = 1; y < MAX_IMCHISTORY; y++ )
         {
            int z = y-1;

            if( channel->history[z] != NULL )
            {
               IMCSTRFREE( channel->history[z] );
               channel->history[z] = IMCSTRALLOC( channel->history[y] );
            }
         }

         t = time( NULL );
         local = localtime( &t );
         snprintf( buf, LGST, "&R[%-2.2d/%-2.2d %-2.2d:%-2.2d] &G%s\n\r",
		local->tm_mon+1, local->tm_mday, local->tm_hour, local->tm_min, msg );
	   IMCSTRFREE( channel->history[x] );
         channel->history[x] = IMCSTRALLOC( buf );
      }
   }
   return;
}

void imc_showchannel( IMC_CHANNEL *c, char *from, char *txt, int emote )
{
   CONNECTION_DATA *d;
   PLAYER_DATA *ch;
   char buf[LGST];

   if( !c->local_name || c->local_name[0] == '\0' || !c->refreshed )
      return;
  
   if( emote < 2 )
      snprintf( buf, LGST, emote ? c->emoteformat : c->regformat, from, color_itom( txt ) );
   else
      snprintf( buf, LGST, c->socformat, color_itom( txt ) );
 
   for( d = first_descriptor; d; d = d->next )
   {
	if( !d->character )
	   continue;

      ch = d->character;

      if( IMCPERM(ch) < c->level || !imc_hasname( IMC_LISTEN(ch), c->local_name ) )
         continue;

      imc_printf( ch, "%s\n\r", buf );
  }
  update_imchistory( c, buf );
}

void imc_sendmessage( IMC_CHANNEL *c, char *name, char *text, int emote )
{
   PACKET out;

   imcstrlcpy( out.from, name, IMC_NAME_LENGTH );
   imc_initdata( &out );

   imc_addkey( &out, "channel", c->name );
   imc_addkey( &out, "text", text );
   imc_addkeyi( &out, "emote", emote );
   imc_addkeyi( &out, "echo", 1 );

   /* send a message out on a channel */
   if( !c->open )
   {
      imcstrlcpy( out.type, "ice-msg-p", IMC_TYPE_LENGTH );
      snprintf( out.to, IMC_NAME_LENGTH, "IMC@%s", channel_mudof( c->name ) );
   }
   else
   {
      /* broadcast */
      imcstrlcpy( out.type, "ice-msg-b", IMC_TYPE_LENGTH );
      imcstrlcpy( out.to, "*@*", IMC_NAME_LENGTH );
   }
   imc_send( &out );
   imc_freedata( &out );
}

/* respond to a who request with the given data */
void imc_send_whoreply( char *to, char *data, int sequence )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;

   if( !strcasecmp( imc_mudof( to ), "*" ) )
      return; /* don't let them do this */

   imc_initdata( &out );

   imcstrlcpy( out.to, to, IMC_NAME_LENGTH );

   imcstrlcpy( out.type, "who-reply", IMC_TYPE_LENGTH );
   imcstrlcpy( out.from, "*", IMC_NAME_LENGTH );

   if( sequence != -1 )
      imc_addkeyi( &out, "sequence", sequence );

   imc_addkey( &out, "text", data );

   imc_send( &out );
   imc_freedata( &out );
}

void imc_whoreply_start( char *to )
{
   wr_sequence = 0;
   wr_to = IMCSTRALLOC( to );
   wr_buf[0] = '\0';
}

void imc_whoreply_add( char *text )
{
   /* give a bit of a margin for error here */
   if( strlen( wr_to ) + strlen( text ) >= IMC_DATA_LENGTH-500 )
   {
      imc_send_whoreply( wr_to, wr_buf, wr_sequence );
      wr_sequence++;
      imcstrlcpy( wr_buf, text, IMC_DATA_LENGTH );
      return;
   }
   imcstrlcat( wr_buf, text, IMC_DATA_LENGTH );
}

void imc_whoreply_end( void )
{
   imc_send_whoreply( wr_to, wr_buf, -( wr_sequence + 1 ) );
   IMCSTRFREE( wr_to );
   wr_buf[0] = '\0';
}

// Retrieves a string length minus the color codes.
int imc_strlen_color( const char *str )
{
   unsigned int c, i, length;

   if( !str || str[0] == '\0' )
      return 0;

   for( length = i = 0 ; i < strlen ( str ) ; i++ )
   {
      for( c = 0; c < 4; c++ )
      {
         if( str[i] == imcansi_conversion[c][1][0] )
            break;
      }

      if( c == 4 )
         ++length;
      else
      {
         for( c = 0; c < 4; c++ )
         {
            if( str[i] == imcansi_conversion[c][0][0] && str[i+1] == imcansi_conversion[c][0][1] )
               break;
         }

         if( c !=4 )
            length++;
         else
            --length;
      }
   }
   return length;
}

char *SetFill( char *string )
{
    int amount;    /* How much we want to put in first */
    int x;
    static char outbuf[400]; /* Stores final string */

    imcstrlcpy( outbuf, "", 400 );

    amount = 78-imc_strlen_color( string ); /* Determine amount to put in front of line */
    if( amount < 1 )
        amount = 1;

    amount = amount/2;

    for( x = 0 ; x < amount ; x++ )
        imcstrlcat( outbuf, " ", 400 );

    imcstrlcat( outbuf, string, 400 );
    imcstrlcat( outbuf, "\n\r", 400 );

    return outbuf;
}

char *imcrankbuffer( PLAYER_DATA *ch )
{
   static char rbuf[SMST];

   if( IMCPERM(ch) >= TRUE )
   {
      imcstrlcpy( rbuf, "&YStaff", SMST );

      if( CH_IMCRANK(ch) && CH_IMCRANK(ch)[0] != '\0' )
         snprintf( rbuf, SMST, "&Y%s", CH_IMCRANK(ch) );
   }
   else
   {
      imcstrlcpy( rbuf, "&BPlayer", SMST );

   	if( CH_IMCRANK(ch) && CH_IMCRANK(ch)[0] != '\0' )
	   snprintf( rbuf, SMST, "&B%s", CH_IMCRANK(ch) );
   }
   return rbuf;
}

int imcconst_color_str_len( const char *argument )
{
    int  str, count = 0;
    bool IS_COLOR = FALSE;

    for ( str = 0; argument[str] != '\0'; str++ )
    {
        if ( argument[str] == '&' )
        {
            if ( IS_COLOR == TRUE )
            {
                count++;
                IS_COLOR = FALSE;
            }
            else
                IS_COLOR = TRUE;
        }
        else if ( argument[str] == '^' )
        {
            if ( IS_COLOR == TRUE )
            {
                count++;
                IS_COLOR = FALSE;
            }
            else
                IS_COLOR = TRUE;
        }
        else
        {
            if ( IS_COLOR == FALSE ) count++;
            else IS_COLOR = FALSE;
        }
    }

    return count;
}

int imcconst_color_strnlen( const char *argument, int maxlength )
{
    int str, count = 0;
    bool IS_COLOR = FALSE;

    for ( str = 0; argument[str] != '\0'; str++ )
    {
        if ( argument[str] == '&' )
        {
            if ( IS_COLOR == TRUE )
            {
                count++;
                IS_COLOR = FALSE;
            }
            else
                IS_COLOR = TRUE;
        }
        else if ( argument[str] == '^' )
        {
            if ( IS_COLOR == TRUE )
            {
                count++;
                IS_COLOR = FALSE;
            }
            else
                IS_COLOR = TRUE;
        }
        else
        {
            if ( IS_COLOR == FALSE ) count++;
            else IS_COLOR = FALSE;
        }

	if ( count >= maxlength ) break;
    }
    if ( count < maxlength ) return ((str - count) + maxlength);

    str++;
    return str;
}

const char *imcconst_color_align( const char *argument, int size, int align )
{
    int space = ( size - imcconst_color_str_len( argument ) );
    static char buf[LGST];

    if ( align == ALIGN_RIGHT || imcconst_color_str_len( argument ) >= size )
        snprintf( buf, LGST, "%*.*s", imcconst_color_strnlen( argument, size ),
            imcconst_color_strnlen( argument, size ), argument );
    else if ( align == ALIGN_CENTER )
        snprintf( buf, LGST, "%*s%s%*s", ( space/2 ),"",argument,
            ((space/2)*2)==space ? (space/2) : ((space/2)+1),"" );
    else
        snprintf( buf, LGST, "%s%*s", argument, space, "" );

    return buf;
}

/* expanded for minimal mud-specific code. I really don't want to replicate
 * stock in-game who displays here, since it's one of the most commonly
 * changed pieces of code. shrug.
 */
void process_rwho( imc_actor_data *from, char *argument )
{
   CONNECTION_DATA *d;
   PLAYER_DATA *person;
   char buf[LGST], output[LGST], personbuf[LGST], tailbuf[LGST], rank[LGST], rankout[LGST];
   char stats[SMST];
   int pcount = 0, xx, yy;

   imc_whoreply_start( from->name );
   imc_whoreply_add( "\n\r" );

   snprintf( buf, LGST, "~R-=[ ~WPlayers on %s ~R]=-", imc_siteinfo.name );
   imc_whoreply_add( SetFill( buf ) );
    
   if( imc_siteinfo.port > 0 )
      snprintf( buf, LGST, "~Y-=[ ~Wtelnet://%s:%d ~Y]=-\n\r", imc_siteinfo.host, imc_siteinfo.port );
   else
      snprintf( buf, LGST, "~Y-=[ telnet://%s ]=-\n\r", imc_siteinfo.host );

   imc_whoreply_add( SetFill( buf ) );

   xx = 0;
   for( d = first_descriptor; d; d = d->next )
   {
	if( d->character && d->connected == CON_PLAYING )
	{
	   if( IMCPERM(d->character) <= IMCPERM_NONE || IMCPERM(d->character) >= TRUE )
	      continue;

	   if( IMCISINVIS(d->character) )
	      continue;

         xx++;
	}
   }

   if( xx > 0 )
   {
	imcstrlcpy( output, "&B--------------------------------=[ &WPlayers &B]=---------------------------------\n\r\n\r", LGST );
	imc_whoreply_add( color_mtoi( output ) );

      for( d = first_descriptor; d; d = d->next ) 
      {
	   if( d->character && d->connected == CON_PLAYING ) 
	   {
            person = d->character;

	      if( IMCPERM(person) <= IMCPERM_NONE || IMCPERM(person) >= TRUE )
		   continue;

	      if( IMCISINVIS( person ) )
	         continue;

            pcount++;

	      snprintf( rank, LGST, "%s", imcrankbuffer( person ) );
		snprintf( rankout, LGST, "%s", imcconst_color_align( rank, 20, ALIGN_CENTER ) );

            imcstrlcpy( stats, "&z[", SMST );
            if( IMCAFK( person ) )
               imcstrlcat( stats, "AFK", SMST );
            else
               imcstrlcat( stats, "---", SMST );
            imcstrlcat( stats, "]&G", SMST );
	      snprintf( personbuf, LGST, "%s %s %s%s\n\r", rankout, stats, CH_IMCNAME(person), CH_IMCTITLE(person) );
	      imc_whoreply_add( color_mtoi( personbuf ) );
	   }
      }
   }

   yy = 0;
   for( d = first_descriptor; d; d = d->next )
   {
	if( d->character && d->connected == CON_PLAYING )
	{
	   if( IMCPERM(d->character) <= IMCPERM_NONE || IMCPERM(d->character) < TRUE )
	      continue;

	   if( IMCISINVIS( d->character ) )
	      continue;

         yy++;
	}
   }

   if( yy > 0 )
   {
	imcstrlcpy( output, "\n\r&R-------------------------------=[ &WImmortals &R]=--------------------------------\n\r\n\r", LGST );
	imc_whoreply_add( color_mtoi( output ) );

      for( d = first_descriptor; d; d = d->next ) 
      {
	   if( d->character && d->connected == CON_PLAYING ) 
	   {
            person = d->character;

	      if( IMCPERM(person) <= IMCPERM_NONE || IMCPERM(person) < TRUE )
		   continue;

	      if( IMCISINVIS( person ) )
		   continue;

            pcount++;

	      snprintf( rank, LGST, "%s", imcrankbuffer( person ) );
		snprintf( rankout, LGST, "%s", imcconst_color_align( rank, 20, ALIGN_CENTER ) );

            imcstrlcpy( stats, "&z[", SMST );
            if( IMCAFK( person ) )
               imcstrlcat( stats, "AFK", SMST );
            else
               imcstrlcat( stats, "---", SMST );
            imcstrlcat( stats, "]&G", SMST );

	      snprintf( personbuf, LGST, "%s %s %s%s\n\r", rankout, stats, CH_IMCNAME(person), CH_IMCTITLE(person) );
	      imc_whoreply_add( color_mtoi( personbuf ) );
	   }
      }
   }

   snprintf( tailbuf, LGST, "\n\r&Y[&W%d Player%s&Y] ", pcount, pcount == 1 ? "" : "s" );
   imc_whoreply_add( color_mtoi( tailbuf ) );

   snprintf( tailbuf, LGST, "&Y[&WHomepage: %s&Y] [&W%3d Max Since Reboot&Y]\n\r", imc_siteinfo.www, IMCMAXPLAYERS );
   imc_whoreply_add( color_mtoi( tailbuf ) );

   imc_whoreply_end();
}

/* edit this if you want to support rfinger */
void process_rfinger( imc_actor_data *from, char *argument )
{
   imc_send_whoreply( from->name, "Sorry, no information is available of that type (yet).\n\r", -1 );
}

/* connect to hub */
bool imc_connect_to( void )
{
   int desc;
   struct sockaddr_in sa;
   char buf[IMC_DATA_LENGTH];
   int r;

   if( imc_active == IA_NONE )
   {
      imcbug( "%s", "IMC is not active" );
      return FALSE;
   }
    
   if( !this_imcmud )
   {
      imcbug( "%s", "No connection data loaded" );
      return FALSE;
   }

   if( this_imcmud->desc > 0 )
   {
      imcbug( "%s", "Already connected" );
      return FALSE;
   }

   imclog( "Connecting to %s", this_imcmud->hubname );

   /* warning: this blocks. It would be better to farm the query out to
    * another process, but that is difficult to do without lots of changes
    * to the core mud code. You may want to change this code if you have an
    * existing resolver process running.
    */
   if( ( sa.sin_addr.s_addr = inet_addr( this_imcmud->host ) ) == -1UL )
   {
      struct hostent *hostinfo;

      if( !( hostinfo = gethostbyname( this_imcmud->host ) ) )
      {
         imcbug( "%s", "imc_connect: couldn't resolve hostname" );
         return FALSE;
      }
      sa.sin_addr.s_addr = *(unsigned long *) hostinfo->h_addr;
   }

   sa.sin_port = htons( this_imcmud->port );
   sa.sin_family = AF_INET;

   desc = socket( AF_INET, SOCK_STREAM, 0 );
   if( desc < 0 )
   {
      perror( "socket" );
      return FALSE;
   }

   r = fcntl( desc, F_GETFL, 0 );
   if( r < 0 || fcntl( desc, F_SETFL, O_NONBLOCK | r ) < 0 )
   {
      perror( "imc_connect: fcntl" );
      close( desc );
      return FALSE;
   }

   if( connect( desc, (struct sockaddr *)&sa, sizeof(sa) ) < 0 )
   {
      if( errno != EINPROGRESS )
      {
         perror( "connect" );
         close( desc );
         return FALSE;
      }
   }

   this_imcmud->state    = IMC_CONNECTING;
   this_imcmud->desc     = desc;
   this_imcmud->insize   = IMC_MINBUF;
   IMCCREATE( this_imcmud->inbuf, char, this_imcmud->insize );
   this_imcmud->outsize  = IMC_MINBUF;
   IMCCREATE( this_imcmud->outbuf, char, this_imcmud->outsize );
   this_imcmud->inbuf[0] = this_imcmud->outbuf[0] = '\0';
   this_imcmud->newoutput = 0;

   snprintf( buf, IMC_DATA_LENGTH, "PW %s %s version=%d autosetup %s",
      imc_name, this_imcmud->clientpw, IMC_VERSION, this_imcmud->serverpw );
   do_imcsend( buf );

   return TRUE;
}

void imc_recv_who( imc_actor_data *from, char *type )
{
   char arg[SMST];
   char output[LGST];

   type = imc_getarg( type, arg, SMST );

   if( !strcasecmp( arg, "who" ) )
   {
      process_rwho( from, type );
      return;
   }
   else if( !strcasecmp( arg, "finger" ) )
   {
      process_rfinger( from, type );
      return;
   }
   else if( !strcasecmp( arg, "info" ) )
      snprintf( output, LGST,
         "~!Site Information --\n\r"
         "~cSite Name      ~W: ~!%s\n\r"
         "~cSite Host      ~W: ~!%s\n\r"
         "~cAdmin Email    ~W: ~!%s\n\r"
         "~cAdmin MUDMail  ~W: ~!Disabled\n\r"
         "~cWeb Site       ~W: ~!%s\n\r"
         "IMC Information --\n\r"
         "~cIMC Version    ~W: ~!%s\n\r"
         "~cIMC Details    ~W: ~!%s\n\r",
         imc_siteinfo.name, imc_siteinfo.host, imc_siteinfo.email, imc_siteinfo.www, IMC_VERSIONID, imc_siteinfo.details );
   else
      snprintf( output, LGST, "%s is not a valid option. Options are: who, finger, or info.\n\r", type );

   imc_send_whoreply( from->name, color_mtoi( color_itom(output)), -1 );
}

/* respond with a whois-reply */
void imc_send_whoisreply( char *to, char *data )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;

   if( !strcasecmp( imc_mudof( to ), "*" ) )
      return; /* don't let them do this */

   imc_initdata( &out );

   imcstrlcpy( out.to, to, IMC_NAME_LENGTH );
   imcstrlcpy( out.type, "whois-reply", IMC_TYPE_LENGTH );
   imcstrlcpy( out.from, "*", IMC_NAME_LENGTH );
   imc_addkey( &out, "text", data );

   imc_send( &out );
   imc_freedata( &out );
}

void imc_recv_whois( imc_actor_data *from, char *to )
{
   PLAYER_DATA *victim;
   char buf[LGST];

   if( ( victim = imc_find_user( to ) ) != NULL && !IMCISINVIS(victim) )
   {
      snprintf( buf, LGST, "imclocate %s : %s@%s is online.\n\r", to, CH_IMCNAME(victim), imc_name );
      imc_send_whoisreply( from->name, buf );
   }
   return;
}

void imc_recv_whoisreply( char *to, char *text )
{
   PLAYER_DATA *victim;

   if( ( victim = imc_find_user( to ) ) != NULL )
      imc_to_char( color_itom(text), victim );
   return;
}

void imc_recv_beep( imc_actor_data *from, char *to )
{
   PLAYER_DATA *victim = NULL;
   char buf[IMC_DATA_LENGTH];

   if( !strcasecmp( to, "*" ) ) /* ignore messages to system */
      return;

   victim = imc_find_user( to );

   if( victim )
   {
      if( IMCPERM(victim) < FALSE )
      {
         if( strcasecmp( imc_nameof( from->name ), "*" ) )
         {
	      snprintf( buf, IMC_DATA_LENGTH, "%s is not yet able to use IMC2.", to );
	      imc_send_tell( NULL, from->name, buf, 1 );
         }
         return;
      }

      if( IMCISINVIS(victim) )
      {
         if( strcasecmp( imc_nameof( from->name ), "*" ) )
         {
	      snprintf( buf, IMC_DATA_LENGTH, "%s is not receiving beeps.", to );
	      imc_send_tell( NULL, from->name, buf, 1 );
         }
         return;
      }

      if( imc_isignoring( victim, from->name ) )
      {
         if( strcasecmp( imc_nameof( from->name ), "*" ) )
         {
	      snprintf( buf, IMC_DATA_LENGTH, "%s is not receiving beeps.", to );
	      imc_send_tell( NULL, from->name, buf, 1 );
         }
         return;
      }

      if( IMCIS_SET( IMCFLAG(victim), IMC_BEEP ) || IMCIS_SET( IMCFLAG(victim), IMC_DENYBEEP ) )
      {
         if( strcasecmp( imc_nameof( from->name ), "*" ) )
         {
	      snprintf( buf, IMC_DATA_LENGTH, "%s is not receiving beeps.", to );
	      imc_send_tell( NULL, from->name, buf, 1 );
         }
         return;
      }

      if( IMCAFK(victim) )
      {
         if( strcasecmp( imc_nameof( from->name ), "*" ) )
         {
	      snprintf( buf, IMC_DATA_LENGTH, "%s is currently AFK. Try back later.", to );
	      imc_send_tell( NULL, from->name, buf, 1 );
         }
         return;
      }
    
      /* always display the true name here */
      snprintf( buf, IMC_DATA_LENGTH, color_itom( "~c\a%s imcbeeps you.~!\n\r" ), from->name );
      imc_to_char( buf, victim );
   }
   else
   {
      snprintf( buf, IMC_DATA_LENGTH, "No player named %s exists here.", to );
      imc_send_tell( NULL, from->name, buf, 1 );
   }
}

/* send a ping with a given timestamp */
void imc_send_ping( char *to, int time_s, int time_u )
{
   PACKET out;

   if( imc_active < IA_UP )
    return;

   imc_initdata( &out );
   imcstrlcpy( out.type, "ping", IMC_TYPE_LENGTH );
   imcstrlcpy( out.from, "*", IMC_NAME_LENGTH );
   imcstrlcpy( out.to, "*@", IMC_NAME_LENGTH );
   imcstrlcpy( out.to+2, to, IMC_MNAME_LENGTH-2 );
   imc_addkeyi( &out, "time-s", time_s );
   imc_addkeyi( &out, "time-us", time_u );

   imc_send( &out );
   imc_freedata( &out );
}

/* called when a keepalive has been received */
void imc_recv_keepalive( char *from, char *version, char *flags, char *network )
{
   REMOTEINFO *p;

   if( !strcasecmp( from, imc_name ) )
      return;
  
   /*  this should never fail, imc.c should create an entry if one doesn't exist (in the path update code) */
   p = imc_find_reminfo( from, 0 );
   if( !p )		    /* boggle */
      return;

   if( strcasecmp( version, p->version ) )    /* remote version has changed? */
   {
      IMCSTRFREE( p->version );              /* if so, update it */
      p->version = IMCSTRALLOC( version );
   }
   /* Not sure how or why this might change, but just in case it does */
   if( network && network[0] != '\0' && strcasecmp( network, p->network ) )
   {
      IMCSTRFREE( p->network );
      p->network = IMCSTRALLOC( network );
   }
}

/* send a pingreply with the given timestamp */
void imc_send_pingreply( char *to, int time_s, int time_u, char *path )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;

   imc_initdata( &out );
   imcstrlcpy( out.type, "ping-reply", IMC_TYPE_LENGTH );
   imcstrlcpy( out.from, "*", IMC_NAME_LENGTH );
   imcstrlcpy( out.to, "*@", IMC_NAME_LENGTH );
   imcstrlcpy( out.to+2, to, IMC_MNAME_LENGTH-2 );
   imc_addkeyi( &out, "time-s", time_s );
   imc_addkeyi( &out, "time-us", time_u );
   imc_addkey( &out, "path", path );

   imc_send( &out );
   imc_freedata( &out );
}

/* called when a ping request is received */
void imc_recv_ping( char *from, int time_s, int time_u, char *path )
{
   /* ping 'em back */
   imc_send_pingreply( from, time_s, time_u, path );
}

void imc_traceroute( int ping, char *pathto, char *pathfrom )
{
   if( !strcasecmp( imc_firstinpath(pathfrom), lastping ) )
   {
      PLAYER_DATA *ch = NULL;

      if( ( ch = imc_find_user( pinger ) ) == NULL )
         return;

      imc_printf( ch, "%s: %dms round-trip-time.\n\rReturn path: %s\n\rSend path:   %s\n\r",
	   imc_firstinpath(pathfrom), ping, pathfrom, pathto ? pathto : "unknown" );
   }
}

/* called when a ping reply is received */
void imc_recv_pingreply( char *from, int time_s, int time_u, char *pathto, char *pathfrom )
{
   REMOTEINFO *p;
   struct timeval tv;

   p = imc_find_reminfo( from, 0 );   /* should always exist */
   if( !p ) /* boggle */
      return;

   gettimeofday( &tv, NULL );      /* grab the exact time now and calc RTT */
   p->ping = (tv.tv_sec - time_s) * 1000 + (tv.tv_usec - time_u) / 1000;

   /* check for pending traceroutes */
   imc_traceroute( p->ping, pathto, pathfrom );
}

/* send a keepalive to everyone */
void imc_send_keepalive( const char *to )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;

   imc_initdata( &out );
   imcstrlcpy( out.type, "is-alive", IMC_TYPE_LENGTH );
   imcstrlcpy( out.from, "*", IMC_NAME_LENGTH );
   imcstrlcpy( out.to, to, IMC_NAME_LENGTH );
   imc_addkey( &out, "versionid", IMC_VERSIONID );

   imc_send( &out );
   imc_freedata( &out );
}

/* Commands called by the interface layer */

/* handle a packet destined for us, or a broadcast */
void imc_recv( PACKET *p )
{
   imc_actor_data d;
   int bcast;
   REMOTEINFO *i;

   bcast = !strcasecmp( imc_mudof( p->i.to ), "*" ) ? 1 : 0;

   getdata( p, &d );

   i = imc_find_reminfo( imc_mudof( p->from ), 0 );
   if( i )
   {
      IMCSTRFREE( i->path );
      i->path = IMCSTRALLOC( p->i.path );
      i->ping = 0;
      i->type = 0;
   }

   /* chat: message to a channel (broadcast) */
   if( !strcasecmp( p->type, "chat" ) && !imc_isignored( p->from ) )
      imc_recv_chat( &d, imc_getkeyi( p, "channel", 0 ), imc_getkey( p, "text", "" ) );

   /* emote: emote to a channel (broadcast) */
   else if( !strcasecmp( p->type, "emote" ) && !imc_isignored( p->from ) )
      imc_recv_emote( &d, imc_getkeyi( p, "channel", 0 ), imc_getkey( p, "text", "" ) );

   /* tell: tell a player here something */
   else if( !strcasecmp( p->type, "tell" ) )
   {
      if( !imc_isignored( p->from ) )
         imc_recv_tell( &d, p->to, imc_getkey( p, "text", "" ), imc_getkeyi( p, "isreply", 0 ) );
   }

   /* who-reply: receive a who response */
   else if( !strcasecmp( p->type, "who-reply" ) || !strcasecmp( p->type, "wHo-reply" ) )
      imc_recv_whoreply( p->to, imc_getkey( p, "text", "" ), imc_getkeyi( p, "sequence", -1 ), -1 );

   /* who: receive a who request */
   else if( !strcasecmp( p->type, "who" ) || !strcasecmp( p->type, "wHo" ) )
   {
      if( !imc_isignored( p->from ) )
         imc_recv_who( &d, imc_getkey( p, "type", "who" ) );
   }

   /* whois-reply: receive a whois response */
   else if( !strcasecmp( p->type, "whois-reply" ) )
      imc_recv_whoisreply( p->to, imc_getkey( p, "text", "" ) );

   /* whois: receive a whois request */
   else if( !strcasecmp( p->type, "whois" ) )
   {
      if( !imc_isignored( p->from ) )
         imc_recv_whois( &d, p->to );
   }

   /* beep: beep a player */
   else if( !strcasecmp( p->type, "beep" ) )
   {
      if( !imc_isignored( p->from ) )
         imc_recv_beep( &d, p->to );
   }

   /* is-alive: receive a keepalive (broadcast) */
   else if( !strcasecmp( p->type, "is-alive" ) )
      imc_recv_keepalive( imc_mudof( p->from ), imc_getkey( p, "versionid", "unknown" ),
	   imc_getkey( p, "flags", "" ), imc_getkey( p, "networkname", "" ) );

   /* ping: receive a ping request */
   else if( !strcasecmp( p->type, "ping" ) )
      imc_recv_ping( imc_mudof( p->from ), imc_getkeyi( p, "time-s", 0 ),
	   imc_getkeyi( p, "time-us", 0 ), p->i.path );

   /* ping-reply: receive a ping reply */
   else if( !strcasecmp( p->type, "ping-reply" ) )
      imc_recv_pingreply( imc_mudof( p->from ), imc_getkeyi( p, "time-s", 0 ),
         imc_getkeyi( p, "time-us", 0 ), imc_getkey( p, "path", NULL ), p->i.path );

   /* handle keepalive requests - shogar */
   else if( !strcasecmp( p->type, "keepalive-request" ) )
      imc_send_keepalive( p->from );

   /* expire closed hubs - shogar */
   else if( !strcasecmp( p->type, "close-notify" ) )
   {
      REMOTEINFO *r;
      char fake[90];
      struct timeval tv;

      r = imc_find_reminfo( imc_getkey( p, "host", "unknown" ), 0 );
      if( r )
      {
         r->type = IMC_REMINFO_EXPIRED;
         for( r = first_rinfo; r; r = r->next )
         {
            char *sf;
            snprintf( fake, 90, "!%s", imc_getkey( p, "host", "___unknown " ) );
            if( r->name && r->path && ( sf = strstr( r->path, fake ) ) && sf
		   && ( *( sf + strlen( fake ) ) == '!' || *( sf + strlen( fake ) ) == 0 ) )
            {
               r->type = IMC_REMINFO_EXPIRED;
               gettimeofday( &tv, NULL );
               imc_send_ping( r->name, tv.tv_sec, tv.tv_usec );
            }
         }
      }
   }

   /* call catch-all fn if present */
   else
   {
      PACKET out;

      if( imc_recv_hook )
         if( (*imc_recv_hook)( p, bcast ) )
            return;

      if( bcast || !strcasecmp( p->type, "reject" ) )
         return;

      /* reject packet */
      imcstrlcpy( out.type, "reject", IMC_TYPE_LENGTH );
      imcstrlcpy( out.to, p->from, IMC_NAME_LENGTH );
      imcstrlcpy( out.from, p->to, IMC_NAME_LENGTH );

      imc_clonedata( p, &out );
      imc_addkey( &out, "old-type", p->type );
      imc_send( &out );
      imc_freedata( &out );
   }
}

/* send a packet to a mud using the right version */
void do_send_packet( PACKET *p )
{
   char *output;

   output = ( *imc_vinfo[IMC_VERSION].generate )( p );

   if( output )
   {
      imc_stats.tx_pkts++;
      if( strlen( output ) > (unsigned int)imc_stats.max_pkt )
         imc_stats.max_pkt = strlen( output );
      do_imcsend( output );
   }
}

void imc_send( PACKET *p )
{
   if( imc_active < IA_UP )
   {
      imcbug( "%s", "imc_send when not active!" );
      return;
   }

   /* initialize packet fields that the caller shouldn't/doesn't set */
   p->i.path[0] = '\0';

   p->i.sequence = imc_sequencenumber++;
   if( !imc_sequencenumber )
      imc_sequencenumber++;

   imcstrlcpy( p->i.to, p->to, IMC_NAME_LENGTH );
   snprintf( p->i.from, IMC_NAME_LENGTH, "%s@%s", p->from, imc_name );
   do_send_packet( p );
}

/* delete the info entry "p" */
void imc_delete_reminfo( REMOTEINFO *p )
{
   IMCUNLINK( p, first_rinfo, last_rinfo, next, prev );
   IMCSTRFREE( p->name );
   IMCSTRFREE( p->version );
   IMCSTRFREE( p->route );
   IMCSTRFREE( p->network );
   IMCSTRFREE( p->path );
   IMCDISPOSE( p );
}

/* send a keepalive request to everyone - shogar */
void imc_request_keepalive( void )
{
   PACKET out;

   imc_initdata( &out );
   imcstrlcpy( out.type, "keepalive-request", IMC_TYPE_LENGTH );
   imcstrlcpy( out.from, "*", IMC_NAME_LENGTH );
   imcstrlcpy( out.to, "*@*", IMC_NAME_LENGTH );
   imc_addkey( &out, "versionid", IMC_VERSIONID );

   imc_send( &out );
   imc_freedata( &out );

   imc_send_keepalive( "*@*" );
}

/* put a line onto descriptors output buffer */
void do_imcsend( char *line )
{
   int len;
   char *newbuf;
   int newsize = this_imcmud->outsize;

   if( this_imcmud->state == IMC_CLOSED )
      return;

   if( !this_imcmud->outbuf[0] )
      this_imcmud->newoutput = 1;

   len = strlen( this_imcmud->outbuf ) + strlen( line ) + 3;

   if( len > this_imcmud->outsize )
   {
      while( newsize < len )
         newsize *= 2;

	IMCCREATE( newbuf, char, newsize );
      imcstrlcpy( newbuf, this_imcmud->outbuf, newsize );
      IMCDISPOSE( this_imcmud->outbuf );
      this_imcmud->outbuf = newbuf;
      this_imcmud->outsize = newsize;
   }
   if( len < this_imcmud->outsize/2 && len >= IMC_MINBUF )
   {
      newsize = this_imcmud->outsize/2;

      IMCCREATE( newbuf, char, newsize );
      imcstrlcpy( newbuf, this_imcmud->outbuf, newsize );
      IMCDISPOSE( this_imcmud->outbuf );
      this_imcmud->outbuf = newbuf;
      this_imcmud->outsize = newsize;
   }
   imcstrlcat( this_imcmud->outbuf, line, this_imcmud->outsize );
   imcstrlcat( this_imcmud->outbuf, "\n\r", this_imcmud->outsize );
}

/* read waiting data from descriptor.
 * read to a temp buffer to avoid repeated allocations
 */
void do_imcread( void )
{
   int size;
   int r;
   char temp[IMC_MAXBUF];
   char *newbuf;
   int newsize;

   r = read( this_imcmud->desc, temp, IMC_MAXBUF-1 );
   if( !r || ( r < 0 && errno != EAGAIN && errno != EWOULDBLOCK ) )
   {
      if( r < 0 )                    /* read error */
         imclog( "Read error on connection to %s", this_imcmud->hubname );
      else                        /* socket was closed */
         imclog( "EOF encountered on connection to %s", this_imcmud->hubname );

      imc_shutdown( TRUE );
      return;
   }

   if( r < 0 )			/* EAGAIN error */
      return;

   temp[r] = '\0';

   size = strlen( this_imcmud->inbuf ) + r + 1;

   if( size >= this_imcmud->insize )
   {
      newsize = this_imcmud->insize;

      while( newsize < size )
         newsize *= 2;

      IMCCREATE( newbuf, char, newsize );
      imcstrlcpy( newbuf, this_imcmud->inbuf, newsize );
      IMCDISPOSE( this_imcmud->inbuf );
      this_imcmud->inbuf = newbuf;
      this_imcmud->insize = newsize;
   }

   if( size < this_imcmud->insize/2 && size >= IMC_MINBUF )
   {
      newsize = this_imcmud->insize;
      newsize /= 2;

      IMCCREATE( newbuf, char, newsize );
      imcstrlcpy( newbuf, this_imcmud->inbuf, newsize );
      IMCDISPOSE( this_imcmud->inbuf );
      this_imcmud->inbuf = newbuf;
      this_imcmud->insize = newsize;
   }

   imcstrlcat( this_imcmud->inbuf, temp, this_imcmud->insize );

   imc_stats.rx_bytes += r;
}

/* write to descriptor */
void do_imcwrite( void )
{
   int size, w;

   if( this_imcmud->state == IMC_CONNECTING )
   {
      /* Wait for server password */
      this_imcmud->state = IMC_WAIT1;
      return;
   }

   size = strlen( this_imcmud->outbuf );
   if( !size )			/* nothing to write */
      return;

   w = write( this_imcmud->desc, this_imcmud->outbuf, size );
   if( !w || ( w < 0 && errno != EAGAIN && errno != EWOULDBLOCK ) )
   {
      if( w < 0 )			/* write error */
         imcbug( "Write error on connection to %s", this_imcmud->hubname );
      else			/* socket was closed */
         imcbug( "EOF encountered on connection to %s", this_imcmud->hubname );

      imc_shutdown( TRUE );
      return;
   }

   if( w < 0 )			/* EAGAIN */
      return;

   if( imcpacketdebug )
      imclog( "Packet sent: %s", this_imcmud->outbuf );

   /* throw away data we wrote */
   imcstrlcpy( this_imcmud->outbuf, this_imcmud->outbuf + w, this_imcmud->outsize );

   imc_stats.tx_bytes += w;
}

/*  try to read a line from the input buffer, NULL if none ready
 *  all lines are \n\r terminated in theory, but take other combinations
 */
char *imcgetline( char *buffer )
{
   int i;
   static char buf[IMC_PACKET_LENGTH];

   /* copy until \n, \r, end of buffer, or out of space */
   for( i = 0; buffer[i] && buffer[i] != '\n' && buffer[i] != '\r' && i+1 < IMC_PACKET_LENGTH; i++ )
      buf[i] = buffer[i];

   /* end of buffer and we haven't hit the maximum line length */
   if( !buffer[i] && i+1 < IMC_PACKET_LENGTH )
   {
      buf[0] = '\0';
      return NULL; /* so no line available */
   }

   /* terminate return string */
   buf[i] = '\0';

   /* strip off extra control codes */
   while( buffer[i] && ( buffer[i] == '\n' || buffer[i] == '\r' ) )
      i++;

   /* remove the line from the input buffer */
   imcstrlcpy( buffer, buffer + i, this_imcmud->insize );

   return buf;
}

void imc_firstrefresh( void )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;
  
   imcstrlcpy( out.from, "*", IMC_NAME_LENGTH );
   imcstrlcpy( out.to, "IMC@*", IMC_NAME_LENGTH );
   imcstrlcpy( out.type, "ice-refresh", IMC_TYPE_LENGTH );
   imc_initdata( &out );
   imc_addkey( &out, "channel", "*" );
   imc_send( &out );
   imc_freedata( &out );
}

/* Handle an autosetup response from a supporting hub - Samson 8-12-03 */
void imc_handle_autosetup( char *source, char *hubname, char *cmd, char *txt )
{
   if( !strcasecmp( cmd, "reject" ) )
   {
      if( !strcasecmp( txt, "connected" ) )
      {
         imclog( "There is already a mud named %s connected to the network.", imc_name );
         imc_shutdown( FALSE );
         return;
      }
      if( !strcasecmp( txt, "private" ) )
      {
         imclog( "%s is a private hub. Autosetup denied.", hubname );
         imc_shutdown( FALSE );
         return;
      }
      if( !strcasecmp( txt, "full" ) )
      {
         imclog( "%s has reached its connection limit. Autosetup denied.", hubname );
         imc_shutdown( FALSE );
         return;
      }
      if( !strcasecmp( txt, "ban" ) )
      {
         imclog( "%s has banned your connection. Autosetup denied.", hubname );
         imc_shutdown( FALSE );
         return;
      }
      imclog( "%s: Invalid 'reject' response. Autosetup failed.", hubname );
      imclog( "Data received: %s %s %s %s", source, hubname, cmd, txt );
      imc_shutdown( FALSE );
      return;
   }

   if( !strcasecmp( cmd, "accept" ) )
   {
      this_imcmud->state = IMC_CONNECTED;

      if( txt && txt[0] != '\0' )
      {
         IMCSTRFREE( this_imcmud->network );
         this_imcmud->network = IMCSTRALLOC( txt );     
      }

      imclog( "Autosetup on %s completed. Network ID: %s", this_imcmud->hubname,
         ( txt && txt[0] != '\0' ) ? txt : "Unknown" );

      imcconnect_attempts = 0;
      imc_request_keepalive();
      imc_firstrefresh();
      return;
   }

   imclog( "%s: Invalid autosetup response.", this_imcmud->hubname );
   imclog( "Data received: %s %s %s %s", source, hubname, cmd, txt );
   imc_shutdown( FALSE );
   return;
}

/* handle a password response from a hub - for connection negotiation. DON'T REMOVE THIS */
void serverpassword( char *argument )
{
   char arg1[IMC_PW_LENGTH], name[IMC_MNAME_LENGTH], pw[IMC_PW_LENGTH];
   char version[IMC_PW_LENGTH], netname[IMC_MNAME_LENGTH];
   int rversion;

   argument = imc_getarg( argument, arg1, IMC_PW_LENGTH );
   argument = imc_getarg( argument, name, IMC_MNAME_LENGTH );
   argument = imc_getarg( argument, pw, IMC_PW_LENGTH );
   argument = imc_getarg( argument, version, IMC_PW_LENGTH );
   argument = imc_getarg( argument, netname, IMC_MNAME_LENGTH );

   if( !strcasecmp( arg1, "PW" ) )
   {
      if( !this_imcmud || strcasecmp( this_imcmud->serverpw, pw ) )
      {
	   imclog( "%s", "Password failure for hub!" );
         imc_shutdown( FALSE );
         return;
      }

      this_imcmud->state = IMC_CONNECTED;

      /* check for a version string (assume version 2 if not present) */
      if( sscanf( version, "version=%d", &rversion ) != 1 )
         rversion = 2;

      /* check for generator/interpreter */
      if( !imc_vinfo[rversion].generate || !imc_vinfo[rversion].interpret )
      {
         imclog( "%s: Unsupported version %d", this_imcmud->hubname, rversion );
         imc_shutdown( FALSE );
         return;
      }

      if( netname && netname[0] != '\0' )
      {
         IMCSTRFREE( this_imcmud->network );
         this_imcmud->network = IMCSTRALLOC( netname );
      }

      imclog( "Connected to %s. Network ID: %s", this_imcmud->hubname,
         ( netname && netname[0] != '\0' ) ? netname : "Unknown" );

      imcconnect_attempts = 0;
      imc_request_keepalive();
      imc_firstrefresh();
      return;
   }

   /* Should only be received from hubs supporting this obviously */
   if( !strcasecmp( arg1, "autosetup" ) )
   {
      imc_handle_autosetup( arg1, name, pw, version );
      return;
   }

   imclog( "Invalid authentication response received from %s!!", this_imcmud->hubname );
   imclog( "Data received: %s %s %s %s", arg1, name, pw, version );
   imc_shutdown( FALSE );
   return;
}

/* start up IMC */
bool imc_startup_network( void )
{
   if( imc_active != IA_CONFIG2 )
   {
      imcbug( "imc_startup_network: called with imc_active == %d", imc_active );
      return FALSE;
   }
  
   imclog( "%s", "IMC2 Network Initializing" );

   imc_active = IA_UP;

   imc_stats.rx_pkts  = 0;
   imc_stats.tx_pkts  = 0;
   imc_stats.rx_bytes = 0;
   imc_stats.tx_bytes = 0;
   imc_stats.sequence_drops = 0;

   /* Connect to Hub */
   if( !imc_connect_to() )
      return FALSE;

   return TRUE;
}

void imc_freechardata( PLAYER_DATA *ch )
{
   IMC_IGNORE *ign, *ign_next;

   if( IS_NPC(ch) || ch->userdata == NULL || ch->userdata->imcchardata == NULL )
	return;

   for( ign = FIRST_IMCIGNORE(ch); ign; ign = ign_next )
   {
      ign_next = ign->next;

      IMCSTRFREE( ign->name );
      IMCUNLINK( ign, FIRST_IMCIGNORE(ch), LAST_IMCIGNORE(ch), next, prev );
      IMCDISPOSE( ign );
   }
   IMCSTRFREE( IMC_LISTEN(ch) );
   IMCSTRFREE( IMC_RREPLY(ch) );
   IMCSTRFREE( IMC_RREPLY_NAME(ch) );
   IMCDISPOSE( CH_IMCDATA(ch) );
   return;
}

void imc_initchar( PLAYER_DATA *ch )
{
   if( IS_NPC(ch) )
	return;

   IMCCREATE( CH_IMCDATA(ch), IMC_CHARDATA, 1 );
   IMC_LISTEN(ch)	= NULL;
   IMC_DENY(ch)   = NULL;
   IMC_RREPLY(ch)	= NULL;
   IMC_RREPLY_NAME(ch) = NULL;
   IMCFLAG(ch)         = 0;
   IMCSET_BIT( IMCFLAG(ch), IMC_COLOR );
   FIRST_IMCIGNORE(ch) = NULL;
   LAST_IMCIGNORE(ch)  = NULL;
   IMCPERM(ch)         = IMCPERM_NOTSET;

   return;
}

/*
 * Read a string from file fp using IMCSTRALLOC [Taken from Smaug's fread_string]
 */
char *imcfread_string( FILE *fp )
{
    char buf[LGST];
    char *plast;
    char c;
    int ln;

    plast = buf;
    buf[0] = '\0';
    ln = 0;

    /*
     * Skip blanks.
     * Read first char.
     */
    do
    {
	if ( feof(fp) )
	{
	    imcbug( "%s", "imcfread_string: EOF encountered on read." );
	    return IMCSTRALLOC( "" );
	}
	c = getc( fp );
    }
    while ( isspace(c) );

    if ( ( *plast++ = c ) == '~' )
	return IMCSTRALLOC( "" );

    for ( ;; )
    {
	if ( ln >= (LGST - 1) )
	{
	     imcbug( "%s", "imcfread_string: string too long" );
	     *plast = '\0';
	     return IMCSTRALLOC( buf );
	}
	switch ( *plast = getc( fp ) )
	{
	default:
	    plast++; ln++;
	    break;

	case EOF:
	    imcbug( "%s", "imcfread_string: EOF" );
	    *plast = '\0';
	    return IMCSTRALLOC( buf );

	case '\n':
	    plast++;  ln++;
	    *plast++ = '\r';  ln++;
	    break;

	case '\r':
	    break;

	case '~':
	    *plast = '\0';
	    return IMCSTRALLOC( buf );
	}
    }
}

/*
 * Read a number from a file. [Taken from Smaug's fread_number]
 */
int imcfread_number( FILE *fp )
{
    int number;
    bool sign;
    char c;

    do
    {
        if ( feof(fp) )
        {
          imclog( "%s", "imcfread_number: EOF encountered on read." );
          return 0;
        }
	c = getc( fp );
    }
    while ( isspace(c) );

    number = 0;

    sign   = FALSE;
    if ( c == '+' )
    {
	c = getc( fp );
    }
    else if ( c == '-' )
    {
	sign = TRUE;
	c = getc( fp );
    }

    if ( !isdigit(c) )
    {
	imclog( "imcfread_number: bad format. (%c)", c );
	return 0;
    }

    while ( isdigit(c) )
    {
        if ( feof(fp) )
        {
          imclog( "%s", "imcfread_number: EOF encountered on read." );
          return number;
        }
	number = number * 10 + c - '0';
	c      = getc( fp );
    }

    if ( sign )
	number = 0 - number;

    if ( c == '|' )
	number += imcfread_number( fp );
    else if ( c != ' ' )
	ungetc( c, fp );

    return number;
}

/*
 * Read to end of line into static buffer [Taken from Smaug's fread_line]
 */
char *imcfread_line( FILE *fp )
{
    static char line[LGST];
    char *pline;
    char c;
    int ln;

    pline = line;
    line[0] = '\0';
    ln = 0;

    /*
     * Skip blanks.
     * Read first char.
     */
    do
    {
	if ( feof(fp) )
	{
	    imcbug( "%s", "imcfread_line: EOF encountered on read." );
	    imcstrlcpy( line, "", LGST );
	    return line;
	}
	c = getc( fp );
    }
    while ( isspace(c) );

    ungetc( c, fp );
    do
    {
	if ( feof(fp) )
	{
	    imcbug( "%s", "imcfread_line: EOF encountered on read." );
	    *pline = '\0';
	    return line;
	}
	c = getc( fp );
	*pline++ = c; ln++;
	if ( ln >= (LGST - 1) )
	{
	    imcbug( "%s", "imcfread_line: line too long" );
	    break;
	}
    }
    while ( c != '\n' && c != '\r' );

    do
    {
	c = getc( fp );
    }
    while ( c == '\n' || c == '\r' );

    ungetc( c, fp );
    *pline = '\0';
    return line;
}

/*
 * Read one word (into static buffer). [Taken from Smaug's fread_word]
 */
char *imcfread_word( FILE *fp )
{
    static char word[SMST];
    char *pword;
    char cEnd;

    do
    {
	if ( feof(fp) )
	{
	    imclog( "%s", "imcfread_word: EOF encountered on read." );
	    word[0] = '\0';
	    return word;
	}
	cEnd = getc( fp );
    }
    while ( isspace( cEnd ) );

    if ( cEnd == '\'' || cEnd == '"' )
    {
	pword   = word;
    }
    else
    {
	word[0] = cEnd;
	pword   = word+1;
	cEnd    = ' ';
    }

    for ( ; pword < word + SMST; pword++ )
    {
	if ( feof(fp) )
	{
	    imclog( "%s", "imcfread_word: EOF encountered on read." );
	    *pword = '\0';
	    return word;
	}
	*pword = getc( fp );
	if ( cEnd == ' ' ? isspace(*pword) : *pword == cEnd )
	{
	    if ( cEnd == ' ' )
		ungetc( *pword, fp );
	    *pword = '\0';
	    return word;
	}
    }

    imclog( "%s", "imcfread_word: word too long" );
    return NULL;
}

/*
 * Read a letter from a file. [Taken from Smaug's fread_letter]
 */
char imcfread_letter( FILE *fp )
{
    char c;

    do
    {
        if ( feof(fp) )
        {
          imclog( "%s", "imcfread_letter: EOF encountered on read." );
          return '\0';
        }
	c = getc( fp );
    }
    while ( isspace(c) );

    return c;
}

/*
 * Read to end of line (for comments). [Taken from Smaug's fread_to_eol]
 */
void imcfread_to_eol( FILE *fp )
{
    char c;

    do
    {
	if ( feof(fp) )
	{
	    imclog( "%s", "imcfread_to_eol: EOF encountered on read." );
	    return;
	}
	c = getc( fp );
    }
    while ( c != '\n' && c != '\r' );

    do
    {
	c = getc( fp );
    }
    while ( c == '\n' || c == '\r' );

    ungetc( c, fp );
    return;
}

void imc_actor_login( PLAYER_DATA *ch )
{
   if( !this_imcmud )
	return;

   /* Somewhat ugly looking, but this should be the only place level gets checked directly now.
    * This will also catch upgraders from old clients - provided they've got their levels set right.
    * If the mud doesn't use levels, the CH_IMCLEVEL macro can be altered to suit whatever system it does use.
    * Samson 6-25-03
    */
   if( IMCPERM(ch) == IMCPERM_NOTSET )
   {
      if( CH_IMCLEVEL(ch) < imc_minlevel )
	   IMCPERM(ch) = IMCPERM_NONE;
      else if( CH_IMCLEVEL(ch) >= imc_minlevel && CH_IMCLEVEL(ch) < imc_immlevel )
	   IMCPERM(ch) = FALSE;
      else if( CH_IMCLEVEL(ch) >= imc_immlevel && CH_IMCLEVEL(ch) < imc_adminlevel )
	   IMCPERM(ch) = TRUE;
      else if( CH_IMCLEVEL(ch) >= imc_adminlevel && CH_IMCLEVEL(ch) < imc_implevel )
	   IMCPERM(ch) = TRUE;
      else if( CH_IMCLEVEL(ch) >= imc_implevel )
	   IMCPERM(ch) = TRUE;
   }

   if( imc_active != IA_UP )
   {
	if( IMCPERM(ch) >= TRUE && imcwait == -2 )
	   imc_to_char( "&RThe IMC2 connection is down. Attempts to reconnect were abandoned due to excessive failures.\n\r", ch );
	return;
   }
   return;
}

bool imc_loadchar( PLAYER_DATA *ch, FILE *fp, const char *word )
{
   bool fMatch = FALSE;

   if( IS_NPC(ch) )
	return FALSE;

   switch( UPPER(word[0]) )
   {
	case 'I':
         IMCKEY( "IMCPerm",      IMCPERM(ch),      imcfread_number( fp ) );
	   if( !strcasecmp( word, "IMCFlags" ) )
	   {
		IMCFLAG(ch) = imcfread_number( fp );
		imc_actor_login( ch );
		fMatch = TRUE;
		break;
	   }

	   if( !strcasecmp( word, "IMClisten" ) )
	   {
		IMC_LISTEN(ch) = imcfread_string( fp );
		if( IMC_LISTEN(ch) != NULL && imc_active == IA_UP )
		{
		   IMC_CHANNEL *channel = NULL;
		   char *channels = IMC_LISTEN(ch);
		   char arg[SMST];

               while( 1 )
               {
                  if( channels[0] == '\0' )
                     break;
                  channels = one_argument( channels, arg );

                  if( !( channel = imc_findlchannel( arg ) ) )
                     imc_removename( &IMC_LISTEN( ch ), arg );
                  if( channel && IMCPERM( ch ) < channel->level )
                     imc_removename( &IMC_LISTEN( ch ), arg );
               }
	      }
		fMatch = TRUE;
		break;
	   }

	   if( !strcasecmp( word, "IMCdeny" ) )
	   {
		IMC_DENY(ch) = imcfread_string( fp );
		if( IMC_DENY(ch) != NULL && imc_active == IA_UP )
		{
		   IMC_CHANNEL *channel = NULL;
		   char *channels = IMC_DENY(ch);
		   char arg[SMST];

               while( 1 )
               {
                  if( channels[0] == '\0' )
                     break;
                  channels = one_argument( channels, arg );

                  if( !( channel = imc_findlchannel( arg ) ) )
                     imc_removename( &IMC_DENY( ch ), arg );
                  if( channel && IMCPERM( ch ) < channel->level )
                     imc_removename( &IMC_DENY( ch ), arg );
               }
		}
		fMatch = TRUE;
		break;
	   }

         if( !strcasecmp( word, "IMCignore" ) )
         {
            IMC_IGNORE *temp;

	      IMCCREATE( temp, IMC_IGNORE, 1 );
            temp->name = imcfread_string( fp );
	      IMCLINK( temp, FIRST_IMCIGNORE(ch), LAST_IMCIGNORE(ch), next, prev );
	      fMatch = TRUE;
	      break;
         }
	break;
   }
   return fMatch;
}

void imc_savechar( PLAYER_DATA *ch, FILE *fp )
{
   IMC_IGNORE *temp;

   if( IS_NPC(ch) )
	return;

   fprintf( fp, "IMCPerm      %d\n", IMCPERM(ch) );
   fprintf( fp, "IMCFlags     %d\n", IMCFLAG(ch) );
   if( IMC_LISTEN(ch) )
      fprintf( fp, "IMCListen %s~\n", IMC_LISTEN(ch) );
   if( IMC_DENY(ch) )
      fprintf( fp, "IMCDeny   %s~\n", IMC_DENY(ch) );
   for( temp = FIRST_IMCIGNORE(ch); temp; temp = temp->next )
      fprintf( fp, "IMCignore	%s~\n", temp->name );
   return;
}

void imcfread_config_file( FILE *fin )
{
   const char *word;
   bool fMatch;

   for( ;; )
   {
	word   = feof( fin ) ? "end" : imcfread_word( fin );
	fMatch = FALSE;
	
	switch( word[0] ) 
	{
	   case '#':
		fMatch = TRUE;
		imcfread_to_eol( fin );
		break;
	   case 'A':
		IMCKEY( "Autoconnect",	this_imcmud->autoconnect,	imcfread_number( fin ) );
		IMCKEY( "Adminlevel",	imc_adminlevel,			imcfread_number( fin ) );
		break;
	   case 'C':
		IMCKEY( "ConnectName",	this_imcmud->hubname,		imcfread_string( fin ) );
		IMCKEY( "ConnectAddr",	this_imcmud->host,		imcfread_string( fin ) );
		IMCKEY( "ConnectPort",	this_imcmud->port,		imcfread_number( fin ) );
		IMCKEY( "ConnectPwd1",	this_imcmud->clientpw,		imcfread_string( fin ) );
		IMCKEY( "ConnectPwd2",	this_imcmud->serverpw,		imcfread_string( fin ) );
		break;
	   case 'E':
		if( !strcasecmp( word, "End" ) )
		{
#ifdef IMCCHRONICLES
               char lbuf1[LGST], lbuf2[LGST];

               snprintf( lbuf1, LGST, "%s %s.%s", CODEBASE_VERSION_TITLE, CODEBASE_VERSION_MAJOR, CODEBASE_VERSION_MINOR );
               if( imc_siteinfo.base )
                  IMCSTRFREE( imc_siteinfo.base );
               imc_siteinfo.base = IMCSTRALLOC( lbuf1 );

               snprintf( lbuf2, LGST, "%s%s", IMC_VERSION_ID, imc_siteinfo.base );
               IMC_VERSIONID = IMCSTRALLOC( lbuf2 );
#endif
		   return;
		}
		break;
	   case 'I':
            IMCKEY( "Immlevel",        imc_immlevel,           imcfread_number( fin ) );
            IMCKEY( "Implevel",        imc_implevel,           imcfread_number( fin ) );
		IMCKEY( "InfoName",		imc_siteinfo.name,	imcfread_string( fin ) );
		IMCKEY( "InfoHost",		imc_siteinfo.host,	imcfread_string( fin ) );
		IMCKEY( "InfoPort",		imc_siteinfo.port,	imcfread_number( fin ) );
		IMCKEY( "InfoEmail",		imc_siteinfo.email,	imcfread_string( fin ) );
		IMCKEY( "InfoWWW",		imc_siteinfo.www,		imcfread_string( fin ) );
		IMCKEY( "InfoDetails",	imc_siteinfo.details,	imcfread_string( fin ) );
		IMCKEY( "InfoBase",		imc_siteinfo.base,	imcfread_string( fin ) );
		break;
	   case 'L':
		IMCKEY( "LocalName",		imc_name,			imcfread_string( fin ) );
		break;
	   case 'M':
		IMCKEY( "Minlevel",		imc_minlevel,		imcfread_number( fin ) );
		break;
	}

	if( !fMatch ) 
	   imcbug( "imcfread_config_file: Bad keyword: %s\n\r", word );
   }
}

/* There should only one of these..... */
void imc_delete_info( void )
{
   int i;

   for( i = 0; i < IMC_MEMORY; i++ )
      IMCSTRFREE( imc_memory[i].from );

   IMCSTRFREE( this_imcmud->hubname );
   IMCSTRFREE( this_imcmud->host );
   IMCSTRFREE( this_imcmud->network );
   IMCSTRFREE( this_imcmud->clientpw );
   IMCSTRFREE( this_imcmud->serverpw );
   IMCDISPOSE( this_imcmud->outbuf );
   IMCDISPOSE( this_imcmud->inbuf );
   IMCDISPOSE( this_imcmud );
   IMCSTRFREE( imc_name );
   IMCSTRFREE( imc_siteinfo.name );
   IMCSTRFREE( imc_siteinfo.host );
   IMCSTRFREE( imc_siteinfo.email );
   IMCSTRFREE( imc_siteinfo.www );
   IMCSTRFREE( imc_siteinfo.details );
   IMCSTRFREE( imc_siteinfo.base );
   IMCSTRFREE( IMC_VERSIONID );
}

bool imc_read_config( void ) 
{
   FILE *fin;
   char cbase[SMST];

   if( this_imcmud != NULL )
	imc_delete_info();
   this_imcmud = NULL;

   IMC_VERSIONID = NULL;

   imclog( "%s", "Loading IMC2 network data..." );

   if( !( fin = fopen( IMC_CONFIG_FILE, "r" ) ) )
   {
	imclog( "%s", "Can't open configuration file" );
	imclog( "%s", "Network configuration aborted." );
	return FALSE;
   }

   for( ; ; )
   {
    	char letter;
 	char *word;

   	letter = imcfread_letter( fin );

	if( letter == '#' )
	{
	   imcfread_to_eol( fin );
	   continue;
      }

	if( letter != '$' )
	{
	   imcbug( "%s", "imc_read_config: $ not found" );
	   break;
	}

	word = imcfread_word( fin );
	if( !strcasecmp( word, "IMCCONFIG" ) && this_imcmud == NULL )
	{
	   IMCCREATE( this_imcmud, HUBINFO, 1 );

	   imc_minlevel = 10;
         imc_immlevel = 101;
	   imc_adminlevel = 113;
         imc_implevel = 115;
         this_imcmud->network = IMCSTRALLOC( "Unknown" );

	   imcfread_config_file( fin );
	   continue;
	}
      else if( !strcasecmp( word, "END" ) )
	   break;
	else
	{
	   imcbug( "imc_read_config: Bad section in config file: %s", word );
	   continue;
      }
   }
   IMCFCLOSE( fin );

   if( !this_imcmud )
   {
	imcbug( "%s", "imc_read_config: No hub connection information!!" );
	imcbug( "%s", "Network configuration aborted." );
	return FALSE;
   }

   if( !this_imcmud->hubname || !this_imcmud->host || !this_imcmud->clientpw || !this_imcmud->serverpw || !this_imcmud->port )
   {
	imcbug( "%s", "imc_read_config: Missing required configuration info." );
	imcbug( "%s", "Network configuration aborted." );
	return FALSE;
   }

   if( !imc_name || imc_name[0] == '\0' )
   {
	imcbug( "%s", "imc_read_config: Mud name not loaded in configuration file." );
	imcbug( "%s", "Network configuration aborted." );
	return FALSE;
   }

   if( !imc_siteinfo.name || imc_siteinfo.name[0] == '\0' )
   {
	imcbug( "%s", "imc_read_config: Missing InfoName parameter in configuration file." );
	imcbug( "%s", "Network configuration aborted." );
	return FALSE;
   }

   if( !imc_siteinfo.host || imc_siteinfo.host[0] == '\0' )
   {
	imcbug( "%s", "imc_read_config: Missing InfoHost parameter in configuration file." );
	imcbug( "%s", "Network configuration aborted." );
	return FALSE;
   }

   if( !imc_siteinfo.email || imc_siteinfo.email[0] == '\0' )
   {
	imcbug( "%s", "imc_read_config: Missing InfoEmail parameter in configuration file." );
	imcbug( "%s", "Network configuration aborted." );
	return FALSE;
   }

   if( !imc_siteinfo.base || imc_siteinfo.base[0] == '\0' )
	imc_siteinfo.base = IMCSTRALLOC( "Unknown Codebase" );

   if( !imc_siteinfo.www || imc_siteinfo.www[0] == '\0' )
	imc_siteinfo.www = IMCSTRALLOC( "Not specified" );

   if( !imc_siteinfo.details || imc_siteinfo.details[0] == '\0' )
	imc_siteinfo.details = IMCSTRALLOC( "No details provided." );

   if( !IMC_VERSIONID )
   {
      snprintf( cbase, SMST, "%s%s", IMC_VERSION_ID, imc_siteinfo.base );
      IMC_VERSIONID = IMCSTRALLOC( cbase );
   }
   imc_siteinfo.disconnect = FALSE;
   return TRUE;
}

IMC_IGN *imc_newignore( void )
{
   IMC_IGN *ign;

   IMCCREATE( ign, IMC_IGN, 1 );
   ign->name = NULL;
   IMCLINK( ign, first_imc_ignore, last_imc_ignore, next, prev );
   return ign;
}

void imc_addignore( char *what )
{
   IMC_IGN *ign;

   ign = imc_newignore();
   ign->name = IMCSTRALLOC( what );
}

/* read an IMC rignores file */
void imc_readignores( void )
{
   FILE *inf;
   char *word;
   char temp[IMC_NAME_LENGTH];

   if( !( inf = fopen( IMC_IGNORE_FILE, "r" ) ) )
   {
      imcbug( "%s", "imc_readignores: couldn't open ignore file" );
      return;
   }

   word = imcfread_word( inf );
   if( strcasecmp( word, "#IGNORES" ) )
   {
	imcbug( "%s", "imc_readignores: Corrupt file" );
	IMCFCLOSE( inf );
	return;
   }

   while( !feof( inf ) && !ferror( inf ) )
   {
	imcstrlcpy( temp, imcfread_word( inf ), IMC_NAME_LENGTH );
	if( !strcasecmp( temp, "#END" ) )
	{
	   IMCFCLOSE( inf );
	   return;
	}
	imc_addignore( temp );
   }

   if( ferror( inf ) )
   {
      perror( "imc_readignores" );
      IMCFCLOSE( inf );
      return;
   }

   IMCFCLOSE( inf );
   return;
}

void imc_loadhistory( void )
{
   char filename[256];
   FILE *tempfile;
   IMC_CHANNEL *tempchan = NULL;
   int x;

   for( tempchan = first_imc_channel; tempchan; tempchan = tempchan->next )
   {
	if( !tempchan->local_name )
	   continue;

      snprintf( filename, 256, "%s/%s.hist", "../imc", tempchan->local_name );

      if( !( tempfile = fopen( filename, "r" ) ) )
	   continue;

      for( x = 0; x < MAX_IMCHISTORY; x++ )
      {
         if( feof( tempfile ) )
		tempchan->history[x] = NULL;
	   else
            tempchan->history[x] = IMCSTRALLOC( imcfread_line( tempfile ) );
	}
      IMCFCLOSE( tempfile );
	unlink( filename );
   }
}

void imc_savehistory( void )
{
   char filename[256];
   FILE *tempfile;
   IMC_CHANNEL *tempchan = NULL;
   int x;

   for( tempchan = first_imc_channel; tempchan; tempchan = tempchan->next )
   {
	if( !tempchan->local_name )
	   continue;

	if( !tempchan->history[0] )
	   continue;

	snprintf( filename, 256, "%s/%s.hist", "../imc", tempchan->local_name );

      if( !( tempfile = fopen( filename, "w" ) ) )
	   continue;

      for( x = 0; x < MAX_IMCHISTORY; x++ )
	{
	   if( tempchan->history[x] != NULL )
            fprintf( tempfile, "%s", tempchan->history[x] );
	}
      IMCFCLOSE( tempfile );
   }
}

void imc_startup( bool force )
{
   if( imc_active != IA_NONE )
   {
      imclog( "imc_startup: called with imc_active = %d", imc_active );
      return;
   }

   imc_now = time( NULL );                  /* start our clock */
   imc_boot = imc_now;

   imc_sequencenumber = imc_now;

   if( !imc_read_config() )
   {
	imc_active = IA_NONE;
	return;
   }

   if( !this_imcmud->autoconnect && !force )
   {
	imclog( "%s", "IMC2 data loaded. Autoconnect not set. IMC will need to be connected manually." );
	return;
   }

   imc_active = imc_name ? IA_CONFIG2 : IA_CONFIG1;

   if( imc_active == IA_CONFIG2 && ( this_imcmud->autoconnect || force ) )
   {
      if( imc_startup_network() )
	{
         imc_initchannels();
	   imc_loadhistory();
         imc_readignores();
	   return;
	}
	imc_active = IA_NONE;
   }
   return;
}

void imc_freechan( IMC_CHANNEL *c )
{
   int x;

   if( !c ) /* How? */
   {
	imcbug( "%s", "imc_freechan: Freeing NULL channel!" );
	return;
   }
   IMCUNLINK( c, first_imc_channel, last_imc_channel, next, prev );
   IMCSTRFREE( c->name );
   IMCSTRFREE( c->owner );
   IMCSTRFREE( c->operators );
   IMCSTRFREE( c->invited );
   IMCSTRFREE( c->excluded );
   IMCSTRFREE( c->local_name );
   IMCSTRFREE( c->regformat );
   IMCSTRFREE( c->emoteformat );
   IMCSTRFREE( c->socformat );

   for( x = 0; x < MAX_IMCHISTORY; x++ )
	IMCSTRFREE( c->history[x] );
   IMCDISPOSE( c );
   return;
}

void imc_shutdownchannels( void )
{
   IMC_CHANNEL *ic, *icnext;

   for( ic = first_imc_channel; ic; ic = icnext )
   {
	icnext = ic->next;

	imc_freechan( ic );
   }
}

void imc_shutdown_network( void )
{
   REMOTEINFO *p, *pnext;

   if( imc_active < IA_UP )
      return;

   imclog( "%s", "Shutting down network" );
   imclog( "rx %ld packets, %ld bytes", imc_stats.rx_pkts, imc_stats.rx_bytes );
   imclog( "tx %ld packets, %ld bytes", imc_stats.tx_pkts, imc_stats.tx_bytes );
   imclog( "largest packet %d bytes", imc_stats.max_pkt );
   imclog( "dropped %d packets by sequence number", imc_stats.sequence_drops );

   close( this_imcmud->desc );
   this_imcmud->desc = -1;

   imc_savehistory();
   imc_shutdownchannels();

   for( p = first_rinfo; p; p = pnext )
   {
      pnext = p->next;
	imc_delete_reminfo( p );
   }
   imc_active = IA_CONFIG2;
}

void imc_freeignore( IMC_IGN *ign )
{
   IMCSTRFREE( ign->name );
   IMCUNLINK( ign, first_imc_ignore, last_imc_ignore, next, prev );
   IMCDISPOSE( ign );
}

/* close down IMC */
void imc_shutdown( bool reconnect )
{
   IMC_IGN *ign, *ign_next;

   if( imc_active == IA_NONE )
      return;

   if( imc_active >= IA_UP )
      imc_shutdown_network( );

   for( ign = first_imc_ignore; ign; ign = ign_next )
   {
      ign_next = ign->next;
      imc_freeignore( ign );
   }
   imc_active = IA_NONE;

   if( reconnect )
   {
      imcwait = 100; /* About 20 seconds or so */
	imclog( "%s", "Connection to hub was lost. Reconnecting in approximately 20 seconds." );
   }
}

/* interpret an incoming packet using the right version */
PACKET *do_interpret_packet( char *line )
{
   int v;
   PACKET *p;

   if( !line[0] )
      return NULL;

   v = IMC_VERSION;

   p = (*imc_vinfo[v].interpret)(line);
   return p;
}

int imc_fill_fdsets( int maxfd, fd_set *iread, fd_set *iwrite, fd_set *exc )
{
   if( imc_active < IA_UP )
      return maxfd;

   /* set up fd_sets for select */

   if( maxfd < this_imcmud->desc )
      maxfd = this_imcmud->desc;

   switch( this_imcmud->state )
   {
      case IMC_CONNECTING:	/* connected/error when writable */
         FD_SET( this_imcmud->desc, iwrite );
         break;
      case IMC_CONNECTED:
      case IMC_WAIT1:
         FD_SET( this_imcmud->desc, iread );
         if( this_imcmud->outbuf && this_imcmud->outbuf[0] != '\0' )
	      FD_SET( this_imcmud->desc, iwrite );
         break;
   }
   return maxfd;
}

/* low-level idle function: read/write buffers as needed, etc */
void imc_idle_select( fd_set *iread, fd_set *iwrite, fd_set *exc, time_t now )
{
   char *command;
   PACKET *p;

   if( this_imcmud->desc < 1 )
	return;

   if( imc_active < IA_CONFIG1 )
      return;

   if( imc_sequencenumber < (unsigned long)imc_now )
      imc_sequencenumber = (unsigned long)imc_now;

   if( imc_active < IA_UP )
      return;

   /* handle results of the select */
   if( this_imcmud->state != IMC_CLOSED && FD_ISSET( this_imcmud->desc, exc ) )
   {
      imc_shutdown( TRUE );
	return;
   }

   if( this_imcmud->state != IMC_CLOSED && FD_ISSET( this_imcmud->desc, iread ) )
      do_imcread( );

   while( this_imcmud->state != IMC_CLOSED && ( command = imcgetline( this_imcmud->inbuf ) ) != NULL )
   {
      if( strlen( command ) > (unsigned int)imc_stats.max_pkt )
	   imc_stats.max_pkt = strlen( command );

      if( imcpacketdebug )
         imclog( "Packet received: %s", command );

      switch( this_imcmud->state )
      {
         case IMC_CLOSED:
	      break;
         case IMC_WAIT1:
	      serverpassword( command );
	      break;
         case IMC_CONNECTED:
	      p = do_interpret_packet( command );
	      if( p )
	      {
               REMOTEINFO *route;
		   bool keepgoing = TRUE;

	         imc_stats.rx_pkts++;

               /* check for duplication, and register the packet in the sequence memory */
               if( p->i.sequence && checkrepeat( imc_mudof( p->i.from ), p->i.sequence ) )
                  keepgoing = FALSE;

               /* check for packets we've already forwarded *
               if( keepgoing && inpath( p->i.path, imc_name ) )
                  keepgoing = FALSE; */

               /* check for really old packets */
               route = imc_find_reminfo( imc_mudof( p->i.from ), 1 );
               if( route && keepgoing )
               {
                  if( ( p->i.sequence + IMC_PACKET_LIFETIME ) < route->top_sequence )
                  {
                     imc_stats.sequence_drops++;
                     keepgoing = FALSE;
                  }
                  if( p->i.sequence > route->top_sequence )
                     route->top_sequence = p->i.sequence;
               }

               /* update our routing info */
               updateroutes( p->i.path );

               /* Receive it if it's for us, otherwise it gets silently dropped */
               if( keepgoing && ( !strcasecmp( imc_mudof( p->i.to ), "*" ) || !strcasecmp( imc_mudof( p->i.to ), imc_name ) ) )
               {
                  imcstrlcpy( p->to, imc_nameof( p->i.to ), IMC_NAME_LENGTH );    /* strip the name from the 'to' */
                  imcstrlcpy( p->from, p->i.from, IMC_NAME_LENGTH );

                  imc_recv( p );
               }
	         imc_freedata( p );
	      }
	      break;
      }
   }

   if( this_imcmud->desc > 0 ) /* Something could have caused shutdown during reading */
   {
      if( this_imcmud->state != IMC_CLOSED && ( FD_ISSET( this_imcmud->desc, iwrite ) || this_imcmud->newoutput ) )
      {
         do_imcwrite( );
         this_imcmud->newoutput = this_imcmud->outbuf[0];
         if( imc_siteinfo.disconnect == TRUE )
            imc_shutdown( FALSE );
      }
   }
}

void imc_loop( void )
{
   fd_set in_set, out_set, exc_set;
   static struct timeval null_time;
   int maxdesc = 0;

#ifdef IMCCIRCLE
   current_time = time(NULL);
#endif

   if( imcwait > 0 )
      imcwait--;

   /* Condition reached only if network shutdown after startup */
   if( imcwait == 1 )
   {
      imcconnect_attempts++;
      if( imcconnect_attempts > 5 )
      {
         imcwait = -2;
         imclog( "Unable to reestablish connection to %s. Abandoning reconnect.", this_imcmud->hubname );
         return;
      }
	imc_startup( TRUE );
	return;
   }

   if( imc_active == IA_NONE || this_imcmud->desc == -1 )
	return;

   FD_ZERO( &in_set  );
   FD_ZERO( &out_set );
   FD_ZERO( &exc_set );

   maxdesc = imc_fill_fdsets( maxdesc, &in_set, &out_set, &exc_set );
   if( select( maxdesc+1, &in_set, &out_set, &exc_set, &null_time ) < 0 )
   {
	perror( "imc_loop: select: poll" );
	imc_shutdown( TRUE );
	return;
   }
   imc_idle_select( &in_set, &out_set, &exc_set, current_time );
   return;
}

IMC_CHANNEL *imc_findchannel( char *name )
{
   IMC_CHANNEL *c;

   for( c = first_imc_channel; c; c = c->next )
      if( !strcasecmp( c->name, name ) )
         return c;
   return NULL;
}

IMC_CHANNEL *imc_findlchannel( char *name )
{
   IMC_CHANNEL *c;

   for( c = first_imc_channel; c; c = c->next )
      if( c->local_name && !strcasecmp( c->local_name, name ) )
         return c;
  return NULL;
}

void imc_recv_msg_r( char *from, char *realfrom, char *chan, char *txt, int emote )
{
   IMC_CHANNEL *c;
   char *mud;

   mud = imc_mudof( from );

   /* forged? */
   if( !strchr( chan, ':' ) || strcasecmp( mud, channel_mudof( chan ) ) )
      return;

   c = imc_findchannel( chan );
   if( !c )
      return;

   if( !c->local_name || ( c->open ) )
      return;

   /* We assume that anything redirected is automatically audible - since we trust the hub... 
    * What's all this *WE* business? *I* don't trust it :)
    */
   imc_showchannel( c, realfrom, txt, emote );
}

void imc_recv_msg_b( char *from, char *chan, char *txt, int emote, char *sender )
{
   IMC_CHANNEL *c;

   c = imc_findchannel( chan );
   if( !c )
      return;

   if( !c->local_name || !c->open )
      return;

   if( sender && sender[0] != '\0' )
      imc_showchannel( c, sender, txt, emote );
   else
      imc_showchannel( c, from, txt, emote );
}

void imc_recv_update( char *from, char *chan, char *owner, char *operators, char *policy, char *invited, char *excluded, char *level )
{
   IMC_CHANNEL *c;
   char *mud;

   mud = imc_mudof( from );

   /* forged? */
   if( !strchr( chan, ':' ) || strcasecmp( mud, channel_mudof( chan ) ) )
      return;

   c = imc_findchannel( chan );

   if( !c )
   {
      int value = get_imcpermvalue( level );
      if( value < 0 || value > TRUE )
         value = TRUE;

	IMCCREATE( c, IMC_CHANNEL, 1 );
      c->name = IMCSTRALLOC( chan );
      c->owner = IMCSTRALLOC( owner );
      c->operators = IMCSTRALLOC( operators );
      c->invited = IMCSTRALLOC( invited );
      c->excluded = IMCSTRALLOC( excluded );
      c->local_name = NULL;
	c->level = value;
	c->refreshed = TRUE;
	IMCLINK( c, first_imc_channel, last_imc_channel, next, prev );
   }
   else
   {
      IMCSTRFREE( c->name );
      IMCSTRFREE( c->owner );
      IMCSTRFREE( c->operators );
      IMCSTRFREE( c->invited );
      IMCSTRFREE( c->excluded );
      c->name = IMCSTRALLOC( chan );
      c->owner = IMCSTRALLOC( owner );
      c->operators = IMCSTRALLOC( operators );
      c->invited = IMCSTRALLOC( invited );
      c->excluded = IMCSTRALLOC( excluded );
	c->refreshed = TRUE;
   }

   /* 3.20+ only supports open and private. Anything not one of these becomes private. */
   if( !strcasecmp( policy, "open" ) )
      c->open = TRUE;
   else
      c->open = FALSE;
}

void imc_save_channels( void )
{
   IMC_CHANNEL *c;
   FILE *fp;
   char name[LGST];

   imcstrlcpy( name, IMC_CHANNEL_FILE, LGST );

   fp = fopen( name, "w" );
   if( !fp )
   {
      imcbug( "Can't write to %s", name );
      return;
   }
  
   for( c = first_imc_channel; c; c = c->next )
   {
	if( !c->local_name || c->local_name[0] == '\0' )
	   continue;

      fprintf( fp, "%s", "#IMCCHAN\n" );
	fprintf( fp, "ChanName   %s~\n", c->name );
	fprintf( fp, "ChanLocal  %s~\n", c->local_name );
	fprintf( fp, "ChanRegF   %s~\n", c->regformat );
	fprintf( fp, "ChanEmoF   %s~\n", c->emoteformat );
	fprintf( fp, "ChanSocF   %s~\n", c->socformat );
	fprintf( fp, "ChanLevel  %d\n",  c->level );
	fprintf( fp, "%s", "End\n\n" );
   }
   fprintf( fp, "%s", "#END\n" );
   IMCFCLOSE( fp );
}

void imc_recv_destroy( char *from, char *channel )
{
   IMC_CHANNEL *c;
   char *mud;

   mud = imc_mudof( from );

   if( !strchr( channel, ':' ) || strcasecmp( mud, channel_mudof( channel ) ) )
      return;

   c = imc_findchannel( channel );
   if( !c )
      return;

   imc_freechan( c );
   imc_save_channels();
}

int imc_recv_chan( PACKET *p, int bcast )
{
   /* redirected msg */
   if( !strcasecmp( p->type, "ice-msg-r" ) )
   {
      imc_recv_msg_r( p->from, imc_getkey( p, "realfrom", "" ), imc_getkey( p, "channel", "" ),
	   imc_getkey( p, "text", "" ), imc_getkeyi( p, "emote", 0 ) );
        return 1;
   }
   else if( !strcasecmp( p->type, "ice-msg-b" ) )
   {
      imc_recv_msg_b( p->from, imc_getkey( p, "channel", "" ), imc_getkey( p, "text", "" ),
         imc_getkeyi( p, "emote", 0 ), imc_getkey( p, "sender", "" ) );
      return 1;
   }
   else if( !strcasecmp( p->type, "ice-update" ) )
   {
      imc_recv_update( p->from, imc_getkey( p, "channel", "" ), imc_getkey( p, "owner", "" ),
         imc_getkey( p, "operators", "" ), imc_getkey( p, "policy", ""),
         imc_getkey( p, "invited", "" ), imc_getkey( p, "excluded", "" ),
         imc_getkey( p, "level", "" ) );
      return 1;
   }
   else if( !strcasecmp( p->type, "ice-destroy" ) )
   {
      imc_recv_destroy( p->from, imc_getkey( p, "channel", "" ) );
      return 1;
   }
   else
      return 0;
}

void imc_readchannel( IMC_CHANNEL *channel, FILE *fp )
{
   const char *word;
   bool fMatch;

   for ( ; ; )
   {
	word   = feof( fp ) ? "End" : imcfread_word( fp );
	fMatch = FALSE;

	switch( UPPER(word[0]) )
	{
	  case '*':
	    fMatch = TRUE;
	    imcfread_to_eol( fp );
	    break;

	  case 'C':
		IMCKEY( "ChanName",		channel->name,		imcfread_string( fp ) );
		IMCKEY( "ChanLocal",		channel->local_name,	imcfread_string( fp ) );
		IMCKEY( "ChanRegF",		channel->regformat,	imcfread_string( fp ) );
		IMCKEY( "ChanEmoF",		channel->emoteformat,	imcfread_string( fp ) );
		IMCKEY( "ChanSocF",		channel->socformat,	imcfread_string( fp ) );
		IMCKEY( "ChanLevel",		channel->level,		imcfread_number( fp ) );
		break;

	  case 'E':
	      if ( !strcasecmp( word, "End" ) )
            {
		   /* Legacy support to convert channel permissions */
		   if( channel->level > TRUE )
		   {
			/* The IMCPERM_NONE condition should realistically never happen.... */
      		if( channel->level < imc_minlevel )
	   		   channel->level = IMCPERM_NONE;
      		else if( channel->level >= imc_minlevel && channel->level < imc_immlevel )
	   		   channel->level = FALSE;
      		else if( channel->level >= imc_immlevel && channel->level < imc_adminlevel )
	   		   channel->level = TRUE;
      		else if( channel->level >= imc_adminlevel && channel->level < imc_implevel )
	   		   channel->level = TRUE;
      		else if( channel->level >= imc_implevel )
	   		   channel->level = TRUE;
		   }
            }
		return;
	    break;
	}

	if( !fMatch )
	    imcbug( "imc_readchannel: no match: %s", word );
   }
}

void imc_loadchannels( void )
{
   FILE *fp;
   IMC_CHANNEL *channel;

   first_imc_channel = NULL;
   last_imc_channel = NULL;

   fp = fopen( IMC_CHANNEL_FILE, "r" );
   if( !fp )
   {
      imcbug( "%s", "Can't open imc channel file" );
      return;
   }

   for ( ; ; )
   {
	char letter;
	char *word;

	letter = imcfread_letter( fp );
	if ( letter == '*' )
	{
	   imcfread_to_eol( fp );
	   continue;
	}

	if( letter != '#' )
	{
	   imcbug( "%s", "imc_loadchannels: # not found." );
	   break;
	}

      word = imcfread_word( fp );
	if ( !strcasecmp( word, "IMCCHAN" ) )
	{
	   int x;

	   IMCCREATE( channel, IMC_CHANNEL, 1 );
	   imc_readchannel( channel, fp );

	   for( x = 0; x < MAX_IMCHISTORY; x++ )
		channel->history[x] = NULL;

	   channel->refreshed = FALSE; /* Prevents crash trying to use a bogus channel */
	   IMCLINK( channel, first_imc_channel, last_imc_channel, next, prev );
         imclog( "configured %s as %s", channel->name, channel->local_name );
	   continue;
	}
	else
         if ( !strcasecmp( word, "END"	) )
	        break;
	else
	{
	   imcbug( "imc_loadchannels: bad section: %s.", word );
	   continue;
	}
    }
    IMCFCLOSE( fp );
    return;
}

/* global init */
void imc_initchannels( void )
{
   imclog( "%s", "IMC Channel client starting..." );

   imc_recv_chain = imc_recv_hook;
   imc_recv_hook = imc_recv_chan;

   imc_loadchannels();
}

/* need exactly 2 %s's, and no other format specifiers */
bool verify_format( const char *fmt, short sneed )
{
   const char *c;
   int i = 0;

   c = fmt;
   while( ( c = strchr( c, '%' ) ) != NULL )
   {
      if( *( c + 1 ) == '%' )  /* %% */
      {
         c += 2;
         continue;
      }
    
      if( *( c + 1 ) != 's' )  /* not %s */
         return FALSE;

      c++;
      i++;
   }
   if( i != sneed )
      return FALSE;

   return TRUE;
}

void imccommand( PLAYER_DATA *ch, char *argument )
{
   char cmd[IMC_NAME_LENGTH];
   char chan[IMC_NAME_LENGTH];
   char data[IMC_DATA_LENGTH];
   char *p;
   PACKET out;
   IMC_CHANNEL *c;

   p = imc_getarg( argument, cmd, IMC_NAME_LENGTH );
   p = imc_getarg( p, chan, IMC_NAME_LENGTH );
   imcstrlcpy( data, p, IMC_DATA_LENGTH );

   if( !cmd[0] || !chan[0] )
   {
      imc_to_char( "Syntax: imccommand <command> <node:channel> [<data..>]\n\r", ch );
	return;
   }

   p = strchr( chan, ':' );
   if( !p )
   {
      c = imc_findlchannel( chan );
      if( c )
         imcstrlcpy( chan, c->name, IMC_NAME_LENGTH );
   }

   snprintf( out.to, IMC_NAME_LENGTH, "IMC@%s", channel_mudof( chan ) );
   imcstrlcpy( out.type, "ice-cmd", IMC_TYPE_LENGTH );
   imcstrlcpy( out.from, CH_IMCNAME(ch), IMC_NAME_LENGTH );
   imc_initdata( &out );
   imc_addkey( &out, "channel", chan );
   imc_addkey( &out, "command", cmd );
   imc_addkey( &out, "data", data );

   imc_send( &out );
   imc_freedata( &out );

   imc_to_char( "Command sent.\n\r", ch );
   return;
}

void imcsetup( PLAYER_DATA *ch, char *argument )
{
   char imccmd[IMC_NAME_LENGTH];
   char chan[IMC_NAME_LENGTH];
   char arg1[IMC_DATA_LENGTH];
   char buf[LGST];
   IMC_CHANNEL *c;
   char *a, *a1;
  
   a = imc_getarg( argument, imccmd, IMC_NAME_LENGTH );
   a = a1 = imc_getarg( a, chan, IMC_NAME_LENGTH );
   a = imc_getarg( a, arg1, IMC_DATA_LENGTH );

   if( !imccmd || imccmd[0] == '\0' || !chan || chan[0] == '\0' )
   {
      imc_to_char( "Syntax: imcsetup <command> <channel> [<data..>]\n\r", ch );
	imc_to_char( "Where 'command' is one of the following:\n\r", ch );
	imc_to_char( "delete setlocal rename perm regformat emoteformat socformat\n\r", ch );
      return;
   }

   c = imc_findchannel( chan );
   if( !c )
   {
      c = imc_findlchannel( chan );

      if( !c )
      {
         imc_to_char( "Unknown channel.\n\r", ch );
         return;
      }
   }

   /* Permission check -- Xorith */
   if( c->level > IMCPERM(ch) )
   {
	imc_to_char( "You cannot modify that channel.", ch );
	return;
   }

   /* Support for "add" argument put back for legacy isetup users */
   if( !strcasecmp( imccmd, "setlocal" ) || !strcasecmp( imccmd, "add" ) )
   {
	if( c->local_name && c->local_name[0] != '\0' )
	{
	   imc_printf( ch, "Channel %s is already locally configured as %s\n\r", c->name, c->local_name );
	   return;
	}
      if( !arg1 || arg1[0] == '\0' )
      {
         imc_to_char( "You must specify a local channel name to complete this setup.\n\r", ch );
         return;
      }
	c->local_name = IMCSTRALLOC( arg1 );
	snprintf( buf, LGST, "&R[&Y%s&R] &C%%s: &c%%s", c->local_name );
	IMCSTRFREE( c->regformat );
	c->regformat = IMCSTRALLOC( buf );
	snprintf( buf, LGST, "&R[&Y%s&R] &c%%s %%s", c->local_name );
	IMCSTRFREE( c->emoteformat );
	c->emoteformat = IMCSTRALLOC( buf );
	snprintf( buf, LGST, "&R[&Y%s&R] &c%%s", c->local_name );
	IMCSTRFREE( c->socformat );
	c->socformat = IMCSTRALLOC( buf );
	imc_printf( ch, "Channel %s is now locally configured as %s\n\r", c->name, c->local_name );
	imc_save_channels();
	return;
   }

   if( !strcasecmp( imccmd, "delete" ) )
   {
      imc_freechan( c );

      imc_to_char( "Channel is no longer configured.\n\r", ch );
      imc_save_channels();
      return;
   }

   if( !strcasecmp( imccmd, "rename" ) )
   {
      if( !arg1 || arg1[0] == '\0' )
      {
          imc_to_char( "Missing 'newname' argument for 'imcsetup rename'\n\r", ch ); /* Lets be more kind! -- X */
          imc_to_char( "Syntax: imcsetup rename <local channel> <newname>\n\r", ch ); /* Fixed syntax message -- X */
          return;
      }

      if( imc_findlchannel( arg1 ) )
      {
         imc_to_char( "New channel name already exists.\n\r", ch );
         return;
      }

      /* Small change here to give better feedback to the ch -- Xorith */
      snprintf( buf, LGST, "Renamed channel '%s' to '%s'.\n\r", c->local_name, arg1 );
      IMCSTRFREE( c->local_name );
      c->local_name = IMCSTRALLOC( arg1 );
      imc_to_char( buf, ch );
      imc_save_channels();
      return;
   }

   if( !strcasecmp( imccmd, "regformat" ) )
   {
      if( !a1[0] )
      {
         imc_to_char( "Syntax: imcsetup regformat <localchannel> <string>\n\r", ch ); /* Syntax Fix -- Xorith */
         return;
      }

      if( !verify_format( a1, 2 ) )
      {
         imc_to_char("Bad format - must contain exactly 2 %s's.\n\r", ch );
         return;
      }

      IMCSTRFREE( c->regformat );
      c->regformat = IMCSTRALLOC( a1 );
      imc_to_char( "The regular format for this channel has been changed successfully.\n\r", ch );

      imc_save_channels();
      return;
   }

   if( !strcasecmp( imccmd, "emoteformat" ) )
   {
      if( !a1[0] )
      {
         imc_to_char( "Syntax: imcsetup emoteformat <localchannel> <string>\n\r", ch ); /* Syntax Fix -- Xorith */
         return;
      }

      if( !verify_format( a1, 2 ) )
      {
         imc_to_char( "Bad format - must contain exactly 2 %s's.\n\r", ch );
         return;
      }

      IMCSTRFREE( c->emoteformat );
      c->emoteformat = IMCSTRALLOC( a1 );
      imc_to_char( "The emote format for this channel has been changed successfully.\n\r", ch );

      imc_save_channels();
      return;
   }

   if( !strcasecmp( imccmd, "socformat" ) )
   {
      if( !a1[0] )
      {
         imc_to_char( "Syntax: imcsetup socformat <localchannel> <string>\n\r", ch ); /* Xorith */
         return;
      }
             
      if( !verify_format( a1, 1 ) )
      {
         imc_to_char( "Bad format - must contain exactly 1 %s.\n\r", ch );
         return;
      }
      
      IMCSTRFREE( c->socformat );
      c->socformat = IMCSTRALLOC( a1 );
      imc_to_char( "The social format for this channel has been changed successfully.\n\r", ch );
   
      imc_save_channels();
      return;
   }

   if( !strcasecmp( imccmd, "perm" ) || !strcasecmp( imccmd, "permission" ) )
   {
      int permvalue = -1;
      if( !arg1[0] )
      {
         imc_to_char( "Syntax: imcsetup level <localchannel> <permission>\n\r", ch );
         return;
      }

      permvalue = get_imcpermvalue( arg1 );
      if( permvalue < 0 || permvalue > TRUE )
      {
	   imc_to_char( "Unacceptable permission setting.\n\r", ch );
         return;
      }

      /* Added permission checking here -- Xorith */
      if( permvalue > IMCPERM(ch) )
      {
	   imc_to_char( "You cannot set a permission higher than your own.\n\r", ch );
	   return;
	}

      c->level = permvalue;

      imc_to_char( "Channel permissions changed.\n\r", ch );
      imc_save_channels();
      return;
   }

   imcsetup( ch, "" );
   return;
}

void imcchanlist( PLAYER_DATA *ch, char *argument )
{
   char buf[LGST];
   char *polly;
   IMC_CHANNEL *c;
   int count = 0;  /* Count -- Xorith */
   char col = 'C'; /* Listening Color -- Xorith */

   if( argument && argument[0] != '\0' )
   {
      c = imc_findlchannel( argument );
      if( !c )
         c = imc_findchannel( argument );

      if( !c )
      {
         imc_to_char( "No such channel.\n\r", ch );
         return;
      }

      if( IMCPERM(ch) < c->level )
      {
         imc_to_char( "No such channel.\n\r", ch );
         return;
      }

      if( !c->refreshed )
      {
         imc_to_char( "%s channel has not been refreshed yet.\n\r", ch );
         return;
      }

      if( c->open )
         polly = "~gOpen";
      else
      polly = "~yPrivate";

      snprintf( buf, LGST,
         "~WChannel %s:\n\r"
         "~c Local name: ~w%s\n\r"
         "~c Regformat : ~w%s\n\r"
         "~c Emformat  : ~w%s\n\r"
         "~c Socformat : ~w%s\n\r"
         "~c Perms     : ~w%s\n\r"
         "\n\r"
         "~c Policy    : ~w%s\n\r"
         "~c Owner     : ~w%s\n\r"
         "~c Operators : ~w%s\n\r"
         "~c Invited   : ~w%s\n\r"
         "~c Excluded  : ~w%s\n\r",

         c->name, c->local_name ? c->local_name : "", c->regformat ? c->regformat : "",
         c->emoteformat ? c->emoteformat : "", c->socformat ? c->socformat : "",
         imcperm_names[c->level], polly, c->owner, c->operators, c->invited, c->excluded );
      imc_to_char( color_itom(buf), ch );
      return;
   }

   /* added level to the display for ilist with no arguments for 2.00 - shogar - /1/26/2000 */
   snprintf( buf, LGST, "~c%-15s ~C%-15s ~B%-15s ~b%-7s ~!%s\n\r", "Name",
      "Local name", "Owner", "Perm", "Policy" );

   for( c = first_imc_channel; c; c = c->next )
   {
      if( IMCPERM(ch) < c->level )
         continue;

      if( c->refreshed )
      {
         if( c->open )
            polly = "~gOpen";
         else
            polly = "~yPrivate";
      }
      else
         polly = "~Runknown";

      /* If it's locally configured and we're not listening, then color it red -- Xorith */
      if( c->local_name )
      {
         if( !imc_hasname( IMC_LISTEN(ch), c->local_name ) )
            col = 'R';
         else
            col = 'C'; /* Otherwise, keep it Cyan -- X */
      }

      snprintf( buf+strlen(buf), LGST,
         "~c%-15.15s ~%c%-*.*s ~B%-15.15s ~b%-7s %s\n\r", c->name, col,
         c->local_name ? 15 : 17, c->local_name ? 15 : 17,
         c->local_name ? c->local_name : "~Y(not local)  ", c->owner,
         imcperm_names[c->level], polly );
      count++; /* Keep a count -- Xorith */
   }
   /* Show the count and a bit of text explaining the red color -- Xorith */
   snprintf( buf+strlen(buf), LGST, "\n\r~W%d ~cchannels found." , count );
   imcstrlcat( buf+strlen(buf), "\n\r~RRed ~clocal name indicates a channel not being listened to.\n\r", LGST );
   imc_to_pager( color_itom( buf ), ch );
}

void imclisten( PLAYER_DATA *ch, char *argument )
{
   IMC_CHANNEL *c;

   if( !argument || argument[0] == '\0' )
   {
      imc_to_char( "Currently tuned into:\n\r", ch );
	if( IMC_LISTEN(ch) && IMC_LISTEN(ch)[0] != '\0' )
         imc_to_char( IMC_LISTEN(ch), ch );
	else
	   imc_to_char( "None", ch );
      imc_to_char( "\n\r", ch );
      return;
   }

   if( !str_cmp( argument, "all" ) )
   {
	for( c = first_imc_channel; c; c = c->next )
	{
         if( !c->local_name )
            continue;

	   if( IMCPERM(ch) >= c->level && !imc_hasname( IMC_LISTEN(ch), c->local_name ) )
		imc_addname( &IMC_LISTEN(ch), c->local_name );
	}
	imc_to_char( "&YYou are now listening to all available IMC2 channels.\n\r", ch );
	return;		
   }

   if( !str_cmp( argument, "none" ) )
   {
	for( c = first_imc_channel; c; c = c->next )
	{
         if( !c->local_name )
            continue;

	   if( imc_hasname( IMC_LISTEN(ch), c->local_name ) )
		imc_removename( &IMC_LISTEN(ch), c->local_name );
	}
	imc_to_char( "&YYou no longer listen to any available IMC2 channels.\n\r", ch );
	return;
   }

   smash_tilde( argument );

   if( !( c = imc_findlchannel( argument ) ) )
   {
      imc_to_char( "No such channel configured locally.\n\r", ch );
      return;
   }

   if( IMCPERM(ch) < c->level )
    {
      imc_to_char( "No such channel configured locally.\n\r", ch );
      return;
   }

   if( imc_hasname( IMC_LISTEN(ch), c->local_name ) )
   {
      imc_removename( &IMC_LISTEN(ch), c->local_name );
      imc_to_char( "Channel off.\n\r", ch );
   }
   else
   {
      imc_addname( &IMC_LISTEN(ch), c->local_name );
      imc_to_char( "Channel on.\n\r", ch );
      imc_sendmessage( c, CH_IMCNAME(ch), "enters the channel.", 1 );
      
   }
}

/* Revised 10/10/03 by Xorith: Recognize the need to capitalize for a new�sentence. */
char *imc_act_string( const char *format, PLAYER_DATA *ch, char *vname )
{
   static char * const he_she  [] = { "it",  "he",  "she" };
   static char * const him_her [] = { "it",  "him", "her" };
   static char * const his_her [] = { "its", "his", "her" };
   static char buf[LGST];
   char tmp_str[LGST];
   const char *i = "";
   char *point;
   bool should_upper = FALSE;

   if( !format || format[0] == '\0' || !ch )
      return NULL;

   point = buf;

   while( *format != '\0' )
   {
      if( *format == '.' || *format == '?' || *format == '!' )
         should_upper = TRUE;
      else if ( should_upper == TRUE && !isspace( *format ) && *format != '$' )
         should_upper = FALSE;

      if( *format != '$' )
      {
         *point++ = *format++;
         continue;
      }
      ++format;

      if( ( !vname || vname[0] == '\0' ) && ( *format == 'N' || *format == 'E' 
       || *format == 'M' || *format == 'S' || *format == 'K' ) )
         i = " !!!!! ";
      else
      {
         switch( *format )
         {
            default:  i = " !!!!! "; break;
            case 'n': i = imc_makename( CH_IMCNAME(ch), imc_name, FALSE ); break;
            case 'N': i = vname; break;
            case 'e': i = should_upper ? 
               imccapitalize( he_she[URANGE(0,CH_IMCSEX(ch), 2)] ) : he_she[URANGE(0, CH_IMCSEX(ch), 2)];
            break;
            case 'E': i = should_upper ? "It" : "it"; break;
            case 'm': i = should_upper ? 
               imccapitalize( him_her[URANGE(0,CH_IMCSEX(ch), 2)] ) : him_her[URANGE(0, CH_IMCSEX(ch), 2)];
            break;
            case 'M': i = should_upper ? "It" : "it"; break;
            case 's': i = should_upper ? 
               imccapitalize( his_her[URANGE(0,CH_IMCSEX(ch), 2)] ) : his_her[URANGE(0, CH_IMCSEX(ch), 2)];
            break;
            case 'S': i = should_upper ? "Its" : "its"; break;
            case 'k': one_argument( CH_IMCNAME(ch), tmp_str ); i = (char *) tmp_str; break;
            case 'K': one_argument( vname, tmp_str ); i = (char *) tmp_str; break;
         }
      }
      ++format;
      while( ( *point = *i ) != '\0' )
         ++point, ++i;
   }
   *point = 0;
   point++;
   *point = '\0';

   buf[0] = UPPER( buf[0] );
   return buf;
}

void imc_save_config( void )
{
   FILE *fp;

   if( ( fp = fopen( IMC_CONFIG_FILE, "w" ) ) == NULL ) 
   {
	imclog( "%s", "Couldn't write to config file." );
	return;
   }

   fprintf( fp, "%s", "$IMCCONFIG\n\n" );
   fprintf( fp, "# This is the IMC2 %s MUD-Net version of the IMC2 config file.\n", IMC_VERSIONID );
   fprintf( fp, "%s", "# It should be much more reliable than the previous format.\n" );
   fprintf( fp, "%s", "# When changing this information, be sure you don't remove the tildes!\n" );
   fprintf( fp, "%s", "# This information can be edited online using the 'imc' command.\n" );
   fprintf( fp, "LocalName    %s~\n", imc_name );
   fprintf( fp, "Autoconnect  %d\n",  this_imcmud->autoconnect );
   fprintf( fp, "Minlevel     %d\n",  imc_minlevel );
   fprintf( fp, "Immlevel     %d\n",  imc_immlevel );
   fprintf( fp, "Adminlevel   %d\n",  imc_adminlevel );
   fprintf( fp, "Implevel     %d\n",  imc_implevel );
   fprintf( fp, "InfoName     %s~\n", imc_siteinfo.name );
   fprintf( fp, "InfoHost     %s~\n", imc_siteinfo.host );
   fprintf( fp, "InfoPort     %d\n",  imc_siteinfo.port );
   fprintf( fp, "InfoEmail    %s~\n", imc_siteinfo.email );
   fprintf( fp, "InfoWWW      %s~\n", imc_siteinfo.www );
   fprintf( fp, "InfoBase     %s~\n", imc_siteinfo.base );
   fprintf( fp, "InfoDetails  %s~\n\n", imc_siteinfo.details );
   fprintf( fp, "%s", "# Your connection information goes here.\n" );
   fprintf( fp, "ConnectName   %s~\n", this_imcmud->hubname );
   fprintf( fp, "ConnectAddr   %s~\n", this_imcmud->host );
   fprintf( fp, "ConnectPort   %d\n",  this_imcmud->port );
   fprintf( fp, "ConnectPwd1   %s~\n", this_imcmud->clientpw );
   fprintf( fp, "ConnectPwd2   %s~\n", this_imcmud->serverpw );
   fprintf( fp, "%s", "End\n\n" );
   fprintf( fp, "%s", "$END\n" );
   IMCFCLOSE( fp );
   return;
}

/* Save current mud-level ignore list. Short, simple. */
void imc_saveignores( void )
{
   FILE *out;
   IMC_IGN *ign;

   if( !( out = fopen( IMC_IGNORE_FILE, "w" ) ) )
   {
      imcbug( "%s", "imc_saveignores: error opening ignore file for write" );
      return;
   }

   fprintf( out, "%s", "#IGNORES\n" );

   for( ign = first_imc_ignore; ign; ign = ign->next )
      fprintf( out, "%s\n", ign->name );

   fprintf( out, "%s", "#END\n" );

   IMCFCLOSE( out );
   return;
}

bool imc_delignore( char *what )
{
   IMC_IGN *ign, *ign_next;

   for( ign = first_imc_ignore; ign; ign = ign_next )
   {
      ign_next = ign->next;
      if( !strcasecmp( what, ign->name ) )
      {
         imc_freeignore( ign );
         return TRUE;
      }
   }
   return FALSE;
}

/* send a who-request to a remote mud */
void imc_send_who( imc_actor_data *from, char *to, char *type )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;

   if( !strcasecmp( imc_mudof( to ), "*" ) )
      return; /* don't let them do this */

   setdata( &out, from );

   snprintf( out.to, IMC_NAME_LENGTH, "*@%s", to );
   imcstrlcpy( out.type, "who", IMC_TYPE_LENGTH );

   imc_addkey( &out, "type", type );

   imc_send( &out );
   imc_freedata( &out );
}

/* send a whois-request to a remote mud */
void imc_send_whois( imc_actor_data *from, char *to )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;

   if( strchr( to, '@' ) )
      return;

   setdata( &out, from );

   snprintf( out.to, IMC_NAME_LENGTH, "%s@*", to );
   imcstrlcpy( out.type, "whois", IMC_TYPE_LENGTH );

   imc_send( &out );
   imc_freedata( &out );
}

/* beep a remote player */
void imc_send_beep( imc_actor_data *from, char *to )
{
   PACKET out;

   if( imc_active < IA_UP )
      return;

   if( !strcasecmp( imc_mudof( to ), "*" ) )
      return; /* don't let them do this */

   setdata( &out, from );
   imcstrlcpy( out.type, "beep", IMC_TYPE_LENGTH );
   imcstrlcpy( out.to, to, IMC_NAME_LENGTH );

   imc_send( &out );
   imc_freedata( &out );
}

void imctell( PLAYER_DATA *ch, char *argument )
{
   char buf[LGST], buf1[LGST];
   imc_actor_data *chdata = imc_getdata( ch );

   if( IMCIS_SET( IMCFLAG(ch), IMC_DENYTELL ) )
   {
      imc_to_char( "You are not authorized to use imctell.\n\r", ch );
      return;
   }

   argument = one_argument( argument, buf );

   if( !argument || argument[0] == '\0' )
   {
	imc_to_char( "Usage: imctell user@mud <message>\n\r", ch );
	imc_to_char( "Usage: imctell [on]/[off]\n\r", ch );
	return;
   }

   if( !strcasecmp( argument, "on" ) )
   {
	IMCREMOVE_BIT( IMCFLAG(ch), IMC_TELL );
	imc_to_char( "You now send and receive imctells.\n\r", ch );
	return;
   }

   if( !strcasecmp( argument, "off" ) )
   {
	IMCSET_BIT( IMCFLAG(ch), IMC_TELL );
	imc_to_char( "You no longer send and receive imctells.\n\r", ch );
	return;
   }

   if( IMCIS_SET( IMCFLAG(ch), IMC_TELL ) )
   {
      imc_to_char( "You have imctells turned off.\n\r", ch );
      return;
   }

   if( IMCISINVIS(ch) )
   {
      imc_to_char( "You are invisible.\n\r", ch );
      return;
   }

   CHECKMUDOF( ch, buf );
   imc_send_tell( chdata, buf, color_mtoi(argument), 0 );
  
   snprintf( buf1, LGST, color_itom( "~cYou imctell ~C%s ~c'~W%s~c'~!\n\r" ), buf, argument );
   imc_to_char( buf1, ch );
   IMCDISPOSE( chdata );
}

void imcreply( PLAYER_DATA *ch, char *argument )
{
   char buf1[LGST];
   imc_actor_data *chdata = imc_getdata( ch );

   /* just check for deny */
   if( IMCIS_SET( IMCFLAG(ch), IMC_DENYTELL ) )
   {
      imc_to_char( "You are not authorized to use imcreply.\n\r", ch );
      return;
   }

   if( IMCIS_SET( IMCFLAG(ch), IMC_TELL ) )
   {
      imc_to_char( "You have imctells turned off.\n\r", ch );
      return;
   }

   if( IMCISINVIS(ch) )
   {
      imc_to_char( "You are invisible.\n\r", ch );
      return;
   }

   if( !IMC_RREPLY(ch) )
   {
      imc_to_char( "You haven't received an imctell yet.\n\r", ch );
      return;
   }

   if( !argument || argument[0] == '\0' )
   {
      imc_to_char( "imcreply what?\n\r", ch );
      return;
   }

   CHECKMUDOF( ch, IMC_RREPLY(ch) );
   imc_send_tell( chdata, IMC_RREPLY(ch), color_mtoi(argument), 1 );

   snprintf( buf1, LGST, color_itom( "~cYou imctell ~C%s ~c'~W%s~c'~!\n\r" ), IMC_RREPLY_NAME(ch), argument );
   imc_to_char( buf1, ch );
   IMCDISPOSE( chdata );
}

void imcwho( PLAYER_DATA *ch, char *argument )
{
   imc_actor_data *chdata = imc_getdata( ch );

   if( !argument || argument[0] == '\0' )
   {
      imc_to_char( "imcwho which mud? See imclist for a list of connected muds.\n\r", ch );
      return;
   }
  
   CHECKMUD( ch, argument );
   imc_send_who( chdata, argument, "who" );
   IMCDISPOSE( chdata );
}

void imclocate( PLAYER_DATA *ch, char *argument )
{
   imc_actor_data *chdata = imc_getdata( ch );

   if( !argument || argument[0] == '\0' )
   {
      imc_to_char( "imclocate who?\n\r", ch );
      return;
   }

   imc_send_whois( chdata, argument );
   IMCDISPOSE( chdata );
}

void imcfinger( PLAYER_DATA *ch, char *argument )
{
   char name[LGST];
   imc_actor_data *chdata = imc_getdata( ch );

   if( IMCIS_SET( IMCFLAG(ch), IMC_DENYFINGER ) )
   {
      imc_to_char( "You are not authorized to use imcfinger.\n\r", ch );
      return;
   }

   if( !argument || argument[0] == '\0' || !strchr( argument, '@' ) )
   {
      imc_to_char( "imcfinger who@where?\n\r", ch );
      return;
   }

   CHECKMUD( ch, imc_mudof(argument) );
   snprintf( name, LGST, "finger %s", imc_nameof(argument) );
   imc_send_who( chdata, imc_mudof(argument), name );
   IMCDISPOSE( chdata );
}

/* Removed imcquery and put in imcinfo. -- Xorith */
void imcinfo( PLAYER_DATA *ch, char *argument )
{
   imc_actor_data *chdata = imc_getdata( ch );

   if( !argument || argument[0] == '\0' )
   {
      imc_to_char( "Syntax: imcinfo <mud>\n\r", ch );
      return;
   }
   CHECKMUD( ch, argument );
   imc_send_who( chdata, argument, "info" );
   IMCDISPOSE( chdata );
}

void imcbeep( PLAYER_DATA *ch, char *argument )
{
   char buf[LGST];
   imc_actor_data *chdata = imc_getdata( ch );

   if( IMCIS_SET( IMCFLAG(ch), IMC_DENYBEEP ) )
   {
      imc_to_char( "You are not authorized to use imcbeep.\n\r", ch );
      return;
   }

   if( !argument || argument[0] == '\0' )
   {
	imc_to_char( "Usage: imcbeep user@mud\n\r", ch );
	imc_to_char( "Usage: imcbeep [on]/[off]\n\r", ch );
	return;
   }

   if( !strcasecmp( argument, "on" ) )
   {
	IMCREMOVE_BIT( IMCFLAG(ch), IMC_BEEP );
	imc_to_char( "You now send and receive imcbeeps.\n\r", ch );
	return;
   }

   if( !strcasecmp( argument, "off" ) )
   {
	IMCSET_BIT( IMCFLAG(ch), IMC_BEEP );
	imc_to_char( "You no longer send and receive imcbeeps.\n\r", ch );
	return;
   }

   if( IMCIS_SET( IMCFLAG(ch), IMC_BEEP ) )
   {
      imc_to_char( "You have imcbeep turned off.\n\r", ch );
      return;
   }

   if( IMCISINVIS(ch) )
   {
      imc_to_char( "You are invisible.\n\r", ch );
      return;
   }

   CHECKMUDOF( ch, argument );
   imc_send_beep( chdata, argument );
   snprintf( buf, LGST, color_itom( "~cYou imcbeep ~Y%s~c.~!\n\r" ), argument );
   imc_to_char( buf, ch );
   IMCDISPOSE( chdata );
}

void imclist( PLAYER_DATA *ch, char *argument )
{
   REMOTEINFO *p;
   char buf[LGST], hubpath[LGST], netname[SMST];
   char *start, *onpath;
   int count = 1, end;

   /* Silly little thing, but since imcchanlist <channel> works... why not? -- Xorith */
   if( argument && argument[0] != '\0' )
   {
      imcinfo( ch, argument );
      return;
   }

   imcstrlcpy( buf, "~WActive muds on IMC2:~!\n\r", LGST );
   snprintf( buf + strlen( buf ), LGST, "~c%-15.15s ~B%-35.35s~! ~g%-15.15s ~G%s", "Name", "IMC2 Version", "Network", "Hub" );
  
   /* Put local mud on the list, why was this not done? It's a mud isn't it? */
   snprintf( buf + strlen( buf ), LGST, "\n\r\n\r~c%-15.15s ~B%-35.35s~! ~g%-15.15s ~G%s~!",
      imc_name, IMC_VERSIONID, this_imcmud->network, this_imcmud->hubname );

   for( p = first_rinfo; p; p = p->next, count++ )
   {
      if( !strcasecmp( p->network, "unknown" ) )
         imcstrlcpy( netname, this_imcmud->network, SMST );
      else
         imcstrlcpy( netname, p->network, SMST );
      /* If there is more then one path use the second path */
      if( p->path && p->path[0] != '\0' )
      {
         if( ( start = strchr( p->path, '!' ) ) != NULL )
         {
            start++;
            onpath = start;
            end = 0;
            for( onpath = start; *onpath != '!' && *onpath != '\0'; onpath++ )
            {
               hubpath[end] = *onpath;
               end++;
            }
            hubpath[end] = '\0';
         }
         else
            imcstrlcpy( hubpath, p->path, LGST );
      }
      snprintf( buf + strlen( buf ), LGST, "\n\r~%c%-15.15s ~B%-35.35s ~g%-15.15s ~G%s~!",
         p->type ? 'R' : 'c', p->name, p->version, netname, hubpath );
   }
   snprintf( buf + strlen( buf ), LGST, "\n\r~WRed mud names indicate connections that are down." );
   snprintf( buf + strlen( buf ), LGST, "\n\r~W%d muds on IMC2 found.\n\r", count );
   imc_to_pager( color_itom( buf ), ch );
}

void imcsockets( PLAYER_DATA *ch, char *argument )
{
   char buf[LGST];
   char *state;
   int r, s;

   snprintf( buf, LGST, "~c%4s ~C%-9s ~B%-15s ~r%-11s ~R%-11s\n\r",
	"Desc", "Mud", "State", "Inbuf", "Outbuf" );

   switch( this_imcmud->state )
   {
      case IMC_CLOSED:
         state = "~rClosed~!";
         break;
      case IMC_CONNECTING:
         state = "~cConnecting~!";
         break;
      case IMC_WAIT1:
         state = "~CWait1~!";
         break;
      case IMC_CONNECTED:
         state = "~GConnected~!";
         break;
      default:
         state = "~RUnknown~!";
         break;
   }
    
   r = strlen( this_imcmud->inbuf );
   s = strlen( this_imcmud->outbuf );
   snprintf( buf + strlen(buf), LGST, "%4d %-9s %-15s ~r%5d/~R%-5d %5d/~r%-5d\n\r",
	this_imcmud->desc, this_imcmud->hubname, state, r, this_imcmud->insize, s, this_imcmud->outsize );

   imc_to_pager( color_itom( buf ), ch );
}

void imcconnect( PLAYER_DATA *ch, char *argument )
{
   if( imc_active != IA_NONE )
   {
	imc_to_char( "IMC appears to already be up!\n\r", ch );
	return;
   }
   imcconnect_attempts = 0;
   imcwait = 0;
   imc_startup( TRUE );
   return;
}

void imcdisconnect( PLAYER_DATA *ch, char *argument )
{
   if( imc_active < IA_UP )
   {
	imc_to_char( "IMC does not appear to be up!\n\r", ch );
	return;
   }
   imc_shutdown( FALSE );
   return;
}

void imcconfig( PLAYER_DATA *ch, char *argument )
{
   char arg1[IMC_DATA_LENGTH];

   argument = imc_getarg( argument, arg1, IMC_DATA_LENGTH );

   if( !arg1 || arg1[0] == '\0' )
   {
	imc_to_char( "&wSyntax: &Gimc <field> [value]\n\r\n\r", ch );
	imc_to_char( "&wConfiguration info for your mud. Changes save when edited.\n\r", ch );
	imc_to_char( "&wYou may set the following:\n\r\n\r", ch );
	imc_to_char( "&wShow       : &GDisplays your current configuration.\n\r", ch );
	imc_to_char( "&wLocalname  : &GThe name IMC2 knows your mud by.\n\r", ch );
	imc_to_char( "&wAutoconnect: &GToggles automatic connection on reboots.\n\r", ch );
	imc_to_char( "&wMinlevel   : &GSets the minimum level IMC2 can see your players at.\n\r", ch );
	imc_to_char( "&wImmlevel   : &GSets the level at which immortal commands become available.\n\r", ch );
	imc_to_char( "&wAdminlevel : &GSets the level at which administrative commands become available.\n\r", ch );
	imc_to_char( "&wImplevel   : &GSets the level at which immplementor commands become available.\n\r", ch );
	imc_to_char( "&wInfoname   : &GName of your mud, as seen from the imcquery info sheet.\n\r", ch );
	imc_to_char( "&wInfohost   : &GTelnet address of your mud.\n\r", ch );
	imc_to_char( "&wInfoport   : &GTelnet port of your mud.\n\r", ch );
	imc_to_char( "&wInfoemail  : &GEmail address of the mud's IMC administrator.\n\r", ch );
	imc_to_char( "&wInfobase   : &GName of the mud's codebase.\n\r", ch );
	imc_to_char( "&wInfoWWW    : &GThe Web address of your mud, cannot contain tildes.\n\r", ch );
	imc_to_char( "&wInfoDetails: &GSHORT Description of your mud.\n\r", ch );
	imc_to_char( "&wConnectname: &GName of the hub your mud connets to IMC on.\n\r", ch );
	imc_to_char( "&wConnectaddr: &GDNS or IP address of the hub you mud connects to.\n\r", ch );
	imc_to_char( "&wConnectport: &GPort of the hub your mud connects to.\n\r", ch );
	imc_to_char( "&wConnectpwd1: &GClient password for your mud.\n\r", ch );
	imc_to_char( "&wConnectpwd2: &GServer password for your mud.\n\r", ch );
	return;
   }

   if( !strcasecmp( arg1, "autoconnect" ) )
   {
	this_imcmud->autoconnect = !this_imcmud->autoconnect;

	if( this_imcmud->autoconnect )
	   imc_to_char( "Autoconnect enabled.\n\r", ch );
	else
	   imc_to_char( "Autoconnect disabled.\n\r", ch );
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "show" ) )
   {
	imc_printf( ch, "&wLocalname  : &G%s\n\r", imc_name );
	imc_printf( ch, "&wAutoconnect: &G%s\n\r", this_imcmud->autoconnect ? "Enabled" : "Disabled" );
	imc_printf( ch, "&wMinlevel   : &G%d\n\r", imc_minlevel );
      imc_printf( ch, "&wImmlevel   : &G%d\n\r", imc_immlevel );
	imc_printf( ch, "&wAdminlevel : &G%d\n\r", imc_adminlevel );
      imc_printf( ch, "&wImplevel   : &G%d\n\r", imc_implevel );
	imc_printf( ch, "&wInfoname   : &G%s\n\r", imc_siteinfo.name );
	imc_printf( ch, "&wInfohost   : &G%s\n\r", imc_siteinfo.host );
	imc_printf( ch, "&wInfoport   : &G%d\n\r", imc_siteinfo.port );
	imc_printf( ch, "&wInfoemail  : &G%s\n\r", imc_siteinfo.email );
	imc_printf( ch, "&wInfobase   : &G%s\n\r", imc_siteinfo.base );
	imc_printf( ch, "&wInfoWWW    : &G%s\n\r", imc_siteinfo.www );
	imc_printf( ch, "&wInfoDetails: &G%s\n\r\n\r", imc_siteinfo.details );
	imc_printf( ch, "&wConnectName: &G%s\n\r", this_imcmud->hubname );
	imc_printf( ch, "&wConnectAddr: &G%s\n\r", this_imcmud->host );
	imc_printf( ch, "&wConnectPort: &G%d\n\r", this_imcmud->port );
	imc_printf( ch, "&wConnectPwd1: &G%s\n\r", this_imcmud->clientpw );
	imc_printf( ch, "&wConecttPwd2: &G%s\n\r", this_imcmud->serverpw );
	return;
   }

   if( !argument || argument[0] == '\0' )
   {
	imcconfig( ch, "" );
	return;
   }

   if( !strcasecmp( arg1, "minlevel" ) )
   {
	int value = atoi( argument );

	imc_printf( ch, "Minimum level set to %d\n\r", value );
      imc_minlevel = value;
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "immlevel" ) )
   {
	int value = atoi( argument );

	imc_printf( ch, "Immortal level set to %d\n\r", value );
      imc_immlevel = value;
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "adminlevel" ) )
   {
	int value = atoi( argument );

	imc_printf( ch, "Admin level set to %d\n\r", value );
      imc_adminlevel = value;
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "implevel" ) && IMCPERM(ch) == TRUE )
   {
	int value = atoi( argument );

	imc_printf( ch, "Implementor level set to %d\n\r", value );
      imc_implevel = value;
	imc_save_config();
	return;
   }

   if( imc_active != IA_NONE )
   {
	imc_printf( ch, "Cannot alter %s while the mud is connected to IMC.\n\r", arg1 );
	return;
   }

   if( !strcasecmp( arg1, "connectname" ) )
   {
	IMCSTRFREE( this_imcmud->hubname );
	this_imcmud->hubname = IMCSTRALLOC( argument );
	imc_printf( ch, "Connectname changed to %s\n\r", argument );
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "connectaddr" ) )
   {
	IMCSTRFREE( this_imcmud->host );
	this_imcmud->host = IMCSTRALLOC( argument );
	imc_printf( ch, "Connectaddr changed to %s\n\r", argument );
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "connectport" ) )
   {
	this_imcmud->port = atoi( argument );
	imc_printf( ch, "Connectport changed to %d\n\r", this_imcmud->port );
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "connectpwd1" ) )
   {
	IMCSTRFREE( this_imcmud->clientpw );
	this_imcmud->clientpw = IMCSTRALLOC( argument );
	imc_printf( ch, "Connectpwd1 changed to %s\n\r", argument );
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "connectpwd2" ) )
   {
	IMCSTRFREE( this_imcmud->serverpw );
	this_imcmud->serverpw = IMCSTRALLOC( argument );
	imc_printf( ch, "Connectpwd2 changed to %s\n\r", argument );
	imc_save_config();
	return;
   }

   if( !strcasecmp( arg1, "localname" ) )
   {
      IMCSTRFREE( imc_name );
      imc_name = IMCSTRALLOC( argument );
      imc_save_config();
	imc_printf( ch, "Localname changed to %s\n\r", argument );
      return;
   }
   
   if( !strcasecmp( arg1, "infoname" ) )
   {
      IMCSTRFREE( imc_siteinfo.name );
      imc_siteinfo.name = IMCSTRALLOC( argument );
	imc_save_config();
	imc_printf( ch, "Infoname change to %s\n\r", argument );
	return;
   }

   if( !strcasecmp( arg1, "infohost" ) )
   {
      IMCSTRFREE( imc_siteinfo.host );
      imc_siteinfo.host = IMCSTRALLOC( argument );
	imc_save_config();
	imc_printf( ch, "Infohost changed to %s\n\r", argument );
	return;
   }

   if( !strcasecmp( arg1, "infoport" ) )
   {
	imc_siteinfo.port = atoi( argument );
	imc_save_config();
	imc_printf( ch, "Infoport changed to %d\n\r", imc_siteinfo.port );
	return;
   }

   if( !strcasecmp( arg1, "infoemail" ) )
   {
      IMCSTRFREE( imc_siteinfo.email );
      imc_siteinfo.email = IMCSTRALLOC( argument );
	imc_save_config();
	imc_printf( ch, "Infoemail changed to %s\n\r", argument );
	return;
   }

   if( !strcasecmp( arg1, "infowww" ) )
   {
      IMCSTRFREE( imc_siteinfo.www );
      imc_siteinfo.www = IMCSTRALLOC( argument );
	imc_save_config();
	imc_printf( ch, "InfoWWW changed to %s\n\r", argument );
	return;
   }

   if( !strcasecmp( arg1, "infobase" ) )
   {
	char cbase[SMST];

      IMCSTRFREE( imc_siteinfo.base );
      imc_siteinfo.base = IMCSTRALLOC( argument );
	imc_save_config();
	imc_printf( ch, "Infobase changed to %s\n\r", argument );

	IMCSTRFREE( IMC_VERSIONID );
	snprintf( cbase, SMST, "%s%s", IMC_VERSION_ID, imc_siteinfo.base );
	IMC_VERSIONID = IMCSTRALLOC( cbase );
	return;
   }

   if( !strcasecmp( arg1, "infodetails" ) )
   {
      IMCSTRFREE( imc_siteinfo.details );
      imc_siteinfo.details = IMCSTRALLOC( argument );
	imc_save_config();
	imc_to_char( "Infodetails updated.\n\r", ch );
	return;
   }

   if( !strcasecmp( arg1, "infoport" ) )
   {
      imc_siteinfo.port = atoi( argument );
	imc_save_config();
	imc_printf( ch, "Infoport changed to %d\n\r", imc_siteinfo.port );
	return;
   }
   imcconfig( ch, "" );
   return;
}

/* Modified this command so it's a little more helpful -- Xorith */
void imcignore( PLAYER_DATA *ch, char *argument )
{
   int count;
   IMC_IGNORE *ign;
   char arg[SMST];

   argument = one_argument( argument, arg );

   if( !arg || arg[0] == '\0' )
   {
      imc_to_char( "You currently ignore the following:\n\r", ch );
      for( count = 0, ign = FIRST_IMCIGNORE(ch); ign; ign = ign->next, count++ )
         imc_printf( ch, "%s\n\r", ign->name );

      if( !count )
         imc_to_char( " none\n\r", ch );
      else
         imc_printf( ch, "\n\r[total %d]\n\r", count );
      imc_to_char( "For help on imcignore, type: IMCIGNORE HELP\n\r", ch );
      return;
   }

   if( !strcasecmp( arg, "help" ) )
   {
	   imc_to_char( "&wTo see your current ignores  : &GIMCIGNORE\n\r", ch );
	   imc_to_char( "&wTo add an ignore             : &GIMCIGNORE ADD <argument>\n\r", ch );
	   imc_to_char( "&wTo delete an ignore          : &GIMCIGNORE DELETE <argument>\n\r", ch );
	   imc_to_char( "&wSee your MUD's help for more information.\n\r", ch );
	   return;
   }

   if( !argument || argument[0] == '\0' )
   {
	imc_to_char( "Must specify both action and name.\n\r", ch );
	imc_to_char( "Please see IMCIGNORE HELP for details.\n\r", ch );
	return;
   }

   if( !strcasecmp( arg, "delete" ) )
   {
	for( ign = FIRST_IMCIGNORE(ch); ign; ign = ign->next )
	{
	   if( !strcasecmp( ign->name, argument ) )
	   {
            IMCUNLINK( ign, FIRST_IMCIGNORE(ch), LAST_IMCIGNORE(ch), next, prev );
	      IMCSTRFREE( ign->name );
	      IMCDISPOSE( ign );
	      imc_to_char( "Entry deleted.\n\r", ch );
	      return;
	   }
	}
	imc_to_char( "Entry not found.\n\rPlease check your ignores by typing IMCIGNORE with no arguments.\n\r", ch );
	return;
   }

   if( !strcasecmp( arg, "add" ) )
   {
	IMCCREATE( ign, IMC_IGNORE, 1 );
	ign->name = IMCSTRALLOC( argument );
	IMCLINK( ign, FIRST_IMCIGNORE(ch), LAST_IMCIGNORE(ch), next, prev );
      imc_printf( ch, "%s will now be ignored.\n\r", argument );
	return;
   }
   imcignore( ch, "help" );
   return;
}

/* Made this command a little more helpful --Xorith */
void imcban( PLAYER_DATA *ch, char *argument )
{
   int count;
   IMC_IGN *ign;
   char arg[SMST];

   argument = one_argument( argument, arg );

   if( !arg || arg[0] == '\0' )
   {
      imc_to_char( "The mud currently bans the following:\n\r", ch );
      for( count = 0, ign = first_imc_ignore; ign; ign = ign->next, count++ )
         imc_printf( ch, "%s\n\r", ign->name );

      if( !count )
         imc_to_char( " none\n\r", ch );
      else
         imc_printf( ch, "\n\r[total %d]\n\r", count );
      imc_to_char( "Type: IMCBAN HELP for more information.\n\r", ch );
      return;
   }

   if( !strcasecmp( arg, "help" ) )
   {
	   imc_to_char( "&wTo see the current bans             : &GIMCBAN\n\r", ch );
	   imc_to_char( "&wTo add a MUD to the ban list        : &GIMCBAN ADD <argument>\n\r", ch );
	   imc_to_char( "&wTo delete a MUD from the ban list   : &GIMCBAN DELETE <argument>\n\r", ch );
       imc_to_char( "&wSee your MUD's help for more information.\n\r", ch );
	   return;
   }

   if( !argument || argument[0] == '\0' )
   {
	imc_to_char( "Must specify both action and name.\n\rPlease type IMCBAN HELP for more information\n\r", ch );
	return;
   }

   if( !strcasecmp( arg, "delete" ) )
   {
      if( imc_delignore( argument ) )
      {
         imc_saveignores( );
	   imc_to_char( "Entry deleted.\n\r", ch );
	   return;
      }
	imc_to_char( "Entry not found.\n\rPlease type IMCBAN without arguments to see the current ban list.\n\r", ch );
   }

   if( !strcasecmp( arg, "add" ) )
   {
      imc_addignore( argument );
      imc_saveignores( );
      imc_printf( ch, "Mud %s will now be banned.\n\r", argument );
	return;
   }
   imcban( ch, "" );
   return;
}

void imcstats( PLAYER_DATA *ch, char *argument )
{
   char buf[1024];

   snprintf( buf, 1024, "IMC statistics\n\r\n\r"
      "~cReceived packets   : ~C%ld\n\r"
      "~cReceived bytes     : ~C%ld\n\r", imc_stats.rx_pkts, imc_stats.rx_bytes );

   snprintf( buf+strlen( buf ), 1024, "~cTransmitted packets: ~C%ld\n\r"
      "~cTransmitted bytes  : ~C%ld\n\r", imc_stats.tx_pkts, imc_stats.tx_bytes );

   snprintf( buf+ strlen( buf ), 1024, "~cMaximum packet size: ~C%d\n\r"
      "~cSequence drops     : ~C%d\n\r", imc_stats.max_pkt, imc_stats.sequence_drops );

   snprintf( buf + strlen(buf), 1024, "~cLast IMC Boot: ~C%s~!\n\r", ctime( &imc_boot ) );

   imc_to_char( color_itom( buf ), ch );
}

void imc_deny_channel( PLAYER_DATA *ch, char *argument ) 
{
   char vic_name[SMST];
   PLAYER_DATA *victim;
   IMC_CHANNEL *channel;

   argument = one_argument( argument, vic_name );

   if( !vic_name || vic_name[0] == '\0' || !argument || argument[0] == '\0' )
   {
	imc_to_char( "Usage: imcdeny <person> <local channel name>\n\r", ch );
	imc_to_char( "Usage: imcdeny <person> [tell/beep/finger]\n\r", ch );
	return;
   }

   if( !( victim = imc_find_user( vic_name ) ) )
   {
	imc_to_char( "No such person is currently online.\n\r", ch );
	return;
   }

   if( IMCPERM(ch) <= IMCPERM(victim) )
   {
      imc_to_char( "You cannot alter their settings.\n\r", ch );
      return;
   }

   if( !strcasecmp( argument, "tell" ) )
   {
	if( !IMCIS_SET( IMCFLAG(victim), IMC_DENYTELL ) )
	{
	   IMCSET_BIT( IMCFLAG(victim), IMC_DENYTELL );
	   imc_printf( ch, "%s can no longer use imctells.\n\r", CH_IMCNAME(victim) );
	   return;
	}
	IMCREMOVE_BIT( IMCFLAG(victim), IMC_DENYTELL );
	imc_printf( ch, "%s can use imctells again.\n\r", CH_IMCNAME(victim) );
	return;
   }

   if( !strcasecmp( argument, "beep" ) )
   {
	if( !IMCIS_SET( IMCFLAG(victim), IMC_DENYBEEP ) )
	{
	   IMCSET_BIT( IMCFLAG(victim), IMC_DENYBEEP );
	   imc_printf( ch, "%s can no longer use imcbeeps.\n\r", CH_IMCNAME(victim) );
	   return;
	}
	IMCREMOVE_BIT( IMCFLAG(victim), IMC_DENYBEEP );
	imc_printf( ch, "%s can use imcbeeps again.\n\r", CH_IMCNAME(victim) );
	return;
   }

   if( !strcasecmp( argument, "finger" ) )
   {
	if( !IMCIS_SET( IMCFLAG(victim), IMC_DENYFINGER ) )
	{
	   IMCSET_BIT( IMCFLAG(victim), IMC_DENYFINGER );
	   imc_printf( ch, "%s can no longer use imcfingers.\n\r", CH_IMCNAME(victim) );
	   return;
	}
	IMCREMOVE_BIT( IMCFLAG(victim), IMC_DENYFINGER );
	imc_printf( ch, "%s can use imcfingers again.\n\r", CH_IMCNAME(victim) );
	return;
   }

   /* Assumed to be denying a channel by this stage. */
   if( ( channel = imc_findlchannel( argument ) ) == NULL ) 
   {
	imc_to_char( "Unknown or unconfigured local channel. Check your channel name.\n\r", ch );
	return;
   }

   if( imc_hasname( IMC_DENY(ch), channel->local_name ) )
   {
	imc_printf( ch, "%s can now listen to %s\n\r", CH_IMCNAME(victim), channel->local_name );
	imc_removename( &IMC_DENY(ch), channel->local_name );
   }
   else
   {
	imc_printf( ch, "%s can no longer listen to %s\n\r", CH_IMCNAME(victim), channel->local_name );
	imc_addname( &IMC_DENY(ch), channel->local_name );
   }
   return;
}

/*  Traceroute and ping.
 *
 *  Be lazy - only remember the last traceroute
 */
void imcping( PLAYER_DATA *ch, char *argument )
{
   struct timeval tv;
  
   if( !argument || argument[0] == '\0' )
   {
      imc_to_char( "Ping which mud?\n\r", ch );
      return;
   }

   CHECKMUD( ch, argument );

   gettimeofday( &tv, NULL );
   imcstrlcpy( lastping, argument, IMC_MNAME_LENGTH );
   imcstrlcpy( pinger, CH_IMCNAME(ch), 100 );
   imc_send_ping( argument, tv.tv_sec, tv.tv_usec );
}

void imcpermstats( PLAYER_DATA *ch, char *argument )
{
   PLAYER_DATA *victim;

   if( !argument || argument[0] == '\0' )
   {
	imc_to_char( "Usage: imcperms <user>\n\r", ch );
	return;
   }

   if( !( victim = imc_find_user( argument ) ) )
   {
	imc_to_char( "No such person is currently online.\n\r", ch );
	return;
   }

   if( IMCPERM(victim) < 0 || IMCPERM(victim) > TRUE )
   {
	imc_printf( ch, "&R%s has an invalid permission setting!\n\r", CH_IMCNAME(victim) );
	return;
   }

   imc_printf( ch, "&YPermissions for %s: %s\n\r", CH_IMCNAME(victim), imcperm_names[IMCPERM(victim)] );
   return;
}

void imcpermset( PLAYER_DATA *ch, char *argument )
{
   PLAYER_DATA *victim;
   char arg[SMST];
   int permvalue;

   argument = one_argument( argument, arg );

   if( !arg || arg[0] == '\0' )
   {
      imc_to_char( "Usage: imcpermset <user> <permission>\n\r", ch );
      imc_to_char( "Permission can be one of: None, Mort, Imm, Admin, Imp\n\r", ch );
	return;
   }

   if( !( victim = imc_find_user( arg ) ) )
   {
	imc_to_char( "No such person is currently online.\n\r", ch );
	return;
   }

   permvalue = get_imcpermvalue( argument );

   if( permvalue < 0 || permvalue > TRUE )
   {
	imc_to_char( "Invalid permission setting.\n\r", ch );
	return;
   }

   if( permvalue > IMCPERM(ch) )
   {
	imc_to_char( "You cannot set permissions higher than your own.\n\r", ch );
	return;
   }

   if( permvalue == IMCPERM(ch) && IMCPERM(ch) != TRUE )
   {
	imc_to_char( "You cannot set permissions equal to your own. Someone higher up must do this.\n\r", ch );
	return;
   }

   if( IMCPERM(ch) < IMCPERM(victim) )
   {
	imc_to_char( "You cannot reduce the permissions of someone above your own.\n\r", ch );
	return;
   }

   /* Just something to avoid looping through the channel clean-up --Xorith */
   if( IMCPERM(victim) == permvalue )
   {
      imc_printf( ch, "%s already has a permission level of %s.\n\r", CH_IMCNAME(victim), imcperm_names[permvalue] );
      return;
   }

   IMCPERM(victim) = permvalue;
   imc_printf( ch, "&YPermission level for %s has been changed to %s\n\r", CH_IMCNAME(victim), imcperm_names[permvalue] );
   /* Channel Clean-Up added by Xorith 9-24-03 */
   /* Note: Let's not clean up IMC_DENY for a player. Never know... */
   if( IMC_LISTEN( victim ) != NULL && imc_active == IA_UP )
   {
      IMC_CHANNEL *channel = NULL;
      char *channels = IMC_LISTEN(victim);

      while(1)
      {
         if( channels[0] == '\0' )
            break;
         channels = one_argument( channels, arg );

         if( !( channel = imc_findlchannel( arg ) ) )
            imc_removename( &IMC_LISTEN( victim ), arg );
         if( channel && IMCPERM(victim) < channel->level )
         {
            imc_removename( &IMC_LISTEN(victim), arg );
            imc_printf( ch, "&YRemoving '%s' level channel: '%s', exceeding new permission of '%s'\n\r",
               imcperm_names[channel->level], channel->local_name, imcperm_names[IMCPERM(victim)] );
         }
      }
   }
   return;
}

void imcinvis( PLAYER_DATA *ch, char *argument )
{
   if( IMCIS_SET( IMCFLAG(ch), IMC_INVIS ) )
   {
	IMCREMOVE_BIT( IMCFLAG(ch), IMC_INVIS );
	imc_to_char( "You are now imcvisible.\n\r", ch );
   }
   else
   {
	IMCSET_BIT( IMCFLAG(ch), IMC_INVIS );
	imc_to_char( "You are now imcinvisible.\n\r", ch );
   }
   return;
}

/* This function should coincide with the command struct below */
void imc_other( PLAYER_DATA *ch, char *argument )
{
   imc_to_char( "&GGeneral Usage:\n\r", ch );
   imc_to_char( "&G------------------------------------------------\n\r\n\r", ch );
   imc_to_char( "&wList channels available                : &Gimcchanlist [name]\n\r", ch );
   imc_to_char( "&wTo tune into a channel                 : &Gimclisten <localchannel>\n\r", ch );
   imc_to_char( "&wList muds connected to IMC2            : &Gimclist\n\r", ch );
   imc_to_char( "&wIgnore someone who annoys you          : &Gimcignore <string>\n\r", ch );
   imc_to_char( "&wMake yourself invisible to IMC2        : &Gimcinvis\n\r", ch );
   imc_to_char( "&wToggle IMC2 color                      : &Gimccolor\n\r", ch );
   imc_to_char( "&wTo obtain information from a MUD       : &Gimcinfo <mud>\n\r", ch ); /* Xorith */
   imc_to_char( "&wTo see who's on a MUD                  : &Gimcwho <mud>\n\r", ch );  /* Xorith */

   if( IMCPERM(ch) >= TRUE )
   {
      imc_to_char( "\n\r&YImmortal functions\n\r", ch );
      imc_to_char( "&Y------------------------------------------------\n\r\n\r", ch );
      imc_to_char( "&YGeneral statistics:\n\r", ch );
      imc_to_char( "&wimcperms <user>\n\r\n\r", ch );
      imc_to_char( "&YChannel control:\n\r", ch );
      imc_to_char( "&wimcdeny <person> <local channel>\n\r", ch );
   }

   if( IMCPERM(ch) >= TRUE )
   {
      imc_to_char( "\n\r&RAdministrative functions\n\r", ch );
      imc_to_char( "&R------------------------------------------------\n\r\n\r", ch );
      imc_to_char( "&RLocal channel setup and editing:\n\r", ch );
      imc_to_char( "&wimcsetup <imcchannelname> <localname> [level]\n\r\n\r", ch );
      imc_to_char( "&RNew channel creation and administration:\n\r", ch );
      imc_to_char( "&wimccommand (something goes here)\n\r\n\r", ch );
      imc_to_char( "&RTraffic control and permissions:\n\r", ch );
      imc_to_char( "&wimcban <string>\n\r", ch );
      imc_to_char( "&wimcpermset <user> <permission>\n\r", ch );
   }
   return;
}

void imccolor( PLAYER_DATA *ch, char *argument )
{
   if( IMCIS_SET( IMCFLAG(ch), IMC_COLOR ) )
   {
	IMCREMOVE_BIT( IMCFLAG(ch), IMC_COLOR );
	imc_to_char( "IMC2 color is now off.\n\r", ch );
   }
   else
   {
	IMCSET_BIT( IMCFLAG(ch), IMC_COLOR );
	imc_to_char( "&RIMC2 c&Yo&Gl&Bo&Pr &Ris now on. Enjoy :)\n\r", ch );
   }
   return;
}

void imcdebug( PLAYER_DATA *ch, char *argument )
{
   imcpacketdebug = !imcpacketdebug;

   if( imcpacketdebug )
      imc_to_char( "Packet debug enabled.\n\r", ch );
   else
      imc_to_char( "Packet debug disabled.\n\r", ch );
   return;
}

const	struct	imccmd_type	imccmd_table	[] =
{
   /* The revamped Merc-like command table. The imc_other function should coincide with this. */
   /* { 3.x cmd name, 2.x cmd name },     Function called,  Permission,	Need to be connected? */

   /* Gives a default list of commands */
   { { "imc", "imc" },                    imc_other,        FALSE,     FALSE },

   /* Command to listen to a channel */
   { { "imclisten", "ichan" },            imclisten,        FALSE,	TRUE },

   /* Command to show the available channels */
   { { "imcchanlist", "ilist" },	      imcchanlist, FALSE,	TRUE },

   /* Shows the list of connected muds */
   { { "imclist", "imclist" },	      imclist,		FALSE,	TRUE },

   /* Toggles the person's imc invisibility state */
   { { "imcinvis", "imcinvis" },	      imcinvis,		FALSE,	FALSE },

   /* Shows a listing of players on another mud who can use imc */
   { { "imcwho", "rwho" },                imcwho,		FALSE, 	TRUE },

   /* Looks to see if a player is online on any of the connected muds */
   { { "imclocate", "rwhois" },           imclocate,		FALSE, 	TRUE },

   /* Sends a private message to a player on another mud */
   { { "imctell", "rtell" },		      imctell,		FALSE, 	TRUE },

   /* Sends a reply back to the last person who sent a tell */
   { { "imcreply", "rreply" },	      imcreply,		FALSE, 	TRUE },

   /* Sends an attention signal to another player */
   { { "imcbeep", "rbeep" },		      imcbeep,		FALSE, 	TRUE },

   /* Prevents other players from pestering you */
   { { "imcignore", "imcignore" },	      imcignore,		FALSE, 	FALSE },

   /* Requests specific information about a player on another mud */
   { { "imcfinger", "rfinger" },	      imcfinger,		FALSE, 	TRUE },

   /* Removed imcquery and put imcinfo in it's place. Made it respond to rquery. -- Xorith */
   /* Sends an information request to another mud */
   { { "imcinfo", "rquery" },             imcinfo,          FALSE,     TRUE },

   /* Toggles the output of color to a player */
   { { "imccolor", "imccolor" },          imccolor,         FALSE,     FALSE },

   /* Connects the mud to the network */
   { { "imcconnect", "rconnect" },        imcconnect,		TRUE,	FALSE },

   /* Disconnects the mud from the network */
   { { "imcdisconnect", "rdisconnect" },  imcdisconnect,	TRUE,	TRUE },

   /* Displays the permission level a player has */
   { { "imcperms", "imcperms" },		imcpermstats,	TRUE,	FALSE },

   /* Disallows a player access to various functions */
   { { "imcdeny",	"imcdeny" },      	imc_deny_channel,	TRUE,	TRUE },

   /* Displays the descriptor the connection uses along with some buffer stats */
   { { "imcsockets", "rsockets" },        imcsockets,       TRUE,      TRUE },

   /* Sets permissions on players */
   { { "imcpermset", "imcpermset" },	imcpermset,		TRUE,	FALSE },

   /* Local control over channels */
   { { "imcsetup", "isetup" },		imcsetup,  		TRUE,	TRUE },

   /* Command to administer channels at the hub level */
   { { "imccommand", "icommand" },  	imccommand,		TRUE,	TRUE },

   /* Bans an entire mud from being able to exchange information */
   { { "imcban", "rignore" },	            imcban,		TRUE,	TRUE },

   /* Sets up the data for your connection */
   { { "imcconfig", "imcconfig" },		imcconfig, 		TRUE,	FALSE },

   /* Gets routing information on another connection */
   { { "imcping", "rping" },              imcping,          TRUE,    TRUE },

   /* Statistical information */
   { { "imcstats", "istats" },            imcstats,         TRUE,    TRUE },

   /* Packet debugging - Be responsible with this! */
   { { "imcdebug", "imcdebug" },          imcdebug,         TRUE,      FALSE },

   { { NULL, NULL }, NULL, 0, 0 }
};

/* check for IMC channels, return TRUE to stop command processing, FALSE otherwise */
bool imc_command_hook( PLAYER_DATA *ch, char *command, char *argument )
{
   IMC_CHANNEL *c;
   int emote = 0, x;

   if( IS_NPC(ch) )
      return FALSE;

   if( !this_imcmud )
   {
	imcbug( "%s", "Ooops. IMC being called with no configuration!" );
	return FALSE;
   }
/*
   if( IMCPERM(ch) <= IMCPERM_NONE )
      return FALSE;
 */

   /* Simple command interpreter menu. Nothing overly fancy etc, but it beats trying to tie directly into the mud's
    * own internal structures. Especially with the differences in codebases. If this looks eerily similar to the Merc
    * command table setup, that's because it's a simplified version of exactly that :)
    */
   for( x = 0; imccmd_table[x].name[0] && imccmd_table[x].name[1] != NULL; x++ )
   {
      if( IS_IMMORTAL(ch) != imccmd_table[x].level && imccmd_table[x].level )
	   continue;

      if( !strcasecmp( command, imccmd_table[x].name[0] ) || !strcasecmp( command, imccmd_table[x].name[1] ) )
      {
	   if( imccmd_table[x].connected == TRUE && imc_active < IA_UP )
	   {
		imc_to_char( "The mud is not currently connected to IMC2.\n\r", ch );
		return TRUE;
	   }

         ( *imccmd_table[x].function )( ch, argument ); 
         return TRUE;
      }
   }

   /* Assumed to be aiming for a channel if you get this far down */
   c = imc_findlchannel( command );

   if( !c )
      return FALSE;

   if( c->level > IMCPERM(ch) )
      return FALSE;

   if( imc_hasname( IMC_DENY(ch), c->local_name ) )
   {
	imc_printf( ch, "You have been denied the use of %s by the administration.\n\r", c->local_name );
	return TRUE;
   }

   if( !c->refreshed )
   {
      imc_printf( ch, "The %s channel has not yet been refreshed by the hub.\n\r", c->local_name );
	return TRUE;
   }

   if( !argument || argument[0] == '\0' )
   {
	int y;

   if( !imc_hasname( IMC_LISTEN(ch), c->local_name ) )
   {
      imclisten( ch, c->local_name );
   }
	imc_printf( ch, "&cThe last %d %s messages:\n\r", MAX_IMCHISTORY, c->local_name );
	for( y = 0; y < MAX_IMCHISTORY; y++ )
	{
	   if( c->history[y] != NULL )
		imc_to_char( c->history[y], ch );
	   else
		break;
	}
	return TRUE;
   }

   if( !imc_hasname( IMC_LISTEN(ch), c->local_name ) )
   {
      imclisten( ch, c->local_name );
   }

   if( *argument == ',' )
   {
      emote = 1;
      argument++;
      while( isspace( *argument ) ) argument++;
   }

   else if( *argument == '@' )
   {
      PLAYER_DATA *vict = NULL;
      char victimname[LGST];
      char socstring[LGST];
      char remade[LGST];
	int cmd;
	bool found;

      argument++;

      argument = one_argument( argument, socstring );

      if( !socstring || socstring[0] == '\0' )
	{
	   imc_to_char( "Putting a social there might help.\n\r", ch );
	   return TRUE;
	}

	found  = FALSE;
	for ( cmd = 0; social_table[cmd].name[0] != '\0'; cmd++ )
	{
	   if( socstring[0] == social_table[cmd].name[0] && !imcstr_prefix( socstring, social_table[cmd].name ) )
	   {
	      found = TRUE;
	      break;
	   }
	}

	if( !found )
	{
	   imc_printf( ch, "Social %s does not exist on this mud.\n\r", socstring );
	   return TRUE;
	}

      argument = one_argument( argument, victimname );

      if( !victimname || victimname[0] == '\0' )
         imcstrlcpy( socstring, social_table[cmd].others_no_arg, LGST );

	/* Minimal target checking, just to be sure they have person@mud format, in the even IMC ever gets TRUE
	 * targetted socials, the groundwork is laid here to check the information - Samson
	 */
	else if( ( vict = imc_find_user( victimname ) ) == NULL || ( vict = imc_find_user( victimname ) ) != ch )
	{
	   char *ps;
	   char person[LGST];
	   char mud[LGST];
	   int z;

         if( ( ps = strchr( argument, '@' ) ) == NULL )
	   {
	      imc_to_char( "You need to specify a person@mud for a targetted social.\n\r", ch );
		return TRUE;
	   }

	   for( z = 0; z < strlen( victimname ); z++ )
	   {
	      person[z] = victimname[z];
	      if( person[z] == '@' )
		   break;
	   }
	   person[z] = '\0';

	   imcstrlcpy( mud, ps+1, LGST );
	   person[0] = toupper( person[0] );
	   mud[0] = toupper( mud[0] );
	   snprintf( victimname, LGST, "%s@%s", person, mud );

         imcstrlcpy( socstring, social_table[cmd].others_found, LGST );
	}
      else
         imcstrlcpy( socstring, social_table[cmd].others_auto, LGST );

      if( !socstring || socstring[0] == '\0' )
      {
         imc_to_char( "That part of the social is blank.\n\r", ch );
         return TRUE;
      }

      imcstrlcpy( remade, (char *)imc_act_string( socstring, ch, victimname ), LGST );
      argument = remade;
      cmd = 0;
      emote = 2;
   }

   imc_sendmessage( c, CH_IMCNAME(ch), color_mtoi(argument), emote );
   return TRUE;
}
