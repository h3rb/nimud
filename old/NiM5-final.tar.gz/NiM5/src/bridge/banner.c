/*
 * banner.c: a program to present text on a TCP port and (optionally) wait
 *           for the reader to hit return before disconnecting.
 *   Author: Alex Stewart <riche@crl.com>
 *           Portions based on/copied from several other programs, including
 *           sign.c by Jeremy Elson <jelson@cs.jhu.edu> and
 *           sign.c (same name, somewhat different program) by unknown
 *             author(s)
 *
 *    Usage: banner [ -n ] { <filename> | - } <port>
 *
 * The first argument is either the name of the file to display when someone
 * connects to the port, or '-', indicating that the text of the message is to
 * be read from stdin when the program starts up.  The second argument is the
 * number of the port to listen for connections on.
 *
 * The -n flag specifies that banner should not wait for a response from the
 * other end, but should disconnect immediately after sending the message out.
 * Note that many implementations of telnet don't handle this well, and end up
 * chopping off the end of the message when this happens, or end up clearing
 * the screen so fast that the user can't read the message, thus the default
 * is to wait for a response from the user before disconnecting.
 *
 * If the -n flag is not used, then banner will wait for a CR or a LF
 * character (hitting the return key) from the other end.
 *
 * BSD-style socket network I/O under unix.  To compile, type:
 *
 *   gcc banner.c -o banner
 *
 * (or substitute your c compiler for gcc if you're not using the GNU compiler)
 *
 * This program is in the public domain.  Do what thou wilt.
 * This program comes with no warranty of any kind, expressed or implied.
 *
 * (and now, enough babbling.. on to the code:)
 */

/* Some relevant settings for the program: */

#define LINE_LEN 80
#define BUF_LEN  256  /* Note: must be at least LINE_LEN+2 */
#define MSG_LEN  4096
#define MAX_FDS  64

/* Includes: */

#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>
#include <fcntl.h>
#include <ctype.h>
#include <string.h>

/* Local header info: */

typedef struct {
  char active;
  int  write_position;
} conn;

int usage(char *name);
int initialize(char *filename, char *port);
void watch(int port);
void greet(int sock);
void fd_output(int fd);
void fd_input(int fd);

int init_socket(int port);
int new_connection(int s);
void close_connection(int fd);
void nonblock(int sock);


/* Global variables: */

char buf[BUF_LEN];
char text[MSG_LEN];
int text_length;
conn conns[MAX_FDS];
int noread = 0;

/* Program: */

void main(int argc, char **argv) { /* Entry point. */
   int i, portnum;
   char *filename = NULL;
   char *port = NULL;

   /* run through the command args and sort out what's which */
   for (i = 1; i < argc; i++) {
      if (!strcmp(argv[i],"-n"))
	 noread = 1;
      else if (!filename)
	 filename = argv[i];
      else if (!port)
	 port = argv[i];
      else {
         exit( usage(argv[0]) );
	 return;
        }
   }

   /* did the user supply all the required args? */
   if (!filename || !port) {
      exit( usage(argv[0]) );
      return;
   }

   portnum = initialize(filename, port);
   watch(portnum);
}

int usage(char *name) { /* Print usage to stderr and return error code */
   fprintf(stderr, "Usage: %s [ -n ] <filename> <port>\n", name);
   return 1;
}

int initialize(char *filename, char *port) { /* set up everything on startup */
   FILE *file;
   int portnum, fd;

   /* convert the port number and check it */
   if (!(portnum = atoi(port))) {
      fprintf(stderr, "Bad port number: %s\n", port);
      exit(1);
   }

   /* Allow interactive input (for short messages or good typists). */
   if (!strcmp(filename, "-")) {
      file = stdin;
   } else if (!(file = fopen(filename, "r"))) {
      perror(filename);
      exit(-1);
   }
   if (isatty(fileno(file)))
      fputs("Enter text to be displayed; end with Ctrl-D.\n", stderr);

   /* Read in the text from the file.  Make sure it doesn't overflow what
      we've allocated for it. */
   for (;;) {
      fgets(buf, LINE_LEN, file);
      if (feof(file))
	 break;
      strcpy(buf+strlen(buf)-1, "\r\n");
      if (strlen(buf) + strlen(text) >= MSG_LEN) {
         fputs("Warning: Text too long.  truncated.\n", stderr);
	 break;
      }
      strcat(text, buf);
   }
   fclose(file);
   text_length = strlen(text);

   /* initialize the conns array */
   for (fd = 0; fd < MAX_FDS; fd++)
      conns[fd].active = 0;

   /* set our log output to be line-buffered and log a startup message */
   setlinebuf(stdout);
   printf(buf, "Starting on port %d", portnum);

   return portnum;
}

void watch(int port) { /* watch a port for connections */
   int mother, fd;
   fd_set input_set, output_set;

   /* Initialize the socket. */
   mother = init_socket(port);

   /* Watch all active sockets for activity. */
   for(;;) {

      /* set up which fds we want to watch for what... */
      FD_ZERO(&input_set);
      FD_ZERO(&output_set);
      for (fd = 0; fd < MAX_FDS; fd++) {
	 if (conns[fd].active) {
	    FD_SET(fd, &input_set);
	    if (conns[fd].write_position != -1) {
	       FD_SET(fd, &output_set);
	    }
	 }
      }

      /* wait for activity */
      if (select(MAX_FDS, &input_set, &output_set, 0, 0) < 0) {
         perror("select");
         exit(1);
      }

      /* do we have a new connection on the mother socket? */
      if (FD_ISSET(mother, &input_set)) {
	 FD_CLR(mother, &input_set); /* (so it doesn't show up when we check
					 for readable sockets below) */
         greet(mother);
      }

      /* do we have any other sockets ready for reading/writing? */
      for (fd = 0; fd < MAX_FDS; fd++) {
	 if (conns[fd].active) {
	    if (FD_ISSET(fd, &input_set))
	       fd_input(fd);
	    if (FD_ISSET(fd, &output_set))
	       fd_output(fd);
	 }
      }
   }
}

void greet(int sock) { /* set up a new connection and write welcome message */
   int fd;

   if ((fd = new_connection(sock)) < 0)
      return;
   else if (fd >= MAX_FDS) {
      close(fd);
      return;
   }
   conns[fd].active = 1;
   conns[fd].write_position = 0;
   fd_output(fd);
}


int new_connection(int s) { /* set up a new connection */
   struct sockaddr_in addr;
   int addr_len = sizeof(addr);
   struct hostent *e; 
   int fd;
   char *hostname;
   u_long a;
   static char numeric_str[20];

   if ((fd = accept(s, (struct sockaddr *) &addr, &addr_len)) < 0)
   {
      perror("Accept");
      return(-1);
   }
   nonblock(fd);

   /* reverse-lookup the hostname if possible and log the connection */

   /*
    * (technically, calling gethostbyaddr is kinda dangerous, because it can
    * block for an indefinite amount of time.. unfortunately there's no
    * adequate, standard way to prevent this, short of fork()ing off a
    * separate process to do the lookup, so we'll just cross our fingers here
    * and pretend unix is a decent OS.. sigh)
    */

   if (e = gethostbyaddr((void *) &addr.sin_addr, sizeof(addr.sin_addr),
			 AF_INET))
      hostname = e->h_name;
   else {
      a = ntohl(addr.sin_addr.s_addr);
      sprintf(numeric_str, "%u.%u.%u.%u",
	      (unsigned) (a >> 24) & 0xff, (unsigned) (a >> 16) & 0xff,
              (unsigned) (a >> 8) & 0xff, (unsigned) a & 0xff);
      hostname = numeric_str;
   }
   printf(buf, "Connect from %s", hostname);

   return(fd);
}

void close_connection(int fd) { /* close the connection */
   close(fd);
   conns[fd].active = 0;
}

int init_socket(int port) { /* initialize and listen to the main socket */
   int s, opt;
   struct sockaddr_in sa;

   /* [comments by jelson:]
    * Should the first argument to socket() be AF_INET or PF_INET?  I don't
    * know, take your pick.  PF_INET seems to be more widely adopted, and
    * Comer (_Internetworking with TCP/IP_) even makes a point to say that
    * people erroneously use AF_INET with socket() when they should be using
    * PF_INET.  However, the man pages of some systems indicate that AF_INET
    * is correct; some such as ConvexOS even say that you can use either one.
    * All implementations I've seen define AF_INET and PF_INET to be the same
    * number anyway, so ths point is (hopefully) moot.
    */

   if ((s = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
      perror("Create socket");
      exit(1);
   }

#if defined(SO_REUSEADDR)
   opt = 1;
   if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR,
		  (char *) &opt, sizeof(opt)  ) < 0) {
      perror("setsockopt REUSEADDR");
      exit(1);
   }
#endif

#if defined(SO_REUSEPORT)
   opt = 1;
   if (setsockopt(s, SOL_SOCKET, SO_REUSEPORT,
		  (char *) &opt, sizeof(opt)  ) < 0) {
      perror("setsockopt REUSEPORT");
      exit(1);
   }
#endif

#if defined(SO_LINGER)
   {
      struct linger ld;

      ld.l_onoff = 0;
      ld.l_linger = 0;
      if (setsockopt(s, SOL_SOCKET, SO_LINGER, &ld, sizeof(ld)) < 0) {
         perror("setsockopt LINGER");
         exit(1);
      }
   }
#endif

   sa.sin_family = AF_INET;
   sa.sin_port = htons(port);
   sa.sin_addr.s_addr = htonl(INADDR_ANY);

   if (bind(s, (struct sockaddr *) & sa, sizeof(sa)) < 0) {
      perror("bind");
      close(s);
      exit(1);
   }
   listen(s, 5);
   conns[s].active = 1;
   conns[s].write_position = -1;
   return s;
}

void fd_output(int fd) { /* write as much as we can of what's left of the text
			    to the given fd, update the position pointer and
			    return */
   int thisround;

   if (conns[fd].write_position > -1) {
      thisround = write(fd, text + conns[fd].write_position,
			text_length - conns[fd].write_position);

      /* if we had a problem writing to the fd, log it and give up */
      if ((thisround < 0) && (errno != EINTR)) {
         perror("Write to socket");
	 conns[fd].write_position = -1;
      } else if (thisround > 0) {
	 /* update our position */
	 conns[fd].write_position += thisround;
	 if (conns[fd].write_position >= strlen(text))
	    conns[fd].write_position = -1;
      }

      if (noread && (conns[fd].write_position < 0))
	 close_connection(fd);
   }
}

void fd_input(int fd) { /* get any input waiting and check it for a CR */
   int len;

   /* read some data into our buffer (if there's more to be read than our
      buffer size, we'll just get the rest next time around) */
   len = read(fd, &buf, BUF_LEN);
   if (len < 0)
      switch (errno) {
       case EINTR:
/*       case EAGAIN:*/
       case EWOULDBLOCK:
	 return;
       default:
	 perror("Read from socket");
  /*
   * Attempt reconnect
   */
	 close_connection(fd);
	 return;
      }

   /* now check for CRs in the input data, and if one is found, close the
      connection. */
   for (--len; len >= 0; len--)
      if ((buf[len] == '\r') || (buf[len] == '\n')) {

	 close_connection(fd);
  /*
   * Broadcast here.
   */
	 return;
      }
}

void nonblock(int sock) { /* set the given socket to non-blocking mode */ 
   if (fcntl(sock, F_SETFL, FNDELAY) == -1)
   {
      perror("Set-nonblock");
      exit(-1);
   }
}

