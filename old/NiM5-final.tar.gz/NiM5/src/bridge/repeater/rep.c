/*
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING); if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/file.h>
#include <signal.h>
#include "rep.h"

#ifndef __FreeBSD__
char *strcasestr( const char *haystack, const char *needle );
#endif

time_t rep_now;  /* current time */
time_t rep_boot; /* current time */
rep_event *rep_event_list, *rep_event_free;
static int event_freecount;
static int control;
char *rep_name;			      /* our IMC name */
unsigned short rep_port;              /* our port; 0=disabled */
unsigned long rep_bind;               /* IP to bind to */
rep_siteinfo_struct rep_siteinfo;

/* sequence memory */
_rep_memory rep_memory[IMC_MEMORY];

unsigned long rep_sequencenumber;	  /* sequence# for outgoing packets */

rep_statistics rep_stats;

IMC_CHANNEL *first_rep_channel;
IMC_CHANNEL *last_rep_channel;
CONNECTION *first_connection;
CONNECTION *last_connection;
INFO *first_info;
INFO *last_info;
REMINFO *first_reminfo;
REMINFO *last_reminfo;
IMC_BLACKLIST *first_blacklist;
IMC_BLACKLIST *last_blacklist;

static void graceful_exit( int sig )
{
   Log( "%s killed from shell.", IMC_VERSIONID );
   rep_shutdown();
}

int main( void )
{
   struct timeval	  last_time;

   gettimeofday( &last_time, NULL );

   signal( SIGPIPE, SIG_IGN );
   signal( SIGTERM, graceful_exit );

   rep_startup( );

   hub_loop(last_time);

   /* Never reaches this point - hub_loop is recursive */
   exit(0);
}

void hub_loop( struct timeval  last_time )
{
    struct timeval now_time;
    long secDelta;
    long usecDelta;
         
    rep_idle( rep_get_event_timeout());

	/*
	 * Synchronize to a clock - make sure that it takes at least a second plus a 1/4 second
     * delay time to go through the loop. Keeps sequence numbers from increasing too fast.
	 * Sleep( last_time + 1/PULSE_PER_SECOND - now ).
	 * Careful here of signed versus unsigned arithmetic.
	 */

    gettimeofday( &now_time, NULL );
      
    usecDelta = ((int) last_time.tv_usec) - ((int) now_time.tv_usec) + 1000000 / 4;
    secDelta  = ((int) last_time.tv_sec ) - ((int) now_time.tv_sec );
	   
    while ( usecDelta < 0 )
    {
        usecDelta += 1000000;
        secDelta  -= 1;
    }

	   
    while ( usecDelta >= 1000000 )
    {
        usecDelta -= 1000000;
        secDelta  += 1;
    }

	   
    if ( secDelta >= 0 && usecDelta >= 0 )
    {
        struct timeval stall_time;

        stall_time.tv_usec = usecDelta;
        stall_time.tv_sec  = secDelta;
		
        if ( select( 0, NULL, NULL, NULL, &stall_time ) < 0 && errno != EINTR )
        {
            perror( "main: select: stall" );
            exit( 1 );
        }
    }

	gettimeofday( &last_time, NULL );
    
    hub_loop(last_time);
    return;
}

// License for strlcpy located at ftp://ftp.openbsd.org/pub/OpenBSD/src/lib/libc/string/strlcpy.c
#ifndef HAVE_STRLCPY
/*
 * Copy src to string dst of size siz.  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz == 0).
 * Returns strlen(src); if retval >= siz, truncation occurred.
 */
size_t strlcpy( char *dst, const char *src, size_t siz )
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;

	/* Copy as many bytes as will fit */
	if (n != 0 && --n != 0) {
		do {
			if ((*d++ = *s++) == 0)
				break;
		} while (--n != 0);
	}

	/* Not enough room in dst, add NUL and traverse rest of src */
	if (n == 0) {
		if (siz != 0)
			*d = '\0';		/* NUL-terminate dst */
		while (*s++)
			;
	}

	return(s - src - 1);	/* count does not include NUL */
}

#endif /* !HAVE_STRLCPY */

// License for strlcat located at ftp://ftp.openbsd.org/pub/OpenBSD/src/lib/libc/string/strlcat.c

#ifndef HAVE_STRLCAT
/*
 * Appends src to string dst of size siz (unlike strncat, siz is the
 * full size of dst, not space left).  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz <= strlen(dst)).
 * Returns strlen(initial dst) + strlen(src); if retval >= siz,
 * truncation occurred.
 */
size_t strlcat( char *dst, const char *src, size_t siz )
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;
	size_t dlen;

	/* Find the end of dst and adjust bytes left but don't go past end */
	while (n-- != 0 && *d != '\0')
		d++;
	dlen = d - dst;
	n = siz - dlen;

	if (n == 0)
		return(dlen + strlen(s));
	while (*s != '\0') {
		if (n != 1) {
			*d++ = *s;
			n--;
		}
		s++;
	}
	*d = '\0';

	return(dlen + (s - src));	/* count does not include NUL */
}

#endif /* !HAVE_STRLCAT */

/*
 *  Error logging
 */
void Log( const char *format, ... )
{
   char buf[LSS];
   struct timeval proper_time;
   time_t current_time;
   char *strtime;
   va_list ap;

   va_start( ap, format );
   vsnprintf( buf, LSS, format, ap );
   va_end( ap );

   gettimeofday( &proper_time, NULL );
   current_time = proper_time.tv_sec;

   strtime                    = ctime( &current_time );
   strtime[strlen(strtime)-1] = '\0';
   fprintf( stderr, "%s :: %s\n", strtime, buf );

   return;
}

/* escape2: escape " -> \", \ -> \\, CR -> \r, LF -> \n */

static const char *escape2(const char *data)
{
   static char buf[IMC_DATA_LENGTH];
   unsigned int i = 0, j = 0;

   buf[0] = '\0';

   if ( !data || data[0] == '\0' )
       return buf;

   for ( i = 0, j = 0; i < IMC_DATA_LENGTH && data[j] != '\0'; i++, j++ ) 
   {
       if ( data[j] == '\n' || data[j] == '\r' || data[j] == '\\' || data[j] == '"' )
       {
           if ( i + 1 == IMC_DATA_LENGTH )
               break;

           buf[i++] = '\\';

           if ( data[j] == '\n' )
               buf[i] = 'n';
           else if ( data[j] == '\r' )
               buf[i] = 'r';
           else if ( data[j] == '\\' )
               buf[i] = '\\';
           else
               buf[i] = '\"';
       }
       else
           buf[i] = data[j];
   }

   buf[i] = '\0';

   return buf;
}

/* printkeys: print key-value pairs, escaping values */
static const char *printkeys( PACKET *data )
{
   static char buf[IMC_DATA_LENGTH];
   char temp[IMC_DATA_LENGTH];
   unsigned char i;

   buf[0] = '\0';

   if ( !data )
       return buf;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( !data->key[i] )
         continue;

      if( !strchr( data->value[i], ' ' ) )
         snprintf( temp, IMC_DATA_LENGTH, "%s=%s ", data->key[i], escape2( data->value[i] ) );
      else
         snprintf( temp, IMC_DATA_LENGTH, "%s=\"%s\" ", data->key[i], escape2( data->value[i] ) );

      strlcat( buf, temp, IMC_DATA_LENGTH );
   }

   return buf;
}

/* add "key=value" to "p" */
void rep_addkey( PACKET *p, const char *key, const char *value )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( p->key[i] && STR_CEQL( key, p->key[i] ) )
      {
         DISPOSE( p->key[i] );
         DISPOSE( p->value[i] );
         break;
      }
   }
   if( !value || value[0] == '\0' )
      return;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( !p->key[i] )
      {
         p->key[i]   = strdup( key );
         p->value[i] = strdup( value );
         return;
      }
   }
}

/* add "key=value" for an integer value */
void rep_addkeyi( PACKET *p, const char *key, int value )
{
   char temp[20];

   snprintf( temp, 20, "%d", value );
   rep_addkey( p, key, temp );
}

/* parsekeys: extract keys from string */
static void parsekeys( const char *string, PACKET *data )
{
   const char *p1;
   char *p2;
   char k[IMC_DATA_LENGTH], v[IMC_DATA_LENGTH];
   bool quote;

   p1 = string;

   while (*p1)
   {
      while( *p1 && isspace(*p1) )
         p1++;

      p2 = k;
      while( *p1 && *p1 != '=' && p2-k < IMC_DATA_LENGTH-1 )
         *p2++=*p1++;
      *p2=0;

      if( !k[0] || !*p1 )		/* no more keys? */
         break;

      p1++;			/* skip the '=' */

      if( *p1 == '"' )
      {
         p1++;
         quote = TRUE;
      }
      else
         quote = FALSE;

      p2 = v;
      while( *p1 && (!quote || *p1 != '"') && (quote || *p1 != ' ') && p2-v < IMC_DATA_LENGTH+1 )
      {
         if( *p1 == '\\' )
         {
	      switch( *(++p1) )
	      {
	         case '\\':
	            *p2++='\\';
	         break;
	         case 'n':
	            *p2++='\n';
	         break;
	         case 'r':
	            *p2++='\r';
	         break;
	         case '"':
	            *p2++='"';
	         break;
	         default:
	            *p2++=*p1;
	         break;
	      }
	      if( *p1 )
	         p1++;
         }
         else
	      *p2++ = *p1++;
      }

      *p2 = 0;

      if( !v[0] )
         continue;

      rep_addkey( data, k, v );

      if( quote && *p1 )
         p1++;
   }
}

/* clear all keys in "p" */
void rep_initdata( PACKET *p )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      p->key[i]   = NULL;
      p->value[i] = NULL;
   }
}

/* free all the keys in "p" */
void rep_freedata( PACKET *p )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
   {
      if( p->key[i] )
         DISPOSE( p->key[i] );
      if( p->value[i] )
         DISPOSE( p->value[i] );
   }
}

/*  rep_getarg: extract a single argument (with given max length) from
 *  argument to arg; if arg==NULL, just skip an arg, don't copy it out
 */
const char *rep_getarg(const char *argument, char *arg, unsigned int length)
{
  unsigned int len = 0;

  if ( !argument || argument[0] == '\0' )
  {
      if ( arg )
          arg[0] = '\0';

      return argument;
  }

  while (*argument && isspace(*argument))
    argument++;

  if (arg)
    while (*argument && !isspace(*argument) && len < length-1)
      *arg++=*argument++, len++;
  else
    while (*argument && !isspace(*argument))
      argument++;

  while (*argument && !isspace(*argument))
    argument++;

  while (*argument && isspace(*argument))
    argument++;

  if (arg)
    *arg = '\0';

  return argument;
}

char *generate2( PACKET *p )
{
   static char temp[IMC_PACKET_LENGTH];
   char newpath[IMC_PATH_LENGTH];

   if( !p->type[0] || !p->i.from[0] || !p->i.to[0] )
   {
      Log( "generate2: bad packet - type: %s from: %s to: %s path %s data: %s", p->type, p->i.from,
        p->i.to, p->i.path, printkeys(p) );
      return NULL;		/* catch bad packets here */
   }

   if( !p->i.path[0] )
      strlcpy( newpath, rep_name, IMC_PATH_LENGTH );
   else
      snprintf( newpath, IMC_PATH_LENGTH, "%s!%s", p->i.path, rep_name );

   snprintf( temp, IMC_PACKET_LENGTH, "%s %lu %s %s %s %s", 
           p->i.from, p->i.sequence, newpath, p->type, p->i.to, printkeys( p ) );
   return temp;
}

PACKET *interpret2( const char *argument )
{
   char seq[20];
   static PACKET out;

   rep_initdata( &out );
   argument = rep_getarg( argument, out.i.from, IMC_NAME_LENGTH );
   argument = rep_getarg( argument, seq, 20 );
   argument = rep_getarg( argument, out.i.path, IMC_PATH_LENGTH );
   argument = rep_getarg( argument, out.type, IMC_TYPE_LENGTH );
   argument = rep_getarg( argument, out.i.to, IMC_NAME_LENGTH );

   if( !out.i.from[0] || !seq[0] || !out.i.path[0] || !out.type[0] || !out.i.to[0] )
   {
      Log( "interpret2: bad packet received and discarded" );
      return NULL;
   }

   parsekeys( argument, &out );

   out.i.sequence = strtoul( seq, NULL, 10 );
   return &out;
}

_rep_vinfo rep_vinfo[] =
{
  { 0, NULL, NULL },
  { 1, NULL, NULL },
  { 2, generate2, interpret2 }
};

/*
 * Key/value manipulation
 */

/* get the value of "key" from "p"; if it isn't present, return "def" */
const char *rep_getkey( const PACKET *p, const char *key, const char *def )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
      if( p->key[i] && STR_CEQL(p->key[i], key))
         return p->value[i];

   return def;
}

/* identical to rep_getkey, except get the integer value of the key */
int rep_getkeyi( const PACKET *p, const char *key, int def )
{
   unsigned char i;

   for( i = 0; i < IMC_MAX_KEYS; i++ )
      if( p->key[i] && STR_CEQL(p->key[i], key))
         return atoi( p->value[i] );

   return def;
}

/*
 *  String manipulation functions, mostly exported
 */

/* return 'mud' from 'player@mud' */
const char *rep_mudof(const char *fullname)
{
   static char buf[IMC_MNAME_LENGTH];
   char *where;

   buf[0] = '\0';

   if ( !fullname || fullname[0] == '\0' )
       return fullname;

   snprintf( buf, IMC_MNAME_LENGTH, "%s", (where = strchr( fullname, '@' )) != NULL ? where + 1 : fullname );
   return buf;
}

/* return 'player' from 'player@mud' */
const char *rep_nameof(const char *fullname)
{
   static char buf[IMC_PNAME_LENGTH];
   unsigned char i = 0, j = 0;

   buf[0] = '\0';

   if ( !fullname || fullname[0] == '\0' )
       return buf;

   for ( i = 0, j = 0; i < IMC_PNAME_LENGTH && fullname[j] != '\0' && fullname[j] != '@'; i++, j++ )
       buf[i] = fullname[j];

   buf[i] = '\0';
   return buf;
}

/* return 'player@mud' from 'player' and 'mud' */
const char *rep_makename(const char *player, const char *mud)
{
  static char buf[IMC_NAME_LENGTH];

  if ( !player || !mud )
      return NULL;

  snprintf( buf, IMC_NAME_LENGTH, "%s@%s", player, mud );
  return buf;
}

/* return 'e' from 'a!b!c!d!e' */
char *rep_lastinpath( const char *path )
{
   const char *where;
   static char buf[IMC_NAME_LENGTH];

   where = path + strlen(path)-1;
   while( *where != '!' && where >= path )
      where--;

   strlcpy( buf, where+1, IMC_NAME_LENGTH );
   return buf;
}

/* return 'b' from 'a!b!c!d!e' */
char * rep_hubinpath( char *path )
{
    const char *separator, *where;
    static char buf[IMC_NAME_LENGTH];
    unsigned int i = 1;

    if ( !path || path[0] == '\0')
        return NULL;

    if ( (separator = strchr( path, '!' ) ) == NULL )
       return rep_name;

    for ( where = separator + 1; *where != '!' && *where != '\0'; where++ )
        i++;

    strlcpy( buf, separator + 1, i );
    return buf;
}

/* return 'a' from 'a!b!c!d!e' */
char *rep_firstinpath( const char *path )
{
   static char buf[IMC_NAME_LENGTH];
   char *p;

   for( p = buf; *path && *path != '!'; *p++=*path++ )
    ;

   *p = 0;
   return buf;
}

/* Check for a name in a list */
int rep_hasname(const char *list, const char *name)
{
    const char *p;
    char arg[IMC_NAME_LENGTH];

    if(!list)
	return(0);

    p=rep_getarg(list, arg, IMC_NAME_LENGTH);
    while (arg[0])
    {
      if (STR_CEQL(name, arg))
        return 1;
      p=rep_getarg(p, arg, IMC_NAME_LENGTH);
    }

    return 0;
}

/* Add a name to a list */
void rep_addname(char **list, const char *name)
{
  char buf[IMC_DATA_LENGTH];

  if (rep_hasname(*list, name))
    return;

  if ( (*list) && (*list)[0] != '\0' )
    snprintf(buf, IMC_DATA_LENGTH, "%s %s", *list, name);
  else
    strlcpy(buf, name, IMC_DATA_LENGTH);
  
  DISPOSE(*list);
  *list=strdup(buf);
}

/* Remove a name from a list */
void rep_removename(char **list, const char *name)
{
  char buf[MSS];
  char arg[IMC_NAME_LENGTH];
  const char *p;
  
  buf[0]=0;
  p=rep_getarg(*list, arg, IMC_NAME_LENGTH);
  while (arg[0])
  {
    if (!STR_CEQL(arg, name))
    {
      if (buf[0])
          strlcat(buf, " ", MSS);

      strlcat(buf, arg, MSS);
    }
    p=rep_getarg(p, arg, IMC_NAME_LENGTH);
  }

  DISPOSE(*list);
  *list=strdup(buf);
}

/* get some IMC stats, return a string describing them */
char *rep_getstats( char *choice )
{
   static char buf[IMC_DATA_LENGTH];
   unsigned int evcount = 0;
   rep_event *ev = rep_event_list;

   if ( !choice || choice[0] == '\0' || STR_CEQL( choice, "network" ))
   {

   
       while( ev )
       {
          evcount++;
          ev = ev->next;
       }

       snprintf( buf, IMC_DATA_LENGTH,
                               "~WGeneral IMC Statistics\n\r"
                               "~cReceived packets   : ~C%ld\n\r"
                               "~cReceived bytes     : ~C%ld\n\r"
                               "~cTransmitted packets: ~C%ld\n\r"
                               "~cTransmitted bytes  : ~C%ld\n\r"
                               "~cMaximum packet size: ~C%d\n\r"
                               "~cPending events     : ~C%d\n\r"
                               "~cSequence drops     : ~C%d\n\r"
                               "~cLast IMC Boot      : ~C%s\n\r",
            rep_stats.rx_pkts, rep_stats.rx_bytes, rep_stats.tx_pkts, rep_stats.tx_bytes,
            rep_stats.max_pkt, evcount, rep_stats.sequence_drops, ctime( &rep_boot ) );

       return buf;
   }  

   if (STR_CEQL( choice, "general"))
   {
      snprintf( buf, IMC_DATA_LENGTH,
                              "~WSite Information:\n\r"
                              "~cName           ~W:~C %s\n\r"
                              "~cIMC Version    ~W:~C %s\n\r"
                              "~cWebpage        ~W:~C %s\n\r",
         rep_name, IMC_VERSIONID, rep_siteinfo.web );

      return buf;
   }

   return "Bad invocation of rep_getstats."; 
}
/*
 *  rep_reminfo handling
 */

/* find an info entry for "name" */
REMINFO *rep_find_reminfo( const char *name )
{
   REMINFO *p;

   if ( !name )
       return NULL;

   for( p = first_reminfo; p; p = p->next )
   {
      if( STR_CEQL( name, p->name ))
         return p;
   }
   return NULL;
}

/* create a new info entry, insert into list */
REMINFO *rep_new_reminfo( char *mud )
{
   REMINFO *p, *mud_prev;

   CREATE( p, REMINFO, 1 );

   p->name    = strdup( mud );
   p->netname = NULL;
   p->web = NULL;
   p->version = NULL;
   p->path   = NULL;
   p->top_sequence = 0;

   for( mud_prev = first_reminfo; mud_prev; mud_prev = mud_prev->next )
      if( strcasecmp( mud_prev->name, mud ) >= 0 )
         break;

   if( !mud_prev )
      LINK( p, first_reminfo, last_reminfo, next, prev );
   else
      INSERT( p, mud_prev, first_reminfo, next, prev );

   return p;
}

/* delete the info entry "p" */
void rep_delete_reminfo( REMINFO *p )
{
   if( !first_reminfo || !p )
      return;

   UNLINK( p, first_reminfo, last_reminfo, next, prev );

   if ( p->name )
      DISPOSE( p->name );
   if ( p->netname )
      DISPOSE( p->netname );
   if ( p->web )
      DISPOSE( p->web );
   if ( p->version )
      DISPOSE( p->version );
   if ( p->path )
      DISPOSE( p->path );

   rep_cancel_event( NULL, p );
   DISPOSE( p );
}

/* get info struct for given mud */
INFO *rep_getinfo( const char *mud )
{
   INFO *p;

   for( p = first_info; p; p = p->next )
      if( STR_CEQL( mud, p->name ) )
         return p;

   return NULL;
}

/* get name of a connection */
const char *rep_getconnectname( const CONNECTION *c )
{
   static char buf[IMC_NAME_LENGTH];
   const char *n;

   if( c->info )
      n = c->info->name;
   else
      n = "unknown";

   snprintf( buf, IMC_NAME_LENGTH, "%s[%d]", n, c->desc );
   return buf;
}

/* set up for a reconnect */
void rep_setup_reconnect( INFO *i )
{
   time_t temp;
   int t;

   /*  add a bit of randomness so we don't get too many simultaneous reconnects */
   /*  attempts a reconnect in two minutes plus random amount */
   temp = (2*60) + (rand()%21) - 20;
   t = rep_next_event( ev_reconnect, i );

   if( t >= 0 && t < temp)
       return;

   if ( t >= 0 )
   {
       rep_cancel_event( ev_reconnect, i );
   }

   rep_add_event( temp, ev_reconnect, i );
   return;
}

const char *ice_mudof(const char *fullname)
{
  static char buf[IMC_MNAME_LENGTH];
  char *where=buf;
  unsigned int count = 0;

  while (*fullname && *fullname != ':' && count < IMC_MNAME_LENGTH - 1)
    *where++=*fullname++, count++;

  *where = 0;
  return buf;
}

/* see if someone can talk on a channel - lots of string stuff here! */
bool ice_audible(IMC_CHANNEL *c, const char *who)
{

  if ( !c || !who || who[0] == '\0' )
    return FALSE;

  /* owners and operators always can */
  if (STR_CEQL(c->owner, who) || rep_hasname(c->operators, who))
    return TRUE;

  /* ICE locally can use any channel */
  if (STR_CEQL(rep_nameof(who), "ICE") && STR_CEQL(rep_mudof(who), rep_name))
    return TRUE;
  
  if (c->open)
  {
    /* open policy. default yes. override with excludes, then invites */
    if ((rep_hasname(c->excluded, who) || rep_hasname(c->excluded, rep_mudof(who))) &&
	!rep_hasname(c->invited, who) && !rep_hasname(c->invited, rep_mudof(who)))
      return FALSE;
      
    return TRUE;
  }

  /* closed or private. default no, override with invites, then excludes */
  
  if ((rep_hasname(c->invited, who) || rep_hasname(c->invited, rep_mudof(who))) &&
      !rep_hasname(c->excluded, who) && !rep_hasname(c->excluded, rep_mudof(who)))
    return TRUE;
    
  return FALSE;
}

/* set up a new rep_connect struct, and link it into rep_connect_list */
CONNECTION *rep_new_connect( void )
{
   CONNECTION *c;

   CREATE( c, CONNECTION, 1 );

   c->state    = CONN_NONE;
   c->desc     = -1;
   c->insize   = IMC_MINBUF;
   CREATE( c->inbuf, char, c->insize );
   c->outsize  = IMC_MINBUF;
   CREATE( c->outbuf, char, c->outsize );
   c->inbuf[0] = c->outbuf[0] = '\0';
   c->info     = NULL;
   c->ip       = NULL;
   c->newoutput = 0;

   LINK( c, first_connection, last_connection, next, prev );
   return c;
}

/*  free buffers and extract 'c' from rep_connect_list
 *  called from rep_idle_select when we're done with a connection with
 *  c->state==CONN_NONE
 */
void rep_extract_connect( CONNECTION *c )
{
   if( c->state != CONN_NONE )
   {
      Log( "rep_extract_connect: non-closed connection" );
      return;
   }

   DISPOSE( c->inbuf );
   DISPOSE( c->outbuf );

   if ( c->ip )
       DISPOSE( c->ip );

   UNLINK( c, first_connection, last_connection, next, prev );
   rep_cancel_event( NULL, c );
   DISPOSE( c );
}

/* update our routing table based on a packet received with path "path" */
static void updateroutes( char *path )
{
   REMINFO *p;
   char *sender;
   char *temp;

   /* loop through each item in the path, and update routes to there */

   temp = path;
   while( temp && temp[0] )
   {
      sender = rep_firstinpath( temp );

      if( !STR_CEQL( sender, rep_name ) )
      {
         /* not from us */
         /* check if its in the list already */

         p = rep_find_reminfo( sender );
         if( !p )			/* not in list yet, create a new entry */
         {
             p = rep_new_reminfo( sender );

             p->netname = strdup("unknown");
             p->web     = strdup("unknown");
             p->version = strdup("unknown");
         }

         if (p->path)
             DISPOSE(p->path);
         p->path = strdup( temp );
      }
      /* get the next item in the path */
      temp = strchr( temp, '!' );
      if( temp )
        temp++;			/* skip to just after the next '!' */
   }
}

/* return 1 if 'name' is a part of 'path'  (internal) */
bool inpath(const char *path, const char *name)
{
  char buf[IMC_MNAME_LENGTH+3];

  if ( !path || path[0] == '\0' || !name || name[0] == '\0' )
      return FALSE;

  if (STR_CEQL(path, name))
      return TRUE;

  snprintf(buf, IMC_MNAME_LENGTH+3, "%s!", name);
  if (STRN_CEQL(path, buf, strlen(buf)))
      return TRUE;

  snprintf(buf, IMC_MNAME_LENGTH+3, "!%s", name);
  if (strlen(buf) < strlen(path) &&
      STR_CEQL(path + strlen(path) - strlen(buf), buf))
      return TRUE;

  snprintf(buf, IMC_MNAME_LENGTH+3, "!%s!", name);
  if (strcasestr(path, buf))
      return TRUE;

  return FALSE;
}

/*
 *  Core functions (all internal)
 */

/* accept a connection on the control port */
static void do_accept( void )
{
   int d;
   CONNECTION *c;
   struct sockaddr_in sa;
   unsigned int size = sizeof(sa);
   int r;

   d = accept( control, (struct sockaddr *) &sa, &size );
   if( d < 0 )
   {
      Log( "do_accept: accept call failed" );
      return;
   }

   r = fcntl( d, F_GETFL, 0 );
   if( r < 0 || fcntl( d, F_SETFL, O_NONBLOCK | r ) < 0 )
   {
      Log( "do_accept: fcntl call failed" );
      close(d);
      return;
   }

   c = rep_new_connect();
   c->state    = CONN_WAITCLIENTPWD;
   c->desc     = d;
   c->ip       = strdup( inet_ntoa(sa.sin_addr) );

   rep_add_event( IMC_LOGIN_TIMEOUT, ev_login_timeout, c );
   Log( "New connection from %s:%d on descriptor %d.", c->ip, ntohs(sa.sin_port), d );
}

/* notify everyone of the closure - shogar */
void rep_close_notify( INFO *i )
{
   PACKET out;

   if ( !i || !i->name || i->name[0] == '\0' )
       return;

   rep_initdata( &out );
   strlcpy( out.type, "close-notify", IMC_TYPE_LENGTH );
   strlcpy( out.from, "*", IMC_NAME_LENGTH );
   strlcpy( out.to, "*@*", IMC_NAME_LENGTH );
   rep_addkey( &out, "versionid", IMC_VERSIONID );
   rep_addkey( &out, "host", i->name );
   rep_send( &out );
   /* log and announce if closed via event - shogar 2/26/2000 */
   Log( "%s: closing link(sending close-notify)", i->name );
   rep_freedata( &out );
}

/* close given connection */
void do_close( CONNECTION *c )
{
   REMINFO *r;

   if( c->state == CONN_NONE )
      return;

   c->state = CONN_NONE;

   if ( c->desc )
   {
       close( c->desc );
       c->desc = 0;
   }

   if ( c->info )
   {
       c->info->connection = NULL;

       /* dont announce a simple reboot  - shogar - 2/2/2000 */ 
       rep_add_event( 60, ev_close_notify, c->info );

       /* Handle reconnects */
       if ( c->info->port > 0 )
           rep_setup_reconnect( c->info );

       if ( (r = rep_find_reminfo( c->info->name ) ) != NULL )
           rep_delete_reminfo( r );

       c->info = NULL;
   }
   else
       Log( "%s: closing link", rep_getconnectname( c ) );

   c->inbuf[0] = '\0';
   c->outbuf[0] = '\0';
}

/* read waiting data from descriptor.
 * read to a temp buffer to avoid repeated allocations
 */
static void do_read( CONNECTION *c )
{
   unsigned int size;
   int r;
   char temp[IMC_MAXBUF];
   char *newbuf;
   unsigned int newsize;

   r = read( c->desc, temp, IMC_MAXBUF-1 );
   if( !r || ( r < 0 && errno != EAGAIN && errno != EWOULDBLOCK ) )
   {
       if( r < 0 )                    /* read error */
           Log( "%s: do_read: %s", rep_getconnectname( c ), strerror(errno) );
       else                        /* socket was closed */
           Log( "%s: do_read: connection closed from other side", rep_getconnectname( c ) );

      do_close( c );
      return;
   }
  
   if( r < 0 )			/* EAGAIN error */
      return;

   temp[r] = '\0';

   size = strlen( c->inbuf ) + r + 1;

   if( size >= c->insize )
   {
      newsize = c->insize;
      while( newsize < size )
         newsize *= 2;

      CREATE( newbuf, char, newsize );
      strlcpy( newbuf, c->inbuf, newsize );
      DISPOSE( c->inbuf );
      c->inbuf = newbuf;
      c->insize = newsize;
   }

   if( size < c->insize/2 && size >= IMC_MINBUF )
   {
      newsize = c->insize;
      newsize /= 2;

      CREATE( newbuf, char, newsize );
      strlcpy( newbuf, c->inbuf, newsize );
      DISPOSE( c->inbuf );
      c->inbuf = newbuf;
      c->insize = newsize;
   }

   strlcat( c->inbuf, temp, c->insize );

   rep_stats.rx_bytes += r;
}

/* write to descriptor */
static void do_write( CONNECTION *c )
{
   unsigned int size = 0;
   int w = 0;

   if( c->state == CONN_SERVERCONNECT )
   {
      /* Wait for server password */
      c->state = CONN_WAITSERVERPWD;
      return;
   }

   size = strlen( c->outbuf );
   if( size == 0 ) /* nothing to write */
      return;

   w = write( c->desc, c->outbuf, size );
   if( !w || ( w < 0 && errno != EAGAIN && errno != EWOULDBLOCK ) )
   {
       if( w < 0 )			/* write error */
           Log( "%s: do_write: %s", rep_getconnectname( c ), strerror(errno) );
       else			/* socket was closed */
           Log( "%s: do_write: connection closed from other side", rep_getconnectname( c ) );

      do_close( c );
      return;
   }

   if( w < 0 )			/* EAGAIN */
      return;

   strlcpy( c->outbuf, c->outbuf + w, c->outsize );

   rep_stats.tx_bytes += w;

}

/* put a line onto descriptors output buffer */
static void do_send( CONNECTION *c, const char *line )
{
   unsigned int len;
   char *newbuf;
   unsigned int newsize = c->outsize;

   if( c->state == CONN_NONE )
      return;

   if( !c->outbuf[0] )
      c->newoutput = 1;

   len = strlen( c->outbuf ) + strlen( line ) + 3;

   if( len > c->outsize )
   {
      while( newsize < len )
         newsize *= 2;

      CREATE( newbuf, char, newsize );
      strlcpy( newbuf, c->outbuf, newsize );
      DISPOSE( c->outbuf );
      c->outbuf = newbuf;
      c->outsize = newsize;
   }
   if( len < c->outsize/2 && len >= IMC_MINBUF )
   {
      newsize = c->outsize/2;

      CREATE( newbuf, char, newsize );
      strlcpy( newbuf, c->outbuf, newsize );
      DISPOSE( c->outbuf );
      c->outbuf = newbuf;
      c->outsize = newsize;
   }
   strlcat( c->outbuf, line, c->outsize  );

   strlcat( c->outbuf, "\n\r", c->outsize );
}

/*  try to read a line from the input buffer, NULL if none ready
 *  all lines are \n\r terminated in theory, but take other combinations
 */
static const char *getline(char *buffer, int len)
{
  unsigned int i;
  static char buf[IMC_PACKET_LENGTH];

  /* copy until \n, \r, end of buffer, or out of space */
  for (i=0; buffer[i] && buffer[i] != '\n' && buffer[i] != '\r' && i+1 < IMC_PACKET_LENGTH; i++)
    buf[i] = buffer[i];

  /* end of buffer and we haven't hit the maximum line length */
  if (!buffer[i] && i+1 < IMC_PACKET_LENGTH)
  {
    buf[0]='\0';
    return NULL;		/* so no line available */
  }

  /* terminate return string */
  buf[i]=0;

  /* strip off extra control codes */
  while (buffer[i] && (buffer[i] == '\n' || buffer[i] == '\r'))
    i++;

  /* remove the line from the input buffer */
  strlcpy(buffer,buffer+i, len);

  return buf;
}

static int memory_head; /* next entry in memory table to use, wrapping */

/* checkrepeat: check for repeats in the memory table */
bool checkrepeat(const char *mud, unsigned long seq)
{
  unsigned int i;

  for (i=0; i<IMC_MEMORY; i++)
    if (rep_memory[i].from && seq == rep_memory[i].sequence && STR_CEQL(mud, rep_memory[i].from))
      return TRUE;

  /* not a repeat, so log it */

  if (rep_memory[memory_head].from)
    DISPOSE(rep_memory[memory_head].from);

  rep_memory[memory_head].from     = strdup(mud);
  rep_memory[memory_head].sequence = seq;
  
  memory_head++;
  if (memory_head==IMC_MEMORY)
    memory_head=0;

  return FALSE;
}

/* send a packet to a mud using the right version */
static void do_send_packet( CONNECTION *c, PACKET *p )
{
   const char *output;
   unsigned char v;

   v = c->version;
   
   if( v > IMC_VERSION )
      v = IMC_VERSION;

   output = ( *rep_vinfo[v].generate )(p);

   if( output )
   {
      rep_stats.tx_pkts++;

      if( strlen( output ) > rep_stats.max_pkt )
         rep_stats.max_pkt = strlen( output );

      do_send( c, output );
   }
}

bool can_forward( const PACKET *p )
{
   if( STR_CEQL( p->type, "chat" ) || STR_CEQL( p->type, "emote" ) )
   {
      unsigned char chan = rep_getkeyi( p, "channel", 0 );
    
      if( chan == 0 || chan == 1 || chan == 3 )
         return FALSE;
   }
   else if ( STR_CEQL( p->type, "keepalive-request" ) )
   {
       if ( !STR_CEQL( rep_mudof(p->from), rep_name ) )
           return FALSE;
   }
   else if ( STR_CEQL( p->type, "ice-refresh" ) )
   {
       bool relay = rep_getkeyi( p, "relayed", 0 );

       if ( !relay && !STR_CEQL( rep_mudof( p->i.from), rep_name ) )
           return FALSE;
   }

   return TRUE;
}

/* forward a packet - main routing function, all packets pass through here */
static void forward( PACKET *p )
{
   REMINFO *route = NULL;
   INFO *i = NULL, *direct = NULL;
   const char *to;
   bool isbroadcast = FALSE;

   /* check for duplication, and register the packet in the sequence memory */
   if( p->i.sequence && checkrepeat( rep_mudof( p->i.from ), p->i.sequence ) )
      return;

   /* check for packets we've already forwarded */
   if( inpath( p->i.path, rep_name ))
      return;

   /* update our routing info */
   updateroutes( p->i.path );

   /* check for really old packets */
   if( (route = rep_find_reminfo( rep_mudof( p->i.from ) )) != NULL )
   {
      if( ( p->i.sequence+IMC_PACKET_LIFETIME ) < route->top_sequence )
      {
         rep_stats.sequence_drops++;
         return;
      }
      if( p->i.sequence > route->top_sequence )
         route->top_sequence = p->i.sequence;
   }

   to = rep_mudof( p->i.to );
   isbroadcast = STR_EQL( to, "*"); /* broadcasts are, well, broadcasts */

   /* forward to our mud if it's for us */
   if( isbroadcast || STR_CEQL( to, rep_name ) )
   {
      strlcpy( p->to, rep_nameof( p->i.to ), IMC_NAME_LENGTH );    /* strip the name from the 'to' */
      strlcpy( p->from, p->i.from, IMC_NAME_LENGTH );

      rep_recv(p);

      /* if its only to us (ie. not broadcast) don't forward it */
      if ( !isbroadcast )
          return;
   }

   /* check if we should just drop it (policy rules) */
   if( !can_forward(p) )
      return;

   /* convert 'to' fields that we have a route for to a hop along the route */
  
   if( !isbroadcast && ( route = rep_find_reminfo( to ) ) != NULL 
           && route->path != NULL && !inpath( p->i.path, rep_lastinpath(route->path) ) )
   /* avoid circular routing */
   {
      /*  check for a direct connection: if we find it, and the route isn't
       *  to it, then the route is a little suspect.. also send it direct
       */
      if( !STR_CEQL( to, rep_lastinpath(route->path) )  
              &&  (i = rep_getinfo(to)) != NULL && i->connection )
         direct = i;

      to = rep_lastinpath(route->path);
   }

   /* check for a direct connection */
  
   if( !isbroadcast && ((i = rep_getinfo(to)) == NULL || !i->connection) 
	   && ( !direct || !direct->connection ))
   {
	 Log( "No path available for packet sent from %s to %s of type %s.", 
             rep_mudof(p->i.from), p->i.to, p->type );
	 return;
   }

   if( isbroadcast )
   {	
      CONNECTION *c = NULL;

      for( c = first_connection; c; c = c->next )
      {
         if( c->state == CONN_COMPLETE )
         {
	      /* don't forward to sites that have already received it, or sites that don't need this packet */
	      if( inpath( p->i.path, c->info->name ) )
	         continue;
	      /* end SPAM fix */
	      do_send_packet( c, p );
         }
      }
   }
   else
      /* forwarding to a specific connection */
   {
      /* but only if they haven't seen it (sanity check) */
      if( i && i->connection && !inpath( p->i.path, i->name ) )
         do_send_packet( i->connection, p );

      /* send on direct connection, if we have one */
      if( direct && direct != i && direct->connection && !inpath( p->i.path, direct->name ) )
         do_send_packet( direct->connection, p );
   }
}

IMC_BLACKLIST *rep_find_blacklist( char *ip )
{
    IMC_BLACKLIST *bld = NULL;

    if ( !ip || ip[0] == '\0' )
        return NULL;

    for ( bld = first_blacklist; bld; bld = bld->next )
        if ( STR_CEQL( bld->ip, ip ) )
            break;

    return bld;
}

bool add_to_blacklist( char *ip )
{
    IMC_BLACKLIST *nble = NULL;

    if ( !ip || ip[0] == '\0' )
        return FALSE;

    if ( (nble = rep_find_blacklist( ip ) ) != NULL )
        return FALSE;

    CREATE( nble, IMC_BLACKLIST, 1 );
    nble->ip = strdup( ip );

    LINK( nble, first_blacklist, last_blacklist, next, prev );
    return TRUE;
}

bool rem_from_blacklist( char *ip )
{
    IMC_BLACKLIST *tbl = NULL;

    if ( !ip || ip[0] == '\0' )
        return FALSE;

    if ( (tbl = rep_find_blacklist( ip ) ) == NULL )
        return FALSE;

    if ( tbl->ip )
        DISPOSE( tbl->ip );

    UNLINK( tbl, first_blacklist, last_blacklist, next, prev );
    DISPOSE(tbl);

    return TRUE;
}

bool rep_readblacklist( void )
{
    char ip[24];
    FILE *bl;

    if ( !(bl = fopen( IMC_BLACKLIST_FILE, "r" )) )
    {
        Log( "Blacklist file could not be opened for reading." );
        return FALSE;
    }

    while ( fscanf( bl, "%23[^\n]\n", ip ) == 1 )
        add_to_blacklist( ip );

    SFCLOSE( bl );
    return TRUE;
}

bool rep_saveblacklist( void )
{
    FILE *bl;
    IMC_BLACKLIST *nble = NULL;

    if ( !(bl = fopen( IMC_BLACKLIST_FILE, "w" )) )
    {
        Log( "Blacklist file could not be opened for writing." );
        return FALSE;
    }

    for( nble = first_blacklist; nble; nble = nble->next )
        if ( nble->ip && nble->ip[0] != '\0' )
            fprintf( bl, "%s\n", nble->ip );

    fprintf( bl, "\n" );

    SFCLOSE( bl );
    return TRUE;
}

/* handle a password from a client */
static void clientpassword( CONNECTION *c, const char *argument )
{
   char type[3], name[IMC_MNAME_LENGTH], pw[IMC_PW_LENGTH], version[20];
   char command[IMC_PW_LENGTH], carg1[IMC_PW_LENGTH];
   INFO *i;
   char response[IMC_PACKET_LENGTH];

   argument = rep_getarg( argument, type, 3 );      /* packet type (has to be PW) */
   argument = rep_getarg( argument, name, IMC_MNAME_LENGTH );  /* remote mud name */
   argument = rep_getarg( argument, pw, IMC_PW_LENGTH );	         /* password */
   argument = rep_getarg( argument, version, IMC_PW_LENGTH );	/* optional version=n string */
   argument = rep_getarg( argument, command, IMC_PW_LENGTH ); /* connection command */
   argument = rep_getarg( argument, carg1, IMC_PW_LENGTH ); /* first argument for connection command */

   /* check for a version string (assume version 2 if not present) */
   if ( sscanf( version, "version=%hu", &c->version ) != 1 )
       c->version = 2;

   /* check for generator/interpreter */
   if( !rep_vinfo[c->version].generate || !rep_vinfo[c->version].interpret )
   {
       Log( "%s: unsupported version %d on connect", rep_getconnectname(c), c->version );
       do_close(c);
       return;
   }

   if( !STR_CEQL( type, "PW" ) )
   {
      Log( "%s: non-PW password packet sent on connect", rep_getconnectname( c ) );
      do_close( c );
      return;
   }

   i = rep_getinfo( name );

   if ( STR_CEQL( command, "autosetup" ) && !i )
   {
       c->state = CONN_DISCONNECT; 

       if ( !rep_siteinfo.autosetup )
       {
           snprintf( response, IMC_PACKET_LENGTH, "autosetup %s reject private", rep_name );
           Log( "%s: autosetup rejected because it is disabled.", rep_getconnectname(c) );
       }
       else if ( (i && i->connection) || rep_find_reminfo(name) != NULL )
       {
           snprintf( response, IMC_PACKET_LENGTH, "autosetup %s reject connected", rep_name );
           Log( "%s: autosetup rejected because mud already connected.", rep_getconnectname(c) );
       }
       else if ( STR_CEQL( name, "*" ) || STR_CEQL( name, "$" ) || strchr( name, '!') 
               || strchr( name, ':') )
       {
           snprintf( response, IMC_PACKET_LENGTH, "autosetup %s reject badname", rep_name );
           Log( "%s: autosetup rejected because mud's name invalid.", rep_getconnectname(c) );
       }
       else if ( rep_siteinfo.conncount >= rep_siteinfo.maxconn )
       {
           snprintf( response, IMC_PACKET_LENGTH, "autosetup %s reject full", rep_name );
           Log( "%s: autosetup rejected because hub is full.", rep_getconnectname(c) );
       }
       else if ( !carg1 || carg1[0] == '\0' )
       {
           snprintf( response, IMC_PACKET_LENGTH, "autosetup %s reject nopass2", rep_name );
           Log( "%s: autosetup rejected because serverpass not sent.", rep_getconnectname(c) );
       }
       else if ( rep_find_blacklist( c->ip ) != NULL )
       {
           snprintf( response, IMC_PACKET_LENGTH, "autosetup %s reject ban", rep_name );
           Log( "%s: autosetup rejected because mud is banned.", rep_getconnectname(c) );
       }
       else
       {
           i = rep_new_info();
           i->name = strdup( name );
           i->clientpw = strdup( pw );
           i->serverpw = strdup( carg1 );

           rep_saveconfig();

           snprintf( response, IMC_PACKET_LENGTH, "autosetup %s accept %s", 
                   rep_name, rep_siteinfo.netname );
       }
   }
   else
   {
       /* do we know them, and do they have the right password? */
       if( !i || !STR_EQL( i->clientpw, pw ) )
       {
           Log( "%s: password failure for %s", rep_getconnectname( c ), name );
           do_close( c );
           return;
       }

       if ( rep_find_blacklist( c->ip ) != NULL )
       {
           Log( "%s: attempted connection from blacklisted %s(%s)", 
                   rep_getconnectname( c ), c->ip, name ); 
           do_close( c );
           return;
       }
   
       if( i->connection )	                      /* kill old connections */
           do_close( i->connection );
       
       /* send our response */
       snprintf( response, IMC_PACKET_LENGTH, "PW %s %s version=%d %s", 
               rep_name, i->serverpw, IMC_VERSION, rep_siteinfo.netname );
   }
       
   do_send( c, response );

   if ( i != NULL )
   {
       /* register them */
       c->state = CONN_COMPLETE;
       i->connection = c;
       c->info = i;

       /* dont log and announce if event - shogar 2/26/2000 */
       if( !rep_find_event( ev_close_notify, i ) )
           Log( "%s: connected (version %d)", rep_getconnectname(c), c->version );

       c->info->last_connected = rep_now;
       rep_cancel_event( ev_login_timeout, c );
       rep_cancel_event( ev_reconnect, c->info );
       /* if reconnecting on simple reboot don't - shogar - 2/1/2000 */
       rep_cancel_event( ev_close_notify, i );
   }

   return;
}

/* handle a password response from a server */
static void serverpassword( CONNECTION *c, const char *argument )
{
   char type[3], name[IMC_MNAME_LENGTH], pw[IMC_PW_LENGTH], version[20];
   INFO *i;

   argument = rep_getarg( argument, type, 3 );	/* has to be PW */
   argument = rep_getarg( argument, name, IMC_MNAME_LENGTH );
   argument = rep_getarg( argument, pw, IMC_PW_LENGTH );
   argument = rep_getarg( argument, version, 20 );

   if( !STR_CEQL( type, "PW" ) )
   {
      Log( "%s: non-PW password packet on connect", rep_getconnectname( c ) );
      do_close( c );
      return;
   }

   i = rep_getinfo( name );
   if( !i || !STR_EQL( i->serverpw, pw ) || i != c->info )
   {
      Log( "%s: password failure for %s", rep_getconnectname( c ), name );
      do_close( c );
      return;
   }

   if( i->connection )	/* kill old connections */
      do_close( i->connection );

   i->connection         = c;

   c->state              = CONN_COMPLETE;

   /* check for a version string (assume version 2 if not present) */
   if( sscanf( version, "version=%hu", &c->version ) != 1 )
      c->version = 2;

   /* check for generator/interpreter */
   if( !rep_vinfo[c->version].generate || !rep_vinfo[c->version].interpret )
   {
      Log( "%s: unsupported version %d on connect", rep_getconnectname(c), c->version );
      do_close( c );
      return;
   }

   Log( "%s: connected (version %d)", rep_getconnectname(c), c->version );

   c->info->last_connected = rep_now;
   rep_cancel_event( ev_login_timeout, c );
   rep_cancel_event( ev_reconnect, c->info );
   /* if reconnecting on simple reboot don't - shogar - 2/1/2000 */
   rep_cancel_event( ev_close_notify, c->info );

   rep_request_keepalive();
   rep_send_keepalive( NULL, "*" );
}

/* start up listening port */
bool rep_startup_port(void)
{
  int i;
  struct sockaddr_in sa;

  Log("Binding port %d for incoming connections.", rep_port);
      
  control = socket(AF_INET, SOCK_STREAM, 0);
  if (control<0)
  {
    Log("rep_startup_port: socket call failure");
    return FALSE;
  }
    
  i=1;
  if (setsockopt(control, SOL_SOCKET, SO_REUSEADDR, (void *)&i, sizeof(i))<0)
  {
    Log("rep_startup_port: SO_REUSEADDR unable to be set");
    close(control);
    return FALSE;
  }
  
  if ((i=fcntl(control, F_GETFL, 0))<0)
  {
    Log("rep_startup_port: fcntl(F_GETFL) call failure");
    close(control);
    return FALSE;
  }

  if (fcntl(control, F_SETFL, i | O_NONBLOCK)<0)
  {
    Log("rep_startup_port: fcntl(F_SETFL) call failure");
    close(control);
    return FALSE;
  }

  sa.sin_family      = AF_INET;
  sa.sin_port        = htons(rep_port);
  sa.sin_addr.s_addr = rep_bind; /* already in network order */
  
  if (bind(control, (struct sockaddr *)&sa, sizeof(sa))<0)
  {
    Log("rep_startup_port: bind call failure");
    close(control);
    return FALSE;
  }
  
  if (listen(control, 3)<0)
  {
    Log("rep_startup_port: listen call failure");
    close(control);
    return FALSE;
  }
  
  return TRUE;
}

/* shut down listening port */
void rep_shutdown_port(void)
{
  Log("Closing listening port.");
  close(control);
}

/* start up IMC */
bool rep_startup_network( void )
{
   INFO *info = NULL;

   control = -1;
      
   if( !rep_startup_port() )
       return FALSE;

   rep_stats.rx_pkts  = 0;
   rep_stats.tx_pkts  = 0;
   rep_stats.rx_bytes = 0;
   rep_stats.tx_bytes = 0;
   rep_stats.sequence_drops = 0;

   /* Allow updating mud connections list without reboot */
   if ( rep_siteinfo.updatefile )
       rep_add_event( 15, ev_mudconnections, NULL );

   /* Start regular replist publication */
   if ( rep_siteinfo.htmlmudlist )
       rep_add_event( 10, ev_htmlmudlist, NULL );

   /* Start regular statistics publication */
   if ( rep_siteinfo.htmlstats )
       rep_add_event( 10, ev_htmlstats, NULL );

   /* Send channel information to everyone */
   rep_add_event( 5, ev_iced_update, NULL );

   /* Clear out any cached replists */
   for ( info = first_info; info; info = info->next )
       rep_add_event( 60, ev_close_notify, info );

   /* do autoconnects */
   for( info = first_info; info; info = info->next )
       if ( info->port > 0 )
           rep_connect_to( info->name );

   return TRUE;
}

void rep_startup( void )
{
  rep_now=time(NULL);                  /* start our clock */
  rep_boot=rep_now;

  Log("%s initializing.", IMC_VERSIONID);

  rep_sequencenumber=rep_now;
  rep_readblacklist();
  iced_load_channels();

  if (!rep_readconfig() || !rep_startup_network())
  {
      Log( "hub: giving up" );
      exit(1);
  }

}

void rep_shutdown_network( void )
{
   rep_event *ev, *ev_next;
   CONNECTION *c, *c_next;
   REMINFO *p, *pnext;

   rep_shutdown_port();

   Log( "Received %ld bytes(%ld packets) total.", rep_stats.rx_bytes, rep_stats.rx_pkts );
   Log( "Received %d age-dropped packets.", rep_stats.sequence_drops );
   Log( "Sent %ld bytes(%ld packets) total.", rep_stats.tx_bytes, rep_stats.tx_pkts );
   Log( "The largest packet sent or received was %d bytes.", rep_stats.max_pkt );

   for( c = first_connection; c; c = c_next )
   {
      c_next = c->next;
      do_close( c );
      rep_extract_connect( c );
   }

   for( p = first_reminfo; p; p = pnext )
   {
      pnext = p->next;
      rep_delete_reminfo( p );
   }

   for( ev = rep_event_list; ev; ev = ev_next )
   {
      ev_next = ev->next;
      ev->next = NULL;
      DISPOSE( ev );
   }
   for( ev = rep_event_free; ev; ev = ev_next )
   {
      ev_next = ev->next;
      ev->next = NULL;
      DISPOSE( ev );
   }
   rep_event_list = rep_event_free = NULL;
}

void rep_delete_info( INFO *i )
{
   CONNECTION *c;

   for( c = first_connection; c; c = c->next )
      if( c->info == i )
         do_close( c );

   UNLINK( i, first_info, last_info, next, prev );

   if( i->name )
      DISPOSE( i->name );
   if( i->host )
      DISPOSE( i->host );
   if( i->clientpw )
      DISPOSE( i->clientpw );
   if( i->serverpw )
      DISPOSE( i->serverpw );

   rep_cancel_event( NULL, i );
   DISPOSE( i );

   rep_siteinfo.conncount--;
}

/* close down rep */
void rep_shutdown( void )
{
   INFO *info, *info_next;

   Log( "Shutting down %s.", IMC_VERSIONID );

   for( info = first_info; info; info = info_next )
   {
      info_next = info->next;
      rep_delete_info( info );
   }

   rep_shutdown_network();

   DISPOSE( rep_name );

   exit(0);
}

/* interpret an incoming packet using the right version */
static PACKET *do_interpret_packet( CONNECTION *c, const char *line )
{
   unsigned char v;
   PACKET *p;

   if( !line[0] )
      return NULL;

   v = c->version;
   if( v > IMC_VERSION )
      v = IMC_VERSION;

   p = ( *rep_vinfo[v].interpret )( line );

   return p;
}

unsigned int rep_fill_fdsets( unsigned int maxfd, fd_set *sread, fd_set *swrite, fd_set *exc )
{
   CONNECTION *c;

   /* set up fd_sets for select */

      
   if( maxfd < control )
       maxfd = control;
      
   FD_SET( control, sread );

   for( c = first_connection; c; c = c->next )
   {
      if( maxfd < c->desc )
         maxfd = c->desc;

      if ( c->state == CONN_NONE )
          continue;

      if ( c->state == CONN_SERVERCONNECT )
      {
          FD_SET( c->desc, swrite );
          continue;
      }

      FD_SET( c->desc, sread );

      if( c->outbuf[0] )
          FD_SET( c->desc, swrite );
   }
   return maxfd;
}

/* shell around rep_idle_select */
void rep_idle(unsigned int s)
{
  fd_set sread, swrite, exc;
  unsigned int maxfd;
  struct timeval timeout;
  int i;

  FD_ZERO(&sread);
  FD_ZERO(&swrite);
  FD_ZERO(&exc);

  maxfd=rep_fill_fdsets(0, &sread, &swrite, &exc);
  timeout.tv_sec = s;
  timeout.tv_usec = 0;

  if (maxfd)
    while ((i=select(maxfd+1, &sread, &swrite, &exc, &timeout)) < 0 && errno == EINTR)	/* loop, ignoring signals */
      ;
  else
    while ((i=select(0, NULL, NULL, NULL, &timeout)) < 0 && errno == EINTR)
      ;

  if (i<0)
  {
    Log("rep_idle: select");
    rep_shutdown();
    return;
  }

  rep_idle_select(&sread, &swrite, &exc, time(NULL));
}

/*
 * Events
 */ 

/* time out a login */
void ev_login_timeout( void *data )
{
   CONNECTION *c = (CONNECTION *)data;

   Log( "%s: login timeout", rep_getconnectname( c ) );
   do_close( c );
}

/* make it an event, dont announce a simple reboot - shogar - 2/1/2000 */
void ev_close_notify( void *data )
{
  INFO *info = (INFO *)data;

  rep_close_notify(info);
}

/* try a reconnect to the given rep_info */
void ev_reconnect( void *data )
{
   INFO *info = (INFO *)data;

   if( !info->connection && info->port > 0 )
	   rep_connect_to( info->name ); 
}

void ev_mudconnections( void *data )
{
    check_mudsfile();

    rep_add_event( 15, ev_mudconnections, NULL );
}

void ev_htmlmudlist( void *data )
{
    write_htmlmudlist( );
    rep_add_event( 60, ev_htmlmudlist, NULL );
}

void ev_htmlstats( void *data )
{
    write_htmlstats( );
    rep_add_event( 60, ev_htmlstats, NULL );
}

void ev_iced_update( void *data )
{
    IMC_CHANNEL *c;

    for ( c = first_rep_channel; c; c = c->next )
        iced_update( c, NULL );
}

void rep_free_event(rep_event *p)
{
  if ( p != rep_event_list )
  {
      rep_event *c = NULL;

      for ( c = rep_event_list; c; c = c->next )
          if ( c->next == p )
          {
              c->next = p->next;
              break;
          }
  }
  else
      rep_event_list = NULL;

  if (event_freecount>10) /* pick a number, any number */
  {
    DISPOSE( p );
  }
  else
  {
    p->next=rep_event_free;
    rep_event_free=p;
    event_freecount++;
  }
}

void rep_add_event(int when, void (*callback)(void *), void *data)
{
  rep_event *p, *cur = NULL, *last = NULL;

  if ( rep_event_free )
  {
      p = rep_event_free;
      rep_event_free = p->next;
      event_freecount--;
  }
  else
      CREATE( p, rep_event, 1 );

  p->when=rep_now+when;
  p->callback=callback;
  p->data=data;

  for (cur=rep_event_list; cur; cur=cur->next )
  {
    if (cur->when > p->when)
      break;

    last = cur;
  }

  p->next=cur;

  if ( !last )
      rep_event_list = p;
  else
      last->next=p;

  return;
}

void rep_cancel_event(void (*callback)(void *), void *data)
{
  rep_event *p, *p_next, **last;

  for (last=&rep_event_list, p=*last; p; p=p_next)
  {
    p_next=p->next;

    if ((!callback) && p->data==data)
    {
      *last=p_next;
      rep_free_event(p);
    }
    else if ((callback) && p->data==data && data != NULL)
    {
      *last=p_next;
      rep_free_event(p);
    }
    else if (p->callback==callback && data==NULL)
    {
      *last=p_next;
      rep_free_event(p);
    }
    else
      last=&p->next;
  }
}

/* 
   added this to help control open and close announcements, tie them to
   the 60 second grace period on close-notify 
   shogar 2/26/2000
*/
rep_event *rep_find_event(void (*callback)(void *), void *data)
{
  rep_event *p;

  for (p=rep_event_list; p; p=p->next)
    if (p->callback==callback && p->data == data )
        return p;

  return NULL;
}

int rep_next_event( void (*callback)(void *), void *data )
{
   rep_event *p;

   for( p = rep_event_list; p; p = p->next )
      if( p->callback == callback && p->data == data )
         return p->when - rep_now;

   return -1;
}

unsigned int rep_get_event_timeout( void )
{
   if ( rep_event_list != NULL )
           return (rep_event_list->when - rep_now);

   /* make sure we don't get too backlogged with events */
   return 60;
}

void rep_run_events(time_t newtime)
{
  rep_event *p;
  void (*callback)(void *);
  void *data;

  while(rep_event_list)
  {
    p=rep_event_list;

    if (p->when > newtime)
      break;

    rep_event_list=p->next;
    callback=p->callback;
    data=p->data;
    rep_now=p->when;

    rep_free_event(p);

    if (callback)
      (*callback)(data);
    else
      Log("rep_run_events: NULL callback");
  }

  rep_now=newtime;
}

/* low-level idle function: read/write buffers as needed, etc */
void rep_idle_select( fd_set *sread, fd_set *swrite, fd_set *exc, time_t now )
{
   const char *command;
   PACKET *p;
   CONNECTION *c, *c_next;

   if( rep_sequencenumber < (unsigned long)rep_now )
      rep_sequencenumber = (unsigned long)rep_now;

   rep_run_events(now);

   /* handle results of the select */

   if( FD_ISSET( control, sread ) )
      do_accept();

   for( c = first_connection; c; c = c_next )
   {
      c_next = c->next;

      if( c->state != CONN_NONE && FD_ISSET( c->desc, exc ) )
         do_close( c );

      if( c->state != CONN_NONE && FD_ISSET( c->desc, sread ) )
         do_read( c );

      while( c->state != CONN_NONE && ( command = getline( c->inbuf, c->insize ) ) != NULL )
      {
         if( strlen( command ) > rep_stats.max_pkt )
	      rep_stats.max_pkt = strlen( command );

         switch( c->state )
         {
            case CONN_DISCONNECT:
                break;
            case CONN_WAITCLIENTPWD:
	         clientpassword( c, command );
	         break;
            case CONN_WAITSERVERPWD:
	         serverpassword( c, command );
	         break;
            case CONN_COMPLETE:
	         p = do_interpret_packet( c, command );
	         if( p )
	         {
                 /* check the last entry in the path is the same as the
                  * sending mud. Also check the first entry to see that it matches
                  * the sender.
                  */
                 rep_stats.rx_pkts++;

		 if ( STR_CEQL( p->type, "ice-refresh" ) )
		     snprintf( p->i.to, IMC_NAME_LENGTH, "ICE@%s", rep_name );

                 /* Does not route packets */
                 if ( !c->info->router )
                 {
                     if ( !STR_CEQL( rep_mudof(p->i.from), c->info->name ) )
                     {
                         Log( "ALERT: Packet from %s forged to look like it was from %s.",
                                 c->info->name, rep_mudof(p->i.from) );
                     }
                     else if ( STR_CEQL( p->type, "close-notify" ) )
                     {
                         Log( "ALERT: %s attempted to send a close-notify packet.", c->info->name );
                     }
                     else
                     {
                         /* Overwrite routes from non-routers */
                         strlcpy( p->i.path, rep_mudof(p->i.from), IMC_MNAME_LENGTH );
                         forward(p);        /* only forward if its a valid packet! */
                     }
                 }
                 else
                 {
                     if( !STR_CEQL( c->info->name, rep_lastinpath( p->i.path ) ) )
                     {
                         Log( "ALERT: Packet passed through %s forged to look like it was passed through %s.", 
                                 c->info->name, rep_lastinpath( p->i.path ) );
                     }
                     else if( !STR_CEQL( rep_mudof( p->i.from ), rep_firstinpath( p->i.path ) ) )
                     {
                         Log( "ALERT: Packet originally from %s forged to look like it was originally from %s", 
                                 p->i.from, rep_firstinpath( p->i.path ) );
                     }
                     else 
                         forward(p);		/* only forward if its a valid packet! */
                 }

                 rep_freedata( p );
	         }
	      break;
         }
      }
   }

   for( c = first_connection; c; c = c_next )
   {
      c_next = c->next;
    
      if( c->state != CONN_NONE && ( FD_ISSET( c->desc, swrite ) || c->newoutput ) )
      {
         do_write( c );
         c->newoutput = c->outbuf[0];

         if ( c->state == CONN_DISCONNECT )
             do_close(c);
      }
   }

   for( c = first_connection; c; c = c_next )
   {
      c_next = c->next;

      if( c->state == CONN_NONE )
         rep_extract_connect( c );
   }
}

/* connect to given mud */
bool rep_connect_to( const char *mud )
{
   INFO *i;
   CONNECTION *c;
   int desc;
   struct sockaddr_in sa;
   char buf[IMC_DATA_LENGTH];
   int r;

   i = rep_getinfo( mud );
   if( !i )
   {
      Log( "rep_connect_to: %s - unknown mud name", mud );
      return 0;
   }

   if( i->connection )
   {
      Log( "rep_connect_to: %s - already connected", mud );
      return 0;
   }

   Log( "rep_connect_to: connecting to %s", mud );

   /*  warning: this blocks. It would be better to farm the query out to
    *  another process, but that is difficult to do without lots of changes
    *  to the core mud code. You may want to change this code if you have an
    *  existing resolver process running.
    */

   if( ( sa.sin_addr.s_addr = inet_addr( i->host ) ) == INADDR_NONE )
   {
      struct hostent *hostinfo;

      if( NULL == ( hostinfo = gethostbyname( i->host ) ) )
      {
         Log( "rep_connect_to: hostname could not be resolved" );
         return 0;
      }
      sa.sin_addr.s_addr = *(unsigned long *) hostinfo->h_addr;
   }
   sa.sin_port   = htons( i->port );
   sa.sin_family = AF_INET;

   desc = socket( AF_INET, SOCK_STREAM, 0 );
   if( desc < 0 )
   {
      Log( "rep_connect_to: socket call failure" );
      return 0;
   }

   r = fcntl( desc, F_GETFL, 0 );
   if( r < 0 || fcntl( desc, F_SETFL, O_NONBLOCK | r ) < 0 )
   {
      Log( "rep_connect_to: fcntl call failure" );
      close( desc );
      return 0;
   }

   if( connect( desc, ( struct sockaddr * )&sa, sizeof( sa ) ) < 0 )
   {
      if( errno != EINPROGRESS )
      {
         Log( "rep_connect_to: connection could not be established" );
         close( desc );
         return 0;
      }
   }
   c = rep_new_connect();

   c->desc     = desc;
   c->state    = CONN_SERVERCONNECT;
   c->info     = i;
   c->ip       = strdup( inet_ntoa( sa.sin_addr ) );

   rep_add_event( IMC_LOGIN_TIMEOUT, ev_login_timeout, c );

   snprintf( buf, IMC_DATA_LENGTH, "PW %s %s version=%d", rep_name, i->clientpw, IMC_VERSION );
   do_send( c, buf );

   return 1;
}

void rep_send(PACKET *p)
{
  /* initialize packet fields that the caller shouldn't/doesn't set */

  p->i.path[0]  = 0;
  
  p->i.sequence = rep_sequencenumber++;
  if (!rep_sequencenumber)
    rep_sequencenumber++;
  
  strlcpy(p->i.to, p->to, IMC_NAME_LENGTH);
  snprintf( p->i.from, IMC_NAME_LENGTH, "%s@%s", p->from, rep_name );
  
  forward(p);
}

INFO *rep_new_info( void )
{
   INFO *i;

   CREATE( i, INFO, 1 );

   i->name       = NULL;
   i->host       = NULL;
   i->port       = 0;
   i->connection = NULL;
   i->clientpw   = NULL;
   i->serverpw   = NULL;
   i->router     = FALSE;
   i->no_list    = FALSE;
   i->last_connected = 0;

   rep_siteinfo.conncount++;

   LINK( i, first_info, last_info, next, prev );
   return i;
}

static void fixactive(IMC_CHANNEL *c)
{
  char arg[IMC_NAME_LENGTH];
  const char *p;
  char buf[IMC_DATA_LENGTH];
  
  if (c->open)
  {
    if ( c->active )
       DISPOSE(c->active);
    c->active=strdup("");
    return;
  }

  buf[0]=0;
  p=rep_getarg(c->invited, arg, IMC_NAME_LENGTH);
  while (arg[0])
  {
    const char *mud=rep_mudof(arg);

    if (!rep_hasname(buf, mud))
    {
      if (buf[0])
          strlcat(buf, " ", IMC_DATA_LENGTH);

      strlcat(buf, mud, IMC_DATA_LENGTH);
    }

    p=rep_getarg(p, arg, IMC_NAME_LENGTH);
  }

  p=rep_getarg(c->operators, arg, IMC_NAME_LENGTH);
  while (arg[0])
  {
    const char *mud=rep_mudof(arg);

    if (!rep_hasname(buf, mud))
    {
      if (buf[0])
          strlcat(buf, " ", IMC_DATA_LENGTH);

      strlcat(buf, mud, IMC_DATA_LENGTH);
    }

    p=rep_getarg(p, arg, IMC_NAME_LENGTH);
  }

  if (!rep_hasname(buf, rep_mudof(c->owner)))
  {
    if (buf[0])
      strlcat(buf, " ", IMC_DATA_LENGTH);

    strlcat(buf, rep_mudof(c->owner), IMC_DATA_LENGTH);
  }
  
  DISPOSE(c->active);
  c->active=strdup(buf);
}

void iced_save_channels( void )
{
   IMC_CHANNEL *c;
   FILE *fp;

   if( !(fp = fopen(IMC_CHANNEL_FILE, "w" )) )
   {
      Log( "Channel file could not be opened for writing." );
      return;
   }

   for( c = first_rep_channel; c; c = c->next )
   {
      /* save */
      fprintf( fp, "%s %s %d\n"
        "localname %s\n"
        "permlevel %s\n"
	    "op %s\n"
	    "invite %s\n"
	    "exclude %s\n\n",
	    c->name, c->owner, c->open, c->local_name, c->permlevel, 
        c->operators[0] ? c->operators : "none", c->invited[0] ? c->invited : "none",
	    c->excluded[0] ? c->excluded : "none" );
   }
   SFCLOSE( fp );
}

void iced_load_channels( void )
{
   FILE *fp;
   char name[LSS], owner[LSS], lname[LSS], permlevel[LSS], operators[LSS], invited[LSS], excluded[LSS];
   int p;

   if( !(fp = fopen(IMC_CHANNEL_FILE, "r" )) )
   {
      Log( "Channel file could not be opened for reading." );
      return;
   }

   Log( "Channel loading procedure started." );

   while( fscanf( fp, "%4095s %4095s %d\n"
        "localname %8[^\n]\n"
        "permlevel %8[^\n]\n"
		"op %4095[^\n]\n"
		"invite %4095[^\n]\n"
		"exclude %4095[^\n]\n\n", 
        name, owner, &p, lname, permlevel, operators, invited, excluded ) == 8 ) 
   {
      IMC_CHANNEL *c;

      CREATE( c, IMC_CHANNEL, 1 );

      if( STR_EQL( operators, "none" ) )
         operators[0] = '\0';
      if( STR_EQL( invited, "none" ) )
         invited[0] = '\0';
      if( STR_EQL( excluded, "none" ) )
         excluded[0] = '\0';

      if ( STR_CEQL( permlevel, "Admin" ) || STR_CEQL( permlevel, "Mort" )
              || STR_CEQL( permlevel, "Imm" ) )
          c->permlevel = strdup( permlevel );
      else
          c->permlevel = strdup( "Admin" );

      c->name = strdup( name );
      c->owner = strdup( owner );
      c->local_name = strdup( lname );
      c->operators = strdup( operators );
      c->invited = strdup( invited );
      c->excluded = strdup( excluded );
      c->active = strdup( "" );
      c->open = p;

	  LINK( c, first_rep_channel, last_rep_channel, next, prev );

      fixactive( c );

      Log( "Channel named %s(owned by %s) was loaded with a policy of %s.", 
              c->name, c->owner, (c->open ? "open" : "private") );
   }
   SFCLOSE( fp );
}

IMC_CHANNEL *iced_findchannel( const char *name )
{
   IMC_CHANNEL *c;

   for( c = first_rep_channel; c; c = c->next )
      if( STR_CEQL( c->name, name ) )
         return c;

   return NULL;
}

void iced_gannounce( const char *fmt, ... )
{
   char buf[IMC_DATA_LENGTH];
   va_list ap;

   va_start( ap, fmt );
   vsnprintf( buf, IMC_DATA_LENGTH, fmt, ap );
   va_end(ap);

   rep_send_emote( buf );
}

void iced_privmsg(IMC_CHANNEL *c, PACKET *out, const char *exclude)
{
  const char *p;
  char arg[IMC_NAME_LENGTH];
  
  p=rep_getarg(c->active, arg, IMC_NAME_LENGTH);
  while(arg[0])
  {
    if ((!exclude || !STR_CEQL(arg, exclude)) && rep_find_reminfo( arg ))
    {
      snprintf(out->to, IMC_NAME_LENGTH, "*@%s", arg);
      rep_send(out);
    }

    p=rep_getarg(p, arg, IMC_NAME_LENGTH);
  }
}

void iced_announce( IMC_CHANNEL *c, const char *fmt, ... )
{
   va_list ap;
   char buf[IMC_DATA_LENGTH];

   strlcpy( buf, "announces that ", IMC_DATA_LENGTH );
  
   va_start( ap, fmt );
   vsnprintf( buf+strlen(buf), ( IMC_DATA_LENGTH-strlen(buf)), fmt, ap );
   va_end( ap );

   if( !c->open )
   {
      PACKET out;
    
      strlcpy( out.from, "ICE", IMC_NAME_LENGTH );
      strlcpy( out.to, "*", IMC_NAME_LENGTH );
      strlcpy( out.type, "ice-msg-r", IMC_TYPE_LENGTH );

      rep_initdata( &out );
      rep_addkey( &out, "realfrom", rep_makename( "ICE", rep_name ) );
      rep_addkey( &out, "text", buf );
      rep_addkey( &out, "channel", c->name );
      rep_addkeyi( &out, "emote", 1 );

      iced_privmsg( c, &out, NULL );

      rep_freedata( &out );
   }
   else
   {
      PACKET out;

      strlcpy( out.from, "ICE", IMC_NAME_LENGTH );
      strlcpy( out.to, "*", IMC_NAME_LENGTH );
      strlcpy( out.type, "ice-msg-b", IMC_TYPE_LENGTH );

      rep_initdata( &out );
      rep_addkey( &out, "text", buf );
      rep_addkey( &out, "channel", c->name );
      rep_addkeyi( &out, "emote", 1 );

      rep_send( &out );
      rep_freedata( &out );
   }
}

/* channel daemon hook */
void iced_recv( const PACKET *p )
{
   /* commands */
   if( STR_CEQL( p->type, "ice-cmd" ) )
   {
      iced_recv_command( p->from, rep_getkey( p, "channel", "" ), rep_getkey( p, "command", "" ),
	   rep_getkey( p, "data", "" ) );
   }
   else if( STR_CEQL( p->type, "ice-msg-p" ) )
   {
      /* private message to be forwarded */
      iced_recv_msg_p( p->from, rep_getkey( p, "channel", "" ), rep_getkey( p, "text", "" ), 
              rep_getkeyi( p, "emote", 0 ), rep_getkeyi( p, "echo", 0 ) );
   }
   else if( STR_CEQL( p->type, "ice-msg-b" ) )
   {
      /* check for misdirection */
      iced_recv_msg_b( p->from, rep_getkey( p, "channel", "" ), rep_getkey( p, "text", "" ),
              rep_getkeyi( p, "emote", 0 ), rep_getkeyi( p, "echo", 0 ) );
   }

   return;
}

#define MAX_ICED_COMMAND 12

const char *channel_accesstring[4] = { "none", "creator", "operator", "owner" };
enum { ACCESS_NONE, ACCESS_CREATOR, ACCESS_OPERATOR, ACCESS_OWNER } channel_access_levels;

struct 
{
  char *name;
  unsigned char level;  /* 0=anyone, 1=op only, 2=owner only */
  void (*cmdfn)(IMC_CHANNEL *c, const char *cname, const char *from, const char *data);
  bool need_data;
} 
iced_cmdtable[MAX_ICED_COMMAND] =
{
  { "list",       ACCESS_NONE,     run_iced_list,      FALSE  },
  { "create",     ACCESS_CREATOR,  run_iced_create,    FALSE  },
  { "destroy",    ACCESS_OWNER,    run_iced_destroy,   FALSE  },
  { "invite",     ACCESS_OPERATOR, run_iced_invite,    TRUE   },
  { "uninvite",   ACCESS_OPERATOR, run_iced_uninvite,  TRUE   },
  { "exclude",    ACCESS_OPERATOR, run_iced_exclude,   TRUE   },
  { "unexclude",  ACCESS_OPERATOR, run_iced_unexclude, TRUE   },
  { "policy",     ACCESS_OWNER,    run_iced_policy,    TRUE   },
  { "addop",      ACCESS_OWNER,    run_iced_addop,     TRUE   },
  { "removeop",   ACCESS_OWNER,    run_iced_removeop,  TRUE   },
  { "permlevel",  ACCESS_OWNER,    run_iced_permlevel, TRUE   },
  { "localname",  ACCESS_OWNER,    run_iced_localname, TRUE   }
};

unsigned int iced_getaccess(IMC_CHANNEL *c, const char *from)
{
    if ( !c )
    {
        if( rep_hasname(rep_siteinfo.chancreators, "*") || rep_hasname(rep_siteinfo.chancreators, from)
            || rep_hasname(rep_siteinfo.chancreators, rep_mudof(from)) )
        return ACCESS_CREATOR;

        return ACCESS_NONE;
    }
    else if ( STR_CEQL(from, c->owner) )
        return ACCESS_OWNER;
    else if (rep_hasname(c->operators, from))
        return ACCESS_OPERATOR;
    else
        return ACCESS_NONE;
}

void iced_recv_command(const char *from, const char *chan, const char *cmd, const char *data)
{
  IMC_CHANNEL *c;
  char arg[IMC_NAME_LENGTH];
  unsigned char i;

  for (i=0; i < MAX_ICED_COMMAND ; i++)
    if (STR_CEQL(iced_cmdtable[i].name, cmd))
      break;

  c = iced_findchannel(chan);

  if (!iced_cmdtable[i].name )
  {
      run_iced_list( c, chan, from, data );
      return;
  }

  if ( !c && iced_cmdtable[i].level > ACCESS_CREATOR )
  {
      rep_send_tell(from, "You need to input a valid channel name to use this command.");
      return;
  }

  if ( c && iced_cmdtable[i].level == ACCESS_CREATOR )
  {
      rep_send_tell(from, "You must make up a new channel for this command.");
      return;
  }

  if (iced_getaccess(c, from) < iced_cmdtable[i].level) 
  {
      if (iced_cmdtable[i].level > ACCESS_CREATOR)
          rep_send_tell(from, "You do not have the access level to use this command with that channel.");
      else if (iced_cmdtable[i].level == ACCESS_CREATOR)
          rep_send_tell(from, "You do not have the access level to create a new channel.");

      return;
  }
      
  rep_getarg(data, arg, IMC_NAME_LENGTH );
      
  if ( (!arg || arg[0] == '\0') && iced_cmdtable[i].need_data)
  {
      rep_send_tell(from, "This command requires additional data.");
      return;
  }

  (*iced_cmdtable[i].cmdfn)(c, chan, from, arg);

  iced_save_channels();
}

/* list commands */
void run_iced_list(IMC_CHANNEL *c, const char *cname, const char *from, const char *data)
{
  char out[IMC_DATA_LENGTH];
  unsigned char i;

  snprintf(out, IMC_DATA_LENGTH,
	 "\n~WAvailable Channel Administration Commands:\n"
	 "~c%-10.10s %s\n", "Name", "Access Level");

  for (i=0; i < MAX_ICED_COMMAND; i++)
  {
      snprintf(out+strlen(out), IMC_DATA_LENGTH - strlen(out),
              "~C%-10.10s %s\n",
              iced_cmdtable[i].name,
              channel_accesstring[iced_cmdtable[i].level]);
  }

  snprintf( out+strlen(out), IMC_DATA_LENGTH - strlen(out), "~cYour access level for this channel: %s\n",
          channel_accesstring[iced_getaccess(c, from)]);

  rep_send_tell(from, out);
}

void iced_send_destroy( const char *cname, const char *to )
{
   PACKET out;

   strlcpy( out.from, "ICE", IMC_NAME_LENGTH );
   strlcpy( out.to, to ? to : "*", IMC_NAME_LENGTH );
   strlcpy( out.type, "ice-destroy", IMC_TYPE_LENGTH );
   rep_initdata( &out );
   rep_addkey( &out, "channel", cname );
   rep_send( &out );
   rep_freedata( &out );
}

/* destroy a channel */
void run_iced_destroy( IMC_CHANNEL *c, const char *cname, const char *from, const char *data )
{
   /* remove/free the channel from our list */
   UNLINK( c, first_rep_channel, last_rep_channel, next, prev );

   Log( "Channel named %s destroyed by %s.", c->name, from );
   iced_gannounce( "announces that the channel called %s has been destroyed by %s.", c->name, from );

   // Moved to up here to fix a bug -- Kratas
   /* send destroy notification */
   iced_send_destroy( c->name, NULL );
   rep_send_tell( from, "The channel has been destroyed successfully." );

   DISPOSE( c->name );
   DISPOSE( c->owner );
   DISPOSE( c->operators );
   DISPOSE( c->invited );
   DISPOSE( c->excluded );
   DISPOSE( c->active );
   DISPOSE( c );
}

/* set channel policy */
void run_iced_policy(IMC_CHANNEL *c, const char *cname, const char *from, const char *data)
{
    if ( STR_CEQL(data, "open") )
    {
        if ( c->open )
        {
            rep_send_tell(from, "This channel already has an open policy." );
            return;
        }

        c->open=TRUE;
        fixactive(c);
        iced_gannounce("announces that the channel called %s now has an open policy.", c->name);
        iced_update(c, NULL);
    }
    else if ( STR_CEQL(data, "private") )
    {
        if ( !c->open )
        {
            rep_send_tell(from, "This channel already has a private policy.");
            return;
        }

        c->open=FALSE;
        fixactive(c);
        iced_gannounce("announces that the channel called %s now has a private policy.", c->name);
        iced_update(c, NULL);
    }
    else
        rep_send_tell(from, "The currently available channel policies are open and private.");
}

/* add operator */
void run_iced_addop(IMC_CHANNEL *c, const char *cname, const char *from, const char *data)
{
  char buf[MSS];

  if ( !strchr( data, '@' ) )
  {
    rep_send_tell(from, "The name of the operator must be in the format of person@mud.");
    return;
  }

  if (rep_hasname(c->operators, data))
  {
    rep_send_tell(from, "That person is already an operator.");
    return;
  }

  rep_addname(&c->operators, data);
  fixactive(c);

  snprintf(buf, MSS, "%s is now an operator of %s.", data, c->name);
  rep_send_tell(from, buf);

  iced_announce(c, "%s is now an operator for this channel.", data);
  iced_update(c, NULL);
}

/* remove operator */
void run_iced_removeop(IMC_CHANNEL *c, const char *cname, const char *from, const char *data)
{
  char buf[MSS];

  if ( !strchr( data, '@' ) )
  {
    rep_send_tell(from, "The name of the operator must be in the format of person@mud.");
    return;
  }
  
  if (!rep_hasname(c->operators, data))
  {
    rep_send_tell(from, "That person is not an operator.");
    return;
  }

  rep_removename(&c->operators, data);
  fixactive(c);

  snprintf(buf, MSS, "%s is no longer an operator of %s.", data, c->name);
  rep_send_tell(from, buf);

  iced_announce(c, "%s is no longer an operator for this channel.", data);
  iced_update(c, NULL);
}

/* invite mud or player */
void run_iced_invite(IMC_CHANNEL *c, const char *cname, const char *from, const char *data)
{
  char buf[MSS];
  
  if (rep_hasname(c->invited, data))
  {
    rep_send_tell(from, "That person is already on the invite list for that channel.");
    return;
  }

  rep_addname(&c->invited, data);
  fixactive(c);

  snprintf(buf, MSS, "%s has now been invited to %s.", data, c->name);
  rep_send_tell(from, buf);

  iced_announce(c, "%s has invited %s to this channel.", from, data);
  iced_update(c, NULL);
}

/* uninvite mud or player */
void run_iced_uninvite(IMC_CHANNEL *c, const char *cname, const char *from, const char *data)
{
  char buf[MSS];

  if (!rep_hasname(c->invited, data))
  {
    rep_send_tell(from, "That person is not currently on the invite list for that channel.");
    return;
  }

  rep_removename(&c->invited, data);
  fixactive(c);

  snprintf(buf, MSS, "%s is no longer invited on %s.", data, c->name);
  rep_send_tell(from, buf);

  iced_announce(c, "%s has uninvited %s from this channel.", from, data);
  iced_update(c, NULL);
}

/* exclude mud or player */
void run_iced_exclude(IMC_CHANNEL *c, const char *cname, const char *from, const char *data)
{
  char buf[MSS];
  
  if (rep_hasname(c->excluded, data))
  {
    rep_send_tell(from, "That person is already on the exclude list for that channel.");
    return;
  }

  rep_addname(&c->excluded, data);

  snprintf(buf, MSS, "%s is now excluded from %s.", data, c->name);
  rep_send_tell(from, buf);

  iced_announce(c, "%s has excluded %s from this channel.", from, data);
  iced_update(c, NULL);
}

/* unexclude mud or player */
void run_iced_unexclude(IMC_CHANNEL *c, const char *cname, const char *from, const char *data)
{
  char buf[MSS];
  
  if (!rep_hasname(c->excluded, data))
  {
    rep_send_tell(from, "That person is not on the exclude list for that channel.");
    return;
  }

  rep_removename(&c->excluded, data);

  snprintf(buf, MSS, "%s is no longer excluded from %s.", data, c->name);
  rep_send_tell(from, buf);

  iced_announce(c, "%s has unexcluded %s from this channel.", from, data);
  iced_update(c, NULL);
}

void run_iced_permlevel( IMC_CHANNEL *c, const char *cname, const char *from, const char *data )
{
  char buf[MSS];
    
  if ( !STR_CEQL( data, "Mort" ) && !STR_CEQL( data, "Imm" ) && !STR_CEQL( data, "Admin" ) )
  {
      rep_send_tell( from, "The current available permlevels are Mort(Mortal), Imm(Immortal), and Admin(Administrator)." );
      return;
  }

  snprintf( buf, MSS, "%s is now the default permission level for %s.", data, c->name );
  rep_send_tell( from, buf );

  if ( c->permlevel )
      DISPOSE( c->permlevel );

  c->permlevel = strdup( data );
  iced_update( c, NULL );
}

void run_iced_localname( IMC_CHANNEL *c, const char *cname, const char *from, const char *data )
{
  char buf[MSS];

  if ( strlen( data ) > 8 )
  {
      rep_send_tell( from, "The default local name can not be longer than 8 characters." );
      return;
  }

  snprintf( buf, MSS, "%s is now the default local name for %s.", data, c->name );
  rep_send_tell( from, buf );

  if ( c->local_name )
      DISPOSE( c->local_name );

  c->local_name = strdup( data );
  iced_update( c, NULL );
}

/* create a channel */
void run_iced_create( IMC_CHANNEL *c, const char *cname, const char *from, const char *data )
{
   IMC_CHANNEL *p;

   if( !cname[0] || !strchr( cname, ':') || !STR_CEQL( ice_mudof(cname), rep_name ) )
   {
      rep_send_tell( from, "You must supply a new channel name in the format of hubname:channame.");
      return;
   }
  
   CREATE( p, IMC_CHANNEL, 1 );
   p->name = strdup( cname );
   p->owner = strdup( from );
   p->local_name = strdup( cname );
   p->permlevel = strdup( "Admin" );
   p->operators = strdup( "" );
   p->invited = strdup( "" );
   p->excluded = strdup( "" );
   p->active = strdup( "" );
   p->open = FALSE; /* Channels should be private in the beginning */

   LINK( p, first_rep_channel, last_rep_channel, next, prev );
   iced_update( p, NULL );

   Log( "Channel named %s created by %s.", p->name, from );
   iced_gannounce( "announces that a channel named %s has been created by %s.", p->name, from );
   rep_send_tell( from, "The channel has been created successfully" );
}

/* private message - for forwarding */
void iced_recv_msg_p( const char *from, const char *chan, const char *txt, int emote, int echo )
{
   IMC_CHANNEL *c;
   PACKET out;
   char temp[IMC_NAME_LENGTH];

   c = iced_findchannel( chan );

   if( !c )
   {
      rep_send_tell( from, "You're trying to talk on a nonexistant channel." );
      iced_send_destroy( chan, rep_mudof( from ) );
      return;
   }

   if( !ice_audible( c, from ) )
   {
      rep_send_tell( from, "You're trying to talk on a channel that you don't have access to." );
      iced_update( c, rep_mudof( from ) );
      return;
   }

   if( c->open )
   {
      rep_send_tell( from, "Misconfiguration, sending private message on nonprivate channel. Try again.");
      iced_update( c, rep_mudof( from ) );
   }

   strlcpy( out.from, "ICE", IMC_NAME_LENGTH );
   strlcpy( out.type, "ice-msg-r", IMC_TYPE_LENGTH ); /* redirect */

   rep_initdata( &out );
   rep_addkey( &out, "realfrom", from );
   rep_addkey( &out, "channel", chan );
   rep_addkey( &out, "text", txt );
   rep_addkeyi( &out, "emote", emote );

   if ( echo )
       iced_privmsg( c, &out, NULL );
   else
   {
       strlcpy( temp, rep_mudof( from ), IMC_NAME_LENGTH ); /* since we do several rep_sends */
       iced_privmsg( c, &out, temp );
   }

   rep_freedata( &out );
}

/* broadcast message - complain if its a private channel */
void iced_recv_msg_b(const char *from, const char *chan, const char *txt, int emote, int echo)
{
  IMC_CHANNEL *c = NULL;
  PACKET out;

  if (!strchr(chan, ':') || !STR_CEQL(ice_mudof(chan), rep_name))
    return;
  
  c = iced_findchannel(chan);

  if (!c)
  {
    rep_send_tell(from, "You're trying to talk on a nonexistant channel.");
    iced_send_destroy(chan, rep_mudof(from));
    return;
  }

  if (!ice_audible(c, from))
  {
    rep_send_tell(from, "You're trying to talk on a channel that you don't have access to.");
    iced_update(c, rep_mudof(from));
    return;
  }

  if (!c->open)
  {
    rep_send_tell(from, "Misconfiguration, sending broadcast message on private channel. Try again.");
    iced_update(c, rep_mudof(from));
  }

  if ( !echo )
      return;

  snprintf( out.from, IMC_NAME_LENGTH, "%s:%s", rep_nameof(from), rep_mudof(from) );
  snprintf( out.to, IMC_NAME_LENGTH, "*@%s", rep_mudof(from) );
  strlcpy( out.type, "ice-msg-b", IMC_TYPE_LENGTH );

  rep_initdata( &out );
  rep_addkey( &out, "text", txt );
  rep_addkey( &out, "channel", chan );
  rep_addkey( &out, "sender", from );
  rep_addkeyi( &out, "emote", emote );

  rep_send(&out);
  rep_freedata( &out ); 
}    


/* update a channel */
void iced_update( IMC_CHANNEL *c, const char *to )
{
   PACKET out;

   strlcpy( out.from, "ICE", IMC_NAME_LENGTH );
   snprintf( out.to, IMC_NAME_LENGTH, "*@%s", to && to[0] != '\0' ? to : "*" );
   strlcpy( out.type, "ice-update", IMC_TYPE_LENGTH );

   rep_initdata( &out );
   rep_addkey( &out, "channel", c->name );
   rep_addkey( &out, "owner", c->owner );
   rep_addkey( &out, "operators", c->operators );

   rep_addkey( &out, "policy", (c->open ? "open" : "private") );
   rep_addkey( &out, "invited", c->invited );
   rep_addkey( &out, "excluded", c->excluded );
   rep_addkey( &out, "level", c->permlevel );
   rep_addkey( &out, "localname", c->local_name );

   rep_send( &out );
   rep_freedata( &out );
   Log( "Channel update for %s sent to %s.", c->name, to ? to : "entire network" );
}

/* Save config file - So nonrebooted updates save */
bool rep_saveconfig( void )
{
    FILE *cf;
    INFO *i;

    if ( !(cf = fopen( IMC_CONFIG_FILE, "w" )) )
    {
        Log( "Configuration file could not be opened for writing." );
        return FALSE;
    }

    fprintf( cf, "%s\n", "#IMC2 Hub Configuration File" );

    if ( rep_name && rep_name[0] != '\0' )
        fprintf( cf, "HubName          %s\n", rep_name );

    if ( rep_siteinfo.netname && rep_siteinfo.netname[0] != '\0')
        fprintf( cf, "NetworkName      %s\n", rep_siteinfo.netname );

    if ( rep_bind > 0 )
    {
        struct sockaddr_in binds;
        
        binds.sin_addr.s_addr = rep_bind;
        fprintf( cf, "Bind             %s\n", inet_ntoa(binds.sin_addr) );
    }

    if ( rep_port > 0 )
        fprintf( cf, "HubPort          %hu\n", rep_port );

    if ( rep_siteinfo.chancreators && rep_siteinfo.chancreators[0] != '\0')
        fprintf( cf, "ChannelCreators  %s\n", rep_siteinfo.chancreators );

    if ( rep_siteinfo.maxconn > 0 )
        fprintf( cf, "MaxConnections   %d\n", rep_siteinfo.maxconn );

    if ( rep_siteinfo.web && rep_siteinfo.web[0] != '\0' )
        fprintf( cf, "WebPage          %s\n", rep_siteinfo.web );

    fprintf( cf, "\n%s\n", "#Optional Capabilities for the Hub" );
    fprintf( cf, "%s\n", rep_siteinfo.updatefile ? "UpdateFile" : "#UpdateFile" );
    fprintf( cf, "%s\n", rep_siteinfo.autosetup ? "AutoSetup" : "#AutoSetup" );
    fprintf( cf, "%s\n", rep_siteinfo.htmlmudlist ? "HTML-Mudlist" : "#HTML-Mudlist" );
    fprintf( cf, "%s\n\n", rep_siteinfo.htmlstats ? "HTML-Stats" : "#HTML-Stats" );

    fprintf( cf, "%s\n\n", "#Connection lines for muds and hubs" );

    fprintf( cf, "%s\n", "#Router-Type1 hubs will be connected to if they are not already." );

    for( i = first_info; i; i = i->next )
    {
         if ( !i->name || i->name[0] == '\0' || !i->clientpw || i->clientpw[0] == '\0' || !i->serverpw
                 || i->serverpw[0] == '\0' || !i->host || i->host[0] == '\0' || i->port == 0 || !i->router )
             continue;

         fprintf( cf, "Router-Type1 %s:%s:%hu:%s:%s\n", i->name, i->host, i->port, i->clientpw,
                 i->serverpw );
    }

    fprintf( cf, "\n%s\n", "#Router-Type2 hubs do not connect directly to the hub." );

    for( i = first_info; i; i = i->next )
    {
         if ( !i->name || i->name[0] == '\0' || i->clientpw || i->serverpw || i->host
                 || i->port > 0 || !i->router )
             continue;

         fprintf( cf, "Router-Type2 %s\n", i->name );
    }

    fprintf( cf, "\n%s\n", "#Mud-Type1 muds will be connected to if they are not already." );

    for( i = first_info; i; i = i->next )
    {
         if ( !i->name || i->name[0] == '\0' || !i->clientpw || i->clientpw[0] == '\0' || !i->serverpw
                 || i->serverpw[0] == '\0' || !i->host || i->host[0] == '\0' || i->port == 0 || i->router )
             continue;

         fprintf( cf, "Mud-Type1 %s:%s:%hu:%s:%s\n", i->name, i->host, i->port, i->clientpw,
                 i->serverpw );
    }

    fprintf( cf, "\n%s\n", "#Mud-Type2 muds will be left to their own means to reconnect." );

    for( i = first_info; i; i = i->next )
    {
         if ( !i->name || i->name[0] == '\0' || !i->clientpw || i->clientpw[0] == '\0' || !i->serverpw
                 || i->serverpw[0] == '\0' || i->host || i->port > 0 || i->router )
             continue;

         fprintf( cf, "Mud-Type2 %s:%s:%s\n", i->name, i->clientpw, i->serverpw );
    }

    fprintf( cf, "\n" );

    SFCLOSE(cf);
    return TRUE;
}

/* read config file */
bool rep_readconfig( void )
{
   FILE *cf;
   INFO *i;
   char name[IMC_MNAME_LENGTH], host[SSS];
   char pw1[IMC_PW_LENGTH], pw2[IMC_PW_LENGTH];
   unsigned short port;
   char buf[MSS];
   char word[MSS];
   short localport = -1; /* added -1 to solve "duplicate localport" error. Suggested by Tagith@UCMM. -- Scion */
   short maxconn = -1;
   char localname[IMC_MNAME_LENGTH]; /* Again suggested ="" by Tagith@UCMM  -- Scion */
   const char *value;
   unsigned long localip;
   bool autosetup = FALSE, updatefile = FALSE, htmlmudlist = FALSE, htmlstats = FALSE;

   char iweb[SSS], chancreators[SSS], netname[11]; 

   localname[0]=iweb[0]=word[0]=chancreators[0]=netname[0]=0;
   localip = INADDR_ANY;

   if ( !(cf = fopen( IMC_CONFIG_FILE, "r" )) )
   {
      Log( "Configuration file could not be opened for reading.");
      return FALSE;
   }

   while(fgets( buf, MSS, cf ) != NULL)
   {

      while( buf[0] && isspace( buf[strlen(buf)-1] ) )
         buf[strlen(buf)-1] = '\0';

      if( buf[0] == '#' || buf[0] == '\n' || !buf[0] )
         continue;

      value = rep_getarg( buf, word, MSS );
      
      if( STR_CEQL( word, "HubName" ) ) 
      {
          if (localname[0])
            Log("Warning: duplicate 'LocalName' lines in configuration file." );
              
          strlcpy( localname, value, IMC_MNAME_LENGTH);
      }
      else if( STR_CEQL( word, "NetworkName" ) ) 
      {
          if (netname[0])
            Log("Warning: duplicate 'NetworkName' lines in configuration file." );
              
          strlcpy( netname, value, 11);
      }
      else if( STR_CEQL( word, "Bind" ) )
      {
         if( localip != INADDR_ANY )
            Log( "Warning: duplicate 'Bind' lines in configuration file." );
         localip = inet_addr( value );
      }
      else if( STR_CEQL( word, "HubPort" ) )
      {
         if( localport  > 0 )
            Log( "Warning: duplicate 'LocalPort' lines in configuration file." );
         localport = atoi( value );
      }
      else if( STR_CEQL( word, "ChannelCreators" ) ) 
      {
          if (chancreators[0])
            Log( "Warning: duplicate 'ChannelCreators' lines in configuration file." );
              
          strlcpy( chancreators, value, SSS);
      }
      else if ( STR_CEQL( word, "MaxConnections" ) )
      {
         if( maxconn > 0 )
             Log( "Warning: duplicate 'MaxConnections' lines in configuration file." );

         maxconn = atoi(value);
      }
      else if( STR_CEQL( word, "WebPage" ) )
      {
          if (iweb[0])
              Log( "Warning: duplicate 'InfoWeb' lines in configuration file." );

          strlcpy( iweb, value, SSS);
      }
      else if( STR_CEQL( word, "UpdateFile" ) )
          updatefile = TRUE;
      else if( STR_CEQL( word, "AutoSetup" ) )
          autosetup = TRUE;
      else if ( STR_CEQL( word, "HTML-Mudlist" ) )
          htmlmudlist = TRUE;
      else if ( STR_CEQL( word, "HTML-Stats" ) )
          htmlstats = TRUE;
      else if( STR_CEQL( word, "Router-Type1" ) || STR_CEQL( word, "Mud-Type1" ) )
      {
         if( sscanf( value, "%19[^:]:%255[^:]:%hu:%19[^:]:%19[^:]", name, host, &port, pw1, pw2) < 5 )
         {
            Log( "Bad Type1 connection line in configuration file: %s", buf );
            continue;
         }

         if ( (i = rep_getinfo(name)) != NULL )
         {
             Log( "Warning: duplicate connection lines in configuration file - discarding new one." );
             continue;
         }

         i = rep_new_info();
         i->name       = strdup(name);
         i->host       = strdup(host);
         i->clientpw   = strdup(pw1);
         i->serverpw   = strdup(pw2);
         i->port       = port;

         if ( STR_CEQL( word, "Router-Type1" ) )
             i->router = TRUE;
      }
      else if( STR_CEQL( word, "Router-Type2" ) )
      {
         if( sscanf( value, "%19[^\n]\n", name ) < 1 )
         {
            Log( "Bad Type2 connection line in configuration file: %s", buf );
            continue;
         }

         if ( (i = rep_getinfo(name)) != NULL )
         {
             Log( "Warning: duplicate connection lines in configuration file - discarding new one." );
             continue;
         }

         i = rep_new_info();
         i->name = strdup(name);
         i->router = TRUE;
         i->no_list = TRUE;
      }
      else if( STR_CEQL( word, "Mud-Type2" ) )
      {
         if( sscanf( value, "%19[^:]:%19[^:]:%19[^:]", name, pw1, pw2) < 3 )
         {
            Log( "Bad Type2 connection line in configuration file: %s", buf );
            continue;
         }

         if ( (i = rep_getinfo(name)) != NULL )
         {
             Log( "Warning: duplicate connection lines in configuration file - discarding new one." );
             continue;
         }

         i = rep_new_info();
         i->name       = strdup(name);
         i->clientpw   = strdup(pw1);
         i->serverpw   = strdup(pw2);
      }
      else
         Log( "Bad line in configuration file: %s", buf );
   }

   if( ferror( cf ) )
   {
      Log("Read error encountered while reading configuration file.");
      SFCLOSE(cf);
      return FALSE;
   }

   SFCLOSE(cf);

   if( !localname[0] || localport <= 0 || !chancreators[0] )
   {
      Log( "LocalName, LocalPort, and ChannelCreators MUST be set to start IMC2 hub" );
      return FALSE;
   }

   if( !iweb[0])
   {
      Log( "InfoWeb MUST be set to start IMC2 hub." );
      return FALSE;
   }

   if ( !netname[0] )
   {
      Log( "NetworkName MUST be set to start IMC2 hub." ); 
      return FALSE;
   }

   if ( maxconn <= 0 )
   {
      Log( "MaxConnections MUST be set to start IMC2 ub." );
      return FALSE;
   }

   rep_name = strdup(localname);
   rep_port = localport;
   rep_bind = localip;
   rep_siteinfo.netname = strdup(netname);
   rep_siteinfo.chancreators = strdup(chancreators);
   rep_siteinfo.web = strdup(iweb);
   rep_siteinfo.updatefile = updatefile;
   rep_siteinfo.autosetup = autosetup;
   rep_siteinfo.htmlmudlist = htmlmudlist;
   rep_siteinfo.htmlstats = htmlstats;
   rep_siteinfo.maxconn = maxconn;

   return TRUE;
}

const char *rep_list( void )
{
   static char buf[IMC_DATA_LENGTH];
   REMINFO *p;
   unsigned int count = 1;

   snprintf( buf, IMC_DATA_LENGTH, "~WNetwork Connection Listings:\n\r"
                "~g%-15.15s  ~c%-35.35s  ~G%-10.10s  ~g%-10.10s"
        "\n\r\n\r~g%-15.15s  ~c%-35.35s  ~G%-10.10s  ~g%-10.10s",
                "Name", "IMC2 Version", "Network", "Hub", 
                rep_name, IMC_VERSIONID, rep_siteinfo.netname, rep_name );

   for( p = first_reminfo; p; p = p->next )
   {
           snprintf( buf + strlen(buf), IMC_DATA_LENGTH - strlen(buf), 
           "\n\r~g%-15.15s  ~c%-35.35s  ~G%-10.10s  ~g%-10.10s",
           p->name, p->version, 
           STR_CEQL( p->netname, "unknown" ) ? rep_siteinfo.netname : p->netname, 
           rep_hubinpath(p->path));

           count++;
   }

   snprintf( buf + strlen( buf ), IMC_DATA_LENGTH - strlen(buf),
           "\n\r~W%d active connections found.\n\r", count );

   return buf;
}

const char *process_directconnection_list( void )
{
    INFO *i = NULL;
    static char buf[IMC_DATA_LENGTH];

    snprintf( buf, IMC_DATA_LENGTH, "~WDirect Connections to %s:\n\r"
            "~g%-15.15s ~c%-20.20s\n\r", rep_name, "Name", "Connection State" );
    
    for( i = first_info; i; i = i->next )
    {
        char lastconn[35];

        if ( i->no_list )
            continue;

        lastconn[0] = '\0';

        if ( i->last_connected  )
        {
            long diff = (long)rep_now - (long)i->last_connected;

            snprintf( lastconn, 35, "Connected: %ld hours %ld minutes", diff/3600, (diff/60)%60 );
        }
        else
            strlcpy( lastconn, "Connected: Unavailable", 35 );
        
        snprintf( buf + strlen(buf), IMC_DATA_LENGTH - strlen(buf), 
                "\n\r~g%-15.15s ~c%-35.35s", i->name, i->connection ? lastconn : "Not Connected" );

    }

    snprintf( buf + strlen(buf), IMC_DATA_LENGTH - strlen(buf), "\n\r" );
    
    return buf;
}

/* send a keepalive request to everyone - shogar */
void rep_request_keepalive( void )
{
   PACKET out;

   rep_initdata( &out );
   strlcpy( out.type, "keepalive-request", IMC_TYPE_LENGTH );
   strlcpy( out.from, "*", IMC_NAME_LENGTH );
   strlcpy( out.to, "*@*", IMC_NAME_LENGTH );
   rep_addkey( &out, "versionid", IMC_VERSIONID );

   rep_send( &out );
   rep_freedata( &out );
}

void relay_ice_refresh( const PACKET *p )
{
   PACKET out;
   INFO *i = NULL;
   unsigned int used_sequence[IMC_MEMORY];
   unsigned int counter = 0, x = 0, new_sequence = p->i.sequence;

   Log( "Channel refresh packet from %s relayed to all configured hubs.", rep_mudof( p->from ) );

   rep_initdata( &out );
   strlcpy( out.type, "ice-refresh", IMC_TYPE_LENGTH );
   strlcpy( out.from, p->from, IMC_NAME_LENGTH );
   strlcpy( out.i.from, p->from, IMC_NAME_LENGTH );
   strlcpy( out.i.path, p->i.path, IMC_PATH_LENGTH );
   rep_addkey( &out, "channel", "*" );
   rep_addkeyi( &out, "relayed", 1 );

   
   for ( counter = 0; counter < IMC_MEMORY; counter++ )
       if ( rep_memory[counter].from && STR_CEQL( rep_mudof( p->from ), rep_memory[counter].from ) )
           used_sequence[x++] = rep_memory[counter].sequence;

   for ( i = first_info; i; i = i->next )
   {
       if ( !i->router )
           continue;

       if ( inpath( p->i.path, i->name ) )
           continue;

       counter = 0;

       while ( counter < x )
       {
           new_sequence--;

           for ( counter = 0; counter < x; counter++ )
               if ( new_sequence == used_sequence[counter] )
                   break;
       }

       out.i.sequence = new_sequence;
       snprintf( out.i.to, IMC_NAME_LENGTH, "ICE@%s", i->name );

       forward ( &out );
   }

   rep_freedata( &out );
   return;
}

void check_mudsfile(void)
{
  FILE *mf;
  INFO *i = NULL;
  char name[IMC_MNAME_LENGTH], pw1[IMC_PW_LENGTH], pw2[IMC_PW_LENGTH];
  char c = '\0';
  bool success = FALSE;

  if ( !(mf = fopen( IMC_UPDATE_FILE, "r" )) )
      return;

  while ( (c = fgetc(mf)) != EOF )
  {
      if ( c == '-' )
      {
          if ( fscanf( mf, "%19[^\n]\n", name ) != 1 )
          {
              Log( "Bad \'-\' line in the update file.");
              continue;
          }

          if ( (i = rep_getinfo(name)) == NULL )
          {
              Log( "Connection referenced in a \'-\' line in the update file could not be found." );
              continue;
          }

          rep_delete_info( i );
          success = TRUE;
          continue;
      }
      else if ( c == '%' )
      {
          char ip[24];

          if ( fscanf( mf, "%23[^\n]\n", ip ) != 1 )
          {
              Log( "Bad \'%%\' line in the update file.");
              continue;
          }

          if( rep_find_blacklist( ip ) == NULL )
          {
              CONNECTION *conn, *conn_next;

              add_to_blacklist( ip );

              for( conn = first_connection; conn; conn = conn_next )
              {
                  conn_next = conn->next;

                  if ( conn->ip && STR_CEQL( conn->ip, ip ))
                      do_close(conn);
              }
          }
          else
              rem_from_blacklist( ip );

          rep_saveblacklist();
      }
      else if ( c == '+' || c == '#' )
      {
          unsigned short port;
          char host[SSS];

          if ( fscanf( mf, "%19[^:]:%255[^:]:%hu:%19[^:]:%19[^\n]\n", name, host, &port, pw1, pw2 ) != 5 )
          {
              Log( "Bad \'%c\' line in the update file.", c );
              continue;
          }

          if ( (i = rep_getinfo(name)) != NULL )
          {
              Log( "Connection listed in a \'%c\' line in the update file already exists.", c ); 
              continue;
          }

          i = rep_new_info();
          i->name       = strdup(name);
          i->host       = strdup(host);
          i->clientpw   = strdup(pw1);
          i->serverpw   = strdup(pw2);
          i->port       = port;

          if ( c == '#' )
              i->router = TRUE;

          rep_connect_to( i->name );
          success = TRUE;
      }
      else if ( c == '@' )
      {
          if ( fscanf( mf, "%19[\n]\n", name ) != 1 )
          {
              Log( "%s", "Bad \'@\' line in the update file" );
              continue;
          }

          if ( (i = rep_getinfo(name)) != NULL )
          {
              Log( "%s", "Connection listed in a \'@\' line in the update file already exists." );
              continue;
          }

          i = rep_new_info();
          i->name = strdup(name);
          i->router = TRUE;
          i->no_list = TRUE;

          success = TRUE;
      }
      else if ( c == '*' )
      {
          if ( fscanf( mf, "%19[^:]:%19[^:]:%19[^\n]\n", name, pw1, pw2 ) != 3 )
          {
              Log( "%s", "Bad \'*\' line in the update file.");
              continue;
          }

          if ( (i = rep_getinfo(name)) != NULL )
          {
              Log( "%s", "Connection listed in a \'*\' line in the update file already exists." ); 
              continue;
          }

          i = rep_new_info();
          i->name       = strdup(name);
          i->clientpw   = strdup(pw1);
          i->serverpw   = strdup(pw2);

          success = TRUE;
      }
      else
      {
          Log( "Bad \'start of line\' character found in the update file.");

          while ( c != '\n' && c != '\r' && c != EOF )
              c = fgetc(mf);

          while ( c == '\n' || c == '\r' )
              c = fgetc(mf);
      }
  }

  SFCLOSE(mf);
  unlink(IMC_UPDATE_FILE);

  if ( success )
      rep_saveconfig();

  return;
}

/* HTML cleaned up by Ntanel Stormblade of Mudworld */
void write_htmlmudlist( void )
{
    FILE *htf;
    REMINFO *p = NULL;
    unsigned int count = 1;
    struct timeval proper_time;
    time_t current_time;
    char *strtime;

    if ( ( htf = fopen( HTML_MUDLIST_FILE, "w" ) ) == NULL )
    {
        Log( "HTML Mudlist File could not be opened for writing." );
        return;
    }

    fprintf( htf, "%s\n", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">" );
    fprintf( htf, "%s\n", "<html>\n<head>" );
    fprintf( htf, "<title>IMC2 Network Listings from %s</title>\n\n", rep_name );
    fprintf( htf, "%s\n", "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=ISO-8859-1\">" );
    fprintf( htf, "%s\n", "<META HTTP-EQUIV=REFRESH CONTENT=60>" );
    fprintf( htf, "<LINK REL=\"stylesheet\" TYPE=\"text/css\" HREF=\"%s\">\n", CSS_FILE_URL );
    fprintf( htf, "%s\n", "</head>" );
    fprintf( htf, "%s\n\n", "<body class=\"body\"" );

    fprintf( htf, "%s\n", "<center><h2 class=\"h2\">Network Connection Listings</h2><br>" );
    fprintf( htf, "%s\n\n", "<table border=0 width=\"100%\">" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"20%\" align=\"left\" valign=\"top\"><font class=\"col1\">Name</font></td>" );
    fprintf( htf, "%s\n", "<td width=\"30%\" align=\"left\" valign=\"top\"><font class=\"col2\">IMC2 Version</font></td>" );
    fprintf( htf, "%s\n", "<td width=\"25%\" align=\"left\" valign=\"top\"><font class=\"col3\">Network</font></td>" );
    fprintf( htf, "%s\n", "<td width=\"25%\" align=\"left\" valign=\"top\"><font class=\"col4\">Hub</font></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    /* Print info for hub */
    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "<td width=\"20%%\" align=\"left\" valign=\"top\"><a href=\"%s\"><font class=\"col1\">%s</font></a></td>\n", 
            rep_siteinfo.web, rep_name );
    fprintf( htf, "<td width=\"30%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n",
            IMC_VERSIONID );
    fprintf( htf, "<td width=\"25%%\" align=\"left\" valign=\"top\"><font class=\"col3\">%s</font></td>\n",
            rep_siteinfo.netname );
    fprintf( htf, "<td width=\"25%%\" align=\"left\" valign=\"top\"><font class=\"col4\">%s</font></td>\n",
            rep_name );
    fprintf( htf, "%s\n\n", "</tr>" );

    /* List the other hubs and muds */
    for ( p = first_reminfo; p; p = p->next ) 
    {
        fprintf( htf, "%s\n", "<tr>" );

        if ( !p->web || p->web[0] == '\0' || STR_CEQL( p->web, "unknown" ) )
        {
            fprintf( htf, "<td width=\"20%%\" align=\"left\" valign=\"top\"><font class=\"col1\">%s</font></td>\n",
                    p->name );
        }
        else
        {
            fprintf( htf, "<td width=\"20%%\" align=\"left\" valign=\"top\"><a href=\"%s\"><font class=\"col1\">%s</font></a></td>\n",
                    p->web, p->name );
        }

        fprintf( htf, "<td width=\"30%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n",
                p->version );
        fprintf( htf, "<td width=\"25%%\" align=\"left\" valign=\"top\"><font class=\"col3\">%s</font></td>\n",
                STR_CEQL( p->netname, "unknown" ) ? rep_siteinfo.netname : p->netname );
        fprintf( htf, "<td width=\"25%%\" align=\"left\" valign=\"top\"><font class=\"col4\">%s</font></td>\n",
                rep_hubinpath( p->path ) );
        fprintf( htf, "%s\n\n", "</tr>" );

        count++;
    }

    gettimeofday( &proper_time, NULL );
    current_time = proper_time.tv_sec;
    strtime = ctime(&current_time);
    strtime[strlen(strtime) - 1] = '\0';

    fprintf( htf, "%s\n\n", "</table><p>" );

    fprintf( htf, "<h3 class=\"h3\">%d active connections found.</h3><p>\n\n", count );

    fprintf( htf, "<h4 class=\"h4\">Last Updated: <i>%s</i></h4>\n\n", strtime );

    fprintf( htf, "%s\n\n", "</center>" );

    fprintf( htf, "%s\n", "</body>\n</html>" );

    SFCLOSE( htf );
    return;
}

/* HTML cleaned up by Ntanel Stormblade of Mudworld */
void write_htmlstats( void )
{
    FILE *htf;
    INFO *i = NULL;
    struct timeval proper_time;
    time_t current_time;
    unsigned int count = 0;
    char *strtime;


    if ( ( htf = fopen( HTML_STATS_FILE, "w" ) ) == NULL )
    {
        Log( "HTML Stats File could not be opened for writing." );
        return;
    }

    fprintf( htf, "%s\n", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">" );
    fprintf( htf, "%s\n", "<html>\n<head>" );
    fprintf( htf, "<title>IMC2 Statistics for %s</title>\n\n", rep_name );
    fprintf( htf, "%s\n", "<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=ISO-8859-1\">" );
    fprintf( htf, "%s\n", "<META HTTP-EQUIV=REFRESH CONTENT=60>" );
    fprintf( htf, "<LINK REL=\"stylesheet\" TYPE=\"text/css\" HREF=\"%s\">\n", CSS_FILE_URL );
    fprintf( htf, "%s\n", "</head>" );
    fprintf( htf, "%s\n\n", "<body class = \"body\"" );

    fprintf( htf, "<center><h2 class=\"h2\">%s Statistical Output</h2><br>\n\n", rep_name );

    fprintf( htf, "%s\n\n", "<table border=\"0\" width=\"100%\">" );
    
    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td colspan=\"2\" width=\"100%\" align=\"left\" valign=\"top\"><h3 class=\"h3\">General Information:</h3></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Name:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>", rep_name );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">IMC2 Version:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n", IMC_VERSIONID );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Time of Startup:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n", ctime( &rep_boot ) );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td colspan=\"2\" width=\"100%\" align=\"center\" valign=\"middle\">&nbsp;<br><hr width=\"50%\">&nbsp;<br></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td colspan=\"2\" width=\"100%\" align=\"left\" valign=\"top\"><h3 class=\"h3\">Optional Capabilities:</h3></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Autosetup:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n", rep_siteinfo.autosetup ? "Enabled" : "Disabled" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Update File:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n", rep_siteinfo.updatefile ? "Enabled" : "Disabled" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Imclist Webpage:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n", rep_siteinfo.htmlmudlist ? "Enabled" : "Disabled" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Stats Webpage:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n", rep_siteinfo.htmlstats ? "Enabled" : "Disabled" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td colspan=\"2\" width=\"100%\" align=\"center\" valign=\"middle\">&nbsp;<br><hr width=\"50%\">&nbsp;<br></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td colspan=\"2\" width=\"100%\" align=\"left\" valign=\"top\"><h3 class=\"h3\">Input & Output Information:</h3></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Number of Received Packets:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%ld</font></td>\n", rep_stats.rx_pkts );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Number of Received Bytes:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%ld</font></td>\n", rep_stats.rx_bytes );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Number of Sent Packets:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%ld</font></td>\n", rep_stats.tx_pkts );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Number of Sent Bytes:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%ld</font></td>\n", rep_stats.tx_bytes );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Largest Packet Handled:</font></td>" );
    fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%d</font></td>\n", rep_stats.max_pkt );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td colspan=\"2\" width=\"100%\" align=\"center\" valign=\"middle\">&nbsp;<br><hr width=\"50%\">&nbsp;<br></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td colspan=\"2\" width=\"100%\" align=\"left\" valign=\"top\"><h3 class=\"h3\">Direct Connections:</h3></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col1\">Name</font></td>" );
    fprintf( htf, "%s\n", "<td width=\"50%\" align=\"left\" valign=\"top\"><font class=\"col2\">Connection State</font></td>" );
    fprintf( htf, "%s\n\n", "</tr>" );

    for ( i = first_info; i; i = i->next )
    {
        REMINFO *r = NULL;
        char lastconn[35];

        if ( i->no_list )
            continue;

        lastconn[0] = '\0';

        if ( i->last_connected )
        {
            long diff = (long) rep_now - (long)i->last_connected;

            snprintf( lastconn, 35, "Connected: %ld hours %ld minutes", diff/3600, (diff/60)%60 );
        }
        else
            strlcpy( lastconn, "Connected: Unavailable", 35 );

        fprintf( htf, "%s\n", "<tr>" );

        if ( ( r = rep_find_reminfo( i->name ) ) == NULL  || !r->web || r->web[0] == '\0'
                || STR_CEQL( r->web, "unknown" ) )
        {
            fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col1\">%s</font></td>\n", i->name );
        }
        else
        {
            fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><a href = \"%s\"><font class=\"col1\">%s</font></a></td>\n", r->web, i->name );
        }

        fprintf( htf, "<td width=\"50%%\" align=\"left\" valign=\"top\"><font class=\"col2\">%s</font></td>\n", i->connection ? lastconn : "Not Connected" );
        fprintf( htf, "%s\n\n", "</tr>" );
        
        count++;
    }

    fprintf( htf, "%s\n", "<tr>" );
    fprintf( htf, "<td colspan=\"2\" width=\"100%%\" align=\"left\" valign=\"top\"><h4 class=\"h4\">%d connection slots.</h4></td>\n", count );
    fprintf( htf, "%s\n\n", "</tr>" );

    gettimeofday( &proper_time, NULL );
    current_time = proper_time.tv_sec;
    strtime = ctime(&current_time);
    strtime[strlen(strtime) - 1] = '\0';

    fprintf( htf, "%s\n\n", "</table><p>" );

    fprintf( htf, "<h4 class=\"h4\">Last Updated: <i>%s</i></h4>\n\n", strtime );

    fprintf( htf, "%s\n\n", "</center>" );

    fprintf( htf, "%s\n", "</body>\n</html>" );

    SFCLOSE( htf );
    return;
}

/* called when a keepalive has been received */
void rep_recv_keepalive( const char *from, const char *version, const char *networkname, const char *web  )
{
   REMINFO *p;

   if( STR_CEQL( from, rep_name ) )
      return;
  
   /* this should never fail, rep.c should create an entry if one doesn't exist (in the path update code) */
   p = rep_find_reminfo( from );
   if( !p )		    /* boggle */
      return;

   if( !STR_CEQL( version, p->version ) )    /* remote version has changed? */
   {
      DISPOSE( p->version );              /* if so, update it */
      p->version = strdup( version );
   }

   if( !STR_CEQL( networkname, p->netname ) )
   {
      DISPOSE( p->netname );
      p->netname = strdup( networkname );
   }

   if( !STR_CEQL( web, p->web ) )
   {
      DISPOSE( p->web );
      p->web = strdup( web );
   }

}

/* called when a ping request is received */
void rep_recv_ping(const char *from, const char *path)
{
  /* ping 'em back */
  rep_send_pingreply(from, path);
}

void rep_recv_who( const char *pname, const char *type )
{
   char arg[IMC_DATA_LENGTH];

   type = rep_getarg( type, arg, IMC_DATA_LENGTH );

   if( STR_CEQL( arg, "who" ) )
     rep_send_whoreply( pname, process_directconnection_list() );
   else if( STR_CEQL( arg, "info" ) )
     rep_send_whoreply( pname, rep_getstats("general") );
   else if( STR_CEQL( arg, "list" ) )
     rep_send_whoreply( pname, rep_list() );
   else if( STR_CEQL( arg, "istats" ) )
     rep_send_whoreply( pname, rep_getstats("network") );
   else if( STR_CEQL( arg, "help" ) || STR_CEQL( arg, "services" ) )
     rep_send_whoreply( pname,
		      "~WAvailable repminfo types:\n\r"
		      "~chelp       ~W- ~Cthis list\n\r"
              "~cwho        ~W- ~Clist directly connected muds\n\r"
		      "~cinfo       ~W- ~Chub information\n\r"
		      "~clist       ~W- ~Clist known muds on IMC\n\r"
		      "~cistats     ~W- ~Cnetwork traffic statistics\n\r" );
   else
     rep_send_whoreply( pname, "Sorry, no information of that type is available." );
}


/* handle a packet destined for us, or a broadcast */
void rep_recv( const PACKET *p )
{
   /* who: receive a who request */
   if( STR_CEQL( p->type, "who" ) || STR_CEQL( p->type, "wHo" ) )
   {
      rep_recv_who( p->from, rep_getkey( p, "type", "who" ) );
   }

   /* is-alive: receive a keepalive (broadcast) */
   else if( STR_CEQL( p->type, "is-alive" ) )
   {
       Log( "Received is-alive from %s.", rep_mudof( p->from ) );
       rep_recv_keepalive( rep_mudof( p->from ), rep_getkey( p, "versionid", "unknown" ),
               rep_getkey( p, "networkname", "unknown"), rep_getkey( p, "url", "unknown") );
   }

   /* ping: receive a ping request */
   else if( STR_CEQL( p->type, "ping" ) )
   {
      rep_recv_ping( rep_mudof( p->from ), p->i.path );
   }

   /* Handle channel refresh requests from muds */
   else if( STR_CEQL( p->type, "ice-refresh" ) )
   {
       IMC_CHANNEL *c = NULL;

       /* Send channel updates from local config */
       for ( c = first_rep_channel; c; c = c->next )
           iced_update( c, rep_mudof( p->from ) );

       /* Send out to other hubs */
       relay_ice_refresh( p );
   }

   /* handle keepalive requests - shogar */
   else if( STR_CEQL( p->type, "keepalive-request" ) )
   {
       struct rep_keepalive *k = NULL;

       Log( "Keepalive request received from %s.", rep_mudof(p->from) );

       CREATE( k, struct rep_keepalive, 1 );
       strlcpy( k->destination, rep_mudof(p->from), IMC_MNAME_LENGTH );
       k->count = 0;
       k->remote = first_reminfo;

       rep_add_event( 1, ev_send_isalive, k );
   }

   /* expire closed hubs - shogar */
   else if( STR_CEQL( p->type, "close-notify" ) )
   {
      INFO *i = NULL;
      REMINFO *r = NULL;

      if ( ( i = rep_getinfo( rep_mudof( p->from ) ) ) == NULL )
          return;

      Log( "Close-notify packet for %s received from %s.", rep_getkey( p, "host", "unknown" ), p->from );

      if ((r = rep_find_reminfo(rep_getkey(p, "host", "") )) != NULL )
      {
          REMINFO *o, *o_next;

          /* if it's a hub, silently delete muds on it from cache */
          for ( o = first_reminfo; o; o = o_next )
          {
              o_next = o->next;

              if ( STR_CEQL( r->name, rep_hubinpath( o->path ) ) )
                  rep_delete_reminfo( o );
          }

          rep_delete_reminfo(r);
      }
   }

   /* call catch-all fn if present */
   else
   {
      iced_recv( p );
   }

   return;
}

/* Commands called by the interface layer */

/* send an emote out on a channel */
void rep_send_emote( const char *argument )
{
   PACKET out;

   rep_initdata(&out);

   strlcpy( out.from, "ICE", IMC_NAME_LENGTH );
   strlcpy( out.to, "*@*", IMC_NAME_LENGTH );
   strlcpy( out.type, "emote", IMC_TYPE_LENGTH );
   rep_addkeyi( &out, "channel", 15 );
   rep_addkeyi( &out, "level", -1 );
   rep_addkey( &out, "text", argument );

   rep_send( &out );
   rep_freedata( &out );
}

/* send a tell to a remote player */
void rep_send_tell( const char *to, const char *argument )
{
   PACKET out;

   if( STR_EQL( rep_mudof(to), "*" ) )
      return; /* don't let them do this */

  
   rep_initdata(&out);
   strcpy( out.from, "ICE" );
   strcpy( out.to, to  );
   strcpy( out.type, "tell"  );
   rep_addkey( &out, "text", argument );
   rep_addkeyi( &out, "isreply", 1 );
   rep_addkeyi( &out, "level", -1 );

   rep_send( &out );
   rep_freedata( &out );
}

/* respond to a who request with the given data */
void rep_send_whoreply( const char *to, const char *data )
{
   PACKET out;

   if( STR_EQL( rep_mudof(to), "*" ) )
      return; /* don't let them do this */

   rep_initdata( &out );

   strlcpy( out.to, to, IMC_NAME_LENGTH );

   strlcpy( out.type, "who-reply", IMC_TYPE_LENGTH );
   strlcpy( out.from, "*", IMC_NAME_LENGTH );

   rep_addkey( &out, "text", data );

   rep_send( &out );
   rep_freedata( &out );
}

void ev_send_isalive( void *data )
{
    REMINFO *r = NULL;
    struct rep_keepalive *k = (struct rep_keepalive *) data;
    unsigned char count = 0;

    rep_cancel_event( ev_send_isalive, k);

    if ( !k )
        return;

    if ( k->count == 0 )
    {
        rep_send_keepalive( NULL, k->destination );
        count++;
    }

    for ( r = k->remote; r != NULL; r = r->next )
    {
        if ( STR_CEQL( k->destination, r->name ) || inpath(r->path, k->destination))
            continue;
            
        rep_send_keepalive( r, k->destination );
        count++;

        /* Don't want to send more than 15 is-alive packets at a time */
        if ( count >= 15 && r->next != NULL )
        {
            k->count += count;
            k->remote = r->next;
            rep_add_event( 3, ev_send_isalive, k );
            return;
        }
    }

    k->destination[0] = '\0';
    k->count = 0;
    k->remote = NULL;

    DISPOSE( k );
    return;
}

/* send a keepalive to everyone */
void rep_send_keepalive( REMINFO *r, char *destination )
{
   PACKET out;

   rep_initdata( &out );

   strlcpy( out.from, "*", IMC_NAME_LENGTH );
   strlcpy( out.type, "is-alive", IMC_TYPE_LENGTH );
   snprintf( out.to, IMC_NAME_LENGTH, "*@%s", destination );
   strlcpy( out.i.to, out.to, IMC_NAME_LENGTH );

   if ( !r )
   {
       snprintf( out.i.from, IMC_NAME_LENGTH, "%s@%s", out.from, rep_name );

       rep_addkey( &out, "versionid", IMC_VERSIONID );
       rep_addkey( &out, "networkname", rep_siteinfo.netname );
       rep_addkey( &out, "url", rep_siteinfo.web );

       out.i.sequence = rep_sequencenumber++;

       if ( !rep_sequencenumber )
           rep_sequencenumber++;

       out.i.path[0] = 0;
   }
   else
   {
       unsigned int used_sequence[IMC_MEMORY];
       unsigned int counter = 0, x = 0, new_sequence = r->top_sequence;

       snprintf( out.i.from, IMC_NAME_LENGTH, "%s@%s", out.from, r->name );

       if ( r->version && r->version[0] != '\0' && !STR_CEQL( r->version, "unknown" ) )
           rep_addkey( &out, "versionid", r->version );

       if ( r->netname && r->netname[0] != '\0' && !STR_CEQL( r->netname, "unknown" ) )
           rep_addkey( &out, "networkname", r->netname );

       if ( r->web && r->web[0] != '\0' && !STR_CEQL( r->web, "unknown" ) )
           rep_addkey( &out, "url", r->web );

       for( counter = 0; counter < IMC_MEMORY; counter++ )
           if ( rep_memory[counter].from && STR_CEQL( r->name, rep_memory[counter].from ) )
               used_sequence[x++] = rep_memory[counter].sequence;

       counter = 0;

       while ( counter < x )
       {
           new_sequence--;

           for ( counter = 0; counter < x; counter++ )
               if ( new_sequence == used_sequence[counter] )
                       break;
       }

       out.i.sequence = new_sequence;

       strlcpy( out.i.path, r->path, IMC_PATH_LENGTH );
   }


   forward( &out );

   rep_freedata( &out );
}

/* send a pingreply with the originating path */
void rep_send_pingreply( const char *to, const char *path )
{
   PACKET out;

   rep_initdata( &out );
   strlcpy( out.type, "ping-reply", IMC_TYPE_LENGTH );
   strlcpy( out.from, "*", IMC_NAME_LENGTH );
   snprintf( out.to, IMC_NAME_LENGTH, "*@%s", to );
   rep_addkey( &out, "path", path );

   rep_send( &out );
   rep_freedata( &out );
}

