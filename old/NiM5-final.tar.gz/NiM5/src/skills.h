/****************************************************************************
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___| G| v4.0   Version 4.0 GOLD EDITION      *
* |  /   \  __|  \__/  |  | |  |     O|        documentation release         *
* |       ||  |        |  \_|  | ()  L|        Hallow's Eve 1999             *
* |    |  ||  |  |__|  |       |     D|                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 *   ___  ___  ___  __    __                                                *
 *  |   ||   ||   ||  |\/|  | 2-x    NiMUD is a software currently under    *
 *   |  \ | |  | |  | |\/| |         development.  It is based primarily on *
 *   | |\\| |  | |  | |  | |         the discontinued package, Merc 2.2.    *
 *   | | \  |  | |  | |  | |         NiMUD is being written and developed   *
 *  |___||___||___||__|  |__|        By Locke and Surreality as a new,      *
 *   NAMELESS INCARNATE *MUD*        frequently updated package similar to  *
 *        S O F T W A R E            the original Merc 2.x.                 *
 *                                                                          *
 *  Just look for the Iron Maiden skull wherever NiMUD products are found.  *
 *                                                                          *
 *  Much time and thought has gone into this software and you are           *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                                                   *
 ****************************************************************************/

/*
 * Skill group defines.
 */

#define GRO_CRAFT                         10
#define GRO_LANGUAGE                          11
#define GRO_LEGERDEMAIN                       12
#define GRO_OFFENSE                           13
#define GRO_DEFENSE                           14
#define GRO_SURVIVAL                          15
#define GRO_WP                                16
#define GRO_FIRE_BASIC                       501
#define GRO_WATER_BASIC                      502
#define GRO_AIR_BASIC                        503
#define GRO_EARTH_BASIC                      504
#define GRO_FIRE_ADV                         601
#define GRO_WATER_ADV                        602
#define GRO_AIR_ADV                          603
#define GRO_EARTH_ADV                        604
#define GRO_FIRE_EXP                         701
#define GRO_WATER_EXP                        702
#define GRO_AIR_EXP                          703
#define GRO_EARTH_EXP                        704
#define GRO_SPC_GENERAL                      901
#define GRO_NECROMANTICS                     902
#define GRO_CONJURATIONS                     903
#define GRO_MALADICTIONS                     904
#define GRO_ILLUSIONS                        905
#define GRO_DIVINATIONS                      906
#define GRO_ENCHANTMENTS                     907
#define GRO_SUMMONINGS                       908
#define GRO_NONE                               0

/*
 * External gsn calls.
 * These are skill_lookup return values for common skills and spells.
 */
extern  sh_int  gsn_repair;
extern  sh_int  gsn_lycanthropy;

extern	sh_int	gsn_backstab;
extern	sh_int	gsn_peek;
extern	sh_int	gsn_pick_lock;
extern	sh_int	gsn_steal;
extern  sh_int  gsn_haggling;

extern  sh_int  gsn_track;
extern  sh_int  gsn_swimming;
extern  sh_int  gsn_fishing;
extern  sh_int  gsn_climb;
extern  sh_int  gsn_riding;
extern  sh_int  gsn_hide;
extern  sh_int  gsn_sneak;

extern	sh_int	gsn_enhanced_damage;
extern  sh_int  gsn_second_attack;
extern  sh_int  gsn_third_attack;
extern  sh_int  gsn_dual_wield;
extern  sh_int  gsn_kick;
extern  sh_int  gsn_hth;

extern  sh_int  gsn_parry;
extern  sh_int  gsn_dodge;
extern	sh_int	gsn_rescue;
extern  sh_int  gsn_flee;
extern  sh_int  gsn_subdue;
extern  sh_int  gsn_disarm;

extern	sh_int	gsn_blindness;
extern	sh_int	gsn_charm_person;
extern	sh_int	gsn_curse;
extern	sh_int	gsn_invis;
extern	sh_int	gsn_mass_invis;
extern	sh_int	gsn_poison;
extern	sh_int	gsn_sleep;

extern  sh_int  gsn_wp_slash;
extern  sh_int  gsn_wp_pierce;
extern  sh_int  gsn_wp_whip;
extern  sh_int  gsn_wp_pound;
extern  sh_int  gsn_wp_ranged;
extern  sh_int  gsn_wp_sharpshooting;
extern  sh_int  gsn_wp_throwing;
extern  sh_int  gsn_wp_other;

extern  sh_int  gsn_craft;
extern  sh_int  gsn_wp;
extern  sh_int  gsn_language;
extern  sh_int  gsn_legerdemain;
extern  sh_int  gsn_offense;
extern  sh_int  gsn_defense;
extern  sh_int  gsn_survival;
extern  sh_int  gsn_fire;
extern  sh_int  gsn_water;
extern  sh_int  gsn_air;
extern  sh_int  gsn_earth;
extern  sh_int  gsn_spc_gen;
extern  sh_int  gsn_spc_necro;
extern  sh_int  gsn_spc_conj;
extern  sh_int  gsn_spc_malad;
extern  sh_int  gsn_spc_illus;
extern  sh_int  gsn_spc_divin;
extern  sh_int  gsn_spc_enchant;
extern  sh_int  gsn_spc_summons;

extern  sh_int  gsn_zengalli;
extern  sh_int  gsn_olani;
extern  sh_int  gsn_mudaki;
extern  sh_int  gsn_zalufini;
extern  sh_int  gsn_haesni;
extern  sh_int  gsn_ghaenish;
extern  sh_int  gsn_argot;
extern  sh_int  gsn_imarind;
extern  sh_int  gsn_alsidi;
extern  sh_int  gsn_brood;
