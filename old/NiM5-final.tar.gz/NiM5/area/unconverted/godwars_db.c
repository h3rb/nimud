/****************************************************************************
 * Locke's   __                      __         NIM Server Software         *
 * ___ ___  (__)__    __ __   __ ___|  | v5     Version 5 (ALPHA)           *
 * |  /   \  __|  \__/  |  | |  |      |        unreleased+revamped 2004    *
 * |       ||  |        |  \_|  | ()   |                                    *
 * |    |  ||  |  |__|  |       |      |                                    *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud  *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool     *
 ****************************************************************************/

/***************************************************************************
 *  God Wars Mud improvements copyright (C) 1994, 1995, 1996 by Richard    *
 *  Woolcock.  This mud is NOT to be copied in whole or in part, or to be  *
 *  run without the permission of Richard Woolcock.  Nobody else has       *
 *  permission to authorise the use of this code.                          *
 ***************************************************************************/

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "nimud.h"

#if defined(KEY)
#undef KEY
#endif

#if defined(SKEY)
#undef SKEY
#endif

#define KEY( literal, field, value )                \
                if ( !str_cmp( word, literal ) )    \
                {                                   \
                    field  = value;                 \
                    fMatch = TRUE;                  \
                    break;                          \
                }

#define SKEY( string, field )                       \
                if ( !str_cmp( word, string ) )     \
                {                                   \
                    free_string( field );           \
                    field = fread_string( fp );     \
                    fMatch = TRUE;                  \
                    break;                          \
                }


#define GWZONE_LIST "godwars_db/zone.lst"


void gw_load_mobiles  args( ( FILE *fp ) );
void gw_load_rooms    args( ( FILE *fp ) );
void gw_load_objects  args( ( FILE *fp ) );
ZONE_DATA *gw_load_zone     args( ( FILE *fp, char *strArea ) );
void gw_load_specials args( ( FILE *fp ) );
void gw_load_resets   args( ( FILE *fp ) );
void gw_load_shops    args( ( FILE *fp ) );


void load_db_gw( void ) {
    /*
     * Read in all the zone files.
     */
    {
        ZONE_DATA *pZone=NULL;
        FILE *fpList;
        char *strzoneNames[MAX_ZONE];
        char buf1[MAX_STRING_LENGTH];
        char buf2[MAX_STRING_LENGTH];
        int x;

        sprintf( strzone, "%s", GWZONE_LIST );

        for ( x = 0; x < MAX_ZONE; x++ ) strzoneNames[x] = NULL;

        if ( ( fpList = fopen( GWZONE_LIST, "r" ) ) == NULL )
        {
            perror( GWZONE_LIST );
            exit( 1 );
        }

        for ( x = 0; x < MAX_ZONE; x++ )
        {
            if ( feof( fpList ) ) break;
            strzoneNames[x] = str_dup( fread_word( fpList ) );
            if ( strzoneNames[x][0] == '$' ) break;
        }

        fclose( fpList );

        sprintf( buf1, "Loading zones: [%5d]\n\r", x );
        write_global( buf1 );

        for ( x = 0; x < MAX_ZONE; x++ )
        {
            if ( feof( fpList ) ) break;
            strzoneNames[x] = str_dup( fread_word( fpList ) );
            if ( strzoneNames[x][0] == '$' ) break;
        }

        fclose( fpList );

        sprintf( buf1, "Loading GW zones: [%5d]\n\r", x );
        write_global( buf1 );

        for ( x = 0; x < MAX_ZONE; x++ )
        {

        if ( strzoneNames[x] == NULL ) break;

        sprintf( strzone, "%s", strzoneNames[x] );

        if ( strzone[0] == '$' )
                break;

        /*
         * Loading output.
         */
        {
#if defined(unix)
            poll_connections( control );
            clean_connections( );
#endif
            sprintf( buf2, "GWConv-Loading [%s]\n", strzone );
#if defined(unix)
            log_string( buf2 );
#endif
            write_global( buf2 );
            connection_output( );
        }


            if ( strzone[0] == '-' )
            {
            fpZone = stdin;
            }
            else
            {
            if ( ( fpZone = fopen( strzone, "r" ) ) == NULL )
            {
                    perror( strzone );
                    exit( 1 );
            }
        }

        for ( ; ; )
            {
        char *word;


                if ( fread_letter( fpZone ) != '#' )
                {
                    bug( "Boot_db: # not found.", 0 );
                    exit( 1 );
                }

                word = fread_word( fpZone );

        if ( word[0] == '$'  )
                     break;


             if ( !str_cmp( word, "AREADATA" ) ) pZone = gw_load_zone      (fpZone, strzone);
        else if ( !str_cmp( word, "MOBILES" ) )  gw_load_mobiles   (fpZone);
        else if ( !str_cmp( word, "OBJECTS" ) )  gw_load_objects   (fpZone);
        else if ( !str_cmp( word, "ROOMS"  ) )   gw_load_rooms     (fpZone);
        else if ( !str_cmp( word, "RESETS"  ) )  gw_load_resets    (fpZone);
        else if ( !str_cmp( word, "SHOPS"  ) )   gw_load_shops    (fpZone);
        else if ( !str_cmp( word, "SPECIALS" ) ) gw_load_specials  (fpZone);
                else
                {
                    bug( "Boot_db: bad section name %s.", word );
                    exit( 1 );
                }
            }
           if ( fpZone != stdin )
               fclose( fpZone );
           save_zone( pZone );
           fpZone = NULL;
       }

   }
};



ZONE_DATA *gw_load_zone( FILE *fp, char *strArea )
{
    ZONE_DATA *pArea;
    char      *word;
    bool      fMatch;

    pArea               = new_zone();
    pArea->age          = 15;
    pArea->nplayer      = 0;
    pArea->filename     = str_dup( strArea );
    pArea->vnum         = top_zone;
    pArea->name         = str_dup( "New Area" );
    pArea->builders     = str_dup( "" );
/*    pArea->repop        = str_dup( "Tock.\n\r" ); */
    pArea->security     = 1;
    pArea->lvnum        = 0;
    pArea->uvnum        = 0;
    pArea->zone_flags   = 0;

    for ( ; ; )
    {
       word   = feof( fp ) ? "End" : fread_word( fp );
       fMatch = FALSE;

       switch ( UPPER(word[0]) )
       {
           case 'N':
            SKEY( "Name", pArea->name );
            break;
           case 'S':
             KEY( "Security", pArea->security, fread_number( fp ) );
            break;
           case 'V':
            if ( !str_cmp( word, "VNUMs" ) )
            {
                pArea->lvnum = fread_number( fp );
                pArea->uvnum = fread_number( fp );
            }
            break;
           case 'E':
             if ( !str_cmp( word, "End" ) )
             {
                 fMatch = TRUE;
                 if ( zone_first == NULL )
                    zone_first = pArea;
                 if ( zone_last  != NULL )
                    zone_last->next = pArea;
                 zone_last   = pArea;
                 pArea->next = NULL;
                 top_zone++;
                 return pArea;
            }
            break;
           case 'B':
            SKEY( "Builders", pArea->builders );
            break;
           case 'R':
/*            SKEY( "Repop",  pArea->repop ); */
            if ( !str_cmp( word, "Reset" ) )
            {
                fread_to_eol( fp );
                fMatch = TRUE;
            }
            break;
       }
    }

}



/*
 * Sets vnum range for zone using OLC protection features.
 */
void assign_zone_vnum( int vnum )
{
    if ( zone_last->lvnum == 0 || zone_last->uvnum == 0 )
	zone_last->lvnum = zone_last->uvnum = vnum;
    if ( vnum != URANGE( zone_last->lvnum, vnum, zone_last->uvnum ) )
	if ( vnum < zone_last->lvnum )
	    zone_last->lvnum = vnum;
	else
	    zone_last->uvnum = vnum;
    return;
}


/*
 * Snarf a mob section.
 */
void gw_load_mobiles( FILE *fp )
{
    ACTOR_INDEX_DATA *pMobIndex;

    if ( zone_last == NULL )	/* OLC */
    {
	bug( "Load_mobiles: no #AREA seen yet.", 0 );
	exit( 1 );
    }
    for ( ; ; )
    {
	sh_int vnum;
	char letter;
	int iHash;

	letter				= fread_letter( fp );
	if ( letter != '#' )
	{
	    bug( "Load_mobiles: # not found.", 0 );
	    exit( 1 );
	}

	vnum				= fread_number( fp );
	if ( vnum == 0 )
	    break;
        vnum += 15000;

	fBootDb = FALSE;
	if ( get_actor_index( vnum ) != NULL )
	{
	    bug( "Load_mobiles: vnum %d duplicated.", vnum );
	    exit( 1 );
	}
	fBootDb = TRUE;

	pMobIndex			= new_actor_index();
	pMobIndex->vnum			= vnum;
	pMobIndex->zone			= zone_last;	/* OLC */
	pMobIndex->name			= fread_string( fp );
	pMobIndex->short_descr		= fread_string( fp );
	pMobIndex->long_descr		= fread_string( fp );
	pMobIndex->description		= fread_string( fp );

	pMobIndex->long_descr[0]	= UPPER(pMobIndex->long_descr[0]);
	pMobIndex->description[0]	= UPPER(pMobIndex->description[0]);

	pMobIndex->act			= fread_number( fp ) | ACT_IS_NPC;
	pMobIndex->bonuses		= fread_number( fp );
	pMobIndex->pShop		= NULL;
	pMobIndex->karma		= fread_number( fp );
	letter				= fread_letter( fp );
	pMobIndex->exp			= number_fuzzy( fread_number( fp ) );

	/*
	 * The unused stuff is for imps who want to use the old-style
	 * stats-in-files method.
	 */
	fread_number( fp );	/* Unused */
	fread_number( fp );	/* Unused */
	fread_number( fp );	/* Unused */
	/* 'd'		*/		  fread_letter( fp );	/* Unused */
 fread_number( fp );	/* Unused */
	/* '+'		*/		  fread_letter( fp );	/* Unused */
fread_number( fp );	/* Unused */
 fread_number( fp );	/* Unused */
	/* 'd'		*/		  fread_letter( fp );	/* Unused */
fread_number( fp );	/* Unused */
	/* '+'		*/		  fread_letter( fp );	/* Unused */
 fread_number( fp );	/* Unused */
fread_number( fp );	/* Unused */
	/* xp can't be used! */		  fread_number( fp );	/* Unused */
	/* position	*/		  fread_number( fp );	/* Unused */
	/* start pos	*/		  fread_number( fp );	/* Unused */

	/*
	 * Back to meaningful values.
	 */
	pMobIndex->sex			= fread_number( fp );

	if ( letter != 'S' )
	{
	    bug( "Load_mobiles: vnum %d non-S.", vnum );
	    exit( 1 );
	}

	iHash			= vnum % MAX_KEY_HASH;
	pMobIndex->next		= actor_index_hash[iHash];
	actor_index_hash[iHash]	= pMobIndex;
	top_actor_index++;
	top_vnum_actor = top_vnum_actor < vnum ? vnum : top_vnum_actor; /* OLC */
	assign_zone_vnum( vnum );	/* OLC */
    }

    return;
}



/*
 * Snarf an obj section.
 */
void gw_load_objects( FILE *fp )
{
    PROP_INDEX_DATA *pObjIndex;

    if ( zone_last == NULL )	/* OLC */
    {
	bug( "Load_objects: no #AREA seen yet.", 0 );
	exit( 1 );
    }
    for ( ; ; )
    {
	sh_int vnum;
	char letter;
	int iHash;

	letter				= fread_letter( fp );
	if ( letter != '#' )
	{
	    bug( "Load_objects: # not found.", 0 );
	    exit( 1 );
	}

	vnum				= fread_number( fp );
	if ( vnum == 0 )
	    break;
        vnum += 15000;

	fBootDb = FALSE;
	if ( get_prop_index( vnum ) != NULL )
	{
	    bug( "Load_objects: vnum %d duplicated.", vnum );
	    exit( 1 );
	}
	fBootDb = TRUE;

	pObjIndex			= new_prop_index();
	pObjIndex->vnum			= vnum;
	pObjIndex->zone			= zone_last;	/* OLC */
	pObjIndex->name			= fread_string( fp );
	pObjIndex->short_descr		= fread_string( fp );
	pObjIndex->description		= fread_string( fp );
	/* Action description */	  fread_string( fp );

	pObjIndex->short_descr[0]	= LOWER(pObjIndex->short_descr[0]);
	pObjIndex->description[0]	= UPPER(pObjIndex->description[0]);

	pObjIndex->item_type		= fread_number( fp );
	pObjIndex->extra_flags		= fread_number( fp );
	pObjIndex->wear_flags		= fread_number( fp );

	pObjIndex->value[0]		= fread_number( fp );
	pObjIndex->value[1]		= fread_number( fp );
	pObjIndex->value[2]		= fread_number( fp );
	pObjIndex->value[3]		= fread_number( fp );

	pObjIndex->weight		= fread_number( fp );
	pObjIndex->cost			= fread_number( fp );	/* Unused */
	/* Cost per day */		  fread_number( fp );

	for ( ; ; )
	{
	    char letter;

	    letter = fread_letter( fp );

	    if ( letter == 'A' )
	    {
		BONUS_DATA *paf;

		paf			= new_bonus();
		paf->type		= -1;
		paf->duration		= -1;
		paf->location		= fread_number( fp );
		paf->modifier		= fread_number( fp );
		paf->bitvector		= 0;
	    }

	    else if ( letter == 'E' )
	    {
		EXTRA_DESCR_DATA *ed;

		ed			= new_extra_descr();
		ed->keyword		= fread_string( fp );
		ed->description		= fread_string( fp );
		ed->next		= pObjIndex->extra_descr;
		pObjIndex->extra_descr	= ed;
		top_ed++;
	    }

	    else if ( letter == 'Q' )
	    {
		fread_string( fp );
		fread_string( fp );
		fread_string( fp );
		fread_string( fp );
		fread_string( fp );
		fread_string( fp );
		fread_number( fp );
		fread_number( fp );
	    }

	    else
	    {
		ungetc( letter, fp );
		break;
	    }
	}

	iHash			= vnum % MAX_KEY_HASH;
	pObjIndex->next		= prop_index_hash[iHash];
	prop_index_hash[iHash]	= pObjIndex;
	top_prop_index++;
	top_vnum_prop = top_vnum_prop < vnum ? vnum : top_vnum_prop; /* OLC */
	assign_zone_vnum( vnum );	/* OLC */
    }

    return;
}



/*
 * Snarf a spawn section.
 */
void gw_load_resets( FILE *fp )	/* OLC */
{
    SPAWN_DATA *pReset = NULL;
    SCENE_INDEX_DATA *pScene;
    int mvn = 0;

    if ( zone_last == NULL )
    {
	bug( "Load_spawns: no #AREA seen yet.", 0 );
	exit( 1 );
    }

    for ( ; ; )
    {
	char             letter;
	int arg1, arg2, arg3;

	if ( ( letter = fread_letter( fp ) ) == 'S' )
	    break;

	if ( letter == '*' )
	{
	    fread_to_eol( fp );
	    continue;
	}

	/* if_flag */	  fread_number( fp );
	arg1	= fread_number( fp );
	arg2	= fread_number( fp );
	arg3	= (letter == 'G' || letter == 'R')
			    ? 0 : fread_number( fp );
			  fread_to_eol( fp );

	/*
	 * Validate parameters.
	 * We're calling the index functions for the side effect.
	 */
	switch ( letter )
	{
	default:
	    bug( "Load_spawns: bad command '%c'.", letter );
	    exit( 1 );
	    break;

	case 'M':

 
            arg1 += 15000;
            arg3 += 15000;
	    get_actor_index  ( arg1 );
	    pScene = get_scene_index ( arg3 );

	    pReset		= new_spawn_data();
	    pReset->rs_vnum	= arg1;
	    pReset->loc	= arg2;
            pReset->percent = 100;
	    pReset->command	= letter;
            pReset->num = -1;
	    mvn = arg3;

                   if ( pScene->spawn_first == NULL )
                        pScene->spawn_first  = pReset;
                   if ( pScene->spawn_last  != NULL )
                        pScene->spawn_last->next = pReset;
                   top_spawn++;

	    break;

	case 'O':
            arg1 += 15000;
            arg3 += 15000;
	    get_prop_index  ( arg1 );
	    pScene = get_scene_index ( arg3 );

	    pReset		= new_spawn_data();
	    pReset->rs_vnum	= arg1;
	    pReset->loc	= arg2;
	    pReset->percent	= 100;
            pReset->num         = -1;
	    pReset->command	= letter;

                 if ( pScene->spawn_first == NULL )
                      pScene->spawn_first  = pReset;
                 if ( pScene->spawn_last  != NULL )
                      pScene->spawn_last->next = pReset;
                 top_spawn++;

	    break;

	case 'P':

	    break;

	case 'G':
	case 'E':

	    break;

	case 'D':
	    break;

	case 'R':
	    break;
	}
    }

    return;
}



/*
 * Snarf a scene section.
 */
void gw_load_rooms( FILE *fp )
{
    SCENE_INDEX_DATA *pRoomIndex;

    if ( zone_last == NULL )
    {
	bug( "Load_spawns: no #AREA seen yet.", 0 );	/* OLC */
	exit( 1 );
    }

    for ( ; ; )
    {
	sh_int vnum;
	char letter;
	int door;
	int iHash;

	letter				= fread_letter( fp );
	if ( letter != '#' )
	{
	    bug( "Load_scenes: # not found.", 0 );
	    exit( 1 );
	}

	vnum				= fread_number( fp );
	if ( vnum == 0 )
	    break;
        vnum += 15000;

	fBootDb = FALSE;
	if ( get_scene_index( vnum ) != NULL )
	{
	    bug( "Load_scenes: vnum %d duplicated.", vnum );
	    exit( 1 );
	}
	fBootDb = TRUE;

	pRoomIndex			= new_scene_index();
	pRoomIndex->people		= NULL;
	pRoomIndex->contents		= NULL;
	pRoomIndex->extra_descr		= NULL;
	pRoomIndex->zone		= zone_last;
	pRoomIndex->vnum		= vnum;
	pRoomIndex->name		= fread_string( fp );
	pRoomIndex->description		= fread_string( fp );
	/* Area number */		  fread_number( fp );
	pRoomIndex->scene_flags		= fread_number( fp );
	pRoomIndex->sector_type		= fread_number( fp );
	pRoomIndex->light		= 0;
	for ( door = 0; door <= 5; door++ )
	    pRoomIndex->exit[door] = NULL;

	for ( ; ; )
	{
	    letter = fread_letter( fp );

	    if ( letter == 'S' )
		break;

	    if ( letter == 'D' )
	    {
		EXIT_DATA *pexit;
		int locks;

		door = fread_number( fp );
		if ( door < 0 || door > 5 )
		{
		    bug( "Fread_scenes: vnum %d has bad door number.", vnum );
		    exit( 1 );
		}

		pexit			= alloc_perm( sizeof(*pexit) );
		pexit->description	= fread_string( fp );
		pexit->keyword		= fread_string( fp );
		pexit->exit_info	= 0;
		pexit->rs_flags		= 0;	/* OLC */
		locks			= fread_number( fp );
		pexit->key		= fread_number( fp );
		pexit->vnum		= fread_number( fp )+15000;

		switch ( locks )
		{
		case 1: pexit->exit_info = EX_ISDOOR;                break;
		case 2: pexit->exit_info = EX_ISDOOR | EX_PICKPROOF; break;
		}

		pRoomIndex->exit[door]	= pexit;
		top_exit++;
	    }
	    else if ( letter == 'E' )
	    {
		EXTRA_DESCR_DATA *ed;

		ed			= alloc_perm( sizeof(*ed) );
		ed->keyword		= fread_string( fp );
		ed->description		= fread_string( fp );
		ed->next		= pRoomIndex->extra_descr;
		pRoomIndex->extra_descr	= ed;
		top_ed++;
	    }
	    else if ( letter == 'T' )
	    {
		fread_string( fp );
		fread_string( fp );
		fread_string( fp );
		fread_string( fp );
		fread_number( fp );
		fread_number( fp );
	fread_number( fp );
	    }
	    else
	    {
		bug( "Load_scenes: vnum %d has flag not 'DES'.", vnum );
		exit( 1 );
	    }
	}

	iHash			= vnum % MAX_KEY_HASH;
	pRoomIndex->next	= scene_index_hash[iHash];
	scene_index_hash[iHash]	= pRoomIndex;
	top_scene++;
	top_vnum_scene = top_vnum_scene < vnum ? vnum : top_vnum_scene; /* OLC */
	assign_zone_vnum( vnum );	/* OLC */
    }

    return;
}



/*
 * Snarf a shop section.
 */
void gw_load_shops( FILE *fp )
{
    SHOP_DATA *pShop;

    for ( ; ; )
    {
	ACTOR_INDEX_DATA *pMobIndex;
	int iTrade;

	pShop			= alloc_perm( sizeof(*pShop) );
	pShop->keeper		= fread_number( fp );

	if ( pShop->keeper == 0 )
	    break;
        pShop->keeper += 15000;

	for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
	    pShop->buy_type[iTrade]	= fread_number( fp );
	pShop->profit_buy	= fread_number( fp );
	pShop->profit_sell	= fread_number( fp );
	pShop->open_hour	= fread_number( fp );
	pShop->close_hour	= fread_number( fp );
				  fread_to_eol( fp );
	pMobIndex		= get_actor_index( pShop->keeper );
	pMobIndex->pShop	= pShop;

	if ( shop_first == NULL )
	    shop_first = pShop;
	if ( shop_last  != NULL )
	    shop_last->next = pShop;

	shop_last	= pShop;
	pShop->next	= NULL;
	top_shop++;
    }

    return;
}



/*
 * Snarf spec proc declarations.
 */
void gw_load_specials( FILE *fp )
{
    for ( ; ; )
    {
	char letter;

	switch ( letter = fread_letter( fp ) )
	{
	default:
	    bug( "Load_specials: letter '%c' not *MS.", letter );
	    exit( 1 );

	case 'S':
	    return;

	case '*':
	    break;

	case 'M':
	    fread_number ( fp );
	    fread_word ( fp ); /* OLC */
	    break;
	}

	fread_to_eol( fp );
    }
}




