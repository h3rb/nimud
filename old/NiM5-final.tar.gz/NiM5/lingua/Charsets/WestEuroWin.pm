# vi: ts=4 sw=4 sts=4

package Charsets::WestEuroWin;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw();
$VERSION	= 0.00;

# Character set Windows Western European code page 1252

my (%_from_utf8, %_to_utf8);

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

# Catalan '�' is included but what about '-' and the apostrophe?
sub letters {
	return '[' . 'A-Z�����-��-�' . 'a-z�����-��-�' . '�' . '�' . ']';
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z�����-��-�/a-z�����-��-�/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z�����-��-�/A-Z�����-��-�/;

	return $str;
}

sub to_utf8 {
	my ($self, $input) = @_;
	my $output = '';

	while ($input =~ /(.|\r|\n)/g) {
		my $c = $1;
		my $o = ord($c);
		my $u = $_to_utf8{$o};
		$output .= $u ? $u : $c;
	}
	return $output;
}

sub from_utf8 {
	my ($self, $input) = @_;
	my $output = '';
	my $state = 0;
	my $len;
	my $u;

	while ($input =~ /(.|\r|\n)/g) {
		my $c = $1;
		my $o = ord($c);
		if ($state == 0) {
			if ($o >= 0xfe) {
				# Invalid initial byte
				$output .= '?';
			} elsif ($o >= 0xc0) {
				$state = 1;
				if ($o >= 0xfc) {
					$len = 6;
				} elsif ($o >= 0xf8) {
					$len = 5;
				} elsif ($o >= 0xf0) {
					$len = 4;
				} elsif ($o >= 0xe0) {
					$len = 3;
				} else {
					$len = 2;
				}
				$u = $o & ((1 << (7 - $len)) - 1);
			} else {
				$output .= $c;
			}
		} else {
			if (($o & 0xc0) != 0x80) {
				# Invalid trailing byte
				$output .= '?';
				$state = 0;
			} else {
				$u <<= 6;
				$u += ($o & 0x3f);
				--$len;
				if ($len <= 1) {
					$state = 0;
					my $a = $_from_utf8{$u};
					if ($a) {
						$output .= chr($a);
					} else {
						$output .= '?';
					}
				}
			}
		}
	}
	return $output;
}

sub BEGIN {
	$_from_utf8{0x20AC} = 0x80;
	$_from_utf8{0x201A} = 0x82;
	$_from_utf8{0x0192} = 0x83;
	$_from_utf8{0x201E} = 0x84;
	$_from_utf8{0x2026} = 0x85;
	$_from_utf8{0x2020} = 0x86;
	$_from_utf8{0x2021} = 0x87;
	$_from_utf8{0x02C6} = 0x88;
	$_from_utf8{0x2030} = 0x89;
	$_from_utf8{0x0160} = 0x8A;
	$_from_utf8{0x2039} = 0x8B;
	$_from_utf8{0x0152} = 0x8C;
	$_from_utf8{0x017D} = 0x8E;
	$_from_utf8{0x2018} = 0x91;
	$_from_utf8{0x2019} = 0x92;
	$_from_utf8{0x201C} = 0x93;
	$_from_utf8{0x201D} = 0x94;
	$_from_utf8{0x2022} = 0x95;
	$_from_utf8{0x2013} = 0x96;
	$_from_utf8{0x2014} = 0x97;
	$_from_utf8{0x02DC} = 0x98;
	$_from_utf8{0x2122} = 0x99;
	$_from_utf8{0x0161} = 0x9A;
	$_from_utf8{0x203A} = 0x9B;
	$_from_utf8{0x0153} = 0x9C;
	$_from_utf8{0x017E} = 0x9E;
	$_from_utf8{0x0178} = 0x9F;
	$_from_utf8{0x00A0} = 0xA0;
	$_from_utf8{0x00A1} = 0xA1;
	$_from_utf8{0x00A2} = 0xA2;
	$_from_utf8{0x00A3} = 0xA3;
	$_from_utf8{0x00A4} = 0xA4;
	$_from_utf8{0x00A5} = 0xA5;
	$_from_utf8{0x00A6} = 0xA6;
	$_from_utf8{0x00A7} = 0xA7;
	$_from_utf8{0x00A8} = 0xA8;
	$_from_utf8{0x00A9} = 0xA9;
	$_from_utf8{0x00AA} = 0xAA;
	$_from_utf8{0x00AB} = 0xAB;
	$_from_utf8{0x00AC} = 0xAC;
	$_from_utf8{0x00AD} = 0xAD;
	$_from_utf8{0x00AE} = 0xAE;
	$_from_utf8{0x00AF} = 0xAF;
	$_from_utf8{0x00B0} = 0xB0;
	$_from_utf8{0x00B1} = 0xB1;
	$_from_utf8{0x00B2} = 0xB2;
	$_from_utf8{0x00B3} = 0xB3;
	$_from_utf8{0x00B4} = 0xB4;
	$_from_utf8{0x00B5} = 0xB5;
	$_from_utf8{0x00B6} = 0xB6;
	$_from_utf8{0x00B7} = 0xB7;
	$_from_utf8{0x00B8} = 0xB8;
	$_from_utf8{0x00B9} = 0xB9;
	$_from_utf8{0x00BA} = 0xBA;
	$_from_utf8{0x00BB} = 0xBB;
	$_from_utf8{0x00BC} = 0xBC;
	$_from_utf8{0x00BD} = 0xBD;
	$_from_utf8{0x00BE} = 0xBE;
	$_from_utf8{0x00BF} = 0xBF;
	$_from_utf8{0x00C0} = 0xC0;
	$_from_utf8{0x00C1} = 0xC1;
	$_from_utf8{0x00C2} = 0xC2;
	$_from_utf8{0x00C3} = 0xC3;
	$_from_utf8{0x00C4} = 0xC4;
	$_from_utf8{0x00C5} = 0xC5;
	$_from_utf8{0x00C6} = 0xC6;
	$_from_utf8{0x00C7} = 0xC7;
	$_from_utf8{0x00C8} = 0xC8;
	$_from_utf8{0x00C9} = 0xC9;
	$_from_utf8{0x00CA} = 0xCA;
	$_from_utf8{0x00CB} = 0xCB;
	$_from_utf8{0x00CC} = 0xCC;
	$_from_utf8{0x00CD} = 0xCD;
	$_from_utf8{0x00CE} = 0xCE;
	$_from_utf8{0x00CF} = 0xCF;
	$_from_utf8{0x00D0} = 0xD0;
	$_from_utf8{0x00D1} = 0xD1;
	$_from_utf8{0x00D2} = 0xD2;
	$_from_utf8{0x00D3} = 0xD3;
	$_from_utf8{0x00D4} = 0xD4;
	$_from_utf8{0x00D5} = 0xD5;
	$_from_utf8{0x00D6} = 0xD6;
	$_from_utf8{0x00D7} = 0xD7;
	$_from_utf8{0x00D8} = 0xD8;
	$_from_utf8{0x00D9} = 0xD9;
	$_from_utf8{0x00DA} = 0xDA;
	$_from_utf8{0x00DB} = 0xDB;
	$_from_utf8{0x00DC} = 0xDC;
	$_from_utf8{0x00DD} = 0xDD;
	$_from_utf8{0x00DE} = 0xDE;
	$_from_utf8{0x00DF} = 0xDF;
	$_from_utf8{0x00E0} = 0xE0;
	$_from_utf8{0x00E1} = 0xE1;
	$_from_utf8{0x00E2} = 0xE2;
	$_from_utf8{0x00E3} = 0xE3;
	$_from_utf8{0x00E4} = 0xE4;
	$_from_utf8{0x00E5} = 0xE5;
	$_from_utf8{0x00E6} = 0xE6;
	$_from_utf8{0x00E7} = 0xE7;
	$_from_utf8{0x00E8} = 0xE8;
	$_from_utf8{0x00E9} = 0xE9;
	$_from_utf8{0x00EA} = 0xEA;
	$_from_utf8{0x00EB} = 0xEB;
	$_from_utf8{0x00EC} = 0xEC;
	$_from_utf8{0x00ED} = 0xED;
	$_from_utf8{0x00EE} = 0xEE;
	$_from_utf8{0x00EF} = 0xEF;
	$_from_utf8{0x00F0} = 0xF0;
	$_from_utf8{0x00F1} = 0xF1;
	$_from_utf8{0x00F2} = 0xF2;
	$_from_utf8{0x00F3} = 0xF3;
	$_from_utf8{0x00F4} = 0xF4;
	$_from_utf8{0x00F5} = 0xF5;
	$_from_utf8{0x00F6} = 0xF6;
	$_from_utf8{0x00F7} = 0xF7;
	$_from_utf8{0x00F8} = 0xF8;
	$_from_utf8{0x00F9} = 0xF9;
	$_from_utf8{0x00FA} = 0xFA;
	$_from_utf8{0x00FB} = 0xFB;
	$_from_utf8{0x00FC} = 0xFC;
	$_from_utf8{0x00FD} = 0xFD;
	$_from_utf8{0x00FE} = 0xFE;
	$_from_utf8{0x00FF} = 0xFF;
	$_to_utf8{0x80} = '€';
	$_to_utf8{0x82} = '‚';
	$_to_utf8{0x83} = 'ƒ';
	$_to_utf8{0x84} = '„';
	$_to_utf8{0x85} = '…';
	$_to_utf8{0x86} = '†';
	$_to_utf8{0x87} = '‡';
	$_to_utf8{0x88} = 'ˆ';
	$_to_utf8{0x89} = '‰';
	$_to_utf8{0x8A} = 'Š';
	$_to_utf8{0x8B} = '‹';
	$_to_utf8{0x8C} = 'Œ';
	$_to_utf8{0x8E} = 'Ž';
	$_to_utf8{0x91} = '‘';
	$_to_utf8{0x92} = '’';
	$_to_utf8{0x93} = '“';
	$_to_utf8{0x94} = '”';
	$_to_utf8{0x95} = '•';
	$_to_utf8{0x96} = '–';
	$_to_utf8{0x97} = '—';
	$_to_utf8{0x98} = '˜';
	$_to_utf8{0x99} = '™';
	$_to_utf8{0x9A} = 'š';
	$_to_utf8{0x9B} = '›';
	$_to_utf8{0x9C} = 'œ';
	$_to_utf8{0x9E} = 'ž';
	$_to_utf8{0x9F} = 'Ÿ';
	$_to_utf8{0xA0} = ' ';
	$_to_utf8{0xA1} = '¡';
	$_to_utf8{0xA2} = '¢';
	$_to_utf8{0xA3} = '£';
	$_to_utf8{0xA4} = '¤';
	$_to_utf8{0xA5} = '¥';
	$_to_utf8{0xA6} = '¦';
	$_to_utf8{0xA7} = '§';
	$_to_utf8{0xA8} = '¨';
	$_to_utf8{0xA9} = '©';
	$_to_utf8{0xAA} = 'ª';
	$_to_utf8{0xAB} = '«';
	$_to_utf8{0xAC} = '¬';
	$_to_utf8{0xAD} = ' ';
	$_to_utf8{0xAE} = '®';
	$_to_utf8{0xAF} = '¯';
	$_to_utf8{0xB0} = '°';
	$_to_utf8{0xB1} = '±';
	$_to_utf8{0xB2} = '²';
	$_to_utf8{0xB3} = '³';
	$_to_utf8{0xB4} = '´';
	$_to_utf8{0xB5} = 'µ';
	$_to_utf8{0xB6} = '¶';
	$_to_utf8{0xB7} = '·';
	$_to_utf8{0xB8} = '¸';
	$_to_utf8{0xB9} = '¹';
	$_to_utf8{0xBA} = 'º';
	$_to_utf8{0xBB} = '»';
	$_to_utf8{0xBC} = '¼';
	$_to_utf8{0xBD} = '½';
	$_to_utf8{0xBE} = '¾';
	$_to_utf8{0xBF} = '¿';
	$_to_utf8{0xC0} = 'À';
	$_to_utf8{0xC1} = 'Á';
	$_to_utf8{0xC2} = 'Â';
	$_to_utf8{0xC3} = 'Ã';
	$_to_utf8{0xC4} = 'Ä';
	$_to_utf8{0xC5} = 'Å';
	$_to_utf8{0xC6} = 'Æ';
	$_to_utf8{0xC7} = 'Ç';
	$_to_utf8{0xC8} = 'È';
	$_to_utf8{0xC9} = 'É';
	$_to_utf8{0xCA} = 'Ê';
	$_to_utf8{0xCB} = 'Ë';
	$_to_utf8{0xCC} = 'Ì';
	$_to_utf8{0xCD} = 'Í';
	$_to_utf8{0xCE} = 'Î';
	$_to_utf8{0xCF} = 'Ï';
	$_to_utf8{0xD0} = 'Ð';
	$_to_utf8{0xD1} = 'Ñ';
	$_to_utf8{0xD2} = 'Ò';
	$_to_utf8{0xD3} = 'Ó';
	$_to_utf8{0xD4} = 'Ô';
	$_to_utf8{0xD5} = 'Õ';
	$_to_utf8{0xD6} = 'Ö';
	$_to_utf8{0xD7} = '×';
	$_to_utf8{0xD8} = 'Ø';
	$_to_utf8{0xD9} = 'Ù';
	$_to_utf8{0xDA} = 'Ú';
	$_to_utf8{0xDB} = 'Û';
	$_to_utf8{0xDC} = 'Ü';
	$_to_utf8{0xDD} = 'Ý';
	$_to_utf8{0xDE} = 'Þ';
	$_to_utf8{0xDF} = 'ß';
	$_to_utf8{0xE0} = 'à';
	$_to_utf8{0xE1} = 'á';
	$_to_utf8{0xE2} = 'â';
	$_to_utf8{0xE3} = 'ã';
	$_to_utf8{0xE4} = 'ä';
	$_to_utf8{0xE5} = 'å';
	$_to_utf8{0xE6} = 'æ';
	$_to_utf8{0xE7} = 'ç';
	$_to_utf8{0xE8} = 'è';
	$_to_utf8{0xE9} = 'é';
	$_to_utf8{0xEA} = 'ê';
	$_to_utf8{0xEB} = 'ë';
	$_to_utf8{0xEC} = 'ì';
	$_to_utf8{0xED} = 'í';
	$_to_utf8{0xEE} = 'î';
	$_to_utf8{0xEF} = 'ï';
	$_to_utf8{0xF0} = 'ð';
	$_to_utf8{0xF1} = 'ñ';
	$_to_utf8{0xF2} = 'ò';
	$_to_utf8{0xF3} = 'ó';
	$_to_utf8{0xF4} = 'ô';
	$_to_utf8{0xF5} = 'õ';
	$_to_utf8{0xF6} = 'ö';
	$_to_utf8{0xF7} = '÷';
	$_to_utf8{0xF8} = 'ø';
	$_to_utf8{0xF9} = 'ù';
	$_to_utf8{0xFA} = 'ú';
	$_to_utf8{0xFB} = 'û';
	$_to_utf8{0xFC} = 'ü';
	$_to_utf8{0xFD} = 'ý';
	$_to_utf8{0xFE} = 'þ';
	$_to_utf8{0xFF} = 'ÿ';
}

1;
