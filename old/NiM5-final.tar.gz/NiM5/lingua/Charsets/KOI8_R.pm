# vi: ts=4 sw=4

package Charsets::KOI8_R;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw(letters_upper letters_lower);
$VERSION	= 0.00;

# Character set KOI8-R

my $upper = "A-Z\xb3\xe0-\xff";
my $lower = "a-z\xa3\xc0-\xdf";

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters_upper {
	return '[' . $upper . ']';
}

sub letters_lower {
	return '[' . $lower . ']';
}

sub letters {
	return '[' . $upper . $lower . ']';
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z\xb3\xe0-\xff/a-z\xa3\xc0-\xdf/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z\xa3\xc0-\xdf/A-Z\xb3\xe0-\xff/;

	return $str;
}

sub BEGIN {
}

1;
