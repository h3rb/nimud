# vi: ts=4 sw=4

package Charsets::CyrillicWin;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw(letters_upper letters_lower);
$VERSION	= 0.00;

# Character set Window Cyrillic Code Page 1251

my $upper = "A-Z\x80\x81\x8a\x8c-\x8f\xa1\xa3\x85\xa8\xaa\xaf\xb2\xbd\xc0-\xdf";
my $lower = "a-z\x90\x83\x9a\x9c-\x9f\xa2\xbc\xb4\xb8\xba\xbf\xb3\xbe\xe0-\xff";

my (%_from_utf8, %_to_utf8);

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters_upper {
	return '[' .$upper . ']';
}

sub letters_lower {
	return '[' . $lower . ']';
}

sub letters {
	return '[' . $upper . $lower . ']';
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z\x80\x81\x8a\x8c-\x8f\xa1\xa3\x85\xa8\xaa\xaf\xb2\xbd\xc0-\xdf/a-z\x90\x83\x9a\x9c-\x9f\xa2\xbc\xb4\xb8\xba\xbf\xb3\xbe\xe0-\xff/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z\x90\x83\x9a\x9c-\x9f\xa2\xbc\xb4\xb8\xba\xbf\xb3\xbe\xe0-\xff/A-Z\x80\x81\x8a\x8c-\x8f\xa1\xa3\x85\xa8\xaa\xaf\xb2\xbd\xc0-\xdf/;

	return $str;
}

sub to_utf8 {
	my ($self, $input) = @_;
	my $output = '';

	while ($input =~ /(.|\r|\n)/g) {
		my $c = $1;
		my $o = ord($c);
		my $u = $_to_utf8{$o};
		$output .= $u ? $u : $c;
	}
	return $output;
}

sub from_utf8 {
	my ($self, $input) = @_;
	my $output = '';
	my $state = 0;
	my $len;
	my $u;

	while ($input =~ /(.|\r|\n)/g) {
		my $c = $1;
		my $o = ord($c);
		if ($state == 0) {
			if ($o >= 0xc0) {
				$state = 1;
				if ($o >= 0xfe) {
					die "** Invalid initial byte\n";
				} elsif ($o >= 0xfc) {
					$len = 6;
				} elsif ($o >= 0xf8) {
					$len = 5;
				} elsif ($o >= 0xf0) {
					$len = 4;
				} elsif ($o >= 0xe0) {
					$len = 3;
				} else {
					$len = 2;
				}
				$u = $o & ((1 << (7 - $len)) - 1);
			} else {
				$output .= $c;
			}
		} else {
			if (($o & 0xc0) != 0x80) {
				$output .= '?';
			} else {
				$u <<= 6;
				$u += ($o & 0x3f);
				--$len;
				if ($len <= 1) {
					$state = 0;
					my $a = $_from_utf8{$u};
					if ($a) {
						$output .= chr($a);
					} else {
						$output .= '?';
					}
				}
			}
		}
	}
	return $output;
}

sub BEGIN {
	$_from_utf8{0x0402} = 0x80;
	$_from_utf8{0x0403} = 0x81;
	$_from_utf8{0x201A} = 0x82;
	$_from_utf8{0x0453} = 0x83;
	$_from_utf8{0x201E} = 0x84;
	$_from_utf8{0x2026} = 0x85;
	$_from_utf8{0x2020} = 0x86;
	$_from_utf8{0x2021} = 0x87;
	$_from_utf8{0x20AC} = 0x88;
	$_from_utf8{0x2030} = 0x89;
	$_from_utf8{0x0409} = 0x8A;
	$_from_utf8{0x2039} = 0x8B;
	$_from_utf8{0x040A} = 0x8C;
	$_from_utf8{0x040C} = 0x8D;
	$_from_utf8{0x040B} = 0x8E;
	$_from_utf8{0x040F} = 0x8F;
	$_from_utf8{0x0452} = 0x90;
	$_from_utf8{0x2018} = 0x91;
	$_from_utf8{0x2019} = 0x92;
	$_from_utf8{0x201C} = 0x93;
	$_from_utf8{0x201D} = 0x94;
	$_from_utf8{0x2022} = 0x95;
	$_from_utf8{0x2013} = 0x96;
	$_from_utf8{0x2014} = 0x97;
	$_from_utf8{0x2122} = 0x99;
	$_from_utf8{0x0459} = 0x9A;
	$_from_utf8{0x203A} = 0x9B;
	$_from_utf8{0x045A} = 0x9C;
	$_from_utf8{0x045C} = 0x9D;
	$_from_utf8{0x045B} = 0x9E;
	$_from_utf8{0x045F} = 0x9F;
	$_from_utf8{0x00A0} = 0xA0;
	$_from_utf8{0x040E} = 0xA1;
	$_from_utf8{0x045E} = 0xA2;
	$_from_utf8{0x0408} = 0xA3;
	$_from_utf8{0x00A4} = 0xA4;
	$_from_utf8{0x0490} = 0xA5;
	$_from_utf8{0x00A6} = 0xA6;
	$_from_utf8{0x00A7} = 0xA7;
	$_from_utf8{0x0401} = 0xA8;
	$_from_utf8{0x00A9} = 0xA9;
	$_from_utf8{0x0404} = 0xAA;
	$_from_utf8{0x00AB} = 0xAB;
	$_from_utf8{0x00AC} = 0xAC;
	$_from_utf8{0x00AD} = 0xAD;
	$_from_utf8{0x00AE} = 0xAE;
	$_from_utf8{0x0407} = 0xAF;
	$_from_utf8{0x00B0} = 0xB0;
	$_from_utf8{0x00B1} = 0xB1;
	$_from_utf8{0x0406} = 0xB2;
	$_from_utf8{0x0456} = 0xB3;
	$_from_utf8{0x0491} = 0xB4;
	$_from_utf8{0x00B5} = 0xB5;
	$_from_utf8{0x00B6} = 0xB6;
	$_from_utf8{0x00B7} = 0xB7;
	$_from_utf8{0x0451} = 0xB8;
	$_from_utf8{0x2116} = 0xB9;
	$_from_utf8{0x0454} = 0xBA;
	$_from_utf8{0x00BB} = 0xBB;
	$_from_utf8{0x0458} = 0xBC;
	$_from_utf8{0x0405} = 0xBD;
	$_from_utf8{0x0455} = 0xBE;
	$_from_utf8{0x0457} = 0xBF;
	$_from_utf8{0x0410} = 0xC0;
	$_from_utf8{0x0411} = 0xC1;
	$_from_utf8{0x0412} = 0xC2;
	$_from_utf8{0x0413} = 0xC3;
	$_from_utf8{0x0414} = 0xC4;
	$_from_utf8{0x0415} = 0xC5;
	$_from_utf8{0x0416} = 0xC6;
	$_from_utf8{0x0417} = 0xC7;
	$_from_utf8{0x0418} = 0xC8;
	$_from_utf8{0x0419} = 0xC9;
	$_from_utf8{0x041A} = 0xCA;
	$_from_utf8{0x041B} = 0xCB;
	$_from_utf8{0x041C} = 0xCC;
	$_from_utf8{0x041D} = 0xCD;
	$_from_utf8{0x041E} = 0xCE;
	$_from_utf8{0x041F} = 0xCF;
	$_from_utf8{0x0420} = 0xD0;
	$_from_utf8{0x0421} = 0xD1;
	$_from_utf8{0x0422} = 0xD2;
	$_from_utf8{0x0423} = 0xD3;
	$_from_utf8{0x0424} = 0xD4;
	$_from_utf8{0x0425} = 0xD5;
	$_from_utf8{0x0426} = 0xD6;
	$_from_utf8{0x0427} = 0xD7;
	$_from_utf8{0x0428} = 0xD8;
	$_from_utf8{0x0429} = 0xD9;
	$_from_utf8{0x042A} = 0xDA;
	$_from_utf8{0x042B} = 0xDB;
	$_from_utf8{0x042C} = 0xDC;
	$_from_utf8{0x042D} = 0xDD;
	$_from_utf8{0x042E} = 0xDE;
	$_from_utf8{0x042F} = 0xDF;
	$_from_utf8{0x0430} = 0xE0;
	$_from_utf8{0x0431} = 0xE1;
	$_from_utf8{0x0432} = 0xE2;
	$_from_utf8{0x0433} = 0xE3;
	$_from_utf8{0x0434} = 0xE4;
	$_from_utf8{0x0435} = 0xE5;
	$_from_utf8{0x0436} = 0xE6;
	$_from_utf8{0x0437} = 0xE7;
	$_from_utf8{0x0438} = 0xE8;
	$_from_utf8{0x0439} = 0xE9;
	$_from_utf8{0x043A} = 0xEA;
	$_from_utf8{0x043B} = 0xEB;
	$_from_utf8{0x043C} = 0xEC;
	$_from_utf8{0x043D} = 0xED;
	$_from_utf8{0x043E} = 0xEE;
	$_from_utf8{0x043F} = 0xEF;
	$_from_utf8{0x0440} = 0xF0;
	$_from_utf8{0x0441} = 0xF1;
	$_from_utf8{0x0442} = 0xF2;
	$_from_utf8{0x0443} = 0xF3;
	$_from_utf8{0x0444} = 0xF4;
	$_from_utf8{0x0445} = 0xF5;
	$_from_utf8{0x0446} = 0xF6;
	$_from_utf8{0x0447} = 0xF7;
	$_from_utf8{0x0448} = 0xF8;
	$_from_utf8{0x0449} = 0xF9;
	$_from_utf8{0x044A} = 0xFA;
	$_from_utf8{0x044B} = 0xFB;
	$_from_utf8{0x044C} = 0xFC;
	$_from_utf8{0x044D} = 0xFD;
	$_from_utf8{0x044E} = 0xFE;
	$_from_utf8{0x044F} = 0xFF;
	$_to_utf8{0x80} = 'Ђ';
	$_to_utf8{0x81} = 'Ѓ';
	$_to_utf8{0x82} = '‚';
	$_to_utf8{0x83} = 'ѓ';
	$_to_utf8{0x84} = '„';
	$_to_utf8{0x85} = '…';
	$_to_utf8{0x86} = '†';
	$_to_utf8{0x87} = '‡';
	$_to_utf8{0x88} = '€';
	$_to_utf8{0x89} = '‰';
	$_to_utf8{0x8A} = 'Љ';
	$_to_utf8{0x8B} = '‹';
	$_to_utf8{0x8C} = 'Њ';
	$_to_utf8{0x8D} = 'Ќ';
	$_to_utf8{0x8E} = 'Ћ';
	$_to_utf8{0x8F} = 'Џ';
	$_to_utf8{0x90} = 'ђ';
	$_to_utf8{0x91} = '‘';
	$_to_utf8{0x92} = '’';
	$_to_utf8{0x93} = '“';
	$_to_utf8{0x94} = '”';
	$_to_utf8{0x95} = '•';
	$_to_utf8{0x96} = '–';
	$_to_utf8{0x97} = '—';
	$_to_utf8{0x99} = '™';
	$_to_utf8{0x9A} = 'љ';
	$_to_utf8{0x9B} = '›';
	$_to_utf8{0x9C} = 'њ';
	$_to_utf8{0x9D} = 'ќ';
	$_to_utf8{0x9E} = 'ћ';
	$_to_utf8{0x9F} = 'џ';
	$_to_utf8{0xA0} = ' ';
	$_to_utf8{0xA1} = 'Ў';
	$_to_utf8{0xA2} = 'ў';
	$_to_utf8{0xA3} = 'Ј';
	$_to_utf8{0xA4} = '¤';
	$_to_utf8{0xA5} = 'Ґ';
	$_to_utf8{0xA6} = '¦';
	$_to_utf8{0xA7} = '§';
	$_to_utf8{0xA8} = 'Ё';
	$_to_utf8{0xA9} = '©';
	$_to_utf8{0xAA} = 'Є';
	$_to_utf8{0xAB} = '«';
	$_to_utf8{0xAC} = '¬';
	$_to_utf8{0xAD} = ' ';
	$_to_utf8{0xAE} = '®';
	$_to_utf8{0xAF} = 'Ї';
	$_to_utf8{0xB0} = '°';
	$_to_utf8{0xB1} = '±';
	$_to_utf8{0xB2} = 'І';
	$_to_utf8{0xB3} = 'і';
	$_to_utf8{0xB4} = 'ґ';
	$_to_utf8{0xB5} = 'µ';
	$_to_utf8{0xB6} = '¶';
	$_to_utf8{0xB7} = '·';
	$_to_utf8{0xB8} = 'ё';
	$_to_utf8{0xB9} = '№';
	$_to_utf8{0xBA} = 'є';
	$_to_utf8{0xBB} = '»';
	$_to_utf8{0xBC} = 'ј';
	$_to_utf8{0xBD} = 'Ѕ';
	$_to_utf8{0xBE} = 'ѕ';
	$_to_utf8{0xBF} = 'ї';
	$_to_utf8{0xC0} = 'А';
	$_to_utf8{0xC1} = 'Б';
	$_to_utf8{0xC2} = 'В';
	$_to_utf8{0xC3} = 'Г';
	$_to_utf8{0xC4} = 'Д';
	$_to_utf8{0xC5} = 'Е';
	$_to_utf8{0xC6} = 'Ж';
	$_to_utf8{0xC7} = 'З';
	$_to_utf8{0xC8} = 'И';
	$_to_utf8{0xC9} = 'Й';
	$_to_utf8{0xCA} = 'К';
	$_to_utf8{0xCB} = 'Л';
	$_to_utf8{0xCC} = 'М';
	$_to_utf8{0xCD} = 'Н';
	$_to_utf8{0xCE} = 'О';
	$_to_utf8{0xCF} = 'П';
	$_to_utf8{0xD0} = 'Р';
	$_to_utf8{0xD1} = 'С';
	$_to_utf8{0xD2} = 'Т';
	$_to_utf8{0xD3} = 'У';
	$_to_utf8{0xD4} = 'Ф';
	$_to_utf8{0xD5} = 'Х';
	$_to_utf8{0xD6} = 'Ц';
	$_to_utf8{0xD7} = 'Ч';
	$_to_utf8{0xD8} = 'Ш';
	$_to_utf8{0xD9} = 'Щ';
	$_to_utf8{0xDA} = 'Ъ';
	$_to_utf8{0xDB} = 'Ы';
	$_to_utf8{0xDC} = 'Ь';
	$_to_utf8{0xDD} = 'Э';
	$_to_utf8{0xDE} = 'Ю';
	$_to_utf8{0xDF} = 'Я';
	$_to_utf8{0xE0} = 'а';
	$_to_utf8{0xE1} = 'б';
	$_to_utf8{0xE2} = 'в';
	$_to_utf8{0xE3} = 'г';
	$_to_utf8{0xE4} = 'д';
	$_to_utf8{0xE5} = 'е';
	$_to_utf8{0xE6} = 'ж';
	$_to_utf8{0xE7} = 'з';
	$_to_utf8{0xE8} = 'и';
	$_to_utf8{0xE9} = 'й';
	$_to_utf8{0xEA} = 'к';
	$_to_utf8{0xEB} = 'л';
	$_to_utf8{0xEC} = 'м';
	$_to_utf8{0xED} = 'н';
	$_to_utf8{0xEE} = 'о';
	$_to_utf8{0xEF} = 'п';
	$_to_utf8{0xF0} = 'р';
	$_to_utf8{0xF1} = 'с';
	$_to_utf8{0xF2} = 'т';
	$_to_utf8{0xF3} = 'у';
	$_to_utf8{0xF4} = 'ф';
	$_to_utf8{0xF5} = 'х';
	$_to_utf8{0xF6} = 'ц';
	$_to_utf8{0xF7} = 'ч';
	$_to_utf8{0xF8} = 'ш';
	$_to_utf8{0xF9} = 'щ';
	$_to_utf8{0xFA} = 'ъ';
	$_to_utf8{0xFB} = 'ы';
	$_to_utf8{0xFC} = 'ь';
	$_to_utf8{0xFD} = 'э';
	$_to_utf8{0xFE} = 'ю';
	$_to_utf8{0xFF} = 'я';
}

1;
