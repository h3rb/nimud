# vi: ts=4 sw=4

package Charsets::UTF_8::Esperanto;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw();
$VERSION	= 0.00;

# Character set UTF-8 Esperanto subset

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters_upper {
	return "([A-Z]|(�[����])|(�[��]))";
}

sub letters_lower {
	return "([a-z]|(�[����])|(�[��]))";
} 

sub letters {
	return "([A-Za-z]|(�[��������])|(�[����]))";
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z/a-z/;

	$str =~ s/Ĉ/ĉ/;
	$str =~ s/Ĝ/ĝ/;
	$str =~ s/Ĥ/ĥ/;
	$str =~ s/Ĵ/ĵ/;
	$str =~ s/Ŝ/ŝ/;
	$str =~ s/Ŭ/ŭ/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z/A-Z/;

	$str =~ s/ĉ/Ĉ/;
	$str =~ s/ĝ/Ĝ/;
	$str =~ s/ĥ/Ĥ/;
	$str =~ s/ĵ/Ĵ/;
	$str =~ s/ŝ/Ŝ/;
	$str =~ s/ŭ/Ŭ/;

	return $str;
}

sub to_utf8 {
	my ($self, $string) = @_;
	return $string;
}

sub from_utf8 {
	my ($self, $string) = @_;
	return $string;
}

sub BEGIN {
}

1;
