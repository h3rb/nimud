# vi: ts=4 sw=4

package Charsets::Latin3;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw();
$VERSION	= 0.00;

# Character set ISO 8859-3 / Latin-3

my (%_from_utf8, %_to_utf8);

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters {
	return '[' . 'A-Z�աա�' . 'a-z������' . ']';
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z�աա�/a-z������/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z������/A-Z�աա�/;

	return $str;
}

sub to_utf8 {
	my ($self, $input) = @_;
	my $output = '';

	while (($input =~ /(.|\n|\r)/g)) {
		my $c = $1;
		my $o = ord($c);
		my $u = $_to_utf8{$o};
		$output .= $u ? $u : $c;
	}
	return $output;
}

sub from_utf8 {
	my ($self, $input) = @_;
	my $output = '';
	my $state = 0;
	my $len;
	my $u;

	while (($input =~ /(.|\n|\r)/g)) {
		my $c = $1;
		my $o = ord($c);
		if ($state == 0) {
			if ($o >= 0xfe) {
				# Invalid initial byte
				$output .= '?';
				print STDERR "** invalid initial byte\n";
			} elsif ($o >= 0xc0) {
				$state = 1;
				if ($o >= 0xfc) {
					$len = 6;
				} elsif ($o >= 0xf8) {
					$len = 5;
				} elsif ($o >= 0xf0) {
					$len = 4;
				} elsif ($o >= 0xe0) {
					$len = 3;
				} else {
					$len = 2;
				}
				$u = $o & ((1 << (7 - $len)) - 1);
			} else {
				$output .= $c;
			}
		} else {
			if (($o & 0xc0) != 0x80) {
				# Invalid trailing byte
				$output .= '?';
				print STDERR "** invalid trailing byte\n";
				$state = 0;
			} else {
				$u <<= 6;
				$u += ($o & 0x3f);
				--$len;
				if ($len <= 1) {
					$state = 0;
					my $a = $_from_utf8{$u};
					if ($a) {
						$output .= chr($a);
					} else {
						$output .= '?';
					}
				}
			}
		}
	}
	return $output;
}

sub BEGIN {
	$_from_utf8{0x00A0} = 0xA0;
	$_from_utf8{0x0126} = 0xA1;
	$_from_utf8{0x02D8} = 0xA2;
	$_from_utf8{0x00A3} = 0xA3;
	$_from_utf8{0x00A4} = 0xA4;
	$_from_utf8{0x0124} = 0xA6;
	$_from_utf8{0x00A7} = 0xA7;
	$_from_utf8{0x00A8} = 0xA8;
	$_from_utf8{0x0130} = 0xA9;
	$_from_utf8{0x015E} = 0xAA;
	$_from_utf8{0x011E} = 0xAB;
	$_from_utf8{0x0134} = 0xAC;
	$_from_utf8{0x00AD} = 0xAD;
	$_from_utf8{0x017B} = 0xAF;
	$_from_utf8{0x00B0} = 0xB0;
	$_from_utf8{0x0127} = 0xB1;
	$_from_utf8{0x00B2} = 0xB2;
	$_from_utf8{0x00B3} = 0xB3;
	$_from_utf8{0x00B4} = 0xB4;
	$_from_utf8{0x00B5} = 0xB5;
	$_from_utf8{0x0125} = 0xB6;
	$_from_utf8{0x00B7} = 0xB7;
	$_from_utf8{0x00B8} = 0xB8;
	$_from_utf8{0x0131} = 0xB9;
	$_from_utf8{0x015F} = 0xBA;
	$_from_utf8{0x011F} = 0xBB;
	$_from_utf8{0x0135} = 0xBC;
	$_from_utf8{0x00BD} = 0xBD;
	$_from_utf8{0x017C} = 0xBF;
	$_from_utf8{0x00C0} = 0xC0;
	$_from_utf8{0x00C1} = 0xC1;
	$_from_utf8{0x00C2} = 0xC2;
	$_from_utf8{0x00C4} = 0xC4;
	$_from_utf8{0x010A} = 0xC5;
	$_from_utf8{0x0108} = 0xC6;
	$_from_utf8{0x00C7} = 0xC7;
	$_from_utf8{0x00C8} = 0xC8;
	$_from_utf8{0x00C9} = 0xC9;
	$_from_utf8{0x00CA} = 0xCA;
	$_from_utf8{0x00CB} = 0xCB;
	$_from_utf8{0x00CC} = 0xCC;
	$_from_utf8{0x00CD} = 0xCD;
	$_from_utf8{0x00CE} = 0xCE;
	$_from_utf8{0x00CF} = 0xCF;
	$_from_utf8{0x00D1} = 0xD1;
	$_from_utf8{0x00D2} = 0xD2;
	$_from_utf8{0x00D3} = 0xD3;
	$_from_utf8{0x00D4} = 0xD4;
	$_from_utf8{0x0120} = 0xD5;
	$_from_utf8{0x00D6} = 0xD6;
	$_from_utf8{0x00D7} = 0xD7;
	$_from_utf8{0x011C} = 0xD8;
	$_from_utf8{0x00D9} = 0xD9;
	$_from_utf8{0x00DA} = 0xDA;
	$_from_utf8{0x00DB} = 0xDB;
	$_from_utf8{0x00DC} = 0xDC;
	$_from_utf8{0x016C} = 0xDD;
	$_from_utf8{0x015C} = 0xDE;
	$_from_utf8{0x00DF} = 0xDF;
	$_from_utf8{0x00E0} = 0xE0;
	$_from_utf8{0x00E1} = 0xE1;
	$_from_utf8{0x00E2} = 0xE2;
	$_from_utf8{0x00E4} = 0xE4;
	$_from_utf8{0x010B} = 0xE5;
	$_from_utf8{0x0109} = 0xE6;
	$_from_utf8{0x00E7} = 0xE7;
	$_from_utf8{0x00E8} = 0xE8;
	$_from_utf8{0x00E9} = 0xE9;
	$_from_utf8{0x00EA} = 0xEA;
	$_from_utf8{0x00EB} = 0xEB;
	$_from_utf8{0x00EC} = 0xEC;
	$_from_utf8{0x00ED} = 0xED;
	$_from_utf8{0x00EE} = 0xEE;
	$_from_utf8{0x00EF} = 0xEF;
	$_from_utf8{0x00F1} = 0xF1;
	$_from_utf8{0x00F2} = 0xF2;
	$_from_utf8{0x00F3} = 0xF3;
	$_from_utf8{0x00F4} = 0xF4;
	$_from_utf8{0x0121} = 0xF5;
	$_from_utf8{0x00F6} = 0xF6;
	$_from_utf8{0x00F7} = 0xF7;
	$_from_utf8{0x011D} = 0xF8;
	$_from_utf8{0x00F9} = 0xF9;
	$_from_utf8{0x00FA} = 0xFA;
	$_from_utf8{0x00FB} = 0xFB;
	$_from_utf8{0x00FC} = 0xFC;
	$_from_utf8{0x016D} = 0xFD;
	$_from_utf8{0x015D} = 0xFE;
	$_from_utf8{0x02D9} = 0xFF;
	$_to_utf8{0xA0} = ' ';
	$_to_utf8{0xA1} = 'Ħ';
	$_to_utf8{0xA2} = '˘';
	$_to_utf8{0xA3} = '£';
	$_to_utf8{0xA4} = '¤';
	$_to_utf8{0xA6} = 'Ĥ';
	$_to_utf8{0xA7} = '§';
	$_to_utf8{0xA8} = '¨';
	$_to_utf8{0xA9} = 'İ';
	$_to_utf8{0xAA} = 'Ş';
	$_to_utf8{0xAB} = 'Ğ';
	$_to_utf8{0xAC} = 'Ĵ';
	$_to_utf8{0xAD} = ' ';
	$_to_utf8{0xAF} = 'Ż';
	$_to_utf8{0xB0} = '°';
	$_to_utf8{0xB1} = 'ħ';
	$_to_utf8{0xB2} = '²';
	$_to_utf8{0xB3} = '³';
	$_to_utf8{0xB4} = '´';
	$_to_utf8{0xB5} = 'µ';
	$_to_utf8{0xB6} = 'ĥ';
	$_to_utf8{0xB7} = '·';
	$_to_utf8{0xB8} = '¸';
	$_to_utf8{0xB9} = 'ı';
	$_to_utf8{0xBA} = 'ş';
	$_to_utf8{0xBB} = 'ğ';
	$_to_utf8{0xBC} = 'ĵ';
	$_to_utf8{0xBD} = '½';
	$_to_utf8{0xBF} = 'ż';
	$_to_utf8{0xC0} = 'À';
	$_to_utf8{0xC1} = 'Á';
	$_to_utf8{0xC2} = 'Â';
	$_to_utf8{0xC4} = 'Ä';
	$_to_utf8{0xC5} = 'Ċ';
	$_to_utf8{0xC6} = 'Ĉ';
	$_to_utf8{0xC7} = 'Ç';
	$_to_utf8{0xC8} = 'È';
	$_to_utf8{0xC9} = 'É';
	$_to_utf8{0xCA} = 'Ê';
	$_to_utf8{0xCB} = 'Ë';
	$_to_utf8{0xCC} = 'Ì';
	$_to_utf8{0xCD} = 'Í';
	$_to_utf8{0xCE} = 'Î';
	$_to_utf8{0xCF} = 'Ï';
	$_to_utf8{0xD1} = 'Ñ';
	$_to_utf8{0xD2} = 'Ò';
	$_to_utf8{0xD3} = 'Ó';
	$_to_utf8{0xD4} = 'Ô';
	$_to_utf8{0xD5} = 'Ġ';
	$_to_utf8{0xD6} = 'Ö';
	$_to_utf8{0xD7} = '×';
	$_to_utf8{0xD8} = 'Ĝ';
	$_to_utf8{0xD9} = 'Ù';
	$_to_utf8{0xDA} = 'Ú';
	$_to_utf8{0xDB} = 'Û';
	$_to_utf8{0xDC} = 'Ü';
	$_to_utf8{0xDD} = 'Ŭ';
	$_to_utf8{0xDE} = 'Ŝ';
	$_to_utf8{0xDF} = 'ß';
	$_to_utf8{0xE0} = 'à';
	$_to_utf8{0xE1} = 'á';
	$_to_utf8{0xE2} = 'â';
	$_to_utf8{0xE4} = 'ä';
	$_to_utf8{0xE5} = 'ċ';
	$_to_utf8{0xE6} = 'ĉ';
	$_to_utf8{0xE7} = 'ç';
	$_to_utf8{0xE8} = 'è';
	$_to_utf8{0xE9} = 'é';
	$_to_utf8{0xEA} = 'ê';
	$_to_utf8{0xEB} = 'ë';
	$_to_utf8{0xEC} = 'ì';
	$_to_utf8{0xED} = 'í';
	$_to_utf8{0xEE} = 'î';
	$_to_utf8{0xEF} = 'ï';
	$_to_utf8{0xF1} = 'ñ';
	$_to_utf8{0xF2} = 'ò';
	$_to_utf8{0xF3} = 'ó';
	$_to_utf8{0xF4} = 'ô';
	$_to_utf8{0xF5} = 'ġ';
	$_to_utf8{0xF6} = 'ö';
	$_to_utf8{0xF7} = '÷';
	$_to_utf8{0xF8} = 'ĝ';
	$_to_utf8{0xF9} = 'ù';
	$_to_utf8{0xFA} = 'ú';
	$_to_utf8{0xFB} = 'û';
	$_to_utf8{0xFC} = 'ü';
	$_to_utf8{0xFD} = 'ŭ';
	$_to_utf8{0xFE} = 'ŝ';
	$_to_utf8{0xFF} = '˙';
}

1;
