#! /usr/bin/perl

# vi: ts=8 sw=8 sts=8

# Parser for Linguaphile "Tongues" language modules

use strict;
use lib ".";

use IO::File;
require TongueParser;

my $p = new TongueParser;

local *fh = \*STDIN;

# Filename on command line?
if ($ARGV[0]) {
	print "** opening $ARGV[0]\n";
	open fh, $ARGV[0] or die "** File not found";
}

$p->init(\*fh,
	undef,
	undef,
	\&dict_start_h,
	\&dict_end_h,
	\&head_h,
	\&entry_h);

my $first_head = 1;
my $first_ent;
my $just_did_head = 0;
my $head_width;

$p->parse();

exit;

sub dict_start_h {
	print "%dictionary = (\n";
}

sub dict_end_h {
	print " },\n" unless ($first_head);
	print ");\n";
}

sub head_h {
	my ($head, $is_comment, $indent) = @_;

	$head_width = length($head) + 3;
	print " },\n" unless ($first_head);
	print "#" if ($is_comment);
	print ' ' x $indent;
	print "'$head'\t";
	print "\t" unless (length($head)>4);
	print '=> { ';
	$just_did_head = 1;
	$first_head = 0;
	$first_ent = 1;
}

sub entry_h {
	my ($f, $v) = @_;
	print ",\n" unless ($first_ent);
	unless ($just_did_head) {
		print "\t" if ($head_width >= 16);
		print "\t\t     ";
	}
	print "'$f' => '$v'";
	$just_did_head = 0;
	$first_ent = 0;
}

