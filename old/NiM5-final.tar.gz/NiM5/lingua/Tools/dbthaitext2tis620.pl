#! /usr/bin/perl

# Convert Thai text files designed for DB ThaiText font with special vowel
# tone and diacritic marks into regular TIS-620 file

use strict;

while (<>) {
	tr/\x83-\x87\x88-\x8c\x92\x93\x94-\x97\x98-\x9c\xfa\xfb\xfc-\xfd/\xe8-\xec\xe8-\xec\xd1\xe7\xd4-\xd7\xe8-\xec\x97\x96\xd8-\xd9/;
	print;
}
