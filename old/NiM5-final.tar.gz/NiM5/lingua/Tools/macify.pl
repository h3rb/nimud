#!/usr/bin/perl
#
# Convert all Perl files within the specified directory from
# Dos/Windows/Unix format into the format for the running OS.
#
# On MacOS, also sets Creator to MacPerl
#
# TODO preserve creation time & permissions when copying
# TODO should accept command-line argument for which format to conver to
#
# � 2001 Andrew Dunbar

use strict;

use File::Find;
if ($^O eq 'MacOS') {
	#use Mac::Files;
	#use Mac::StandardFile;
	#require 'GUSI.ph';
}

my ($ffound, $feol, $ftype, $fctor) = (0, 0, 0, 0);
my $dir;
my ($toeol, $toeoltext);

# Set to the character(s) you wish EOLs to be converted to
if ($^O eq 'os2' || $^O eq 'MSWin32' || $^O eq 'dos') {
	$toeol = "\xd\xa";
	$toeoltext = 'CR+LF (Dos, Windows, OS2)';
} elsif ($^O eq 'MacOS') {
	$toeol = "\xd";
	$toeoltext = 'CR (MacOS <= 9.x)';
} else {
	# Anything else behaves like Unix, especially 'amigaos' and 'darwin'
	$toeol = "\xa";
	$toeoltext = 'LF (Unix, Amiga, MacOS X)';
}

# Mac file open dialog
# TODO this code for Macs, interpret command line args for others
if ($^O eq 'MacOS') {
	$dir = MacPerl::Choose(GUSI::AF_FILE(), 0, 'Pick a folder ... ', '',
		GUSI::CHOOSE_DIR());
} else {
	$dir = $ARGV[0];
}

if ($dir) {
	print "Converting all EOLs to $toeoltext in '$dir'...\n";
	find(\&wanted, $dir);
	print "$ffound Perl files found\n";
	print "$feol files had wrong EOLs\n";
	if ($^O eq 'MacOS') {
		print "$ftype files had wrong type (but not fixed)\n";
		print "$fctor files had wrong creator\n";
	}
} else {
	print "Nothing to Convert.\n";
}

sub wanted {
	if (/\.p[l|m]$/) {
		++$ffound;
		macify($File::Find::name, $_);

		# Set file creator to MacPerl if it's not already
		if ($^O eq 'MacOS') {
			if (my $fileCat= FSpGetCatInfo($_)) {
				if (my $fileInfo = $fileCat->ioFlFndrInfo()) {
					my $mctype = $fileInfo->fdType();
					my $mcctor = $fileInfo->fdCreator();
					my $dirty = 0;

					if ($mctype ne 'TEXT') {
						++$ftype;
						print "Type is $mctype, not TEXT $_, but not fixing...\n";
					}
					if ($mcctor ne 'McPL') {
						++$fctor;
						print "Creator is $mcctor, not MacPerl $_, fixing...\n";
						$fileInfo->fdCreator('McPL');
						$dirty = 1;
					}

					if ($dirty) {
						$fileCat->ioFlFndrInfo($fileInfo);
						FSpSetCatInfo($_, $fileCat);
					}
				}
			}
		}
	}
}

sub macify {
	my ($path, $file) = @_;
	my %eols;
	$eols{w} = 0;
	$eols{u} = 0;
	$eols{m} = 0;
	my $changedeol = 0;
	if (open(fh, "<$file")) {
		if (open(fho, ">$file.")) {
			my $c = getc fh;
			while (1) {
				last if ($c eq '');# || $c eq undef);
				my $o = $c;
				my $c2 = getc fh;

				# unix/amiga format?
				if ($c eq "\xa") {
					++$eols{u};
					$o = $toeol;
					$changedeol = 1 if $toeol ne "\xa";
				# dos/windows format?
				} elsif ($c eq "\xd" && $c2 eq "\xa") {
					++$eols{w};
					$o = $toeol;
					$changedeol = 1 if $toeol ne "\xd\xa";
					$c2 = getc fh;
				# mac format?
				} elsif ($c eq "\xd") {
					++$eols{m};
					$o = $toeol;
					$changedeol = 1 if $toeol ne "\xd";
				}
				print fho $o;
				$c = $c2;
			}
			close(fho);
			my $r;
			$r .= sprintf ' %d win', $eols{w} if ($eols{w});
			$r .= sprintf ' %d unix', $eols{u} if ($eols{u});
			$r .= sprintf ' %d mac', $eols{m} if ($eols{m});

			if ($changedeol) {
				++$feol;
				printf "$path $r\n";
				if (rename($file, "$file..")) {
					if (rename("$file.", $file)) {
						unless (unlink "$file..") {
							print "Can't delete original file $file..\n";
						}
					} else {
						print "Can't rename new file to old file $file. -> $file\n";
					}
				} else {
					print "Can't rename original file to temporaryfile $file -> $file..\n";
				}
			} else {
				# TODO this should be for "non-desired" eols, not for "non-mac" eols
				unlink "$file." unless $changedeol;
			}
		} else {
			print "Can't open output $file. $!\n";
		}
		close(fh);
	} else {
		print "Can't open input $file $!\n";
	}
}
