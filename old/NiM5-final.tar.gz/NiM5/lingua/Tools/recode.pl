# This program reads 8-bit character set description file as available
# on unicode.org and converts them to a Perl tr/// statement suitable
# for translating from the first character set to the second.
# Characters that do not exist in both sets are translated to the '?'.
#
# Note that filenames and such are currently hard-coded.
#
# Originally inspired to enable MacPerl to input and output MacRoman
# but work with Windows CP1252 internal data.
#
# � Andrew Dunbar 2001

use strict;

my (@l1, @l2, @cp1252, @mr, %u);

my ($l, $u);

# Read ISO 8859-1 Western character set description
open fh, '8859-1.TXT';
while ($l = <fh>) {
	if ($l =~ /^0x(..)\s+0x(....)\s+#\s*(.*)$/) {
		$u = hex($2);
		$l1[hex $1] = $u;
		$u{$u}->{l1} = hex($1);
		$u{$u}->{name} = $3 unless $u{$u}->{name};
	}
}
close fh;

# Read ISO 8859-2 Western character set description
open fh, '8859-2.TXT';
while ($l = <fh>) {
	if ($l =~ /^0x(..)\s+0x(....)\s+#\s*(.*)$/) {
		$u = hex($2);
		$l2[hex $1] = $u;
		$u{$u}->{l2} = hex($1);
		$u{$u}->{name} = $3 unless $u{$u}->{name};
	}
}
close fh;

# Read Windows Codepage 1252 Western character set description
open fh, 'CP1252.TXT';
while ($l = <fh>) {
	if ($l =~ /^0x(..)\s+0x(....)\s+#\s*(.*)$/) {
		$u = hex($2);
		$cp1252[hex $1] = $u;
		$u{$u}->{cp1252} = hex($1);
		$u{$u}->{name} = $3 unless $u{$u}->{name};
	}
}
close fh;

# Read Macintosh MacRoman character set description
open fh, 'ROMAN.TXT';
while ($l = <fh>) {
	if ($l =~ /^0x(..)\s+0x(....)\s+#\s*(.*)$/) {
		$u = hex($2);
		$mr[hex $1] = $u;
		$u{$u}->{mr} = hex($1);
		$u{$u}->{name} = $3 unless $u{$u}->{name};
	}
}
close fh;

foreach my $i (sort {$a <=> $b} keys %u) {
	my ($l1, $l2, $cp1252, $mr) =
		($u{$i}->{l1}, $u{$i}->{l2}, $u{$i}->{cp1252}, $u{$i}->{mr});
	
	my ($hl1, $hl2, $hcp1252, $hmr);

	$hl1 = sprintf "0x%02X", $l1 if $l1 ne undef;
	$hl2 = sprintf "0x%02X", $l2 if $l2 ne undef;
	$hcp1252 = sprintf "0x%02X", $cp1252 if $cp1252 ne undef;
	$hmr = sprintf "0x%02X", $mr if $mr ne undef;

	$hl1 = '????' if $hl1 eq undef;
	$hl2 = '????' if $hl2 eq undef;
	$hcp1252 = '????' if $cp1252 eq undef;
	$hmr = '????' if $hmr eq undef;
}

my ($win2mac, $mac2win);

for my $i (0x80 .. 0xff) {
	my $u = $cp1252[$i];
	my $su = $u ? sprintf("0x%04X",$u) : '?';
	my $mac = $u{$u}->{mr} if $u ne '?';
	my $smac = $mac ? sprintf("\\x%02x",$mac) : '?';
	$win2mac .= $smac;
}

print "Win -> Mac:\ntr/\\x80-\\xff/$win2mac/\n";

for my $i (0x80 .. 0xff) {
	my $u = $mr[$i];
	my $su = $u ? sprintf("0x%04X",$u) : '?';
	my $win = $u{$u}->{cp1252} if $u ne '?';
	my $swin = $win ? sprintf("\\x%02x",$win) : '?';
	$mac2win .= $swin;
}

print "Mac -> Win:\ntr/\\x80-\\xff/$mac2win/\n";
