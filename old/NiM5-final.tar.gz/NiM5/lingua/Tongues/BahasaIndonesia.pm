# vi: ts=8 sw=8 sts=8

package Tongues::BahasaIndonesia;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
# a b c d e f g h i j k l m n o p q r s t u v w x y z

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# BahasaIndonesia to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'saya'		=> { 'x' => 'i',
		     '#' => 'me',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'aku'		=> { 'x' => 'i',
		     '#' => 'me',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'kita'		=> { 'x' => 'we',
		     '#' => 'us; inclusive',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 'kami'		=> { 'x' => 'we',
		     '#' => 'us; exclusive',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 #   2nd person
 'anda'		=> { 'x' => 'you',
		     '#' => 'formal?',
 		     't' => 'pro',
		     'p' => '2' },
 'saudara'	=> { 'x' => 'you',
		     '#' => 'polite?',
 		     't' => 'pro',
		     'p' => '2' },
 'kamu'		=> { 'x' => 'you',
		     '#' => 'familiar?',
 		     't' => 'pro',
		     'p' => '2' },
 'engkau'	=> { 'x' => 'you',
		     '#' => 'formal?',
 		     't' => 'pro',
		     'p' => '2' },
 'bapak'	=> { 'x' => 'you',
		     '#' => 'polite?',
 		     't' => 'pro',
		     'p' => '2' },
 'ibu'		=> { 'x' => 'you',
		     '#' => 'familiar?',
 		     't' => 'pro',
		     'p' => '2' },
 'kalian'	=> { 'x' => 'you',
		     '#' => 'familiar?',
 		     't' => 'pro',
		     'p' => '2' },
# 'saudara sekalian'	=> { 'x' => 'you',
#		     '#' => 'polite?',
#			     't' => 'pro',
#			     'p' => '2' },
# 'anda sekalian'	=> { 'x' => 'you',
#		     '#' => 'formal?',
#			     't' => 'pro',
#			     'p' => '2' },
 #   3rd person
 'dia'		=> { 'x' => 'he',
		     '#' => 'she',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's' },
 'mereka'	=> { 'x' => 'they',
		     '#' => 'them',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p' },
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 'de'	=> { 'x' => 'of',
	     't' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 'minggu'	=> { 'x' => 'sunday' },
 'senin'	=> { 'x' => 'monday' },
 'selasa'	=> { 'x' => 'tuesday' },
 'rabu'		=> { 'x' => 'wednesday' },
 'kamis'	=> { 'x' => 'thursday' },
 'jumat'	=> { 'x' => 'friday' },
 'sabtu'	=> { 'x' => 'saturday' },
 'januari'	=> { 'x' => 'january' },
 'februari'	=> { 'x' => 'february' },
 'maret'	=> { 'x' => 'march' },
 'april'	=> { 'x' => 'april' },
 'mei'		=> { 'x' => 'may' },
 'juni'		=> { 'x' => 'june' },
 'juli'		=> { 'x' => 'july' },
 'agustus'	=> { 'x' => 'august' },
 'september'	=> { 'x' => 'september' },
 'oktober'	=> { 'x' => 'october' },
 'november'	=> { 'x' => 'november' },
 'desember'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 'pasal'	=> { 'x' => 'article',
 		     't' => 'n' },
);
}

1;

