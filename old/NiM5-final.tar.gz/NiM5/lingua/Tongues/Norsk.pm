# vi: ts=8 sw=8

package Tongues::Norsk;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun
 #  Definiteness
 [ 'en',	'',	'the ',		'',	'n' ],	# masc. sing. def.
 #[ 'a',		'',	'the ',		'',	'n' ],	# fem. sing. def.
 [ 'et',	'',	'the ',		'',	'n' ],	# neut. sing. def.
 [ 'er',	'',	'some ',	's',	'n' ],	# plur. indef.
 [ 'ene',	'',	'the ',		's',	'n' ],	# plur. def.
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine
#	f -> feminine
#	n -> neuter
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative

# Norwegian to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 'er'		=> { 'x' => 'the',
 		     't' => 'art' },
 #   Indefinite articles
 #    Singular
 'en'		=> { 'x' => 'a',
 		     't' => 'art',
		     'g' => 'c' },
 'ei'		=> { 'x' => 'z',
 		     't' => 'art',
		     'g' => 'c' },
 'et'		=> { 'x' => 'z',
 		     't' => 'art',
		     'g' => 'n' },
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 #  Other functional words
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 # Bokmal
 's�ndag'	=> { 'x' => 'sunday' },
 'mandag'	=> { 'x' => 'monday' },
 'tirsdag'	=> { 'x' => 'tuesday' },
 'onsdag'	=> { 'x' => 'wednesday' },
 'torsdag'	=> { 'x' => 'thursday' },
 'fredag'	=> { 'x' => 'friday' },
 'l�rdag'	=> { 'x' => 'saturday' },
 'januar'	=> { 'x' => 'january' },
 'februar'	=> { 'x' => 'february' },
 'mars'		=> { 'x' => 'march' },
 'april'	=> { 'x' => 'april' },
 'mai'		=> { 'x' => 'may' },
 'juni'		=> { 'x' => 'june' },
 'juli'		=> { 'x' => 'july' },
 'august'	=> { 'x' => 'august' },
 'september'	=> { 'x' => 'september' },
 'oktober'	=> { 'x' => 'october' },
 'november'	=> { 'x' => 'november' },
 'desember'	=> { 'x' => 'december' },
 # Nynorsk
 'sundag'	=> { 'x' => 'sunday' },
 'm�ndag'	=> { 'x' => 'monday' },
 'tysdag'	=> { 'x' => 'tuesday' },
 'onsdag'	=> { 'x' => 'wednesday' },
 'torsdag'	=> { 'x' => 'thursday' },
 'fredag'	=> { 'x' => 'friday' },
 'laurdag'	=> { 'x' => 'saturday' },
 'januar'	=> { 'x' => 'january' },
 'februar'	=> { 'x' => 'february' },
 'mars'		=> { 'x' => 'march' },
 'april'	=> { 'x' => 'april' },
 'mai'		=> { 'x' => 'may' },
 'juni'		=> { 'x' => 'june' },
 'juli'		=> { 'x' => 'july' },
 'august'	=> { 'x' => 'august' },
 'september'	=> { 'x' => 'september' },
 'oktober'	=> { 'x' => 'october' },
 'november'	=> { 'x' => 'november' },
 'desember'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 'bok'		=> { 'x' => 'book',
 		     't' => 'n' },
 'elektrisitet'	=> { 'x' => 'electricity',
 		     't' => 'n' },
 'konvolutt'	=> { 'x' => 'envelope',
 		     't' => 'n' },
 'minutt'	=> { 'x' => 'minute',
 		     't' => 'n' },
 'ordbok'	=> { 'x' => 'dictionary',
 		     't' => 'n' },
 'pass'		=> { 'x' => 'passport',
 		     't' => 'n' },
 'skitt'	=> { 'x' => 'shit',
 		     't' => 'n' },
 'sv�mme'	=> { 'x' => 'swim',
 		     't' => 'v' },
 'vindu'	=> { 'x' => 'window',
 		     't' => 'n' },
);
}

1;

