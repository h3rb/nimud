# vi: ts=8 sw=8 sts=8

package Tongues::Catala;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Extra characters (ISO & Windows)
# � � � � � � � � �
# � � � � � � � �

# Alphabetical order
# A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
# a b c d e f g h i j k l m n o p q r s t u v w x y z

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun gender
 [ 'a',		'o',	'',		'',	'n' ],
 [ 'a',		'',	'',		'',	'n' ],
 # Noun plural
 [ 's',		'',	'',		's',	'n' ],	# 1
 [ 'es',	'',	'',		's',	'n' ],	# 2
 [ '�es',	'�',	'',		's',	'n' ],	# 2b
 [ '�es',	'�',	'',		's',	'n' ],
 [ '�es',	'�',	'',		's',	'n' ],
 [ '�es',	'�',	'',		's',	'n' ],
 [ '�es',	'�',	'',		's',	'n' ],
 [ 'anes',	'�n',	'',		's',	'n' ],	# 3
 [ 'enes',	'�n',	'',		's',	'n' ],
 [ 'ines',	'�n',	'',		's',	'n' ],
 [ 'ones',	'�n',	'',		's',	'n' ],
 [ 'unes',	'�n',	'',		's',	'n' ],
 [ 'ases',	'�s',	'',		's',	'n' ],
 [ 'eses',	'�s',	'',		's',	'n' ],
 [ 'ises',	'�s',	'',		's',	'n' ],
 [ 'oses',	'�s',	'',		's',	'n' ],
 [ 'uses',	'�s',	'',		's',	'n' ],
 [ 'ces',	'z',	'',		's',	'n' ],	# 5
 # Adjectives
 [ 'a',		'o',	'',		'',	'a' ],
 [ 'os',	'o',	'',		'',	'a' ],
 [ 'as',	'o',	'',		'',	'a' ],
 [ 's',		'',	'',		'',	'a' ],
 [ 'es',	'',	'',		'',	'a' ],
 [ '�simo',	'o',	'very ',	'',	'a' ],
 [ '�sima',	'o',	'very ',	'',	'a' ],
 [ '�simos',	'o',	'very ',	'',	'a' ],
 [ '�simas',	'o',	'very ',	'',	'a' ],
 # Verb past participle
 [ 'ado',	'ar',	'',		'ed',	'v' ],
 [ 'ada',	'ar',	'',		'ed',	'v' ],
 [ 'ados',	'ar',	'',		'ed',	'v' ],
 [ 'adas',	'ar',	'',		'ed',	'v' ],
 [ 'ido',	'er',	'',		'ed',	'v' ],
 [ '�do',	'er',	'',		'ed',	'v' ],
 [ 'ida',	'er',	'',		'ed',	'v' ],
 [ 'idos',	'er',	'',		'ed',	'v' ],
 [ 'idas',	'er',	'',		'ed',	'v' ],
 [ 'ido',	'ir',	'',		'ed',	'v' ],
 [ 'ida',	'ir',	'',		'ed',	'v' ],
 [ 'idos',	'ir',	'',		'ed',	'v' ],
 [ 'idas',	'ir',	'',		'ed',	'v' ],
 # Verb gerund
 [ 'ando',	'ar',	'',		'ing',	'v' ],
 [ 'iendo',	'er',	'',		'ing',	'v' ],
 [ 'iendo',	'ir',	'',		'ing',	'v' ],
 # Verb present participle
 [ 'ante',	'ar',	'',		'ing',	'v' ],
 [ 'iente',	'er',	'',		'ing',	'v' ],
 [ 'iente',	'ir',	'',		'ing',	'v' ],
 # Verb imperitive
 [ 'ad',	'ar',	'',		'',	'v' ],	# 2pp
 [ 'ed',	'er',	'',		'',	'v' ],	# 2pp
 [ 'id',	'ir',	'',		'',	'v' ],	# 2pp
 # Verb present
 [ 'o',		'ar',	'(i) ',		'',	'v' ],
 [ 'o',		'er',	'(i) ',		'',	'v' ],
 [ 'o',		'ir',	'(i) ',		'',	'v' ],
 [ 'as',	'ar',	'(you) ',	'',	'v' ],
 [ 'es',	'er',	'(you) ',	'',	'v' ],
 [ 'es',	'ir',	'(you) ',	'',	'v' ],
 [ 'a',		'ar',	'(it) ',	's',	'v' ],
 [ 'e',		'er',	'(it) ',	's',	'v' ],
 [ 'e',		'ir',	'(it) ',	's',	'v' ],
 [ 'amos',	'ar',	'(we) ',	'',	'v' ],	# also pret.
 [ 'emos',	'er',	'(we) ',	'',	'v' ],
 [ 'imos',	'ir',	'(we) ',	'',	'v' ],	# also pret.
 [ '�is',	'ar',	'(you) ',	'',	'v' ],	# castillian
 [ '�is',	'er',	'(you) ',	'',	'v' ],	# castillian
 [ '�s',	'ir',	'(you) ',	'',	'v' ],	# castillian
 [ 'an',	'ar',	'(they) ',	'',	'v' ],
 [ 'en',	'er',	'(they) ',	'',	'v' ],
 [ 'en',	'ir',	'(they) ',	'',	'v' ],
 # Verb present subjunctive, imperitive
 [ 'es',	'ar',	'(you) ',	'',	'v' ],
 [ 'as',	'er',	'(you) ',	'',	'v' ],
 [ 'as',	'ir',	'(you) ',	'',	'v' ],
 [ 'e',		'ar',	'(it) ',	'(s)',	'v' ],	# i
 [ 'a',		'er',	'(it) ',	'(s)',	'v' ],	# i
 [ 'a',		'ir',	'(it) ',	'(s)',	'v' ],	# i
 [ 'emos',	'ar',	'(we) ',	'',	'v' ],
 [ 'amos',	'er',	'(we) ',	'',	'v' ],
 [ 'amos',	'ir',	'(we) ',	'',	'v' ],
 [ '�is',	'ar',	'(you) ',	'',	'v' ],	# castillian
 [ '�is',	'er',	'(you) ',	'',	'v' ],	# castillian
 [ '�is',	'ir',	'(you) ',	'',	'v' ],	# castillian
 [ 'en',	'ar',	'(they) ',	'',	'v' ],
 [ 'an',	'er',	'(they) ',	'',	'v' ],
 [ 'an',	'ir',	'(they) ',	'',	'v' ],
 # Verb preterite
 [ '�',		'ar',	'(i) ',		'ed',	'v' ],
 [ '�',		'er',	'(i) ',		'ed',	'v' ],
 [ '�',		'ir',	'(i) ',		'ed',	'v' ],
 [ 'aste',	'ar',	'(you) ',	'ed',	'v' ],
 [ 'iste',	'er',	'(you) ',	'ed',	'v' ],
 [ 'iste',	'ir',	'(you) ',	'ed',	'v' ],
 [ '�',		'ar',	'(it) ',	'ed',	'v' ],
 [ 'i�',	'er',	'(it) ',	'ed',	'v' ],
 [ 'i�',	'ir',	'(it) ',	'ed',	'v' ],
 #[ 'amos',	'ar',	'(we) ',	'ed',	'v' ],	# also pres.
 [ 'imos',	'er',	'(we) ',	'ed',	'v' ],
 #[ 'imos',	'ir',	'(we) ',	'ed',	'v' ],	# also pres.
 [ 'asteis',	'ar',	'(you) ',	'ed',	'v' ],	# castillian
 [ 'isteis',	'er',	'(you) ',	'ed',	'v' ],	# castillian
 [ 'isteis',	'ir',	'(you) ',	'ed',	'v' ],	# castillian
 [ 'aron',	'ar',	'(they) ',	'ed',	'v' ],
 [ 'ieron',	'er',	'(they) ',	'ed',	'v' ],
 [ 'ieron',	'ir',	'(they) ',	'ed',	'v' ],
 # Verb imperfect
 [ 'aba',	'ar',	'(it) ',	'ed',	'v' ],	# i
 [ '�a',	'er',	'(it) ',	'ed',	'v' ],	# i
 [ '�a',	'ir',	'(it) ',	'ed',	'v' ],	# i
 [ 'abas',	'ar',	'(you) ',	'ed',	'v' ],
 [ '�as',	'er',	'(you) ',	'ed',	'v' ],
 [ '�as',	'ir',	'(you) ',	'ed',	'v' ],
 [ '�bamos',	'ar',	'(we) ',	'ed',	'v' ],
 [ '�amos',	'er',	'(we) ',	'ed',	'v' ],
 [ '�amos',	'ir',	'(we) ',	'ed',	'v' ],
 [ 'abais',	'ar',	'(you) ',	'ed',	'v' ],	# castillian
 [ '�ais',	'er',	'(you) ',	'ed',	'v' ],	# castillian
 [ '�ais',	'ir',	'(you) ',	'ed',	'v' ],	# castillian
 [ 'aban',	'ar',	'(they) ',	'ed',	'v' ],
 [ '�an',	'er',	'(they) ',	'ed',	'v' ],
 [ '�an',	'ir',	'(they) ',	'ed',	'v' ],
 # Verb future
 [ '�',		'',	'(i) will ',	'',	'v' ],
 [ '�s',	'',	'(you) will ',	'',	'v' ],
 [ '�',		'',	'(it) will ',	'',	'v' ],
 [ 'emos',	'',	'(we) will ',	'',	'v' ],
 [ '�is',	'',	'(you) will ',	'',	'v' ],	# castillian
 [ '�n',	'',	'(they) will ',	'',	'v' ],
 # Verb conditional
 [ '�a',	'',	'(it) would ',		'',	'v' ],	# i
 [ '�as',	'',	'(you) would ',		'',	'v' ],
 [ '�amos',	'',	'(we) would ',		'',	'v' ],
 [ '�ais',	'',	'(you) would ',		'',	'v' ],	# castillian
 [ '�an',	'',	'(they) would ',	'',	'v' ],
 # Verb imperfect subjunctive
 [ 'ara',	'ar',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'ase',	'ar',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'aras',	'ar',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ases',	'ar',	'(you) would\'ve ',	'ed',	'v' ],
 [ '�ramos',	'ar',	'(we) would\'ve ', 	'ed',	'v' ],
 [ '�semos',	'ar',	'(we) would\'ve ', 	'ed',	'v' ],
 [ 'arais',	'ar',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'aseis',	'ar',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'aran',	'ar',	'(they) would\'ve ',	'ed',	'v' ],
 [ 'asen',	'ar',	'(they) would\'ve ',	'ed',	'v' ],
 [ 'iera',	'er',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'iese',	'er',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'ieras',	'er',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieses',	'er',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'i�ramos',	'er',	'(we) would\'ve ', 	'ed',	'v' ],
 [ 'i�semos',	'er',	'(we) would\'ve ', 	'ed',	'v' ],
 [ 'ierais',	'er',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieseis',	'er',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieran',	'er',	'(they) would\'ve ',	'ed',	'v' ],
 [ 'iesen',	'er',	'(they) would\'ve ',	'ed',	'v' ],
 [ 'iera',	'ir',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'iese',	'ir',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'ieras',	'ir',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieses',	'ir',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'i�ramos',	'ir',	'(we) would\'ve ', 	'ed',	'v' ],
 [ 'i�semos',	'ir',	'(we) would\'ve ', 	'ed',	'v' ],
 [ 'ierais',	'ir',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieseis',	'ir',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieran',	'ir',	'(they) would\'ve ',	'ed',	'v' ],
 [ 'iesen',	'ir',	'(they) would\'ve ',	'ed',	'v' ],
 #  (For irregular verbs, derived from 3pp pret.)
 [ 'ara',	'aron',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'ase',	'aron',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'aras',	'aron',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ases',	'aron',	'(you) would\'ve ',	'ed',	'v' ],
 [ '�ramos',	'aron',	'(we) would\'ve ', 	'ed',	'v' ],
 [ '�semos',	'aron',	'(we) would\'ve ', 	'ed',	'v' ],
 [ 'arais',	'aron',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'aseis',	'aron',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'aran',	'aron',	'(they) would\'ve ',	'ed',	'v' ],
 [ 'asen',	'aron',	'(they) would\'ve ',	'ed',	'v' ],
 [ 'iera',	'ieron',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'iese',	'ieron',	'(he) would\'ve ',	'ed',	'v' ],	# i
 [ 'ieras',	'ieron',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieses',	'ieron',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'i�ramos',	'ieron',	'(we) would\'ve ', 	'ed',	'v' ],
 [ 'i�semos',	'ieron',	'(we) would\'ve ', 	'ed',	'v' ],
 [ 'ierais',	'ieron',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieseis',	'ieron',	'(you) would\'ve ',	'ed',	'v' ],
 [ 'ieran',	'ieron',	'(they) would\'ve ',	'ed',	'v' ],
 [ 'iesen',	'ieron',	'(they) would\'ve ',	'ed',	'v' ],
 # Adverb
 [ 'mente',	'',	'',		'ly',	'a' ],
 [ 'amente',	'o',	'',		'ly',	'a' ],
 # Appended pronouns (infinitive)
 [ 'lo',	'',	'',		' it',		'v' ],
 [ 'los',	'',	'',		' them',	'v' ],
 [ 'le',	'',	'',		' it',		'v' ],
 [ 'les',	'',	'',		' them',	'v' ],
 [ 'la',	'',	'',		' it',		'v' ],
 [ 'las',	'',	'',		' them',	'v' ],
 [ 'me',	'',	'',		' me',		'v' ],
 [ 'te',	'',	'',		' you',		'v' ],
 [ 'se',	'',	'',		' (self)',	'v' ],
 # Appended pronouns (imperative)
 [ 'alo',	'ar',	'',		' it',		'v' ],
 [ 'alos',	'ar',	'',		' them',	'v' ],
 [ 'ale',	'ar',	'',		' it',		'v' ],
 [ 'ales',	'ar',	'',		' them',	'v' ],
 [ 'ala',	'ar',	'',		' it',		'v' ],
 [ 'alas',	'ar',	'',		' them',	'v' ],
 [ 'ame',	'ar',	'',		' me',		'v' ],
 [ 'ate',	'ar',	'',		' you',		'v' ],
 [ 'ase',	'ar',	'',		' (self)',	'v' ],
 #
 [ 'elo',	'er',	'',		' it',		'v' ],
 [ 'elos',	'er',	'',		' them',	'v' ],
 [ 'ele',	'er',	'',		' it',		'v' ],
 [ 'eles',	'er',	'',		' them',	'v' ],
 [ 'ela',	'er',	'',		' it',		'v' ],
 [ 'elas',	'er',	'',		' them',	'v' ],
 [ 'eme',	'er',	'',		' me',		'v' ],
 [ 'ete',	'er',	'',		' you',		'v' ],
 [ 'ese',	'er',	'',		' (self)',	'v' ],
 #
 [ 'elo',	'ir',	'',		' it',		'v' ],
 [ 'elos',	'ir',	'',		' them',	'v' ],
 [ 'ele',	'ir',	'',		' it',		'v' ],
 [ 'eles',	'ir',	'',		' them',	'v' ],
 [ 'ela',	'ir',	'',		' it',		'v' ],
 [ 'elas',	'ir',	'',		' them',	'v' ],
 [ 'eme',	'ir',	'',		' me',		'v' ],
 [ 'ete',	'ir',	'',		' you',		'v' ],
 [ 'ese',	'ir',	'',		' (self)',	'v' ],

 # Numbers
 [ 'id�s',	'e',	'',		' two' ],
 [ 'isiete',	'e',	'',		' seven' ],

 # Higher level transformations
 # Noun to noun
 [ 'ito',	'o',	'little ',	'',	'n' ],	# dimin.
 [ 'ita',	'a',	'little ',	'',	'n' ],	# dimin. fem.
 [ 'guito',	'go',	'little ',	'',	'n' ],	# dimin.
 [ 'guita',	'ga',	'little ',	'',	'n' ],	# dimin. fem.
 # Noun to verb
 [ 'ador',	'ar',	'',		'er',	'v' ],
 [ 'edor',	'er',	'',		'er',	'v' ],
 [ 'idor',	'ir',	'',		'er',	'v' ],
 # Verb to noun
 [ 'aci�n',	'ar',	'',		'ing',	'v' ],
];

#Fields:
# x -> translation		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjunction
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine		default for words ending in a
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation (verbs):
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> conjugation (pronouns):
#	s -> subject
#	do -> direct object
#	io -> indirect object

# Catala to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 'el'	=> { 'x' => 'the',
		     '#' => 'he',
             't' => 'art' },
 #     Plural
 'els'	=> { 'x' => 'the',
	     't' => 'art',
	     'g' => 'm',
	     'n' => 'p' },
 #    Feminine
 #     Singular
 'la'	=> { 'x' => 'the',
	     't' => 'art',
	     'g' => 'f' },
 #     Plural
 'les'	=> { 'x' => 'the',
	     't' => 'art',
	     'g' => 'f',
	     'n' => 'p' },
 #    Neuter
 #     Singular
 'lo'	=> { 'x' => '(the)',
		     '#' => 'it' },
 #     Plural
 'los'	=> { 'x' => 'the',
	     't' => 'art',
	     'n' => 'p' },
 #   Indefinite articles
 'un'		=> { 'x' => 'a',
		     '#' => 'an, one',
		     't' => 'art',
		     'g' => 'm' },
 'una'		=> { 'x' => 'a',
		     '#' => 'an, one',
		     't' => 'art',
		     'g' => 'f' },
 'uns'		=> { 'x' => 'some',
 		     'g' => 'm' },
 'unes'		=> { 'x' => 'some',
 		     'g' => 'f' },
 #   Special articles
 'en'		=> { 'x' => 'the',
		     '#' => "n' l'" },
 'na'		=> { 'x' => 'the',
		     '#' => "formal; familiar=la; n' l'" },

 #  Pronouns & possessive adjectives
 #   1st person
 'jo'		=> { 'x' => 'i',
		     '#' => 'Valencia: yo',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'me'		=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'm�'		=> { 'x' => 'me',
		     '#' => 'pronoun',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'meu'		=> { 'x' => 'my',
		     '#' => 'poss. adjective; mine',
		     't' => 'a' },
 'meva'		=> { 'x' => 'my',
		     '#' => 'poss. adjective; mine',
		     't' => 'a' },
 'meus'		=> { 'x' => 'my',
		     '#' => 'poss. adjective; mine',
		     't' => 'a' },
 'meves'	=> { 'x' => 'my',
		     '#' => 'poss. adjective; mine',
		     't' => 'a' },
 'nosaltres'	=> { 'x' => 'we' },
 'nos'		=> { 'x' => 'us',
		     '#' => '(also reflexive)' },
 'nostre'	=> { 'x' => 'our' },
 'nostra'	=> { 'x' => 'our' },
 'nostres'	=> { 'x' => 'our' },
 #   2nd person
 'tu'		=> { 'x' => 'you',
		     '#' => 'familiar',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'teu'		=> { 'x' => 'your',
		     '#' => 'poss. adjective; yours',
		     't' => 'a' },
 'teva'		=> { 'x' => 'your',
		     '#' => 'poss. adjective; yours',
		     't' => 'a' },
 'teus'		=> { 'x' => 'your',
		     '#' => 'poss. adjective; yours',
		     't' => 'a' },
 'teves'	=> { 'x' => 'your',
		     '#' => 'poss. adjective; yours',
		     't' => 'a' },
 'vosaltres'	=> { 'x' => 'you',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p' },
 'vostre'	=> { 'x' => 'your' },
 'vostra'	=> { 'x' => 'your' },
 'vostres'	=> { 'x' => 'your' },
 #   3rd person
 'ell'		=> { 'x' => 'he',
		     '#' => 'it ',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
 'vost�'	=> { 'x' => 'you',
		     '#' => 'formal',
		     't' => 'pro',
		     'p' => '3',
		     '#' => 'grammatical 3rd, logical 2nd',
		     'n' => 's' },
 'vost�s'	=> { 'x' => 'you',
		     '#' => 'formal',
		     't' => 'pro',
		     'p' => '3',
		     '#' => 'grammatical 3rd, logical 2nd',
		     'n' => 'p' },
 'ella'		=> { 'x' => 'she',
		     '#' => 'it, her?',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f' },
 'ells'		=> { 'x' => 'they',
		     '#' => 'them, theirs?',
		     't' => 'pro',
		     'g' => 'm',
		     'n' => 'p' },
 'elles'	=> { 'x' => 'they',
		     '#' => 'them, theirs',
		     't' => 'pro',
		     'g' => 'f',
		     'n' => 'p' },
 'se'		=> { 'x' => '(self)',
		     '#' => 'refl. pron. (no translation)',
		     't' => 'pro' },
 'seu'		=> { 'x' => 'its',
		     '#' => 'poss. adjective; his/hers/its',
		     't' => 'a' },
 'seva'		=> { 'x' => 'its',
		     '#' => 'poss. adjective; his/hers/its',
		     't' => 'a' },
 'seus'		=> { 'x' => 'its',
		     '#' => 'poss. adjective; his/hers/its',
		     't' => 'a' },
 'seves'	=> { 'x' => 'its',
		     '#' => 'poss. adjective; his/hers/its',
		     't' => 'a' },

 #   Indefinite pronouns

 #  Interrogatives
 'quin'		=> { 'x' => 'which',
		     '#' => 'interr. and adv.',
 		     't' => 'pro',
		     'n' => 's' },
 'quina'	=> { 'x' => 'which',
		     '#' => 'interr. and adv.',
 		     't' => 'pro',
		     'n' => 's' },
 'quins'	=> { 'x' => 'which',
		     '#' => 'interr. and adv.',
 		     't' => 'pro',
		     'n' => 'p' },
 'quines'	=> { 'x' => 'which',
		     '#' => 'interr. and adv.',
 		     't' => 'pro',
		     'n' => 'p' },
 'cu�l'		=> { 'x' => 'which',
		     '#' => 'interr.',
 		     't' => 'pro' },

 #  Other functional words
 'a'		=> { 'x' => 'to',
		     't' => 'p' },
 'amb'		=> { 'x' => 'with',
		     't' => 'p' },
 'cap'		=> { 'x' => 'towards',
		     '#' => 'cap a',
		     't' => 'p' },
 'damunt'	=> { 'x' => 'on',
		     't' => 'p' },
 'de'		=> { 'x' => 'of',
		     '#' => 'from',
		     't' => 'p' },
# 'des de'	=> { 'x' => 'from',
#		     '#' => 'since',
#		     't' => 'p' },
 'dins'		=> { 'x' => 'inside',
		     '#' => 'into' },
 'en'		=> { 'x' => 'in',
        	     't' => 'p' },
 'qual'		=> { 'x' => 'that',
		     '#' => 'than, what, which' },
 'quals'	=> { 'x' => 'that',
		     '#' => 'than, what, which' },
 'quan'		=> { 'x' => 'when',
		     '#' => 'and conj.?',
 		     't' => 'adv' },

 #   Partitive / Contractions
 'al'		=> { 'x' => 'to the',
		     '#' => '(2 words)',
		     'g' => 'm' },

 # Numbers: cardinal and ordinal
 'cero'		=> { 'x' => 'zero' },
 # 'uno'
 'primer'	=> { 'x' => 'first',
		     't' => 'a' },
 'primero'	=> { 'x' => 'first',
		     't' => 'a' },
 'dos'		=> { 'x' => 'two' },
 'segundo'	=> { 'x' => 'second',
		     '#' => 'noun, ordinal number' },
 'tres'		=> { 'x' => 'three' },
 'tercer'	=> { 'x' => 'third',
		     '#' => 'ordinal',
		     't' => 'a' },
 'tercero'	=> { 'x' => 'third',
		     '#' => 'ordinal',
		     't' => 'a' },
 'cuatro'	=> { 'x' => 'four' },
 'cinco'	=> { 'x' => 'five' },
 'seis'		=> { 'x' => 'six' },
 'siete'	=> { 'x' => 'seven' },
 'ocho'		=> { 'x' => 'eight' },
 'octavo'	=> { 'x' => 'eighth' },
 'nueve'	=> { 'x' => 'nine' },
 'diez'		=> { 'x' => 'ten' },
 'decena'	=> { 'x' => 'ten',
		     '#' => '(or so), una ~',
 		     't' => 'n' },
 'once'		=> { 'x' => 'eleven' },
 'doce'		=> { 'x' => 'twelve' },
 'docena'	=> { 'x' => 'dozen',
 		     't' => 'n' },
 'veinte'	=> { 'x' => 'twenty' },
 'treinta'	=> { 'x' => 'thirty' },
 'cuarenta'	=> { 'x' => 'forty' },
 'cincuenta'	=> { 'x' => 'fifty' },
 'sesenta'	=> { 'x' => 'sixty' },
 'setenta'	=> { 'x' => 'seventy' },
 'ochenta'	=> { 'x' => 'eighty' },
 'noventa'	=> { 'x' => 'ninety' },
 'cien'		=> { 'x' => 'hundred' },
 'ciento'	=> { 'x' => 'hundred' },
 'mil'		=> { 'x' => 'thousand' },
 'mill�n'	=> { 'x' => 'million' },

 # Days and months
 'domingo'	=> { 'x' => 'sunday' },
 'lunes'	=> { 'x' => 'monday' },
 'martes'	=> { 'x' => 'tuesday' },
 'mi�rcoles'	=> { 'x' => 'wednesday' },
 'jueves'	=> { 'x' => 'thursday',
		     '#' => 'inv.' },
 'viernes'	=> { 'x' => 'friday',
		     't' => 'n' },
 's�bado'	=> { 'x' => 'saturday',
		     't' => 'n' },
 'enero'	=> { 'x' => 'january' },
 'febrero'	=> { 'x' => 'february' },
 'marzo'	=> { 'x' => 'march' },
 'abril'	=> { 'x' => 'april' },
 'mayo'		=> { 'x' => 'may' },
 'junio'	=> { 'x' => 'june' },
 'julio'	=> { 'x' => 'july' },
 'agosto'	=> { 'x' => 'august' },
 'septiembre'	=> { 'x' => 'september' },
 'octubre'	=> { 'x' => 'october' },
 'noviembre'	=> { 'x' => 'november' },
 'diciembre'	=> { 'x' => 'december' },

 # Key verbs
 #  ser - be
 'ser'		=> { 'x' => 'be',
		     '#' => '"to be"',
		     't' => 'v',
		     '#' => 'also noun - being' },
 #   ser present
 'soy'		=> { 'x' => '(i) am',
		     'r' => 'ser',
		     't' => 'v',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'p' },
 'eres'		=> { 'x' => '(you) are',
 		     'r' => 'ser',
		     't' => 'v',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'p' },
 'es'		=> { 'x' => '(it) is',
		     '#' => 'he/she',
		     'r' => 'ser',
		     't' => 'v',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'p' },
 'somos'	=> { 'x' => '(we) are',
		     'r' => 'ser',
		     't' => 'v',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'p' },
 'sois'		=> { 'x' => '(you) are',
		     'r' => 'ser',
		     't' => 'v',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'p' },
 'son'		=> { 'x' => '(they) are',
		     'r' => 'ser',
		     't' => 'v',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'p' },
 #   ser imperfect
 'era'		=> { 'x' => '(it) was',
		     '#' => '(i) was',
		     'r' => 'ser',
		     't' => 'v',
		     'n' => 's',
		     'c' => 'i' },
 'eras'		=> { 'x' => '(you) were',
		     'r' => 'ser',
		     't' => 'v',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'i' },
 '�ramos'	=> { 'x' => '(we) were',
 		     'r' => 'ser',
		     't' => 'v',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'i' },
 'erais'	=> { 'x' => '(you) were',
 		     'r' => 'ser',
		     't' => 'v',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'i' },
 'eran'		=> { 'x' => '(they) were',
 		     'r' => 'ser',
		     't' => 'v',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'i' },
 #   ser present subjunctive
 'sear'		=> { 'x' => 'be',
		     '#' => 'virtual base pres. subj.',
		     'r' => 'ser',
		     't' => 'v' },
 #   ser preterite; same as ir preterite!
 'fuir'		=> { 'x' => 'be',
		     '#' => 'virtual base pret.',
 		     'r' => 'ser',
		     '#' => 'also ir',
		     't' => 'v' },
  'fui'		=> { 'x' => '(i) was',
		     '#' => 'not "fu�"; went',
 		     'r' => 'ser',
		     '#' => 'also ir',
		     't' => 'v' },
  'fue'		=> { 'x' => '(it) was',
		     '#' => 'not "fui�"; went',
 		     'r' => 'ser',
		     '#' => 'also ir',
		     't' => 'v' },
  'fueron'	=> { 'x' => '(they) were',
		     '#' => 'not "fuieron"',
 		     'r' => 'ser',
		     '#' => 'also ir',
		     't' => 'v' },
 #   ser imperfect subjunctive?
 'fuera'	=> { 'x' => '(it) were',
		     '#' => '(i) were',
 		     'r' => 'ser',
		     '#' => 'also ir',
		     't' => 'v' },
 #  estar - be
 'estar'	=> { 'x' => 'be',
		     '#' => 'compare with "ser"',
		     't' => 'v' },
 'estoy'	=> { 'x' => '(i) am',
		     't' => 'v',
		     'r' => 'estar' },
 'est�s'	=> { 'x' => '(you) are',
		     't' => 'v',
		     'r' => 'estar' },
 'est�'		=> { 'x' => '(it) is',
 		     'r' => 'estar',
		     't' => 'v' },
 'estado'	=> { 'x' => 'state',
		     '#' => 'also pp. of estar; been',
 		     't' => 'n' },
 'est�n'	=> { 'x' => '(they) are',
 		     'r' => 'estar',
		     't' => 'v' },
 'estuve'	=> { 'x' => '(i) was',
 		     'r' => 'estar',
 		     't' => 'v' },
 'estuvieron'	=> { 'x' => '(they) were',
 		     'r' => 'estar',
 		     't' => 'v' },
 'estuvo'	=> { 'x' => '(it) was',
 		     'r' => 'estar',
 		     't' => 'v' },
 # haber - have
 'haber'	=> { 'x' => 'have',
		     't' => 'v' },
 #  haber pres.
 'he'		=> { 'x' => '(i) have',
 		     'r' => 'haber',
		     't' => 'v', },
 'has'		=> { 'x' => '(you) have',
 		     'r' => 'haber',
		     't' => 'v' },
 'ha'		=> { 'x' => '(it) has',
 		     'r' => 'haber',
		     't' => 'v' },
 'hemos'	=> { 'x' => '(we) have' },
 'han'		=> { 'x' => '(they) had' },
 #  haber pres. subj.
 'hayar'	=> { 'x' => 'have',
		     '#' => 'virtual base',
 		     'r' => 'haber',
		     't' => 'v' },
 #  haber fut. and condit.
 'habrar'	=> { 'x' => 'have',
		     '#' => 'virtual base',
 		     'r' => 'haber',
		     't' => 'v' },
 #  haber pret.
 'huber'	=> { 'x' => 'have',
		     '#' => 'virtual base',
 		     'r' => 'haber',
		     't' => 'v' },
 'hube'		=> { 'x' => '(i) had',
 		     'r' => 'haber',
		     't' => 'v',
		     'p' => '1',
		     'n' => 's',
		     'c' => 't' },
 'hubo'		=> { 'x' => '(it) had',
 		     'r' => 'haber',
		     't' => 'v',
		     'p' => '3',
		     'n' => 's',
		     'c' => 't' },
 #  haber imp. subj.
 'hubiera'	=> { 'x' => '(it) had',
		     '#' => 'I had' },
 #  impersonal!
 'hay'		=> { 'x' => 'there is',
		     '#' => 'there are (two words)' },
 #  hacer - to do; to make
 'hacer'	=> { 'x' => 'make',
		     '#' => 'do',
 		     't' => 'v' },
 'haga'		=> { 'x' => '(it) makes',
		     't' => 'v',
		     'r' => 'hacer' },
 'hagamos'	=> { 'x' => '(we) make' },
 'hagan'	=> { 'x' => '(they) make' },
 'hagas'	=> { 'x' => '(you) make' },
 'hago'		=> { 'x' => '(i) make' },
 'hizo'		=> { 'x' => '(it) made',
		     '#' => '(it) did',
 		     'r' => 'hacer',
		     't' => 'v',
		     'p' => '3',
		     'n' => 's',
		     'c' => 't' },
 'hecho'	=> { 'x' => 'made' },
 #  gustar - to please; translates to 'to like' in English
 'gustar'	=> { 'x' => 'please',
		     '#' => '"like" but with subj & obj swapped',
		     't' => 'v' },
 #  ir - to go
 'ir'		=> { 'x' => 'go',
		     't' => 'v' },
  'var'		=> { 'x' => 'go',
		     '#' => 'virtual base pres.',
  		     'r' => 'ir',
		     't' => 'v' },
   'voy'	=> { 'x' => '(i) go',
		     '#' => 'not "vo"',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'p' },
   'vais'	=> { 'x' => '(you) go',
		     '#' => 'not "v�is"',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'p' },
  'vayar'	=> { 'x' => 'go',
		     '#' => 'virtual base pres. subj.',
  		     'r' => 'ir',
		     't' => 'v' },
  'iba'		=> { 'x' => '(it) went',
		     '#' => 'i, he/she/it',
		     't' => 'v',
		     'r' => 'ir',
		     'n' => 's',
		     'c' => 'i' },
  'ibas'	=> { 'x' => '(you) went',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'i' },
  'ibamos'	=> { 'x' => '(we) went',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'i' },
  'ibais'	=> { 'x' => '(you) went',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'i' },
  'iban'	=> { 'x' => '(they) went',
		     't' => 'v',
		     'r' => 'ir',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'i' },
 #  poder - can (modal)
 'poder'	=> { 'x' => 'can',
		     '#' => 'be able to',
		     't' => 'v',
		     '#' => 'also noun: power' },
 'pude'		=> { 'x' => '(i) could',
 		     'r' => 'poder',
		     't' => 'v',
		     'p' => '1',
		     'n' => 's',
		     'c' => 't' },
 #   virtual base for pres., subj.
 'pueder'	=> { 'x' => 'can',
		     '#' => 'be able to',
 		     'r' => 'poder',
		     't' => 'v' },
 #   virtual base for preterite
 'puder'	=> { 'x' => 'be able to',
		     '#' => 'could',
 		     'r' => 'poder',
		     't' => 'v' },
 #   virtual base for fut., cond.
 'podr'		=> { 'x' => 'be able to',
		     'r' => 'poder',
		     't' => 'v' },
 #  deber - should (modal)
 'deber'	=> { 'x' => 'should',
		     't' => 'v' },
 #  tener - have
 'tener'	=> { 'x' => 'have',
		     't' => 'v' },
  'ten'		=> { 'x' => 'have',
		     '#' => 'imperative',
  		     'r' => 'tener',
		     't' => 'v',
		     'n' => 's',
		     'c' => 'imp' },
  'tenger'	=> { 'x' => 'have',
		     '#' => 'virtual base pres., pres. subj.',
  		     'r' => 'tener',
		     't' => 'v' },
  'tiener'	=> { 'x' => 'have',
		     '#' => 'virtual base pres.',
  		     'r' => 'tener',
		     't' => 'v' },
  'tendr'	=> { 'x' => 'have',
		     '#' => 'virtual base fut., condit.',
  		     'r' => 'tener',
		     't' => 'v' },
  'tuver'	=> { 'x' => 'have',
		     '#' => 'virtual base pret.',
  		     'r' => 'tener',
		     't' => 'v' },
  'tuve'	=> { 'x' => '(it) had',
		     'r' => 'tener',
		     't' => 'v',
		     'p' => '1',
		     'n' => 's',
		     'c' => 't' },
  'tuvo'	=> { 'x' => '(i) had',
		     'r' => 'tener',
		     't' => 'v',
		     'p' => '3',
		     'n' => 's',
		     'c' => 't' },
 # Vocabulary
 'article'	=> { 'x' => 'article',
		     't' => 'n' },
 'catal�'	=> { 'x' => 'catalan',
		     't' => 'n' },
 'm�n'		=> { 'x' => 'world',
		     't' => 'n',
		     'g' => 'm' },
 'pel�l�cula'	=> { 'x' => 'movie',
		     't' => 'n' },
);
}

1;

