# vi: ts=8 sw=8 sts=8

package Tongues::Interlingua;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
# a b c d e f g h i j k l m n o p q r s t u v w x y z

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Pronoun
 # Noun
 # Noun object
 # Noun gender
 # Noun plural
 [ 's',		'',	'',		's',	'n' ],
 [ 'es',	'',	'',		's',	'n' ],
 [ 'ches',	'c',	'',		's',	'n' ],
 # Adjective
 # Adjective plural
 # Adjective opposite
 # Verb
 # Verb present
 # Verb past
 # Verb future
 # Verb imperitive
 # Verb continuous?
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			pronouns
#	m -> masculine
#	f -> feminine
# n -> number:			nouns, pronouns
#	s -> singular		default
#	p -> plural
# p -> person:			pronouns
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 
#	p -> prepositional

# Interlingua to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 'le'		=> { 'x' => 'the' },
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'io'		=> { 'x' => 'i',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'me'		=> { 'x' => 'me',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'nos'		=> { 'x' => 'we',
		     '#' => 'us',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 #   2nd person
 'tu'		=> { 'x' => 'you',
		     '#' => 'thou',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'te'		=> { 'x' => 'you',
		     '#' => 'thee',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'vos'		=> { 'x' => 'you',
		     '#' => 'youse/y\'all',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p' },
 #   3rd person
 'ille'		=> { 'x' => 'he',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
# 'le'		=> { 'x' => 'him',
# 		     't' => 'pro',
#		     'p' => '3',
#		     'n' => 's',
#		     'g' => 'm' },
 'illa'		=> { 'x' => 'she',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f' },
 'la'		=> { 'x' => 'her',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f' },
 'illo'		=> { 'x' => 'it',
		     '#' => 'subject/nom.',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'n' },
 'lo'		=> { 'x' => 'it',
		     '#' => 'object/accus.',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'n' },
 'illes'	=> { 'x' => 'they',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'g' => 'm' },
 'les'		=> { 'x' => 'them',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'g' => 'm' },
 'illas'	=> { 'x' => 'they',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'g' => 'f' },
 'las'		=> { 'x' => 'them',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'g' => 'f' },
 'illos'	=> { 'x' => 'they',
		     '#' => 'subject/nom.',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'g' => 'n' },
 'los'		=> { 'x' => 'them',
		     '#' => 'object/accus.',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'g' => 'n' },
 #   Other pronouns
 'se'		=> { 'x' => 'self',
		     '#' => 'reflexive pronoun, 3rd pers. only',
		     't' => 'p' },
 #  Interrogatives
 #  Other functional words
 'e'		=> { 'x' => 'and',
		     't' => 'conj' },
 'in'		=> { 'x' => 'in',
		     't' => 'p' },
 'minus'	=> { 'x' => 'less',
		     '#' => 'least; adv.?' },
 'plus'		=> { 'x' => 'more',
		     '#' => 'most; adv.?' },
 'quando'	=> { 'x' => 'when',
		     '#' => 'and conj.?',
 		     't' => 'adv' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'zero'		=> { 'x' => 'zero' },
 'un'		=> { 'x' => 'one' },
 'duo'		=> { 'x' => 'two' },
 'tres'		=> { 'x' => 'three' },
 'quatro'	=> { 'x' => 'four' },
 'cinque'	=> { 'x' => 'five' },
 'sex'		=> { 'x' => 'six' },
 'septe'	=> { 'x' => 'seven' },
 'octo'		=> { 'x' => 'eight' },
 'nove'		=> { 'x' => 'nine' },
 'dece'		=> { 'x' => 'ten' },
 'vinti'	=> { 'x' => 'twenty' },
 'trenta'	=> { 'x' => 'thirty' },
 'quaranta'	=> { 'x' => 'forty' },
 'cinquanta'	=> { 'x' => 'fifty' },
 'sexanta'	=> { 'x' => 'sixty' },
 'septanta'	=> { 'x' => 'seventy' },
 'octanta'	=> { 'x' => 'eighty' },
 'novanta'	=> { 'x' => 'ninety' },
 'cento'	=> { 'x' => 'hundred' },
 'mille'	=> { 'x' => 'thousand' },
 'million'	=> { 'x' => 'million' },
 # Days and months
 'dominica'	=> { 'x' => 'sunday' },
 'lunedi'	=> { 'x' => 'monday' },
 'martedi'	=> { 'x' => 'tuesday' },
 'mercuridi'	=> { 'x' => 'wednesday' },
 'jovedi'	=> { 'x' => 'thursday' },
 'venerdi'	=> { 'x' => 'friday' },
 'sabato'	=> { 'x' => 'saturday' },
 'januario'	=> { 'x' => 'january' },
 'frebruario'	=> { 'x' => 'february' },
 'martio'	=> { 'x' => 'march' },
 'april'	=> { 'x' => 'april' },
 'maio'		=> { 'x' => 'may' },
 'junio'	=> { 'x' => 'june' },
 'julio'	=> { 'x' => 'july' },
 'augusto'	=> { 'x' => 'august' },
 'septembre'	=> { 'x' => 'september' },
 'octobre'	=> { 'x' => 'october' },
 'novembre'	=> { 'x' => 'november' },
 'decembre'	=> { 'x' => 'december' },
 # Key verbs
 'esser'	=> { 'x' => 'be',
		     't' => 'v' },
  'es'		=> { 'x' => 'is',
		     'r' => 'esser',
		     't' => 'v',
		     'c' => 't' },
 'haber'	=> { 'x' => 'have',
		     't' => 'v' },
  'ha'		=> { 'x' => 'have',
		     'r' => 'haber',
		     't' => 'v',
		     'c' => 't' },
 'vader'	=> { 'x' => 'go',
		     't' => 'v' },
  'va'		=> { 'x' => 'go',
		     'r' => 'vader',
		     't' => 'v',
		     'c' => 't' },
 # Vocabulary
 'american'	=> { 'x' => 'american',
		     '#' => 'noun & adj.?' },
 'anno'		=> { 'x' => 'year',
		     't' => 'n' },
 'articulo'	=> { 'x' => 'article',
		     't' => 'n' },
 'belle'	=> { 'x' => 'beautiful',
		     't' => 'a' },
 'blau'		=> { 'x' => 'blue',
		     't' => 'a' },
 'bon'		=> { 'x' => 'good',
		     't' => 'a' },
 'breve'	=> { 'x' => 'short',
		     '#' => 'brief',
		     't' => 'a' },
 'cyclic'	=> { 'x' => 'cyclic',
		     't' => 'a' },
 'dan'		=> { 'x' => 'danish',
		     '#' => 'noun & adj.?' },
 'delicate'	=> { 'x' => 'delicate',
		     't' => 'a' },
 'equal'	=> { 'x' => 'equal',
		     't' => 'a' },
 'die'		=> { 'x' => 'day',
		     't' => 'n' },
 'femina'	=> { 'x' => 'woman',
		     't' => 'n' },
 'integre'	=> { 'x' => 'whole',
		     't' => 'a' },
 'interlingua'	=> { 'x' => 'interlingua' },
 'international'	=> { 'x' => 'international',
			     't' => 'a' },
 'libro'	=> { 'x' => 'book',
		     't' => 'n' },
 'lingua'	=> { 'x' => 'language',
		     't' => 'n' },
 'longe'	=> { 'x' => 'long',
		     't' => 'a' },
 'matre'	=> { 'x' => 'mother',
		     't' => 'n' },
 'mundo'	=> { 'x' => 'world',
		     't' => 'n' },
 'natal'	=> { 'x' => 'christmas',
		     't' => 'n' },
 'national'	=> { 'x' => 'national',
		     't' => 'a' },
 'par'		=> { 'x' => 'even' },
 'parve'	=> { 'x' => 'small',
		     't' => 'a' },
 'pascha'	=> { 'x' => 'easter',
		     't' => 'n' },
 'patre'	=> { 'x' => 'father',
		     't' => 'n' },
 'ric'		=> { 'x' => 'rich',
		     't' => 'a' },
 'viage'	=> { 'x' => 'trip',
		     '#' => 'voyage',
		     't' => 'n' },
 'vita'		=> { 'x' => 'life',
		     't' => 'n' },
);
}

1;

