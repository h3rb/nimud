# vi: ts=8 sw=8

package Tongues::Gaeilge;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin1

# Alphabetical order
# A B C D E F G H I (J K) L M N O P (Q) R S T U (V W X Y Z)
# a b c d e f g h i (j k) l m n o p (q) r s t u (v w x y z)

# Extra characters (ISO)
# Á É Í Ó Ú
# á é í ó ú

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# Gaeilge to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 'de'	=> { 'x' => 'of',
	     't' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 'dé domhnaigh'	=> { 'x' => 'sunday' },
 'dé luain'	=> { 'x' => 'monday' },
 'dé máirt'	=> { 'x' => 'tuesday' },
 'dé céadaoin'	=> { 'x' => 'wednesday' },
 'déardaoin'	=> { 'x' => 'thursday' },
 'dé haoine'	=> { 'x' => 'friday' },
 'dé sathairn'	=> { 'x' => 'saturday' },
 'eanáir'	=> { 'x' => 'january' },
 'feabhra'	=> { 'x' => 'february' },
 'márta'	=> { 'x' => 'march' },
 'aibreán'	=> { 'x' => 'april' },
 'mí na bealtaine'	=> { 'x' => 'may' },
 'meith'	=> { 'x' => 'june' },
 'iúil'			=> { 'x' => 'july' },
 'lúnasa'	=> { 'x' => 'august' },
 'meán fómhair'	=> { 'x' => 'september' },
 'deireadh fómhair'	=> { 'x' => 'october' },
 'mí na samhna'	=> { 'x' => 'november' },
 'mí na nollag'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 'airteagal'	=> { 'x' => 'article',
		     't' => 'n' },
);
}

1;

