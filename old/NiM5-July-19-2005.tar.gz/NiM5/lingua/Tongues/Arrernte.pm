# vi: ts=8 sw=8 sts=8

package Tongues::Arrernte;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A E G H I K L M N P R T U W Y
# a e g h i k l m n p r t u w y

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	s -> subject	 		default
#	o -> object
#	d -> dative
#	p -> possessive

# Arrernte to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'ayenge'	=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 's' },
 'the'		=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 's' },
 'ayenge'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'o' },
 'ayenhe'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'o' },
 'atyenge'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'd' },
 'atyenhe'	=> { 'x' => 'my',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'p' },
 'atyinhe'	=> { 'x' => 'my',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'p' },

 'ilerne'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     'c' => 's' },
 'ilernenhe'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     'c' => 'o' },
 'ilerneke'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     'c' => 'd' },
 'ilernekenhe'	=> { 'x' => 'our',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     'c' => 'p' },

 'anwerne'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 's' },
 'anwernenhe'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'o' },
 'anwerneke'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'd' },
 'anwernekenhe'	=> { 'x' => 'our',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'p' },

 #   2nd person
 'unte'		=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 's' },
 'ngenhe'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'o' },
 'ngkwenge'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'd' },
 'ngkwinhe'	=> { 'x' => 'your',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'p' },

 'mpwele'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 's' },
 'mpwelenhe'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'o' },
 'mpweleke'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'd' },
 'mpwelekenhe'	=> { 'x' => 'your',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'p' },

 'arrantherre'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 's' },
 'arrenhantherre'	=> { 'x' => 'you',
			     't' => 'pro',
			     'p' => '2',
			     'n' => 'p',
			     'c' => 'o' },
 'arrekantherre'	=> { 'x' => 'you',
			     't' => 'pro',
			     'p' => '2',
			     'n' => 'p',
			     'c' => 'd' },
 'arrekantherrenhe'	=> { 'x' => 'your',
			     't' => 'pro',
			     'p' => '2',
			     'n' => 'p',
			     'c' => 'p' },

 #   3rd person
 're'		=> { 'x' => 'he',
		     '#' => 'she; it',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 's' },
 'renhe'	=> { 'x' => 'him; her; it',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'o' },
 'ikwere'	=> { 'x' => 'him; her; it',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'd' },
 'ikwerenhe'	=> { 'x' => 'his',
		     '#' => 'hers; its',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'p' },

 're-atherre'	=> { 'x' => 'they',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 's' },
 'renhe-atherre'	=> { 'x' => 'them',
			     't' => 'pro',
			     'p' => '3',
			     'n' => 'd',
			     'c' => 'o' },
 'renhe-atherrenhe'	=> { 'x' => 'them',
			     't' => 'pro',
			     'p' => '3',
			     'n' => 'd',
			     'c' => 'o' },
 'ikwere-atherre'	=> { 'x' => 'them',
			     't' => 'pro',
			     'p' => '3',
			     'n' => 'd',
			     'c' => 'd' },
 'ikwere-atherrenhe'	=> { 'x' => 'their',
			     't' => 'pro',
			     'p' => '3',
			     'n' => 'd',
			     'c' => 'p' },

 'itne'		=> { 'x' => 'they',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 's' },
 'itnenhe'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'o' },
 'itneke'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'd' },
 'itnekenhe'	=> { 'x' => 'their',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'p' },

 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 # Key verbs
 # Vocabulary
);
}

1;

