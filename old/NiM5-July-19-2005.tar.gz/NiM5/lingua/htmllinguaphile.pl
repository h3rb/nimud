#! /usr/bin/perl
# vi: ts=4 sw=4 sts=4

require 5.002;
require Linguaphile;
require HTML::Parser;
require HTML::Entities;

use strict;

use lib ".";

my $default_src_lang = 'es';
my $default_dst_lang = 'en';

use Getopt::Std;

use vars qw($opt_s $opt_d $opt_a $opt_l $opt_q $opt_P);

my $line;

getopts('s:d:alqP');

$opt_s = $default_src_lang unless $opt_s;
$opt_d = $default_dst_lang unless $opt_d;

my $fh = *STDIN;

# Filename on command line?
if ($ARGV[0]) {
	open $fh, $ARGV[0] or die "** File not found";
}

my %inside;

my %langmap;

my $lang = $opt_s;

print STDERR "** default language: $lang\n";

$langmap{$lang} = new Linguaphile;

$langmap{$lang}->init($opt_s, $opt_d);

# Create parser object
my $p = HTML::Parser->new(
	api_version => 3,
	unbroken_text => 1,
	default_h => [sub { print shift }, 'text'],
	start_h => [\&start_handler, 'tagname, text, attr'],
	end_h => [\&end_handler, 'tagname, text'],
	text_h => [\&text_handler, 'text']);

$p->parse_file($fh);

exit;

sub start_handler {
	my ($tag, $text, $attr) = @_;

	++ $inside{$tag};

	print $text;

	# if there's a lang tag
	if ($attr->{lang}) {
		my $newlang = $attr->{lang};
		# open a new translator if this is the first use of this language
		print STDERR "** new language: $newlang\n";
		if ($attr->{lang} && !$langmap{$newlang}) {
			$langmap{$newlang} = new Linguaphile;
			if ($langmap{$newlang}->init($newlang,$opt_d)) {
				#$oldlang = $lang;
				$lang = $newlang;
			} else {
				$lang = $opt_s;
			}
		}
	}
}

sub end_handler {
	my ($tag, $text) = @_;
	-- $inside{$tag};
	print $text;
}

sub text_handler {
	my $text = shift;

	if ($inside{script} || $inside{style}) {
		print $text;
	} else {
		print $langmap{$lang}->translate(HTML::Entities::decode($text));
	}
}
