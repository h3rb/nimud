/*
 * Internal stuff.
 */
extern int gotoloops;

#define  VD    VARIABLE_DATA

/*
 * Reserved functions for internal parsing.
 */
VD * func_goto     args( ( void * caller, int type, VD *label ) );
VD * func_if       args( ( void * caller, int type, VD *exp, VD *iftrue, VD *iffalse ) );
VD * func_label    args( ( void * caller, int type ) );
VD * func_return   args( ( void * caller, int type, VD *value ) );
VD * func_halt     args( ( void * caller, int type, VD *value ) );
VD * func_permhalt args( ( void * caller, int type ) );
VD * func_wait     args( ( void * caller, int type, VD *value ) );
VD * func_autowait args( ( void * caller, int type, VD *value ) );
VD * func_call     args( ( void * caller, int type, VD *trigname, VD *target ) );
VD * func_vget     args( ( void * caller, int type, VD *newvar, VD *varname, VD *trigname, VD *target ) );
VD * func_vset     args( ( void * caller, int type, VD *varname, VD *ourvar, VD *trigname, VD *target ) );

/*
 * Further stuff.
 */
VD * func_vcpy     args( ( void * caller, int type, VD *old, VD *new, VD *trigname ) );
VD * func_self     args( ( void * caller, int type, VD *varname ) );

/*
 * "Constants."
 */

VD * func_null     args( ( void * caller, int type ) );

/*
 * Boolean conditionals.
 */
VD * func_cmp      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_not      args( ( void * caller, int type, VD *value ) );
VD * func_or       args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_and      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_xor      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_less     args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_greater  args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_pre      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_in       args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_strstr   args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_pcmp     args( ( void * caller, int type, VD *astr, VD *bstr ) );

/*
 * Mathematics.
 */
VD * func_add      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_sub      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_mult     args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_div      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_mod      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_random   args( ( void * caller, int type, VD *astr, VD *bstr ) );

VD * func_band     args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_bor      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_bxor     args( ( void * caller, int type, VD *astr, VD *bstr ) );


/*
 * String things.
 */
VD * func_cat      args( ( void * caller, int type, VD *astr, VD *bstr ) );
VD * func_word     args( ( void * caller, int type, VD *astr, VD *value ) );

/*
 * Output functions.
 */
VD * func_out      args( ( void * caller, int type, VD *out, VD *ch, VD *arg1, VD *arg2, VD *act_type ) );
VD * func_numw     args( ( void * caller, int type, VD *astr ) );
VD * func_strp     args( ( void * caller, int type, VD *value, VD *old, VD *new ) );

/*
 * Game-related functions for mobiles.
 */
VD * func_do       args( ( void * caller, int type, VD *exp0, VD *exp1, VD *exp2, VD *exp3, VD *exp4, VD *exp5 ) );
VD * func_step     args( ( void * caller, int type, VD *value ) );
VD * func_ms       args( ( void * caller, int type, VD *astr, VD *bstr ) );

/*
 * Game-related functions for objects.
 */
VD *func_os        args( ( void * caller, int type, VD *astr, VD *bstr ) );

/*
 * Game-related functions for rooms.
 */

/*
 * Other game-related functions.
 */
VD *func_sameroom  args( ( void * caller, int type, VD *value ) );
VD *func_eval      args( ( void * caller, int type, VD *value ) );

#undef  VD
