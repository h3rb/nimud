
#define FIGHT_PARRY                    1
#define FIGHT_DODGE                    2
#define FIGHT_PRIMARY                  4
#define FIGHT_SECONDARY                8

