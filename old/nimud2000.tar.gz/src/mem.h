
extern int         top_affect;
extern int         top_area;
extern int         top_ed;
extern int         top_exit;
extern int         top_help;
extern int         top_mob_index;
extern int         top_obj_index;
extern int         top_reset;
extern int         top_room;
extern int         top_shop;
extern int         top_variable;
extern int         top_trigger;
extern int         top_script;

extern int         top_vnum_script;
extern int         top_vnum_mob;
extern int         top_vnum_obj;
extern int         top_vnum_room;

