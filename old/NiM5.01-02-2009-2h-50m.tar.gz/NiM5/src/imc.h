/*
 * IMC2 MUD-Net versions 4.20 through 4.24b developed by Alsherok.
 * Copyright (c)2002-2003 Roger Libiez ( Samson )
 * Contributions to the 4.22b client Copyright (c)2003 by Xorith
 * Registered with the United States Copyright Office
 * TX 5-555-584
 * Version number for 4.2x series artificially raised to indicate the true nature of upgrades
 * made to the 3.10 client. If the Continuum developers won't correct their version number to
 * reflect THEIR true nature, then we need to raise ours to compensate for their error.
 *
 * IMC2 MUD-Net versions 3.00 and 3.10 developed by Asherok and Crimson Oracles.
 * Copyright (c)2002-2003 Roger Libiez ( Samson )
 * Additional code Copyright (c)2002 by Orion Elder.
 * Registered with the United States Copyright Office
 * TX 5-555-584
 *
 * IMC2 Gold versions 1.00 though 2.00 are developed by MudWorld.
 * Copyright (C) 1999 - 2002 Haslage Net Electronics (Anthony R. Haslage)
 *
 * IMC2 version 0.10 - an inter-mud communications protocol
 * Copyright (C) 1996 & 1997 Oliver Jowett <oliver@randomly.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING); if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

/* Don't have vsnprintf or other variants?  Uncomment these lines: */
#define vsnprintf sprintf
#define snprintf sprintf

/* Number of entries to keep in the channel histories */
#define MAX_IMCHISTORY 20

/* This is the protocol version */
#define IMC_VERSION 2
#define IMC_VERSION_ID "IMC2 4.24b MUD-Net "

#define IMC_CHANNEL_FILE "imc.channels"
#define IMC_CONFIG_FILE  "imc.config"
#define IMC_IGNORE_FILE  "imc.ignores"

/* Make sure you set the macros in the imccfg.h file properly or things get ugly from here. */
#include "imccfg.h"

typedef enum
{
   IMCPERM_NOTSET, IMCPERM_NONE, IMCPERM_MORT, IMCPERM_IMM, IMCPERM_ADMIN, IMCPERM_IMP
} imc_permissions;

/* Ye olde Merc-like command struct */
struct imccmd_type
{
   const char *name[2];
   CMD_FUN *function;
   int level;
   bool connected;
};

/* Flag macros */
#define IMCIS_SET(flag, bit)	((flag) & (bit))
#define IMCSET_BIT(var, bit)	((var) |= (bit))
#define IMCREMOVE_BIT(var, bit)((var) &= ~(bit))

/* Player flags */
#define IMC_TELL        (1 <<  0)
#define IMC_DENYTELL    (1 <<  1)
#define IMC_BEEP        (1 <<  2)
#define IMC_DENYBEEP    (1 <<  3)
#define IMC_INVIS       (1 <<  4)
#define IMC_PRIVACY     (1 <<  5)
#define IMC_DENYFINGER  (1 <<  6)
#define IMC_AFK         (1 <<  7)
#define IMC_COLOR       (1 <<  8)

#define IMCPERM(ch)           (CH_IMCDATA((ch))->imcperm)
#define IMCFLAG(ch)           (CH_IMCDATA((ch))->imcflag)
#define FIRST_IMCIGNORE(ch)   (CH_IMCDATA((ch))->imcfirst_ignore)
#define LAST_IMCIGNORE(ch)    (CH_IMCDATA((ch))->imclast_ignore)
#define IMC_LISTEN(ch)        (CH_IMCDATA((ch))->imc_listen)
#define IMC_DENY(ch)          (CH_IMCDATA((ch))->imc_denied)
#define IMC_RREPLY(ch)        (CH_IMCDATA((ch))->rreply)
#define IMC_RREPLY_NAME(ch)   (CH_IMCDATA((ch))->rreply_name)
#define IMCISINVIS(ch)        ( IMCWIZINVIS((ch)) || IMCIS_SET( IMCFLAG((ch)), IMC_INVIS ) )
#define IMCAFK(ch)            ( IMCIS_SET( IMCFLAG((ch)), IMC_AFK ) )

/* Should not need to edit anything below this point */

#define LGST 4096 /* Large String */
#define SMST 1024 /* Small String */

/* Macro taken from DOTD codebase. Fcloses a file, then nulls its pointer for safety. */
#define IMCFCLOSE(fp)  fclose(fp); fp=NULL;

/*
 * Memory allocation macros.
 */
#define IMCCREATE(result, type, number)                           \
do                                                                \
{                                                                 \
    if (!((result) = (type *) calloc ((number), sizeof(type))))   \
    {                                                             \
	imclog( "Malloc failure @ %s:%d\n", __FILE__, __LINE__ );   \
	abort();                                                    \
    }                                                             \
} while(0)

#define IMCDISPOSE(point)     \
do                            \
{                             \
   if((point))                \
   {                          \
	free((point));          \
	(point) = NULL;         \
   }                          \
} while(0)

#define IMCSTRALLOC strdup
#define IMCSTRFREE IMCDISPOSE

/* double-linked list handling macros -Thoric ( From the Smaug codebase ) */
/* Updated by Scion 8/6/1999 */
#define IMCLINK(link, first, last, next, prev)  \
do                                              \
{                                               \
   if ( !(first) )                              \
   {                                            \
      (first) = (link);                         \
      (last) = (link);                          \
   }                                            \
   else                                         \
      (last)->next = (link);                    \
   (link)->next = NULL;                         \
   if ((first) == (link))                       \
      (link)->prev = NULL;                      \
   else                                         \
      (link)->prev = (last);                    \
   (last) = (link);                             \
} while(0)

#define IMCINSERT(link, insert, first, next, prev)    \
do                                                    \
{                                                     \
   (link)->prev = (insert)->prev;                     \
   if ( !(insert)->prev )                             \
      (first) = (link);                               \
   else                                               \
      (insert)->prev->next = (link);                  \
   (insert)->prev = (link);                           \
   (link)->next = (insert);                           \
} while(0)

#define IMCUNLINK(link, first, last, next, prev) \
do                                               \
{                                                \
   if ( !(link)->prev )                          \
   {                                             \
      (first) = (link)->next;                    \
	if((first))                                \
	   (first)->prev = NULL;                   \
   }                                             \
   else                                          \
   {                                             \
      (link)->prev->next = (link)->next;         \
   }                                             \
   if( !(link)->next )                           \
   {                                             \
      (last) = (link)->prev;                     \
	if((last))                                 \
	   (last)->next = NULL;                    \
   }                                             \
   else                                          \
   {                                             \
      (link)->next->prev = (link)->prev;         \
   }                                             \
} while(0)

/*
 * Color Alignment Parameters
 */
#ifndef ALIGN_LEFT
   #define ALIGN_LEFT	1
#endif
#ifndef ALIGN_CENTER
   #define ALIGN_CENTER	2
#endif
#ifndef ALIGN_RIGHT
   #define ALIGN_RIGHT	3
#endif

/* Less tweakable parameters - only change these if you know what they do */

/* number of packets to remember at a time */
#define IMC_MEMORY 256

/* start dropping really old packets based on this figure */
#define IMC_PACKET_LIFETIME 60

/* min input/output buffer size */
#define IMC_MINBUF        256

/* max input/output buffer size */
#define IMC_MAXBUF        16384

/* Changing these impacts the protocol itself - other muds may drop your
 * packets if you get this wrong
 */
/* max length of any packet */
#define IMC_PACKET_LENGTH 16300

/* max length of any mud name */
#define IMC_MNAME_LENGTH  20

/* max length of any player name */
#define IMC_PNAME_LENGTH  40

/* max length of any player@mud name */
#define IMC_NAME_LENGTH   (IMC_MNAME_LENGTH+IMC_PNAME_LENGTH+1)

/* max length of a path */
#define IMC_PATH_LENGTH   200

/* max length of a packet type */
#define IMC_TYPE_LENGTH   20

/* max length of a password */
#define IMC_PW_LENGTH     20

/* max length of a data type (estimate) */
#define IMC_DATA_LENGTH   (IMC_PACKET_LENGTH-2*IMC_NAME_LENGTH-IMC_PATH_LENGTH-IMC_TYPE_LENGTH-20)

/* max number of data keys in a packet */
#define IMC_MAX_KEYS      20

/* activation states */

#define IA_NONE        0
#define IA_CONFIG1     1
#define IA_CONFIG2     2
#define IA_UP          3

/* connection states */
#define IMC_CLOSED     0 /* No active connection */
#define IMC_CONNECTING 1 /* Contacting hub */
#define IMC_WAIT1      2 /* Waiting for hub verification */
#define IMC_CONNECTED  3 /* Fully connected */

#define IMC_REMINFO_NORMAL 0
#define IMC_REMINFO_EXPIRED 1

#define CHECKMUD( ch, m )                                         \
do {                                                              \
   if (strcasecmp((m), imc_name) && !imc_find_reminfo((m),1))     \
   {                                                              \
      char mbuf[SMST];                                            \
      snprintf( mbuf, SMST, "Warning: '%s' doesn't seem to be active on IMC.\n\r", (m)); \
      imc_to_actor( mbuf, (ch));                                   \
   }                                                              \
} while(0)

#define CHECKMUDOF( ch, n ) CHECKMUD( (ch), imc_mudof((n)) )

/* No real functional difference in alot of this, but double linked lists DO seem to handle better,
 * and they look alot neater too. Yes, readability IS important! - Samson
 */
typedef struct imc_channel IMC_CHANNEL;    /* Channels, both local and non-local */
typedef struct imc_hubinfo HUBINFO;         /* The given mud :) */
typedef struct imc_packet PACKET;           /* It's a packet! */
typedef struct imc_remoteinfo REMOTEINFO;   /* Information on a mud connected to IMC */
typedef struct imc_ignore_data IMC_IGN;     /* Mud level ignore stuff */
typedef struct imcactor_data IMC_CHARDATA;   /* Player flags */
typedef struct imc_ignore IMC_IGNORE;	  /* Player level ignores */

extern IMC_CHANNEL *first_imc_channel;
extern IMC_CHANNEL *last_imc_channel;
extern REMOTEINFO *first_rinfo;
extern REMOTEINFO *last_rinfo;
extern IMC_IGN *first_imc_ignore;
extern IMC_IGN *last_imc_ignore;

struct imc_ignore
{
   IMC_IGNORE *next;
   IMC_IGNORE *prev;
   char *name;
};

struct imcactor_data
{
   int imcperm;       /* Permission level for the player */
   int imcflag;       /* Flags set on the player */
   char *rreply;      /* IMC reply-to */
   char *rreply_name; /* IMC reply-to shown to char */
   char *imc_listen;  /* Channels the player is listening to */
   char *imc_denied;  /* Channels the player has been denied use of */
   IMC_IGNORE	*imcfirst_ignore; /* List of ignored people */
   IMC_IGNORE	*imclast_ignore;
};

/* a player on IMC */
typedef struct
{
  char name[IMC_NAME_LENGTH];	/* name of character */
  int level;			/* trust level */
} imc_actor_data;

struct imc_channel
{
   IMC_CHANNEL *next;
   IMC_CHANNEL *prev;
   char *name;         /* name of channel */
   char *owner;        /* owner (singular) of channel */
   char *operators;    /* current operators of channel */
   bool open;
   char *invited;
   char *excluded;
   char *local_name;
   short level;
   char *regformat;
   char *emoteformat;
   char *socformat;
   char *history[MAX_IMCHISTORY];
   bool refreshed;
};

/* an IMC packet, as seen by the high-level code */
struct imc_packet
{
   char to[IMC_NAME_LENGTH];	/* destination of packet */
   char from[IMC_NAME_LENGTH];	/* source of packet      */
   char type[IMC_TYPE_LENGTH];	/* type of packet        */
   char *key[IMC_MAX_KEYS];
   char *value[IMC_MAX_KEYS];

  /* internal things which only the low-level code needs to know about */
   struct
   {
      char to[IMC_NAME_LENGTH];
      char from[IMC_NAME_LENGTH];
      char path[IMC_PATH_LENGTH];
      unsigned long sequence;
  } i;
};

/* The mud's connection data for the hub */
struct imc_hubinfo
{
   char *hubname;			/* name of hub */
   char *host;			/* hostname of hub */
   char *network;             /* Network name of the hub, set at keepalive - Samson */
   unsigned short port;		/* remote port of hub */
   char *serverpw;		/* server password */
   char *clientpw;		/* client password */
   bool autoconnect;		/* Do we autoconnect on bootup or not? - Samson */

   /* Conection parameters - These don't save in the config file */
   int desc;                /* descriptor */
   unsigned short state;    /* IMC_xxxx state */
   unsigned short version;  /* version of remote site */
   short newoutput;         /* try to write at end of cycle regardless of fd_set state? */
   char *inbuf;		    /* input buffer */
   int insize;
   char *outbuf;		    /* output buffer */
   int outsize;
};

/* IMC statistics */
typedef struct
{
  long rx_pkts;		        /* Received packets                      */
  long tx_pkts;		        /* Transmitted packets                   */
  long rx_bytes;		/* Received bytes                        */
  long tx_bytes;		/* Transmitted bytes                     */

  int max_pkt;                  /* Max. size packet processed            */
  int sequence_drops;           /* Dropped packets due to age            */
} imc_statistics;

/* info about another mud on IMC */
struct imc_remoteinfo
{
   REMOTEINFO *next;
   REMOTEINFO *prev;
   char *name;
   char *version;
   char *network;
   int ping;
   int type;
   char *route;
   char *path;
   unsigned long top_sequence;
};

/* A mudwide ignore entry */
struct imc_ignore_data
{
   IMC_IGN *next;
   IMC_IGN *prev;
   char *name;
};

/* for the versioning table */
typedef struct
{
  int version;
  char *(*generate) (PACKET *);
  PACKET *(*interpret) (char *);
} _imc_vinfo;

/* an entry in the memory table */
typedef struct
{
  char *from;
  unsigned long sequence;
} _imc_memory;

/* site information */
typedef struct
{
  char *name;    /* FULL name of mud */
  char *host;    /* host AND port */
  char *email;   /* contact address (email) */
  char *www;     /* homepage */
  char *details; /* BRIEF description of mud */
  char *base;    /* Name of the mud's codebase */
  int port;      /* The port the mud itself is on */
  bool disconnect;
} imc_siteinfo_struct;

extern char *IMC_VERSIONID;

extern imc_siteinfo_struct imc_siteinfo;

/* the packet memory table */
extern _imc_memory imc_memory[IMC_MEMORY];

/* the version lookup table */
extern _imc_vinfo imc_vinfo[];

/* global stats struct */
extern imc_statistics imc_stats;

/* the local IMC name */
extern char *imc_name;

/* the current time */
extern time_t imc_now;

/* next sequence number to use */
extern unsigned long imc_sequencenumber;

/* Connected state */
extern int imc_active;

/* Internal functions */
void imc_initchannels( void );
void do_imcsend( char *line );
void imc_send( PACKET *p );
char *color_mtoi( const char * );
char *color_itom( const char * );
IMC_CHANNEL *imc_findlchannel( char *name );
