/******************************************************************************
 * Locke's   __                      __         NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5     Version 5 (ALPHA)             *
 * |  /   \  __|  \__/  |  | |  |      |        unreleased+revamped 2004      *
 * |       ||  |        |  \_|  | ()   |                                      *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/

/* Lycanthropics and vampirism */
/* possible future idea: jeckle-n-hyde type changlings */

#if defined(BSD)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "nimud.h"
#include "skills.h"
#include "defaults.h"

#define CON(x)    ( get_curr_con(x) )
#define DEX(x)    ( get_curr_dex(x) )



/*
 * Anyone (PC or NPC) may attempt to bite another.
 */
void cmd_bite( PLAYER_DATA *ch, char *argument ) {

    PLAYER_DATA *vict;

    if ( !IS_LYCANTHROPIC(ch) 
      && !IS_VAMPIRE(ch) ) {
       send_to_actor( "You bite your nails, silly you.\n\r", ch );
       return;
    }

    vict = get_actor_scene( ch, argument );

    if ( !vict ) {
       send_to_actor( "Who?\n\r", ch );
       return;
    }

    if ( IS_VAMPIRE(ch) && IS_VAMPIRE(vict) ) {
       send_to_actor( "Ah, but you are both already vampires...\n\r", ch );
       return;
    }

    if ( !IS_NPC(vict) && vict->position != POS_SLEEPING ) {
       send_to_actor( "You may only bite other players while they are sleeping.\n\r", ch );
       return;
    }

    /* no skill for this, just a percentage chance based on dex */
    if ( number_range( 0, 100 ) >= 50+dex_app[DEX(ch)].defensive
      && number_range( 0, 100 ) >= 50+dex_app[DEX(vict)].defensive ) {
    
        ansi_color( GREEN, ch );
        ansi_color( GREEN, vict );
        act("$n bite$v $N hard on the neck!", ch, NULL, vict, TO_ALL );

        if ( number_range( 0, 100 ) >= con_app[CON(vict)].shock
        && number_range( 0, 100 ) >= con_app[CON(vict)].resistance ) {
   
               char buf[MAX_STRING_LENGTH];

            ansi_color( BOLD, vict );
            send_to_actor( "You feel different.\n\r", ch );

            /* Transfer of the problem.. */
            if ( IS_VAMPIRE(ch) ) {
               if ( IS_NPC(vict) ) SET_BIT(ch->act, ACT_VAMPIRE);
               else SET_BIT(ch->act2, PLR_VAMPIRE);
               sprintf( buf, "%s was bitten and has joined the brood.", NAME(vict) );
               add_history( vict, buf );
            }
            else {
               if ( IS_NPC(vict) ) SET_BIT(ch->act, ACT_LYCANTHROPE);
               else SET_BIT(ch->act2, PLR_LYCANTHROPE);
               sprintf( buf, "%s contracts the disease of lycanthropy.", NAME(vict) );
               add_history( vict, buf );
            }
            
        }
        else {
            BONUS_DATA af;

            ansi_color( GREEN, ch );
            act( "$n chokes and gags.", vict, NULL, NULL, TO_SCENE );
            send_to_actor( "You choke and gag.\n\r", vict );
            af.type      = skill_vnum(skill_lookup("poison"));
            af.duration  = 5;
            af.location  = APPLY_CON;
            af.modifier  = -1;
            af.bitvector = AFF_POISON;
            bonus_join( vict, &af );
        }
        send_to_actor( "Your teeth sink deep into tasty flesh.\n\r", ch );

        if ( IS_VAMPIRE(ch) && !IS_VAMPIRE(vict) ) {

	BONUS_DATA af;

	af.type      = skill_vnum(skill_lookup("lycanthropy"));
	af.duration  = 5;
	af.location  = APPLY_STR;
	af.modifier  = 1;
	af.bitvector = AFF_METAMORPH;
	bonus_join( ch, &af );

        send_to_actor( "You draw your life's energy from the blood you taste.\n\r", ch );
        }
        
    }
    else {
         act( "$N slip$v away before $n can bite $M.", ch, NULL, vict, TO_NOTVICT );
         act( "You avoid being bitten by $N.", vict, NULL, ch, TO_ACTOR );
    }

    ansi_color( NTEXT, ch );
    ansi_color( NTEXT, vict );
    return;
};



/*
 * Routine called by update.c when the moon turns full.
 * Changes descripts and augments player statistics temporarily 
 * until moon changes phase.
 *
 * Phase-based changes effect only PCs.  Use scripts
 * to create the illusion for NPCs.
 */
void change_lycanthropes( bool fWere ) {

    PLAYER_DATA *ch;

    for ( ch = actor_list;  ch != NULL; ch = ch->next ) {
    
     if ( !IS_LYCANTHROPIC(ch) )
         continue;

     if( fWere ) {
		BONUS_DATA af;

		ansi_color( BOLD, ch );
		act( "$n grows claws and teeth because of $s disease.", ch, NULL, NULL, TO_SCENE );
		send_to_actor( "You growl and snarl, growing long teeth and fur.\n\r", ch );

		af.type      = skill_vnum(skill_lookup("lycanthropy"));
		af.duration  = 10;
		af.location  = APPLY_STR;
		af.modifier  = 10;
		af.bitvector = AFF_METAMORPH;
		bonus_join( ch, &af );
                ansi_color( NTEXT, ch );

           free_string( ch->short_descr );
           ch->short_descr = str_dup( "a werewolf" );
           free_string( ch->long_descr );
           ch->long_descr = str_dup( "A long-haired werewolf growls and snarls.\n\r" );           
     }
     else {
        if ( ch->short_descr != NULL ) {
	free_string( ch->short_descr );
        free_string( ch->long_descr );
        ch->short_descr = NULL;
	ch->long_descr = NULL;

        send_to_actor( "You return to human form.\n\r", ch );
  	act( "$n returns to human form.", ch, NULL, NULL, TO_SCENE );
        }
     }
        
    }

    return;
};
