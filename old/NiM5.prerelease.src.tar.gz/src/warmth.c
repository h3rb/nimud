/******************************************************************************
 * Locke's   __ -based on merc v5.0-____        NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5.1a  Version 5.1a                  *
 * |  /   \  __|  \__/  |  | |  |      |        documentation release         *
 * |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/


/*
 * Returns the temperature of the
 * scene the character is in.
 */
int scene_temp( PLAYER_DATA *ch, ROOM_INDEX_DATA *pScene ) {
    EXIT_DATA *pExit;
        int direction = 0;
        int scene_temp = 0;
        int temp_adjust = 0;
        int temp = weather_info.temperature;

        if ( IS_NPC( ch ) || !ch->in_scene )
                return 0;

        /*
         * If I am not mistaken this doesn't work as of yet.
         * I am rather lazy so I dont know if I will get this
         * part working ever.  What it is SUPPOSE to do is if
         * the current scene your in has exits that lead to the
         * outside and they don't have doors or the doors are
         * open then the scene temperature drops down.
         * Also I should add a check to see if the exit is a
         * window and if the window is open I just keep forgetting
         * about that.  Also Daurven you need to add that check into
         * the archery code you dumb shit.
         *                                               -- Daurven
         */
    for( direction = 0;  direction < MAX_DIR; direction++ ) {
        pExit = ch->in_scene->exit[direction];

                if ( IS_SET( ch->in_scene->scene_flags, ROOM_INDOORS )
                && ch->in_scene->scene_temp != 0 ) {
                        if ( pExit != NULL && !IS_SET( pExit->exit_info, EX_CLOSED )
                        && !IS_SET( pExit->to_scene->scene_flags, ROOM_INDOORS ) )
                                scene_temp = temp / 2 - ch->in_scene->scene_temp;
                        else
                                scene_temp = ch->in_scene->scene_temp;
                }
        }

        switch (ch->in_scene->sector_type) {
        default:
                temp_adjust = 0;
                break;
        case SECT_INSIDE:
                case SECT_CITY:
                temp_adjust = 0;
                break;
        case SECT_DESERT:
                temp_adjust = 10;
                break;
        case SECT_ICELAND:
                temp_adjust = -30;
                break;
        case SECT_MOUNTAIN:
                temp_adjust = -15;
                break;
        case SECT_HILLS:
                case SECT_FIELD:
                temp_adjust = -5;
                break;
                case SECT_FOREST:
                        temp_adjust = -10;
                        break;
        case SECT_AIR:
                temp_adjust = -3;
                break;
    }

        scene_temp += temp_adjust;
        temp += scene_temp;
        return temp;
}
