/******************************************************************************
 * Locke's   __ -based on merc v5.0-____        NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5.1a  Version 5.1a                  *
 * |  /   \  __|  \__/  |  | |  |      |        documentation release         *
 * |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/

/*
 * Please note the following terminology used throughout the script parser.
 *
 * owner   -> pointer to the original prop, actor or scene that is running
 *             the script trigger
 *
 * type     ->  of TYPE_ROOM, TYPE_EXIT, TYPE_OBJECT or TYPE_ACTOR
 *
 * This is the ickiest part of the whole script scriptess: multiple index
 * type support.  In order to have triggers are these three props,
 * many hacks have been placed to permit this.  Be very careful when
 * referring to owner variables.
 *
 * What's a literal statement?   Items enclosed in {,} brackets that
 * do not evaluate their variables until the second pass by a function.
 * Nest for other desired effects.
 *
 * What is a trigger versus a script?
 *
 * Triggers are instances that point to code and lists of variables.
 * Think of them as seperate scriptesses.  Each trigger is at some
 * stage of script parsing: either it is parsing a line of code,
 * or its performing a wait state, or its halted.
 *
 * A script is "script index data" which is the database entry for
 * the script.  It contains the code and the trigger specifications for
 * a particular scriptedure, but is a static entity (unless a builder
 * is editing it).  It provides a way to make multiple instances of
 * the same code.
 *
 * How is this language constructed?
 *
 * There are two types of commands a scriptedure writer can write: one is
 * a variable assignment, and the other is a function call.
 *
 * This limits the ability of the code but maximizes the standards by
 * which the code is designed, and hopefully keeps it simple for the
 * user.
 *
 * It is also very picky and has no compiler: so lots of debugging is
 * by using the debugging commands in accordance with trial-and-error
 * coding techniques.
 *
 * Its versatile enough to make a lever or a simple spec script, but can
 * be extensible through spec_scripts or by the addition of new functions
 * that provide special actions.
 *
 * Conditionals are a difficulty in this code.  It is not a very versatile
 * script language in this sense, but could provide a structure for
 * very complicated scripts, with minimal strain on resources.
 * (Switch() is coming)
 *
 * if() statements are limited because they do not allow delays in their
 * direct branches, but can brance to subroutines.
 *
 * point:  if statements should use goto()s as their branches, unless
 *         you are doing something simple.
 *
 * for instance:
 * if ( cmp(random(4),1), goto(label1), goto(label2) );
 */

#if defined(BSD)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "nimud.h"
#include "script.h"
#include "function.h"

/*
 * Locals.
 */
char * eval_expression        args( ( void * owner, int type, char *exp ) );



/*
 * Returns the currently parsing trigger of the owner.
 */
TRIGGER_DATA *curtrig( void * owner, int type )
{
    PROP_DATA *obj;
    PLAYER_DATA *ch;
    ROOM_INDEX_DATA *scene;

    switch ( type )
    {
       case TYPE_OBJ:  obj  = (PROP_DATA *)owner;        return obj->current;
       case TYPE_ACTOR:  ch   = (PLAYER_DATA *)owner;       return ch->current;
       case TYPE_ROOM: scene = (ROOM_INDEX_DATA *)owner; return scene->current;
        default:
         bug( "Curtrig: Invalid requested owner-type.", 0 );
         return NULL;
    }
}



/*
 * Return a pointer to the globals of a said owner.
 */
VARIABLE_DATA **varlist( void * owner, int type )
{
    PROP_DATA *obj;
    PLAYER_DATA *ch;
    ROOM_INDEX_DATA *scene;

    switch ( type )
    {
       case TYPE_OBJ: obj  = (PROP_DATA *)owner;        return &obj->globals;
       case TYPE_ACTOR: ch   = (PLAYER_DATA *)owner;       return &ch->globals;
      case TYPE_ROOM: scene = (ROOM_INDEX_DATA *)owner; return &scene->globals;
             default: bug( "Varlist: Invalid requested owner-type.", 0 );
                      return NULL;
    }
}




/* 
 * Remove a variable from the list.
 */
void rem_variable( VARIABLE_DATA **vlist, char *name )
{
   VARIABLE_DATA *v, *vp;

    vp = NULL;
    for ( v = *vlist;  v != NULL;  v = v->next )
    {
        if ( !str_cmp( v->name, name ) )
        break;
        vp = v;
    }

    if ( v == NULL ) return;

    if ( vp == NULL && v != NULL )
         (*vlist) = (*vlist)->next;

    if ( vp != NULL && v != NULL )
         vp->next = v->next;
        
    free_variable(v);
    return;
}

/*
 * Searches a variable list for a variable with supplied name.
 */
VARIABLE_DATA *get_variable( VARIABLE_DATA *vlist, char *name )
{
    VARIABLE_DATA *v;

    for ( v = vlist;  v != NULL;  v = v->next )
    {
        if ( !str_cmp( v->name, name ) )
        break;
    }
    return v;
}




/*
 * Searches the owner's list for a variable with supplied name.
 * In my later years, I'm beginning to wonder why this code is here.
 * Answer = translate_variables
 */
VARIABLE_DATA *find_variable( void * owner, int type, char *name )
{
    VARIABLE_DATA *v;
    TRIGGER_DATA *trig = curtrig(owner,type);

    if ( trig )
    {
        for ( v = trig->locals;  v != NULL;  v = v->next )
        {
            if ( !str_cmp( v->name, name ) )
            break;
        }

        if ( v ) return v;
    }


    for ( v = *varlist(owner,type);  v != NULL;  v = v->next )
    {
        if ( !str_cmp( v->name, name ) )
        break;
    }

    return v;
}



/*
 * Grabs a variable from the beginning of an argument, *argument must be
 * pointing to first %.
 *
 * This is used for assigning variables in the script interpreter.
 */
char *grab_variable( char *argument, char *vname )
{
    argument = skip_spaces( argument );
    if ( *argument != '%' )
    {
        *vname = '\0';
        return argument;
    }

    *vname++ = *argument++;
    while ( *argument != '%' && *argument != '\0' ) *vname++ = *argument++;

    *vname++ = '%';
    *vname++ = '\0';

    return skip_spaces( ++argument );
}



/*
 * Translates all variables on said owner's expression if "%string%,"
 * ignoring parsing of literals.  (Strips the literals out)
 */
char *translate_variables_noliterals( void * owner, int type, char *exp )
{
    VARIABLE_DATA *var;
    char buf[MAX_STRING_LENGTH];
    char *point;
    char *vpoint;
    char vname[MAX_STRING_LENGTH];


    point = buf;
    while ( *exp != '\0' )
    {
        /*
         * Ignore literals.
         */
        if ( *exp == '}' || *exp == '{' || *exp == ']' || *exp == '[' )
        { 
           exp++;
           continue;
        }
        
        if ( *exp == '%' )
        {
            vname[0] = '\0';
            vpoint = vname;

            /*
             * %variable%
             * ^
             */

            *vpoint++ = *exp++;
            while ( *exp != '%' && *exp != '\0' ) *vpoint++ = *exp++;

            *vpoint++ = '%';
            *vpoint++ = '\0';

            /*
             * %variable%
             *           ^
             */

            var = find_variable( owner, type, vname );

            if ( var != NULL
             && var->type == TYPE_STRING )
            {
                /* Insert value */
                vpoint = var->value;
                while ( !MTD(vpoint) ) *point++ = *vpoint++;
            }
            else
            {
                vpoint = vname;
                while ( *vpoint != '\0' ) *point++ = *vpoint++;
            }
        }
        else
        *point++ = *exp++;
    }

    *point = '\0';

    return str_dup( buf );
}



/*
 * Translates all variables on said owner's expression if "%string%,"
 * except those contained within literal statements.   { like this }
 */
char *translate_variables( void * owner, int type, char *exp )
{
    VARIABLE_DATA *var;
    char buf[MAX_STRING_LENGTH];
    char *point;
    char *vpoint;
    char vname[MAX_STRING_LENGTH];


    point = buf;
    while ( *exp != '\0' )
    {
        if ( *exp == '%' )
        {
            vname[0] = '\0';
            vpoint = vname;

            /*
             * %variable%
             * ^
             */
            while ( *exp != '\0' )
            {
                *vpoint++ = *exp++;

                if ( *exp == '%' )
                    break;
            }

            *vpoint++ = *exp++;
            *vpoint = '\0';

            var = find_variable( owner, type, vname );

            if ( var != NULL
             && var->type == TYPE_STRING )
            {
                vpoint = var->value;
                while ( !MTD(vpoint) ) *point++ = *vpoint++;
            }
            else
            {
                vpoint = vname;
                while ( *vpoint != '\0' ) *point++ = *vpoint++;
            }
        }
        else
        {
            /*
             * Jump past literals.
             */
            if ( *exp == '{' || *exp == '[' )
            {
                int curlies = 0;

                *point++ = *exp++;
                while( *exp != '\0' )
                {

                    /*
                     * Ok, get the hell out of here, we're done.
                     * { .... }
                     *        ^
                     */
                    if ( curlies == 0 )
                       if ( *exp == '}' || *exp == ']'
                         || *exp == '\0' )
                         break;

                    if ( *exp == '{' || *exp == '[' ) curlies++;
                    else
                    if ( *exp == '}' || *exp == ']' ) curlies--;

                    *point++ = *exp++;
                }

                if ( curlies != 0 )
                NOTIFY("Notify>  Translate_variables: Unmatched {}s in literal.", LEVEL_IMMORTAL, WIZ_NOTIFY_SCRIPT);

                if ( *exp == '}' || *exp == ']' ) *point++ = *exp++;
            }
            else
            *point++ = *exp++;
        }
    }

    *point = '\0';

    return str_dup( buf );
}





/*
 * Receives: func(param, .... )
 * Breaks up parameters, and recurses into each.
 *
 * To add a new function, simply add it to the long if-statements.
 */
VARIABLE_DATA *eval_function( void * owner, int type, char *exp )
{
    VARIABLE_DATA *value;
    char func_name[MAX_STRING_LENGTH];
    char buf[MAX_STRING_LENGTH];
    char params [MAX_PARAMS][MAX_STRING_LENGTH];
    VARIABLE_DATA *ppoint[MAX_PARAMS];
    char *point;
    char *original;
    int x;

    if ( *exp == '\0' ) return NULL;
    if ( *exp == '{' || *exp == '['  )
    {
        value = new_variable( );
        value->value = str_dup( exp );
        value->type  = TYPE_STRING;
        return value;
    }
    original = exp;

    /*
     * Prepare the pointers for the parameters.
     */
    for ( x = 0; x < MAX_PARAMS; x++ )
    {
        params[x][0] = '\0';
        ppoint[x] = NULL;
    }

    /*
     * Grab the function name.
     * func(param, .... )
     * ^
     */
    exp = skip_spaces( exp );
    point = func_name;
    while ( *exp != '('
         && *exp != ' '
         && *exp != '\0' ) *point++ = *exp++;
    *point = '\0';
    exp = skip_spaces( exp );

    /*
     * Grab and evaluate, recursively, each parameter.
     * func(param, .... )
     *     ^
     */
    if ( *exp != '\0' ) exp++;
    for ( x = 0;  (*exp != '\0') && (x < MAX_PARAMS);  x++ )
    {
        int param_paren = 0;

        /*
         * Grab the parameters.
         * func(param, .... )
         *      ^---^  ^--^
         *        1  to  x
         */

        point = params[x];
        while( *exp != '\0' )
        {
            /*
             * Jump past literals.
             */
            if ( *exp == '{' || *exp == '[' )
            {
                int curlies = 0;

                *point++ = *exp++;
                while( *exp != '\0' )
                {

                    /*
                     * Ok, get the hell out of here, we're done.
                     * { .... }
                     *        ^
                     */
                    if ( curlies == 0 )
                       if ( *exp == '}' || *exp == ']'
                         || *exp == '\0' )
                         break;

                    if ( *exp == '{' || *exp == '[' ) curlies++;
                    else
                    if ( *exp == '}' || *exp == ']' ) curlies--;

                    *point++ = *exp++;
                }

                if ( curlies != 0 )
                NOTIFY("Notify>  Eval_function: Unmatched {}s in literal.", LEVEL_IMMORTAL, WIZ_NOTIFY_SCRIPT);

                if ( *exp == '}' || *exp == ']' ) *point++ = *exp++;
            }

            /*
             * Ok, get the hell out of here, we're done.
             * func(param, .... )
             *           ^  or  ^
             */
            if ( param_paren == 0 )
                if ( *exp == ','
                  || *exp == ')'
                  || *exp == '\0' )
                {
                    if ( *exp == ',' || *exp == ')' ) exp++;
                    break;
                }


            if ( *exp == '(' ) param_paren++;
            else
            if ( *exp == ')' ) param_paren--;

/*            if ( *exp == ' ' ) exp++;
            else */ *point++ = *exp++;
        }

        *point = '\0';

        /*
         * Evaluate each one.
         */

        ppoint[x] = eval_function( owner, type, params[x] );

   /*     bug( "params[%d]:", x );
          bug( params[x],0 );
          bug( ppoint[x],0 );         */
    }


    buf[0] = '\0';

    /*
     * Remember, ppoint[] now contains the evaluated values.
     * Place more often called functions first.
     *
     * Idea for improvement: make this list dynamic (a linked list of
     * functions, defined at startup as pointers to table indexes),
     * and save call counts.  Sort the list during database saves.
     * Then iterate the list here.
     */

    /* Note to self: change functionality of goto() here
     * If the goto() function is called, it jumps the code immediately
     * This will need to be changed to accomplish statements like:
     * if (this, goto(this), goto(that) ); 
     */

value = NULL;
switch ( func_name[0] ) {

 case 'g':
    FUNC("goto",     func_goto    (owner, type, ppoint[0]) );
    else
    FUNC("greater",  func_greater (owner, type, ppoint[0], ppoint[1]) );
 break;

 case 'a':
    FUNC("autowait", func_autowait(owner, type, ppoint[0]) );
    else
    FUNC("and",      func_and     (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("add",      func_add     (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("alert",    func_alert   (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("addowed",  func_addowed (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("addbounty",func_addbounty (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("act",      func_act     (owner, type, ppoint[0], ppoint[1], ppoint[2], ppoint[3], ppoint[4]) );
 break;

 case 'b':
    FUNC("bounty",   func_bounty  (owner, type, ppoint[0]) );
    else
    FUNC("band",     func_band    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("bor",      func_bor     (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("bxor",     func_bxor    (owner, type, ppoint[0], ppoint[1]) );
 break;

 case 'i':
    FUNC("if",       func_if      (owner, type, ppoint[0], ppoint[1], ppoint[2]) );
    else
    FUNC("in",       func_in      (owner, type, ppoint[0], ppoint[1]) );
 break;

 case 'f':
    FUNC("foreach",func_foreach (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("force",    func_force   (owner, type, ppoint[0]) );
 break;


 case 'c':
    FUNC("create",   func_create  (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("close",    func_close   (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("call",     func_call    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("cmp",      func_cmp     (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("cat",      func_cat     (owner, type, ppoint[0], ppoint[1]) );
 break;


case 'o':
    FUNC("or",       func_or      (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("os",       func_os      (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("open",     func_open    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("owed",     func_owed     (owner, type, ppoint[0]) );
break;


case 'm':
    FUNC("mult",     func_mult    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("move",     func_move    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("month",    func_month   (owner, type) );
    else
/*    FUNC("makescene", func_makescene (owner, type, ppoint[0], ppoint[1]) ); 
      else */
    FUNC("moon",     func_moon    (owner, type) );
    else
    FUNC("ms",       func_ms      (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("moveall",  func_moveall  (owner, type, ppoint[0], ppoint[1], ppoint[2]) );
    else
    FUNC("mix",      func_mix (owner, type, ppoint[0], ppoint[1], ppoint[2]) );
    else
    FUNC("mana",     func_mana    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("mod",      func_mod     (owner, type, ppoint[0], ppoint[1]) );
break;

case 'w':
    FUNC("wait",     func_wait    (owner, type, ppoint[0]) );
    else
    FUNC("weather",  func_weather (owner, type) );
    else
    FUNC("word",     func_word    (owner, type, ppoint[0], ppoint[1]) );
break;

case 'n':
    FUNC("name",     func_tname    (owner, type, ppoint[0]) );
    else
    FUNC("not",      func_not     (owner, type, ppoint[0]) );
    else
    FUNC("numw",     func_numw    (owner, type, ppoint[0]) );
break;

case 'd':
    FUNC("do",       func_do      (owner, type, ppoint[0], ppoint[1], ppoint[2], ppoint[3], ppoint[4], ppoint[5] ) );
    else
    FUNC("disarm",   func_disarm  (owner, type, ppoint[0]) );
    else
    FUNC("dispense", func_dispense (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("div",      func_div     (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("dream",    func_dream   (owner, type, ppoint[0]) );
    else
    FUNC("death",    func_death   (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("dayofweek",     func_dayofweek  (owner, type) );
    else
    FUNC("day",      func_day     (owner, type) );
    else
    FUNC("dig",      func_dig     (owner, type, ppoint[0], ppoint[1], ppoint[2] ) );
break;

case 'j':
    FUNC("jump",     func_jump    (owner, type, ppoint[0]) );
break;

case 'e':
    FUNC("empty", func_empty (owner, type, ppoint[0]) );
    else
    FUNC("each",func_each (owner, type, ppoint[0]) );
    else
    FUNC("elude",    func_elude   (owner, type) );
    else
    FUNC("eat",      func_eat     (owner, type, ppoint[0]) );
    else
    FUNC("e",        func_eval    (owner, type, ppoint[0]) );
break;

case 'h':
    FUNC("here",     func_here    (owner, type) );
    else
    FUNC("heal",     func_heal    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("hurt",     func_hurt    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("home",     func_home    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("halt",     func_halt    (owner, type, ppoint[0]) );
    else
    FUNC("history",  func_history (owner, type, ppoint[0], ppoint[1]) );
break;

case 's':
    FUNC("self",     func_self    (owner, type, ppoint[0]) );
    else
    FUNC("strstr",   func_strstr  (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("samescene", func_samescene(owner, type, ppoint[0]) );
    else
    FUNC("sub",      func_sub     (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("strp",     func_strp    (owner, type, ppoint[0], ppoint[1], ppoint[2]) );
    else
    FUNC("strip",    func_strip   (owner, type, ppoint[0]) );
    else
    FUNC("sort",func_sort (owner, type, ppoint[0], ppoint[1]) );
break;

case 't':
    FUNC("time",     func_time    (owner, type) );
break;

case 'p':
    FUNC("permhalt", func_permhalt(owner, type ) );
    else
    FUNC("push",func_push (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("pay",      func_pay   (owner, type, ppoint[0], ppoint[0]) );
    else
    FUNC("purge",    func_purge   (owner, type, ppoint[0]) );
    else
    FUNC("pre",      func_pre     (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("pos",      func_pos   (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("pop",  func_pop (owner, type, ppoint[0]) );
/*
    else
    FUNC("players",  func_players (owner, type) );
 */
break;

case 'l':
    FUNC("label",    func_label   (owner, type) );
    else
    FUNC("less",     func_less    (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("lrem",func_lrem (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("lrnd",func_lrnd (owner, type, ppoint[0]) );
    else
    FUNC("level", func_level (owner, type, ppoint[0]) );
    else
    FUNC("lshift",func_lshift (owner, type, ppoint[0]) );
break;

case 'r':
    FUNC("reagents", func_reagents (owner, type, ppoint[0], ppoint[1], ppoint[2]) );
    else
    FUNC("reset",    func_spawn   (owner, type, ppoint[0]) );
    else
    FUNC("range",    func_range   (owner, type, ppoint[0], ppoint[1], ppoint[2]) );
    else
    FUNC("random", func_random (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("recho",    func_recho   (owner, type, ppoint[0], ppoint[1]) );
    else
    FUNC("rshift",func_rshift (owner, type, ppoint[0]) );
    else
    FUNC("return",   func_return  (owner, type, ppoint[0]) );
    else
    FUNC("rndplr",   func_rndplr  (owner, type, ppoint[0]) );
    else
    FUNC("rnddir",   func_rnddir  (owner, type) );
    else
    FUNC("rtitle",   func_rtitle  (owner, type, ppoint[0], ppoint[1]) );
break;

case 'y':
    FUNC("year",     func_year    (owner, type) );
break;

case 'u':
    FUNC("users", func_users (owner, type, ppoint[0]) );
    else
    FUNC("undig", func_undig( owner, type, ppoint[0], ppoint[1] ) );
break;

default:
    {
        value = new_variable();
        value->type = TYPE_STRING;
        value->value = str_dup( original );
    }
break;
}
    /*
     * Flush the parameters.
     */
    for ( x = 0; x < MAX_PARAMS; x++ ) free_variable( ppoint[x] );
    return value;
}



/*
 * Assigns a variable, creating a new one if required.
 * Note string routines embedded in scriptedure.
 */
void assign_var( void * owner, int type, VARIABLE_DATA *var, char *name )
{
    VARIABLE_DATA *v;
    TRIGGER_DATA *trig = curtrig(owner,type);

    v = find_variable( owner, type, name );

    if ( v == NULL && trig == NULL )
    return;

    if ( v )
    {
        if ( v->type == TYPE_STRING )
        {
            free_string( (char *)v->value );
            v->value = str_dup( "" );
        }
    }
    else
    {
        v = new_variable( );
        v->next = trig->locals;
        trig->locals = v;
        v->name = str_dup( name );
        v->value = str_dup( "" );
    }

    if (var == NULL) return;

    v->type = var->type;
    v->value = var->type == TYPE_STRING ? str_dup( var->value ) : var->value;

    return;
}



/*
 * Handles assignment statements
 */
void parse_assign( TRIGGER_DATA *trig, char *line, void * owner, int type )
{
    char vname[MAX_STRING_LENGTH];
    VARIABLE_DATA *value;

    line = grab_variable( line, vname );
    value = eval_function( owner, type, line );
    assign_var( owner, type, value, vname );
    free_variable(value);
    return;
}




/*
 * The script parser
 */
void parse_script( TRIGGER_DATA *trig, void * owner, int type )
{
    PLAYER_DATA *ch, *bch;
    VARIABLE_DATA *pVar; /* tracking code */
    PROP_DATA *obj;
    ROOM_INDEX_DATA *scene;
    char buf[MAX_STRING_LENGTH];
    char *commands;
/*
    char *current_line;
 */
    int rvnum = 0;

    if ( trig == NULL )
    {
        bug( "Parse_script: NULL trig.", 0 );
        return;
    }

    if ( owner == NULL )  {
    bug( "Parse_script: NULL owner.", 0 );
    return;
    }

    switch ( type )
    {
       case TYPE_OBJ:
         obj  = (PROP_DATA *)owner;
         obj->current  = trig;
         rvnum = obj->in_scene ? obj->in_scene->vnum : 0;
        break;
       case TYPE_ACTOR:
         ch   = (PLAYER_DATA *)owner;
         ch->current   = trig;
         rvnum = ch->in_scene->vnum;
        break;
       case TYPE_ROOM:
         scene = (ROOM_INDEX_DATA *)owner;
         scene->current = trig;
         rvnum = scene->vnum;
        break;
       default:
         bug( "Parse_script: Invalid requested owner-type.", 0 );
        break;
    }

        /*
         * Tracking Code
         */
    if ( trig->location != NULL )
    {
        for ( bch = char_list;  bch != NULL;  bch = bch->next )
        {
            if ( bch->pcdata == NULL )
                continue;

            if ( bch->pcdata->trackscr != owner )
                continue;

            if ( trig->wait < trig->autowait )
                continue;

            if ( trig->wait > trig->autowait && trig->autowait == 0 )
                continue;

            /*
             * Isolate one line of code. (TO BE ADDED)
             */

            sprintf( buf, "-------------------====[%5d in %5d] %s (%d, auto %d) If: %d\n\r%s",
                     trig->script->vnum, rvnum, trig->script->name,
                     trig->wait, trig->autowait, trig->last_conditional,
                     trig->location );
            send_to_char( buf, bch );

            for ( pVar = trig->locals;  pVar != NULL;  pVar = pVar->next )
            {
                sprintf( buf, "  [%2d] %s ", pVar->type, pVar->name );
                send_to_char( buf, bch );

                switch ( pVar->type )
                {
                    case TYPE_STRING: sprintf( buf, " = \"%s\"\n\r", (char *)pVar->value ); break;
                    case TYPE_ACTOR:    sprintf( buf, " = %s\n\r", NAME( (PLAYER_DATA *)pVar->value ) ); break;
                    case TYPE_OBJ:    sprintf( buf, " = obj %d\n\r", ((PROP_DATA  *)pVar->value)->pIndexData->vnum ); break;
                    case TYPE_ROOM:   sprintf( buf, " = scene %d\n\r", ((ROOM_INDEX_DATA *)pVar->value)->vnum ); break;
                    default:          sprintf( buf, " = <unknown:%d>\n\r", pVar->type ); break;
                }
                send_to_char( buf, bch );
            }
        }
    }

    if ( trig->wait != 0 ) trig->wait--;
    gotoloops = 0;

    /*
     * Iterate through a set of code lines.
     * Stop when the script is halted, finished or delayed.
     */
    while ( !IS_SET(trig->bits, SCRIPT_HALT)
         && !MTD(trig->location)
         && trig->wait == 0 )
    {
        /*
         * Advance a line.
         */
        trig->location = one_line( trig->location, buf );
        commands = skip_spaces( buf );

        if ( *commands == '\0' ) continue;

        /*
         * Actually call a function or assign a variable.
         */
        if ( *commands == '%' )
        parse_assign( trig, commands, owner, type );
        else
        {
            VARIABLE_DATA *value;

            value = eval_function( owner, type, commands );
            free_variable( value );
        }

        if ( trig->autowait) trig->wait = trig->autowait;
    }

    /*
     * Are we done?
     * If so, remove all variables associated with this script.
     */
    if ( MTD(trig->location) )
    {
        VARIABLE_DATA *pVar, *pVar_next;

        for ( pVar = trig->locals;  pVar != NULL; pVar = pVar_next )
        {
            pVar_next = pVar->next;
            free_variable( pVar );
        }

        trig->locals = NULL;
        trig->location = NULL;
    }
    return;
}



/*
 * Sets a trigger on the owner by beginning the parse.
 */
int trigger( void * owner, int type, TRIGGER_DATA *trig )
{
    int returned;

    trig->location = trig->script->commands;
    parse_script( trig, owner, type );
    returned = trig->returned;                 /* Save returned value.    */
    trig->returned = 0;                        /* Default returned value. */
    return returned;
}



/*
 * Quick and dirty multi-purpose script owner, used in most hard-code calls.
 */
int script_update( void * owner, int type, int ttype, PLAYER_DATA *actor,
                    PROP_DATA *catalyst, char *astr, char *bstr  )
{
    TRIGGER_DATA *trig;
    ROOM_INDEX_DATA *scene =NULL;
    PLAYER_DATA *ch =NULL;
    PROP_DATA *obj =NULL;
    int returned = 0;
    
    switch ( type )
    {
       case TYPE_OBJ:  obj = (PROP_DATA *)owner; trig = obj->triggers; break;

       case TYPE_ACTOR:  ch  = (PLAYER_DATA *)owner; trig = ch->triggers; break;

       case TYPE_ROOM: scene = (ROOM_INDEX_DATA *)owner; trig = scene->triggers;
                       break;

       default: trig = NULL;
                bug( "Trigger: Invalid requested owner-type.", 0 );   break;
    }
    
    for ( ; trig != NULL; trig = trig->next )
    {

        if ( trig->script->type != ttype
          || trig->location != NULL )
        continue;

        {
            TRIGGER_DATA *oldtrig = curtrig(owner,type);
            VARIABLE_DATA *var;

            switch ( type )
            {
               case TYPE_OBJ:  obj->current  = trig; break;
               case TYPE_ACTOR:  ch->current   = trig; break;
               case TYPE_ROOM: scene->current = trig; break;
               default: break;
            }

    if ( trig != NULL && trig->script->type != TRIG_EACH_PULSE ) {
          char buf[MAX_STRING_LENGTH];
          sprintf( buf, "Notify> Script %d, %s triggered by %s%s%s%s%s%s%s%s", trig->script->vnum, trig->script->name, actor ? NAME(actor) : "",
												  catalyst != NULL ? " " : "",
												  catalyst != NULL  ? STR(catalyst,short_descr) : "",
												  astr != NULL || bstr != NULL ? " with the following variables:" : ".",
												  astr ? "\n%astr% = " : "", astr != NULL ? astr : "",
												  bstr ? "\n%bstr% = " : "", bstr != NULL ? bstr : "" );
	  NOTIFY( buf, LEVEL_IMMORTAL, WIZ_NOTIFY_SCRIPT);
     }

            var = new_variable( );

            if ( actor )
            {
                var->type  = TYPE_ACTOR;
                var->value = (PLAYER_DATA *)actor;
                assign_var( owner, type, var, "%actor%" );

                var->type = TYPE_STRING;
                var->value = (char *)str_dup( STR((PLAYER_DATA *)actor,name));
                assign_var( owner, type, var, "%aname%" );
                free_string((char *)var->value);
            }

            if ( catalyst )
            {
                var->type = TYPE_OBJ;
                var->value = (PROP_DATA *)catalyst;
                assign_var( owner, type, var, "%catalyst%" );
            }

            if ( astr )
            {
                var->type = TYPE_STRING;
                var->value = str_dup( astr );
                assign_var( owner, type, var, "%astr%" );
            }

            if ( bstr )
            {
                var->type = TYPE_STRING;
                var->value = str_dup( bstr );
                assign_var( owner, type, var, "%bstr%" );
            }

            switch ( type )
            {
               case TYPE_OBJ:  obj->current  = oldtrig; break;
               case TYPE_ACTOR:  ch->current   = oldtrig; break;
               case TYPE_ROOM: scene->current = oldtrig; break;
               default: break;
            }

            free_variable( var );
        }
          
        if ( (returned = trigger(owner, type, trig)) ) break;
    }

    return returned;
}



/*
 * Triggers a list of props, like above, quick and dirty.
 */
void trigger_list( PROP_DATA *list, int ttype, PLAYER_DATA  *actor,
                  PROP_DATA *catalyst, char *astr, char *bstr )
{
    PROP_DATA *obj, *prop_next;

    for ( obj = list;  obj != NULL;  obj = prop_next )
    {
        prop_next = obj->next_content;

        script_update( obj, TYPE_OBJ, ttype, actor, catalyst, astr, bstr );
    }

    return;
}


extern VARIABLE_DATA *mud_var_list;  /* from mem.c */


/*
 * This little command helps a user debug the scripts online.  It can give
 * information about a single trigger, or general info on the actor's current
 * state of execution.
 */
void cmd_script( PLAYER_DATA *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    char buf[MAX_STRING_LENGTH];
    PLAYER_DATA *victim;
/*
    void * owner;
    int type;
 */

    if ( IS_NPC(ch) || ch->pcdata == NULL )
        return;

    one_argument( argument, arg );
    if ( arg[0] == '\0' )
    {
    send_to_char( "Tracking stopped.\n\r", ch );
    ch->pcdata->trackscr = 0;
	return;
    }

    if ( !str_cmp( arg, "variables" ) )
    {
        VARIABLE_DATA *pVar;

        send_to_char ( "Mud-wide script variables:\n\r", ch );
        for ( pVar = mud_var_list;  pVar != NULL;  pVar = pVar->next_mud_var )
        {
            sprintf( buf, "  [%2d] %s ", pVar->type, pVar->name );
            send_to_char( buf, ch );

            switch ( pVar->type )
            {
                case TYPE_STRING: sprintf( buf, " = \"%s\"\n\r", (char *)pVar->value ); break;
                case TYPE_ACTOR:    sprintf( buf, " = %s\n\r", NAME( (PLAYER_DATA *)pVar->value ) ); break;
                case TYPE_OBJ:    sprintf( buf, " = obj %d\n\r", ((PROP_DATA  *)pVar->value)->pIndexData->vnum ); break;
                case TYPE_ROOM:   sprintf( buf, " = scene %d\n\r", ((ROOM_INDEX_DATA *)pVar->value)->vnum ); break;
                       default:   sprintf( buf, " = <unknown:%d>\n\r", pVar->type ); break;
            }
            send_to_char( buf, ch );
        }

        return;
    }


    if ( ( victim = get_char_world( ch, arg ) ) == NULL )
    {
    send_to_char( "They aren't here.\n\r", ch );
	return;
    }

    if ( IS_NPC(victim) )
    {
        bool fFound = FALSE;
        TRIGGER_DATA *pTrig;
        VARIABLE_DATA *pVar;

        ch->pcdata->trackscr = victim;

        sprintf( buf, "Tracking %s in %s, scripts:\n\r", NAME(victim),
                                                       victim->in_scene->name );
        send_to_char( buf, ch );

        for ( pTrig = victim->triggers; pTrig != NULL;  pTrig = pTrig->next )
        {
            fFound = TRUE;

            sprintf( buf, "-==[TRACKING]==---------[%5d] %s (%d, auto %d)\n\r%s",
                     pTrig->script->vnum, pTrig->script->name,
                     pTrig->wait, pTrig->autowait,
                     pTrig->location ? pTrig->location : "" );
            send_to_char( buf, ch );

            for ( pVar = pTrig->locals;  pVar != NULL;  pVar = pVar->next )
            {
            sprintf( buf, "  [%2d] %s ", pVar->type, pVar->name );
            send_to_char( buf, ch );

            switch ( pVar->type )
            {
                case TYPE_STRING: sprintf( buf, " = \"%s\"\n\r", (char *)pVar->value ); break;
                case TYPE_ACTOR:    sprintf( buf, " = %s\n\r", NAME( (PLAYER_DATA *)pVar->value ) ); break;
                case TYPE_OBJ:    sprintf( buf, " = obj %d\n\r", ((PROP_DATA  *)pVar->value)->pIndexData->vnum ); break;
                case TYPE_ROOM:   sprintf( buf, " = scene %d\n\r", ((ROOM_INDEX_DATA *)pVar->value)->vnum ); break;
                       default:   sprintf( buf, " = <unknown:%d>\n\r", pVar->type ); break;
            }
            send_to_char( buf, ch );
            }
        }
        if ( !fFound )
        send_to_char( "None.\n\r", ch );
    }

    return;
}

/*
 * Godspeak.  Tests scripting language for debugging purposes.
 */  
void cmd_gspeak( PLAYER_DATA *ch, char *argument )
{
      VARIABLE_DATA *var; 
      int type = TYPE_ACTOR;
      char arg[MAX_STRING_LENGTH];
      char arg1[MAX_STRING_LENGTH];
      char arg2[MAX_STRING_LENGTH];
      char *p;

      p = argument;
      argument = one_argument( argument, arg ); 
      argument = one_argument( argument, arg1 ); 
      argument = one_argument( argument, arg2 ); 

      

      if ( is_number( arg ) && ch->triggers == NULL ) {
           SCRIPT_DATA *pScript;

           pScript = get_script_index( atoi(arg) );
           if ( pScript == NULL ) {
                send_to_char( p, ch );
                send_to_char( " = ", ch );
                send_to_char( p, ch );  
                send_to_char( "; or no valid script found\n\r", ch );
                return;
           }
/*
 * Add fake variables.
 */ 

           var = new_variable( );

           var->type  = TYPE_ACTOR;
           var->value = (PLAYER_DATA *)ch;
           assign_var( ch, type, var, "%actor%" );

           var->type = TYPE_STRING;
           var->value = str_dup( NAME(ch) );
           assign_var( ch, type, var, "%aname%" );
           free_string((char *)var->value);

           var->type = TYPE_OBJ;
           var->value = ch->carrying;
           assign_var( ch, type, var, "%catalyst%" );

           var->type = TYPE_STRING;
           var->value = str_dup( arg1 );
           assign_var( ch, type, var, "%astr%" );

           var->type = TYPE_STRING;
           var->value = str_dup( arg2 );
           assign_var( ch, type, var, "%bstr%" );

           free_variable( var );

            

           var = eval_function( ch, TYPE_ACTOR, pScript->commands ); 
           return;
      }

      var = eval_function( ch, TYPE_ACTOR, p );
      if ( var != NULL ) {
       send_to_char( p, ch );
       send_to_char( " = ", ch );
       send_to_char( var->value, ch );
       send_to_char( "\n\r", ch ); 
       free_variable( var );
      }
      return;
} 
