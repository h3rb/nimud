
/****************************************************************************
******************************************************************************
* Locke's   __ -based on merc v5.0-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___|  | v5.1a  Version 5.1a                  *
* |  /   \  __|  \__/  |  | |  |      |        documentation release         *
* |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
* |    |  ||  |  |__|  |       |      |                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 *                                                                          *
 *      This is the server software for The Isles, called NiMUD 5.1a        *
 *                                                                          *
 *    Portions of this code are copyrighted to Herb Gilliland.              * 
 *    Copyright (c) 1994-2003 by Herb Gilliland.  All rights reserved.      *
 *                                                                          *
 *  Much time and thought has gone into this software and you are           *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                                                   *
 *                                                                          *
 ****************************************************************************
 *   Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *   Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 ****************************************************************************/

#if defined(BSD)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "nimud.h"
#include "spells.h"
#include "skills.h"
#include "script.h"

SPELL_DATA *spell_list = NULL;



SPELL_DATA *find_spell( char *argument )
{
    SPELL_DATA *pSpell;

    for ( pSpell = spell_list; pSpell != NULL;  pSpell = pSpell->next )
    {
        if ( !str_prefix( argument, pSpell->name ) ) return pSpell;
    }

    return NULL;
}

SPELL_DATA *get_spell_index( int vnum )
{
    SPELL_DATA *pSpell;

    for ( pSpell = spell_list; pSpell != NULL;  pSpell = pSpell->next )
    {
        if ( vnum == pSpell->vnum ) return pSpell;
    }

    return NULL;
}


void clear_spell_book( SPELL_BOOK_DATA *pSpellBook ) {
    SPELL_BOOK_DATA *spell, *spell_next;

    for( spell = pSpellBook;  spell != NULL;  spell = spell_next ) {
         spell_next = spell->next;
         free_spell_book_data( spell );
    }
}

bool has_spell( SPELL_BOOK_DATA *book, int vnum ) {
    SPELL_BOOK_DATA *pSpell;

    for ( pSpell = book;  pSpell != NULL;  pSpell = pSpell->next )
        if ( vnum == pSpell->vnum ) return TRUE;

    return FALSE;
}



/*
 * Compute a saving throw.
 * Negative apply's make saving throw better.
 */
bool saves_spell( int level, PLAYER_DATA *victim )
{
    int save;

    save = 40 + ( victim->saving_throw ) * 5;
    save = URANGE( 5, save, 95 );
    return number_percent( ) < save;
}


int find_gem_mana( PLAYER_DATA *ch, int bit )
{
    PROP_DATA *obj;
    PROP_DATA *cont;
    int mana = 0;

    if ( bit == 0 ) return -1;

    for ( obj = ch->carrying; obj != NULL; obj = obj->next_content )
    {
        if ( obj->item_type == ITEM_GEM && VAL_SET(obj, 0, bit) )
        {
            mana += obj->value[1];
        }
        else
        if ( obj->item_type == ITEM_CONTAINER && !IS_SET(obj->value[1], CONT_CLOSED) )
        {
            for ( cont = obj->contains; cont != NULL; cont = cont->next_content )
            {
            if ( cont->item_type == ITEM_GEM && VAL_SET(cont, 0, bit) )
            {
                 mana += cont->value[1];
            }
            }
        }
    }

    return mana;
}

void take_mana_gem( PLAYER_DATA *ch, int mana, int bit )
{
    PROP_DATA *obj, *prop_next;
    PROP_DATA *cont, *cont_next;

    if ( mana == 0 ) return;

    for ( obj = ch->carrying; obj != NULL; obj = prop_next )
    {
        prop_next = obj->next_content;
        if ( obj->item_type == ITEM_GEM && VAL_SET(obj, 0, bit) )
        {
            if ( obj->value[1] >= mana )
            {
                obj->value[1] -= mana;
                if ( obj->value[1] == 0 )
                {
                act( "$p is drained of all its power, and shatters into thousands of shards!",
                     ch, obj, NULL, TO_CHAR );
                prop_from_char( obj );
                extract_prop( obj );
                }
                return;
            }
            else
            {
                mana -= obj->value[1];
                act( "$p is drained of all its power, and shatters into thousands of shards!",
                     ch, obj, NULL, TO_CHAR );
                prop_from_char( obj );
                extract_prop( obj );
            }
        }
        else
        if ( obj->item_type == ITEM_CONTAINER && !IS_SET(obj->value[1], CONT_CLOSED) )
        {
            for ( cont = obj->contains; cont != NULL; cont = cont_next )
            {
            cont_next = cont->next_content;
            if ( cont->item_type == ITEM_GEM && VAL_SET(cont, 0, bit) )
            {
               if ( cont->value[1] >= mana )
               {
                   cont->value[1] -= mana;
                   if ( cont->value[1] == 0 )
                   {
                   act( "$p is drained of all its power, and shatters into thousands of shards!",
                        ch, cont, NULL, TO_CHAR );
                   prop_from_char( cont );
                   extract_prop( cont );
                   }
                   return;
               }
               else
               {
                   mana -= cont->value[1];
                   act( "$p is drained of all its power, and shatters into thousands of shards!",
                        ch, cont, NULL, TO_CHAR );
                   prop_from_char( cont );
                   extract_prop( cont );
               }
            }
            }
        }
    }

    return;
}


void cmd_scribe( PLAYER_DATA *ch, char *argument )
{
   SPELL_DATA *pSpell;
   PLAYER_DATA *rch = NULL;
   ACTOR_INDEX_DATA *pActorIndex = NULL;

   if ( get_item_char( ch, ITEM_BOOK ) ) {
       send_to_char( "You cannot find your spellbook.\n\r", ch );
       return;
   }

   if ( *argument == '\0' ) {
       char buf[MAX_STRING_LENGTH]; 
        bool fMatch;
        SPELL_BOOK_DATA *pSpellBook;

   buf[0] = '\0';
   fMatch = FALSE;
   for ( pSpellBook = ch->spells;  pSpellBook != NULL;  pSpellBook = pSpellBook->next )
   {
      pActorIndex = NULL;
      for ( rch = ch->in_scene->people;  rch != NULL; rch = rch->next_in_scene )
      {
        if ( IS_NPC(rch)
          && IS_SET(rch->act, ACT_PRACTICE) )
        {
            pActorIndex = rch->pIndexData;
            break;
        }
      }

       if ( (pSpell = get_spell_index( pSpellBook->vnum )) != NULL )
       {
           strcat( buf, "page " );
           strcat( buf, numberize( pSpellBook->vnum ) );
           strcat( buf, " " );
           strcat( buf, pSpell->name );
           strcat( buf, ": " );
           if ( pSpellBook->name != &str_empty[0] ) {strcat( buf, pSpellBook->name); strcat( buf, "'s " ); }
           strcat( buf, skill_table[URANGE(0,pSpell->group_gsn,MAX_SKILL-1)].name );
           strcat( buf, "\n\r" );
           fMatch = TRUE;
       }
       }

       if ( pActorIndex == NULL || rch == NULL ) {
        send_to_char( "There is no one here to teach you.\n\r", ch ); 
        return;
       }

      if ( fMatch ) send_to_char( "Available spells:\n\r", ch );
      else act( "$T knows nothing of magick.", ch, NULL, pActorIndex->short_descr, TO_CHAR );
      send_to_char( buf, ch ); 
   
      return;
   }

   pSpell = find_spell( argument );
   if ( !pSpell ) {
      send_to_char( "You do not know of that spell.\n\r", ch );
      return;
   }

   if ( has_spell( ch->spells, pSpell->vnum ) ) {
       send_to_char( "You have already scribed that spell.\n\r", ch );
       return;
   }

    pActorIndex = NULL;
    for ( rch = ch->in_scene->people;  rch != NULL; rch = rch->next_in_scene )
    {
        if ( IS_NPC(rch)
          && IS_SET(rch->act, ACT_PRACTICE) )
        {
            pActorIndex = rch->pIndexData;
            break;
        }
    }

   if ( pActorIndex == NULL || rch == NULL ) {
        send_to_char( "There is no one here to teach you.\n\r", ch ); 
        return;
   }
   else {
        if ( has_spell( pActorIndex->pSpells, pSpell->vnum ) ) {

                   SPELL_BOOK_DATA *pNewPage;
                   SPELL_BOOK_DATA *pEndPage;

                   if ( pSpell->level > ch->exp_level ) {
                       send_to_char( "You are not yet ready for that spell.\n\r", ch );
                       return;
                   } 

                   pNewPage = new_spell_book_data( );
                   act( "$n scribe$v a new spell from $N.", ch, NULL, rch, TO_ALL );

                   pNewPage->next = NULL;
                   pNewPage->vnum = pSpell->vnum;  
                   pNewPage->name = str_dup( pActorIndex->short_descr );

                   for ( pEndPage = ch->spells;  pEndPage != NULL;  pEndPage = pEndPage->next )
                   if ( pEndPage->next == NULL ) break;

                   if ( pEndPage == NULL || ch->spells == NULL ) ch->spells =  pNewPage; 
                   else pEndPage->next = pNewPage;
             }
          else act( "$E does not know of that spell.", ch, NULL, rch, TO_CHAR );
   }
   return;   
}
   

void cmd_spellbook( PLAYER_DATA *ch, char *argument )
{ 
   SPELL_DATA *pSpell;
   SPELL_BOOK_DATA *pSpellBook;
   char buf[MAX_STRING_LENGTH];
   bool fMatch;
   int count;

   if ( get_item_char( ch, ITEM_BOOK ) ) {
       send_to_char( "You cannot find your spellbook.\n\r", ch );
       return;
   }

   count = 0;
   buf[0] = '\0';
   fMatch = FALSE;
   for ( pSpellBook = ch->spells;  pSpellBook != NULL;  pSpellBook = pSpellBook->next )
   {
       if ( (pSpell = get_spell_index( pSpellBook->vnum )) != NULL )
       {
           strcat( buf, "page " );
           strcat( buf, numberize( count++ ) );
           strcat( buf, " " );
           strcat( buf, pSpell->name );
           strcat( buf, ": " );
           strcat( buf, skill_table[URANGE(0,pSpell->group_gsn,MAX_SKILL-1)].name );
           strcat( buf, "\n\r" );
           fMatch = TRUE;
       }
   }
   

   if ( !fMatch ) {
      send_to_char( "Your spellbook is empty.\n\r", ch );
      return;
   }

   ansi_color( CYAN, ch );
   send_to_char( "You thumb through the vellum pages of your spellbook:\n\r", ch );
   send_to_char( buf, ch );
   ansi_color( NTEXT, ch );
   return;
}

/*
 * The kludgy global is for spells who want more stuff from command line.
 */
char *target_name;


void cmd_cast( PLAYER_DATA *ch, char *argument )
{
    char arg1[MAX_INPUT_LENGTH];
    char arg2[MAX_INPUT_LENGTH];
    PLAYER_DATA *victim;
    SPELL_DATA *pSpell;
    PROP_DATA *obj;
    void *vo;
    int mana;
    int char_mana;
    int sn = 0;

    /*
     * Switched NPC's can cast spells, but others can, too, if they are alone.
     */
    if ( IS_NPC(ch) && (ch->master != NULL) )
	return;

    target_name = one_argument( argument, arg1 );
    one_argument( target_name, arg2 );

    if ( arg1[0] == '\0' )
    {
	send_to_char( "Cast which what where?\n\r", ch );
	return;
    }

    if ( (pSpell = find_spell( arg1 )) == NULL )
    {
        send_to_char( "No such spell.\n\r", ch );
        return;
    }

    {
          SPELL_BOOK_DATA *pSpellBook;

          for ( pSpellBook = ch->spells;  pSpellBook != NULL; pSpellBook = pSpellBook->next )
          if ( pSpellBook->vnum == pSpell->vnum ) break;

          if ( pSpellBook == NULL ) {
              send_to_char( "You don't know of that spell.\n\r", ch );
          }
    }

    if ( ch->position < pSpell->minimum_position )
    {
    send_to_char( "It is impossible to concentrate enough.\n\r", ch );
	return;
    }

    if ( pSpell->mana_cost == 0 ) { mana = 0; send_to_char( "You begin to prepare the spell.\n\r", ch ); 
     } else  
    mana = IS_NPC(ch) ? 0 : UMAX( pSpell->mana_cost, 100 / ( 2 ) );

    /*
     * Locate targets.
     */
    victim	= NULL;
    obj		= NULL;
    vo		= NULL;
      
    switch ( pSpell->target )
    {
    default:
	bug( "Cmd_cast: bad target for sn %d.", sn );
	return;

    case TAR_IGNORE:
	break;

    case TAR_CHAR_OFFENSIVE:
	if ( arg2[0] == '\0' )
	{
	    if ( ( victim = ch->fighting ) == NULL )
	    {
		send_to_char( "Cast the spell on whom?\n\r", ch );
		return;
	    }
	}
	else
	{
	    if ( ( victim = get_char_scene( ch, arg2 ) ) == NULL )
	    {
		send_to_char( "They aren't here.\n\r", ch );
		return;
	    }
	}

	vo = (void *) victim;
	break;

    case TAR_CHAR_DEFENSIVE:
	if ( arg2[0] == '\0' )
	{
	    victim = ch;
	}
	else
	{
	    if ( ( victim = get_char_scene( ch, arg2 ) ) == NULL )
	    {
		send_to_char( "They aren't here.\n\r", ch );
		return;
	    }
	}

	vo = (void *) victim;
	break;

    case TAR_CHAR_SELF:
    if ( arg2[0] != '\0' && !is_name( arg2, STR(ch, name) ) )
	{
	    send_to_char( "You cannot cast this spell on another.\n\r", ch );
	    return;
	}

	vo = (void *) ch;
	break;

    case TAR_OBJ_INV:
	if ( arg2[0] == '\0' )
	{
	    send_to_char( "What should the spell be cast upon?\n\r", ch );
	    return;
	}

    if ( ( obj = get_prop_carry( ch, arg2 ) ) == NULL )
	{
        send_to_char( "You are not carrying that in your hand.\n\r", ch );
	    return;
	}

	vo = (void *) obj;
	break;
    }
	    

    char_mana = find_gem_mana( ch, skill_table[sn].mana_type ) + ch->mana;

    if ( !IS_NPC(ch) && mana > char_mana && !IS_IMMORTAL(ch) )
    {
        switch ( skill_table[sn].mana_type )
        {
            default: send_to_char( "You lack the mana.\n\r", ch ); break;
     case MANA_FIRE: send_to_char( "You don't have enough Fire gems.\n\r", ch ); break;
      case MANA_AIR: send_to_char( "You don't have enough Air gems.\n\r", ch ); break;
    case MANA_WATER: send_to_char( "You don't have enough Water gems.\n\r", ch ); break;
    case MANA_EARTH: send_to_char( "You don't have enough Earth gems.\n\r", ch ); break;
        }
        return;
    }
      
    WAIT_STATE( ch, pSpell->beats );

    if ( !IS_IMMORTAL(ch) || char_mana >= mana )
    {
    if ( !IS_NPC(ch) && number_percent( ) > LEARNED(ch,sn) )
    {
	send_to_char( "You lost your concentration.\n\r", ch );
        if ( mana > ch->mana ) {
           ch->mana = 0;
           mana -= ch->mana*2;
        } else
        ch->mana -= mana/2;

        take_mana_gem( ch, mana/2, skill_table[sn].mana_type );
    }
    else
    {
    if ( mana > ch->mana ) {
      mana -= ch->mana;
      ch->mana = 0;
    }
    else
    ch->mana -= mana;

/*    (*skill_table[sn].spell_fun) ( sn, INTERPOLATE(1, 40, 
LEARNED(ch,sn)), ch, vo ); */
    add_event( ch, TYPE_ACTOR, 
                   pSpell->vnum, 
                   0, "",
                   ch, victim, obj, "", "" );   
 
    {
    }
    
    take_mana_gem( ch, mana, skill_table[sn].mana_type );
    }
    }

    if ( skill_table[sn].target == TAR_CHAR_OFFENSIVE
    &&   victim != ch
    &&   victim->master != ch )
    {
	PLAYER_DATA *vch;
	PLAYER_DATA *vch_next;

	for ( vch = ch->in_scene->people; vch; vch = vch_next )
	{
	    vch_next = vch->next_in_scene;
	    if ( victim == vch && victim->fighting == NULL )
	    {
        oroc( victim, ch );
		break;
	    }
	}
    }

    return;
}



/*
 * Cast spells at targets using a magical prop.
 */
void prop_cast_spell( int sn, int level, PLAYER_DATA *ch, PLAYER_DATA *victim, PROP_DATA *obj )
{
    SPELL_DATA *pSpell= NULL;
    void *vo;

    if ( sn <= 0 )
	return;

    if ( sn >= MAX_SKILL || ( pSpell = find_spell( skill_table[sn].name) ) == NULL )
    {
	bug( "Obj_cast_spell: bad sn %d.", sn );
	return;
    }

    switch ( skill_table[sn].target )
    {
    default:
	bug( "Obj_cast_spell: bad target for sn %d.", sn );
	return;

    case TAR_IGNORE:
	vo = NULL;
	break;

    case TAR_CHAR_OFFENSIVE:
	if ( victim == NULL )
	    victim = ch->fighting;
    if ( victim == NULL )
	{
        send_to_char( "The spell fizzles.\n\r", ch );
	    return;
	}
	vo = (void *) victim;
	break;

    case TAR_CHAR_DEFENSIVE:
	if ( victim == NULL )
	    victim = ch;
	vo = (void *) victim;
	break;

    case TAR_CHAR_SELF:
	vo = (void *) ch;
	break;

    case TAR_OBJ_INV:
	if ( obj == NULL )
	{
        send_to_char( "The spell fizzles.\n\r", ch );
	    return;
	}
	vo = (void *) obj;
	break;
    }

    target_name = "";
    add_event( ch, TYPE_ACTOR, pSpell->vnum, 0, "", ch, victim, obj, "", "" );   

    if ( skill_table[sn].target == TAR_CHAR_OFFENSIVE
    &&   victim != ch
    &&   victim->master != ch )
    {
	PLAYER_DATA *vch;
	PLAYER_DATA *vch_next;

	for ( vch = ch->in_scene->people; vch; vch = vch_next )
	{
	    vch_next = vch->next_in_scene;
	    if ( victim == vch && victim->fighting == NULL )
	    {
        oroc( victim, ch );
		break;
	    }
	}
    }

    return;
}


