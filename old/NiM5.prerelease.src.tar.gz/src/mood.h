/*
 * Mood effects for NPCs and PCs.
 */


/*
 * Accompanying feature: cmd_set() -> set mood
 *                                   set nomood
 */


#define MOOD_HAPPY     0
#define MOOD_SAD       1
#define MOOD_ANGRY     2
#define MOOD_DESPAIR   3
#define MOOD_EXCITED   4
