/*
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___| G| v4.0   Version 4.0 GOLD EDITION      *
* |  /   \  __|  \__/  |  | |  |     O|        documentation release         *
* |       ||  |        |  \_|  | ()  L|        Hallow's Eve 1999             *
* |    |  ||  |  |__|  |       |     D|                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 */
#define DEF_PORT                 5554


#define COIN_PLATINUM              0
#define COIN_GOLD                  1
#define COIN_SILVER                2
#define COIN_COPPER                3

/*
 * Hardcoded actor virtual numbers.
 */
#define ACTOR_VNUM_TEMPLATE          1
#define ACTOR_VNUM_CITYGUARD         2

#define ACTOR_VNUM_GHOST            10
#define ACTOR_VNUM_SKELETON         11
#define ACTOR_VNUM_ZOMBIE           12
#define ACTOR_VNUM_WIGHT            13
#define ACTOR_VNUM_WRAITH           14
#define ACTOR_VNUM_VAMPIRE          15
#define ACTOR_VNUM_DAEMON           16

#define DEFAULT_RACE               0



/*
 * Hardcoded prop virtual numbers.
 */
#define OBJ_VNUM_TEMPLATE              1
#define OBJ_VNUM_MONEY_ONE             2
#define OBJ_VNUM_MONEY_SOME            3

#define OBJ_VNUM_COMP                  4
#define OBJ_VNUM_GOODS                 4

#define OBJ_VNUM_CORPSE_NPC            5
#define OBJ_VNUM_CORPSE_PC             6

#define OBJ_VNUM_SEVERED_HEAD         10

#define OBJ_VNUM_MUSHROOM             20
#define OBJ_VNUM_LIGHT_BALL           21
#define OBJ_VNUM_SPRING               22

#define OBJ_VNUM_DEFAULT_WEAPON       30
#define OBJ_VNUM_DEFAULT_VEST         31
#define OBJ_VNUM_DEFAULT_PACK         32
#define OBJ_VNUM_DEFAULT_LIGHT        33
#define OBJ_VNUM_DEFAULT_BELT         34
#define OBJ_VNUM_DEFAULT_SHIELD       35
#define OBJ_VNUM_DEFAULT_TINDERBOX    36
#define OBJ_VNUM_DEFAULT_LETTER       37
#define OBJ_VNUM_DEFAULT_FOOD         38
#define OBJ_VNUM_DEFAULT_DRINK        39

/*
 * Hardcoded scene virtual numbers.
 */
#define ROOM_VNUM_TEMPLATE            1
#define ROOM_VNUM_LIMBO               2
#define ROOM_VNUM_CHAT                3
#define ROOM_VNUM_APPLICATIONS        4
#define ROOM_VNUM_DEATH               5
#define ROOM_VNUM_DEATH_NEW         524
#define ROOM_VNUM_DEFAULT_HOME     5000       

#define ROOM_VNUM_START               6

#define ROOM_VNUM_GUEST              99


