
/****************************************************************************
******************************************************************************
* Locke's   __ -based on merc v5.0-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___|  | v5.1a  Version 5.1a                  *
* |  /   \  __|  \__/  |  | |  |      |        documentation release         *
* |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
* |    |  ||  |  |__|  |       |      |                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 *                                                                          *
 *      This is the server software for The Isles, called NiMUD 5.1a        *
 *                                                                          *
 *    Portions of this code are copyrighted to Herb Gilliland.              * 
 *    Copyright (c) 1994-2003 by Herb Gilliland.  All rights reserved.      *
 *                                                                          *
 *  Much time and thought has gone into this software and you are           *
 *  benefitting.  We hope that you share your changes too.  What goes       *
 *  around, comes around.                                                   *
 *                                                                          *
 ****************************************************************************
 *   Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *   Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 ****************************************************************************/

#if defined(BSD)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "nimud.h"
#include "defaults.h"
#include "script.h"


/*
 * From mem.c
 */
extern VARIABLE_DATA * mud_var_list;


/*
 * Find a race.
 */
int race_lookup( int vnum )
{
    if ( vnum >= MAX_RACE || vnum <= 0 ) return 0; 
    return vnum;
}


/*
 * Retrieve a character's trusted level for permission checking.
 */
int get_trust( PLAYER_DATA *ch )
{
    if ( ch == NULL ) return -1;

    if ( ch->pcdata )
    return PC(ch,level);

    /*
     * Switch characters are trusted at their original level.
     * Doesn't count switching into players (which isn't allowed)
     */
    if ( ch->desc != NULL )
    {
       if ( ch->desc->original != NULL )
       ch = ch->desc->original;
    }

    if ( IS_NPC(ch) )
    return LEVEL_MORTAL;

    return -1;
}






/*
 * Retrieve character's current strength.
 */
int get_curr_str( PLAYER_DATA *ch )
{
    int max;

	max = 25;

    return URANGE( 3, ch->perm_str + ch->mod_str, max );
}




/*
 * Retrieve character's current intelligence.
 */
int get_curr_int( PLAYER_DATA *ch )
{
    int max;

	max = 25;

    return URANGE( 3, ch->perm_int + ch->mod_int, max );
}



/*
 * Retrieve character's current wisdom.
 */
int get_curr_wis( PLAYER_DATA *ch )
{
    int max;

	max = 25;

    return URANGE( 3, ch->perm_wis + ch->mod_wis, max );
}


/*
 * Retrieve character's current dexterity.
 */
int get_curr_dex( PLAYER_DATA *ch )
{
    int max;

	max = 25;

    return URANGE( 3, ch->perm_dex + ch->mod_dex, max );
}



/*
 * Retrieve character's current constitution.
 */
int get_curr_con( PLAYER_DATA *ch )
{
    int max;

	max = 25;

    return URANGE( 3, ch->perm_con + ch->mod_con, max );
}




/*
 * Retrieve a character's carry capacity.
 */
int can_carry_w( PLAYER_DATA *ch )
{
    if ( IS_IMMORTAL(ch) || (IS_NPC(ch) && ch->pIndexData->pShop) )
	return 1000000;

    return str_app[get_curr_str(ch)].carry;
}


/*
 * Apply or remove an affect to a character.
 */
void bonus_modify( PLAYER_DATA *ch, BONUS_DATA *paf, bool fAdd )
{
    PROP_DATA *obj, *prop_next;
    int mod;
    static int depth;

    mod = paf->modifier;

    if ( fAdd )
    {
	SET_BIT( ch->bonuses, paf->bitvector );
    }
    else
    {
        int race = race_lookup( ch->race );
        PROP_DATA *obj;

        REMOVE_BIT( ch->bonuses, paf->bitvector );

        SET_BIT(ch->bonuses, RACE(race,bonus_bits) );

        /*
         * Make check if your wearing two affects of the same bitvector.
         */
        for ( obj = ch->carrying;   obj != NULL;  obj = obj->next_content )
        {
            BONUS_DATA *af;

            if ( NOT_WORN(obj) )
             continue;

            for ( af = obj->bonus; af != NULL;  af = af->next )
            {
                if (IS_SET( af->bitvector, paf->bitvector ) )
                SET_BIT(ch->bonuses, af->bitvector);
            }
        }

        mod = 0 - mod;
    }

    if ( IS_NPC(ch) )
	return;

    switch ( paf->location )
    {
    default:
        {
            int sn;

            if ( (sn = slot_lookup(paf->location)) <= 0 )
            {
                bug( "Bonus_modify: unknown location %d.", paf->location );
                paf->location = APPLY_NONE;
                return;
            }

            PC(ch,learned[sn]) += mod;
        }
    break;
    case APPLY_NONE:                                   break;
    case APPLY_STR:           ch->mod_str      += mod; break;
    case APPLY_DEX:           ch->mod_dex      += mod; break;
    case APPLY_INT:           ch->mod_int      += mod; break;
    case APPLY_WIS:           ch->mod_wis      += mod; break;
    case APPLY_CON:           ch->mod_con      += mod; break;
    case APPLY_SEX:           ch->sex          += mod; break;
    case APPLY_AGE:           PC(ch,age)       += mod; break;
    case APPLY_SIZE:          ch->size         += mod; break;
    case APPLY_AC:            ch->armor        += mod; break;
    case APPLY_HITROLL:       ch->hitroll      += mod; break;
    case APPLY_DAMROLL:       ch->damroll      += mod; break;
    case APPLY_SAVING_THROW:  ch->saving_throw += mod; break;
    }

    if ( depth == 0 )    /* prop_from/to_char recurses */
    {
    depth++;
    for ( obj = ch->carrying;
          obj != NULL && can_carry_w( ch ) < ch->carry_weight;
          obj = prop_next )
    {
    prop_next = obj->next_content;
    
    act( "You drop $p.", ch, obj, NULL, TO_CHAR );
    act( "$n drops $p.", ch, obj, NULL, TO_ROOM );
    unequip_char( ch, obj );
    prop_from_char( obj );
    prop_to_scene( obj, ch->in_scene );
    }
    depth--;
    }
    return;
}



/*
 * Give an affect to a char.
 */
void bonus_to_char( PLAYER_DATA *ch, BONUS_DATA *paf )
{
    BONUS_DATA *paf_new;


    paf_new = new_bonus( );

    *paf_new		= *paf;
    paf_new->next	= ch->bonus;
    ch->bonus	= paf_new;

    bonus_modify( ch, paf_new, TRUE );
    return;
}



/*
 * Remove an affect from a char.
 */
void bonus_remove( PLAYER_DATA *ch, BONUS_DATA *paf )
{
    if ( ch->bonus == NULL )
    {
	bug( "Bonus_remove: no affect.", 0 );
	return;
    }

    bonus_modify( ch, paf, FALSE );

    if ( paf == ch->bonus )
    {
	ch->bonus	= paf->next;
    }
    else
    {
	BONUS_DATA *prev;

	for ( prev = ch->bonus; prev != NULL; prev = prev->next )
	{
	    if ( prev->next == paf )
	    {
		prev->next = paf->next;
		break;
	    }
	}

	if ( prev == NULL )
	{
	    bug( "Bonus_remove: cannot find paf.", 0 );
	    return;
	}
    }

    free_bonus( paf );
    return;
}



/*
 * Strip all affects of a given sn.
 */
void bonus_strip( PLAYER_DATA *ch, int sn )
{
    BONUS_DATA *paf;
    BONUS_DATA *paf_next;

    for ( paf = ch->bonus; paf != NULL; paf = paf_next )
    {
	paf_next = paf->next;
	if ( paf->type == sn )
	    bonus_remove( ch, paf );
    }

    return;
}



/*
 * Return true if a char is bonus by a spell.
 */
bool is_bonused( PLAYER_DATA *ch, int sn )
{
    BONUS_DATA *paf;

    for ( paf = ch->bonus; paf != NULL; paf = paf->next )
    {
	if ( paf->type == sn )
	    return TRUE;
    }

    return FALSE;
}



/*
 * Add or enhance an affect.
 */
void bonus_join( PLAYER_DATA *ch, BONUS_DATA *paf )
{
    BONUS_DATA *paf_old;
    bool found;

    found = FALSE;
    for ( paf_old = ch->bonus; paf_old != NULL; paf_old = paf_old->next )
    {
	if ( paf_old->type == paf->type )
	{
	    paf->duration += paf_old->duration;
	    paf->modifier += paf_old->modifier;
	    bonus_remove( ch, paf_old );
	    break;
	}
    }

    bonus_to_char( ch, paf );
    return;
}


/*
 * Move a char out of a scene.
 */
void char_from_scene( PLAYER_DATA *ch )
{
    PROP_DATA *obj;

    set_furn( ch, NULL );

    if ( ch->in_scene == NULL )
    {
	bug( "Char_from_scene: NULL.", 0 );
	return;
    }

    if ( !IS_NPC(ch) )
	--ch->in_scene->zone->nplayer;

    for ( obj = ch->carrying; obj != NULL;  obj = obj->next_content )
    {

    if ( obj->item_type == ITEM_LIGHT
      && IS_LIT(obj)
      && ch->in_scene->light > 0 )    --ch->in_scene->light;
    }

    if ( ch == ch->in_scene->people )
    {
	ch->in_scene->people = ch->next_in_scene;
    }
    else
    {
	PLAYER_DATA *prev;

	for ( prev = ch->in_scene->people; prev; prev = prev->next_in_scene )
	{
	    if ( prev->next_in_scene == ch )
	    {
		prev->next_in_scene = ch->next_in_scene;
		break;
	    }
	}

	if ( prev == NULL )
	    bug( "Char_from_scene: ch not found.", 0 );
    }

    ch->in_scene      = NULL;
    ch->next_in_scene = NULL;
    return;
}



/*
 * Move a char into a scene.
 */
void char_to_scene( PLAYER_DATA *ch, ROOM_INDEX_DATA *pSceneIndex )
{
    PROP_DATA *obj;

    if ( pSceneIndex == NULL )
    {
	bug( "Char_to_scene: NULL.", 0 );
        pSceneIndex = get_scene_index( ROOM_VNUM_DEATH );
    }

    ch->in_scene         = pSceneIndex;
    ch->next_in_scene	= pSceneIndex->people;
    pSceneIndex->people	= ch;

    if ( !IS_NPC(ch) )
	++ch->in_scene->zone->nplayer;

    for ( obj = ch->carrying; obj != NULL;  obj = obj->next_content )
    {   
    if ( obj->item_type == ITEM_LIGHT && IS_LIT(obj) )   ++ch->in_scene->light;
    }

    return;
}




/*
 * Move (intelligently) an prop to a char.
 */
void prop_to_char_money( PROP_DATA *obj, PLAYER_DATA *ch )
{
    PROP_DATA *fobj;

    if ( obj->item_type == ITEM_MONEY  )
    {
    for ( fobj = ch->carrying;  fobj != NULL; fobj = fobj->next_content )
    {
        if ( fobj->item_type == ITEM_CONTAINER )
        {
            PROP_DATA *iobj;

            for ( iobj = fobj->contains; iobj != NULL; iobj = iobj->next_content )
            {
                if ( iobj->item_type == ITEM_MONEY )
                {
                    break;
                }
            }
            if ( iobj == NULL )
            continue;

            prop_to_prop( obj, fobj );
            merge_money_prop( fobj );
            return;
        }
    }

    if ( fobj == NULL )
    {
    for ( fobj = ch->carrying;  fobj != NULL; fobj = fobj->next_content )
    {
        if ( fobj->item_type == ITEM_CONTAINER )
        {
            prop_to_prop( obj, fobj );
            merge_money_prop( fobj );
            return;
        }
    }
    }
    }

    if ( obj->item_type == ITEM_LIGHT
    &&   IS_LIT(obj)
    &&   ch->in_scene != NULL )
    ++ch->in_scene->light;

    obj->next_content = ch->carrying;
    ch->carrying      = obj;
    obj->carried_by     = ch;
    obj->in_scene        = NULL;
    obj->in_prop         = NULL;
    ch->carry_number   += get_prop_number( obj );
    ch->carry_weight   += get_prop_weight( obj );

}


/*
 * Give an obj to a char.
 */
void prop_to_char( PROP_DATA *obj, PLAYER_DATA *ch )
{
    if ( obj->item_type == ITEM_LIGHT
    &&   IS_LIT(obj)
    &&   ch->in_scene != NULL )
    ++ch->in_scene->light;

    obj->next_content = ch->carrying;
    ch->carrying      = obj;
    obj->carried_by     = ch;
    obj->in_scene        = NULL;
    obj->in_prop         = NULL;
    ch->carry_number   += get_prop_number( obj );
    ch->carry_weight   += get_prop_weight( obj );
    REMOVE_BIT(obj->extra_flags, ITEM_USED);
    return;
}



/*
 * Take an obj from its character.
 */
void prop_from_char( PROP_DATA *obj )
{
    PLAYER_DATA *ch;

    if ( ( ch = obj->carried_by ) == NULL )
    {
	bug( "Obj_from_char: null ch.", 0 );
	return;
    }

    if ( (obj->wear_loc != WEAR_NONE
       && obj->wear_loc != WEAR_HOLD_1
       && obj->wear_loc != WEAR_HOLD_2
       && obj->wear_loc != WEAR_BELT_1
       && obj->wear_loc != WEAR_BELT_2
       && obj->wear_loc != WEAR_BELT_3
       && obj->wear_loc != WEAR_BELT_4
       && obj->wear_loc != WEAR_BELT_5)
      || IS_SET(obj->extra_flags,ITEM_USED) )        unequip_char( ch, obj );

    if ( ch->carrying == obj )
    {
	ch->carrying = obj->next_content;
    }
    else
    {
	PROP_DATA *prev;

	for ( prev = ch->carrying; prev != NULL; prev = prev->next_content )
	{
	    if ( prev->next_content == obj )
	    {
		prev->next_content = obj->next_content;
		break;
	    }
	}

	if ( prev == NULL )
	    bug( "Obj_from_char: obj not in list.", 0 );
    }

    if ( obj->item_type == ITEM_LIGHT
    &&   IS_LIT(obj)
    &&   ch->in_scene != NULL
    &&   ch->in_scene->light > 0 )
    --ch->in_scene->light;


    obj->carried_by	 = NULL;
    obj->next_content	 = NULL;
    ch->carry_number	-= get_prop_number( obj );
    ch->carry_weight	-= get_prop_weight( obj );
    return;
}




/*
 * Find the ac value of an obj, including position effect.
 */
int apply_ac( PROP_DATA *obj, int iWear )
{
    if ( obj->item_type != ITEM_ARMOR )
	return 0;

    return obj->value[0];
}


/*
 * Get an prop from a char using a type reference.
 * Goes 1 deep.  Returns 1st instance.
 */
PROP_DATA *get_item_char( PLAYER_DATA *ch, int itype )
{  
    PROP_DATA *obj, *obj2;

    for ( obj = ch->carrying;  obj != NULL; obj = obj->next_content )
    {
        if ( obj->item_type == itype ) return obj;

        for ( obj2 = obj->contains;  obj2 != NULL; obj2 = obj2->next_content )
        { if ( obj2->item_type == itype ) return obj2; }
    }
  
    return NULL;
}

/*
 * Get an prop from a char using a type reference.
 * Goes 1 deep.  Returns 1st instance.
 */
PROP_DATA *get_tool_char( PLAYER_DATA *ch, int nbit )
{  
    PROP_DATA *obj, *obj2;

    for ( obj = ch->carrying;  obj != NULL; obj = obj->next_content )
    {
        if ( obj->item_type == ITEM_TOOL 
          && IS_SET(obj->value[1], nbit) ) return obj;

        for ( obj2 = obj->contains;  obj2 != NULL; obj2 = obj2->next_content )
        if ( obj2->item_type == ITEM_TOOL
          && IS_SET(obj2->value[1], nbit) ) return obj2;
    }
  
    return NULL;
}


/*
 * Get an prop from a char using type referencing.
 */
PROP_DATA *get_item_held( PLAYER_DATA *ch, int itype )
{
    PROP_DATA *obj;

    if ( ( obj = get_eq_char( ch, WEAR_HOLD_1 ) ) != NULL
        && obj->item_type == itype )
        return obj;

    if ( ( obj = get_eq_char( ch, WEAR_WIELD_1 ) ) != NULL
        && obj->item_type == itype )
        return obj;

    if ( ( obj = get_eq_char( ch, WEAR_HOLD_2 ) ) != NULL
        && obj->item_type == itype )
        return obj;

    if ( ( obj = get_eq_char( ch, WEAR_WIELD_2 ) ) != NULL
        && obj->item_type == itype )
        return obj;

    return NULL;
}


/*
 * Find a piece of eq on a character.
 */
PROP_DATA *get_eq_char( PLAYER_DATA *ch, int iWear )
{
    PROP_DATA *obj;

    for ( obj = ch->carrying; obj != NULL; obj = obj->next_content )
    {
	if ( obj->wear_loc == iWear )
	    return obj;
    }

    return NULL;
}




/*
 *  Return if an prop can be put in their hands (hands empty?)
 */
int hand_empty( PLAYER_DATA *ch )
{
    PROP_DATA *h1, *h2;

    h1 = get_eq_char( ch, WEAR_HOLD_1 );
    if ( h1 == NULL ) h1 = get_eq_char( ch, WEAR_WIELD_1 );
    h2 = get_eq_char( ch, WEAR_HOLD_2 );
    if ( h2 == NULL ) h2 = get_eq_char( ch, WEAR_WIELD_2 );

    if ( (h1 != NULL && IS_SET( h1->wear_flags, ITEM_TWO_HANDED ))
      || (h2 != NULL && IS_SET( h2->wear_flags, ITEM_TWO_HANDED )) )
            return WEAR_NONE;

    if ( h1 == NULL ) return WEAR_HOLD_1;
    if ( h2 == NULL ) return WEAR_HOLD_2;

    return WEAR_NONE;
}



/*
 * Return the denominator to the empty wield slot on a character.
 */
int wield_free( PLAYER_DATA *ch, PROP_DATA *obj )
{
    PROP_DATA *h1, *h2;

    h1 = get_eq_char( ch, WEAR_HOLD_1 );
    if ( h1 == NULL ) h1 = get_eq_char( ch, WEAR_WIELD_1 );
    h2 = get_eq_char( ch, WEAR_HOLD_2 );
    if ( h2 == NULL ) h2 = get_eq_char( ch, WEAR_WIELD_2 );

    if ( (h1 != NULL 
        && IS_SET( h1->wear_flags, ITEM_TWO_HANDED ) 
        && h1->wear_loc == WEAR_WIELD_1)
      || (h2 != NULL 
        && IS_SET( h2->wear_flags, ITEM_TWO_HANDED ) 
        && h2->wear_loc == WEAR_WIELD_2) )
    return WEAR_NONE;

    if ( h1 == NULL || h1 == obj ) return WEAR_WIELD_1;
    if ( h2 == NULL || h2 == obj ) return WEAR_WIELD_2;

    return WEAR_NONE;
}


/*
 *  Return if an prop can be put in their belt (hands empty?)
 */
int belt_empty( PLAYER_DATA *ch )
{
    if ( get_eq_char( ch, WEAR_WAIST )  == NULL )        return WEAR_NONE;

    if ( get_eq_char( ch, WEAR_BELT_1 ) == NULL )        return WEAR_BELT_1;
    if ( get_eq_char( ch, WEAR_BELT_2 ) == NULL )        return WEAR_BELT_2;
    if ( get_eq_char( ch, WEAR_BELT_3 ) == NULL )        return WEAR_BELT_3;
    if ( get_eq_char( ch, WEAR_BELT_4 ) == NULL )        return WEAR_BELT_4;
    if ( get_eq_char( ch, WEAR_BELT_5 ) == NULL )        return WEAR_BELT_5;

    return WEAR_NONE;
}


/*
 * Unequip a char with an obj.
 */
bool unequip_char( PLAYER_DATA *ch, PROP_DATA *obj )
{
    BONUS_DATA *paf;

    if ( (obj->wear_loc == WEAR_NONE) )
    {
        obj->wear_loc = hand_empty( ch );
        return TRUE;
    }

    if ( (obj->wear_loc == WEAR_NONE
      || obj->wear_loc == WEAR_HOLD_1
      || obj->wear_loc == WEAR_HOLD_2
      || obj->wear_loc == WEAR_BELT_1
      || obj->wear_loc == WEAR_BELT_2
      || obj->wear_loc == WEAR_BELT_3
      || obj->wear_loc == WEAR_BELT_4
      || obj->wear_loc == WEAR_BELT_5)
      && !IS_SET(obj->extra_flags, ITEM_USED) )
    {
    return TRUE;
    }

    for ( paf = obj->pIndexData->bonus; paf != NULL; paf = paf->next )
    bonus_modify( ch, paf, FALSE );
    for ( paf = obj->bonus; paf != NULL; paf = paf->next )
    bonus_modify( ch, paf, FALSE );

    ch->armor       += obj->value[0];
    obj->wear_loc    = hand_empty( ch );
    REMOVE_BIT(obj->extra_flags, ITEM_USED);

    return TRUE;
}

/*
 * Equip a char with an obj.
 */
void equip_char( PLAYER_DATA *ch, PROP_DATA *obj, int iWear )
{
    BONUS_DATA *paf;

    if ( (obj->wear_loc != WEAR_NONE
       && obj->wear_loc != WEAR_HOLD_1
       && obj->wear_loc != WEAR_HOLD_2
       && obj->wear_loc != WEAR_BELT_1
       && obj->wear_loc != WEAR_BELT_2
       && obj->wear_loc != WEAR_BELT_3
       && obj->wear_loc != WEAR_BELT_4
       && obj->wear_loc != WEAR_BELT_5)
      || IS_SET(obj->extra_flags, ITEM_USED)
      || get_eq_char( ch, iWear ) != NULL )
    {
        bug( "Equip_char: already equipped (%d).", iWear );
        return;
    }

    if ( iWear == WEAR_NONE
      || iWear == WEAR_HOLD_1
      || iWear == WEAR_HOLD_2
      || iWear == WEAR_BELT_1
      || iWear == WEAR_BELT_2
      || iWear == WEAR_BELT_3
      || iWear == WEAR_BELT_4
      || iWear == WEAR_BELT_5)
    {
       bug( "Equip_char: equipped how? (%d)", iWear );
       return;
    }

    for ( paf = obj->pIndexData->bonus; paf != NULL; paf = paf->next )
	bonus_modify( ch, paf, TRUE );
    for ( paf = obj->bonus; paf != NULL; paf = paf->next )
	bonus_modify( ch, paf, TRUE );

    ch->armor           -= obj->value[0];
    obj->wear_loc	 = iWear;
    SET_BIT(obj->extra_flags, ITEM_USED);

    return;
}


/*
 * Count occurrences of an obj in a list.
 */
int count_prop_list( OBJ_INDEX_DATA *pPropIndex, PROP_DATA *list )
{
    PROP_DATA *obj;
    int nMatch;

    nMatch = 0;
    for ( obj = list; obj != NULL; obj = obj->next_content )
    {
	if ( obj->pIndexData == pPropIndex )
	    nMatch++;
    }

    return nMatch;
}



/*
 * Move an obj out of a scene.
 */
void prop_from_scene( PROP_DATA *obj )
{
    ROOM_INDEX_DATA *in_scene;

    if ( ( in_scene = obj->in_scene ) == NULL )
    {
	bug( "prop_from_scene: NULL.", 0 );
	return;
    }

    if ( obj == in_scene->contents )
    {
	in_scene->contents = obj->next_content;
    }
    else
    {
	PROP_DATA *prev;

	for ( prev = in_scene->contents; prev; prev = prev->next_content )
	{
	    if ( prev->next_content == obj )
	    {
		prev->next_content = obj->next_content;
		break;
	    }
	}

	if ( prev == NULL )
	{
	    bug( "Obj_from_scene: obj not found.", 0 );
	    return;
	}
    }

    if ( obj->item_type == ITEM_LIGHT && IS_LIT(obj) )  --obj->in_scene->light;

    obj->in_scene      = NULL;
    obj->next_content = NULL;
    return;
}



/*
 * Move an obj into a scene.
 */
void prop_to_scene( PROP_DATA *obj, ROOM_INDEX_DATA *pSceneIndex )
{
    if ( obj->item_type == ITEM_LIGHT && IS_LIT(obj) )  ++pSceneIndex->light;

    obj->next_content		= pSceneIndex->contents;
    pSceneIndex->contents	= obj;
    obj->in_scene		= pSceneIndex;
    obj->carried_by		= NULL;
    obj->in_prop			= NULL;
    obj->wear_loc       = WEAR_NONE;

    return;
}



/*
 * Move an prop into an prop.
 */
void prop_to_prop( PROP_DATA *obj, PROP_DATA *prop_to )
{
    obj->next_content   = prop_to->contains;
    prop_to->contains    = obj;
    obj->in_prop			= prop_to;
    obj->in_scene		= NULL;
    obj->carried_by		= NULL;
    obj->wear_loc       = WEAR_NONE;

    for ( ; prop_to != NULL; prop_to = prop_to->in_prop )
    {
	if ( prop_to->carried_by != NULL )
	{
	    prop_to->carried_by->carry_number += get_prop_number( obj );
	    prop_to->carried_by->carry_weight += get_prop_weight( obj );
	}
    }

    return;
}



/*
 * Move an prop out of an prop.
 */
void prop_from_prop( PROP_DATA *obj )
{
    PROP_DATA *prop_from;

    if ( ( prop_from = obj->in_prop ) == NULL )
    {
	bug( "Obj_from_prop: null prop_from.", 0 );
	return;
    }

    if ( obj == prop_from->contains )
    {
	prop_from->contains = obj->next_content;
    }
    else
    {
	PROP_DATA *prev;

	for ( prev = prop_from->contains; prev; prev = prev->next_content )
	{
	    if ( prev->next_content == obj )
	    {
		prev->next_content = obj->next_content;
		break;
	    }
	}

	if ( prev == NULL )
	{
	    bug( "Obj_from_prop: obj not found.", 0 );
	    return;
	}
    }

    obj->next_content = NULL;
    obj->in_prop       = NULL;

    for ( ; prop_from != NULL; prop_from = prop_from->in_prop )
    {
	if ( prop_from->carried_by != NULL )
	{
	    prop_from->carried_by->carry_number -= get_prop_number( obj );
	    prop_from->carried_by->carry_weight -= get_prop_weight( obj );
	}
    }

    return;
}



/*
 * Extract an obj from the world.
 */
void extract_prop( PROP_DATA *obj )
{
    PROP_DATA *prop_content;
    PROP_DATA *prop_next;
    extern PROP_DATA *prop_free;
    VARIABLE_DATA *pVar;
    VARIABLE_DATA *pVar_next;

    {
        PLAYER_DATA *actor;

        for ( actor = char_list;  actor != NULL; actor = actor->next )
        {
            if ( actor->furniture == obj )
            actor->furniture = NULL;

            if ( actor->hitched_to == obj )
            actor->hitched_to = NULL;
        }
    }

    for ( pVar = mud_var_list;  pVar != NULL;  pVar = pVar_next )
    {
        pVar_next = pVar->next;
        if ( pVar->type == TYPE_OBJ && (PROP_DATA *)pVar->value == obj )
        {
            pVar->type  = TYPE_STRING;
            pVar->value = str_dup( "" );
        }
    }


    if ( obj->in_scene != NULL )    prop_from_scene( obj );
    if ( obj->carried_by != NULL ) prop_from_char( obj );
    if ( obj->in_prop != NULL )     prop_from_prop( obj );

    for ( prop_content = obj->contains; prop_content; prop_content = prop_next )
    {
	prop_next = prop_content->next_content;
	extract_prop( obj->contains );
    }

    if ( prop_list == obj )
    {
	prop_list = obj->next;
    }
    else
    {
	PROP_DATA *prev;

	for ( prev = prop_list; prev != NULL; prev = prev->next )
	{
	    if ( prev->next == obj )
	    {
		prev->next = obj->next;
		break;
	    }
	}

	if ( prev == NULL )
	{
	    bug( "Extract_prop: obj %d not found.", obj->pIndexData->vnum );
	    return;
	}
    }

    {
	BONUS_DATA *paf;
	BONUS_DATA *paf_next;

	for ( paf = obj->bonus; paf != NULL; paf = paf_next )
	{
	    paf_next    = paf->next;

        free_bonus( paf );
	}
    }

    {
	EXTRA_DESCR_DATA *ed;
	EXTRA_DESCR_DATA *ed_next;

	for ( ed = obj->extra_descr; ed != NULL; ed = ed_next )
	{
	    ed_next		= ed->next;

        free_extra_descr( ed );
	}
    }

    free_string( obj->name        );
    free_string( obj->description );
    free_string( obj->description_plural );
    free_string( obj->short_descr );
    free_string( obj->short_descr_plural );
    free_string( obj->action_descr );
    free_string( obj->real_description );
    --obj->pIndexData->count;
    obj->next	= prop_free;
    prop_free	= obj;
    return;
}



/*
 * Extract a char from the world.
 */
void extract_char( PLAYER_DATA *ch, bool fPull )
{
    PLAYER_DATA *wch;
    PROP_DATA *obj;
    PROP_DATA *prop_next;
    VARIABLE_DATA *pVar;
    VARIABLE_DATA *pVar_next;

    if ( ch->in_scene == NULL )
    {
	bug( "Extract_char: NULL.", 0 );
	return;
    }

    if ( fPull )
    {
        PLAYER_DATA *pet;
        PLAYER_DATA *pet_next;

        for ( pet = char_list; pet != NULL; pet = pet_next )
        {
            pet_next = pet->next;
            if ( ch != pet
              && ( pet->master == ch )
              && IS_SET(pet->act, ACT_PET) )
            extract_char( pet, TRUE );
        }
    }

    for ( pVar = mud_var_list;  pVar != NULL;  pVar = pVar_next )
    {
        pVar_next = pVar->next_mud_var;
        if ( pVar->type == TYPE_ACTOR && (PLAYER_DATA *)pVar->value == ch )
        {
            pVar->type  = TYPE_STRING;
            pVar->value = str_dup( "" );
        }
    }

    {
        PLAYER_DATA *clist;

        for ( clist = char_list;  clist != NULL;  clist = clist->next )
        {
            if ( clist->pcdata != NULL )
            {
                if ( clist->pcdata->trackscr == ch )
                    cmd_script( clist, "" );
            }
        }
    }

    if ( ch->haggling != NULL )
    {
        if ( ch->haggling->carried_by == NULL )
        extract_prop( ch->haggling );
        ch->haggling = NULL;
    }

    if ( fPull )
	die_follower( ch );

    stop_fighting( ch, TRUE );

    for ( obj = ch->carrying; obj != NULL; obj = prop_next )
    {
	prop_next = obj->next_content;
	extract_prop( obj );
    }
    
    char_from_scene( ch );
    
    if ( ch->riding != NULL )
    {
       ch->riding->rider = NULL;
       ch->riding             = NULL;
    }
    
    if ( ch->rider != NULL )
    {
       ch->rider->riding = NULL;
       ch->rider         = NULL;
    }
    
    if ( !IS_NPC(ch) )
        PC(ch,condition)[COND_THIRST] = 100;

    
    if ( !fPull )
    {
    char_to_scene( ch, get_scene_index( ROOM_VNUM_DEATH ) );
    cmd_look( ch, "auto" );
	return;
    }

    if ( IS_NPC(ch) )
	--ch->pIndexData->count;

    if ( ch->desc != NULL && ch->desc->original != NULL )
	cmd_return( ch, "" );

    if ( ch->desc != NULL ) ch->desc->snoop_by = NULL;


    if ( ch == char_list )
    {
       char_list = ch->next;
    }
    else
    {
	PLAYER_DATA *prev;

	for ( prev = char_list; prev != NULL; prev = prev->next )
	{
	    if ( prev->next == ch )
	    {
		prev->next = ch->next;
		break;
	    }
	}

	if ( prev == NULL )
	{
	    bug( "Extract_char: char not found.", 0 );
	    return;
	}
    }

    for ( wch = mount_list;  wch != NULL;  wch = wch->next )
    {
        if ( wch->master != ch )
        continue;

        /*
         * Clip from mount list (on first).
         */
        if ( wch == mount_list )
        {
            mount_list = mount_list->next;
        }
        else
        {
            PLAYER_DATA *prev;

            for ( prev = mount_list; prev != NULL; prev = prev->next )
            {
                /*
                 * Clip from list.
                 */
                if ( prev->next == wch )
                {
                    prev->next = wch->next;
                    break;
                }
            }

            if ( prev == NULL && wch->next != NULL )
            {
                bug( "Extract_char: mount not found.", 0 );
                return;
            }
        }
        /*
         * Watch for recursion.
         */
        extract_char( wch, TRUE );
    }

    if ( ch->desc )
	ch->desc->character = NULL;
    free_char( ch );
    return;
}



/*
 * Find a char in the scene.
 */
PLAYER_DATA *get_char_scene( PLAYER_DATA *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    PLAYER_DATA *rch;
    int number;
    int count;

    number = number_argument( argument, arg );
    count  = 0;

    if ( !str_cmp( arg, "self" ) || !str_cmp( arg, "me" ) )
	return ch;

    if ( !str_cmp( arg, "mount" ) )
    return ch->riding;

    for ( rch = ch->in_scene->people; rch != NULL; rch = rch->next_in_scene )
    {
        if ( ch == rch && count <= 1 )
        continue;
        
        if ( !can_see( ch, rch ) )
        continue;

        if ( !is_name( arg, STR(rch, name) ) )
        {
            if ( !IS_NPC(rch) && is_name( arg, rch->keywords ) )
            ;
            else continue;
        }

        if ( ++count == number )
            return rch;
    }
    
    if ( !is_name( arg, STR(ch, name) ) )
    {
        if ( !IS_NPC(ch) && is_name( arg, ch->keywords ) )
        return ch;
    }   

    return NULL;
}




/*
 * Find a char in the world.
 */
PLAYER_DATA *get_char_world( PLAYER_DATA *ch, char *argument )
{
    char arg[MAX_INPUT_LENGTH];
    PLAYER_DATA *wch;
    int number;
    int count;

    if ( ( wch = get_char_scene( ch, argument ) ) != NULL )
	return wch;

    number = number_argument( argument, arg );
    count  = 0;
    for ( wch = char_list; wch != NULL ; wch = wch->next )
    {
        if ( !can_see( ch, wch ) )
        continue;

        if ( !is_name( arg, STR(wch, name) ) )
        {
            if ( !IS_NPC(wch) && is_name( arg, wch->keywords ) )
            ;
            else continue;
        }

        if ( ++count == number )
            return wch;
    }

    return NULL;
}



/*
 * Find some prop with a given index data.
 * Used by zone-reset 'P' command.
 */
PROP_DATA *get_prop_type( OBJ_INDEX_DATA *pPropIndex )
{
    PROP_DATA *obj;

    for ( obj = prop_list; obj != NULL; obj = obj->next )
    {
	if ( obj->pIndexData == pPropIndex )
	    return obj;
    }

    return NULL;
}



      
/*
 * Return # of props which an prop counts as.
 * Thanks to Tony Chamberlain for the correct recursive code here.
 */
int get_prop_number( PROP_DATA *obj )
{
    int number;

    if ( obj->item_type == ITEM_CONTAINER )
	number = 0;
    else
	number = 1;

    for ( obj = obj->contains; obj != NULL; obj = obj->next_content )
	number += get_prop_number( obj );

    return number;
}



/*
 * Return weight of an prop, including weight of contents.
 * Danger: Recursion ahead.
 */
int get_prop_weight( PROP_DATA *obj )
{
    int weight;

    weight = obj->weight;
    if ( obj->item_type == ITEM_DRINK_CON )
    weight += obj->value[0]/10;

    for ( obj = obj->contains; obj != NULL; obj = obj->next_content )
	weight += get_prop_weight( obj );

    return weight;
}



/*
 * True if scene is dark.
 */
int scene_is_dark( ROOM_INDEX_DATA *pSceneIndex )
{
    if ( pSceneIndex == NULL ) return FALSE;

    /*
     * Someone gotta light?
     */
    if ( pSceneIndex->light > 0 )
    return FALSE;

    /*
     * Is it supposed to be dark here?
     */
    if ( IS_SET(pSceneIndex->scene_flags, ROOM_DARK) )
    return TRUE;

    /*
     * Are we inside?
     */
    if ( pSceneIndex->sector_type == SECT_INSIDE )
    return FALSE;

    /*
     * If it is daylight.
     */
    if ( weather_info.sunlight == SUN_RISE
      || weather_info.sunlight == SUN_LIGHT )
    return FALSE;

    /*
     * If the moon is out and you're in the city or a field.
     */
    if ( weather_info.sunlight == MOON_RISE
      && weather_info.sky == SKY_CLOUDLESS
      && (pSceneIndex->sector_type == SECT_FIELD
       || pSceneIndex->sector_type == SECT_CITY) )
    return FALSE;

    /* 
     * If the sky is cloudy and you're in the forest..
     */
    if ( weather_info.sky != SKY_CLOUDLESS
      && pSceneIndex->sector_type == SECT_FOREST )
    return TRUE;
 

    return FALSE;
}



/*
 * True if scene is private.
 */
bool scene_is_private( ROOM_INDEX_DATA *pSceneIndex )
{
    PLAYER_DATA *rch;
    int count;

    if ( pSceneIndex->max_people == 0 )
    return FALSE;

    count = 0;
    for ( rch = pSceneIndex->people; rch != NULL; rch = rch->next_in_scene )
	count++;

    if ( count >= pSceneIndex->max_people )
	return TRUE;

    return FALSE;
}



/*
 * True if char can see victim.
 */
bool can_see( PLAYER_DATA *ch, PLAYER_DATA *victim )
{
    if ( ch == victim )
	return TRUE;
    
    if ( !IS_NPC(ch) && IS_SET(ch->act2, WIZ_HOLYLIGHT) )
	return TRUE;

    if ( IS_AFFECTED(ch, AFF_BLIND) )
	return FALSE;

    if ( scene_is_dark( ch->in_scene ) && !IS_AFFECTED(ch, AFF_INFRARED) )
	return FALSE;

/*
    if ( IS_NPC(ch) && HAS_SCRIPT(ch) && !IS_SET(ch->act, ACT_AGGRESSIVE ) )
    return TRUE;
 */

    if ( IS_AFFECTED(victim, AFF_INVISIBLE)
    &&   !IS_AFFECTED(ch, AFF_DETECT_INVIS) )
	return FALSE;

    if ( IS_AFFECTED(victim, AFF_HIDE)
    &&   !IS_AFFECTED(ch, AFF_DETECT_HIDDEN)
    &&   victim->fighting == NULL
    &&   ( IS_NPC(ch) ? !IS_NPC(victim) : IS_NPC(victim) ) )
	return FALSE;

    if (  get_trust( ch ) < GET_PC(victim,wizinvis,0)
       && get_trust( ch ) < get_trust( victim ) )
    return FALSE;

    return TRUE;
}



/*
 * True if char can see obj.
 */
bool can_see_prop( PLAYER_DATA *ch, PROP_DATA *obj )
{
    if ( !IS_NPC(ch) && IS_SET(ch->act2, WIZ_HOLYLIGHT) )
	return TRUE;

    if ( IS_AFFECTED( ch, AFF_BLIND ) )
    return FALSE;

    if ( IS_SET( obj->extra_flags, ITEM_BURNING ) )
    return TRUE;

    if ( obj->item_type == ITEM_LIGHT && IS_LIT( obj ) )
	return TRUE;

    if ( scene_is_dark( ch->in_scene ) && !IS_AFFECTED(ch, AFF_INFRARED) )
	return FALSE;

    if ( IS_SET(obj->extra_flags, ITEM_INVIS)
    &&   !IS_AFFECTED(ch, AFF_DETECT_INVIS) )
	return FALSE;

    return TRUE;
}



/*
 * True if char can drop obj.
 */
bool can_drop_prop( PLAYER_DATA *ch, PROP_DATA *obj )
{
    if ( !IS_SET(obj->extra_flags, ITEM_NODROP) )
	return TRUE;

    if ( IS_IMMORTAL(ch) )
	return TRUE;

    if ( NOT_WORN( obj ) )
    return TRUE;

    return FALSE;
}


/*
 * Get an extra description from a list.
 */
char *get_extra_descr( const char *name, EXTRA_DESCR_DATA *ed )
{
    for ( ; ed != NULL; ed = ed->next )
    {
	if ( is_name( name, ed->keyword ) )
        return ed->description;
    }
    return NULL;
}



/*
 * Use up some of a tool.
 */
bool use_tool( PROP_DATA *obj, int bit )
{
    if ( obj == NULL
      || obj->item_type != ITEM_TOOL
      || !VAL_SET(obj, 0, bit) )
    return FALSE;

    if ( obj->value[1] <= 0 )
    return FALSE;

    obj->value[1]--;
    return TRUE;
}



/*
 * Find a percentage, with error checking.
 */
int PERCENTAGE( int amount, int max )
{
    if (max > 0) return (amount*100)/max;

    return amount*100;
}



/*
 * Check for a skill.
 */
bool skill_check( PLAYER_DATA *ch, int sn, int modifier )
{
    int level;

    /* Spawn last used time */
    if ( !IS_NPC(ch) )
	PC(ch, last_used)[sn] = 0;

    if ( modifier == 0 ) modifier = 100;
    
    level = LEARNED(ch,sn) > 0 ?
            INTERPOLATE(0, modifier, LEARNED(ch,sn)) : 0;

    if( URANGE(0, level, 100) > number_percent( ) )
    {
	/* Improvement by use chance 0% ... 4% */
    if ( ((4 - int_app[get_curr_int(ch)].learn)/4)+1 >=number_range(1,100))
        advance_skill( ch, sn, number_range(1,skill_table[sn].max_prac),0);
	return TRUE;
    }
    else
    {
	/* Learn from mistakes 0% ... 3% */
    if ( ((2 - int_app[get_curr_int(ch)].learn)/4)+1 >= number_range(1,100) )
        advance_skill( ch, sn, number_range(1,skill_table[sn].max_prac),0);
	return FALSE;
    }
}


/*
 * Check the wield weight of a actor, for quick equations.
 */
int wield_weight( PLAYER_DATA *ch )
{
    int weight;
    PROP_DATA *w1, *w2, *sh;

    w1 = get_eq_char(ch, WEAR_WIELD_1);
    w2 = get_eq_char(ch, WEAR_WIELD_2);
    sh = get_eq_char(ch, WEAR_SHIELD);

    weight = 0;
    if ( w1 ) weight += w1->weight;
    if ( w2 ) weight += w2->weight;
    if ( sh ) weight += sh->weight;

    return weight;
}




bool is_hooded( PLAYER_DATA *ch )
{
    PLAYER_DATA *looker;
    PROP_DATA *hood;
    
    
    return FALSE;

    for ( looker = ch->in_scene->people; 
          looker != NULL; 
          looker = looker->next_in_scene ) {
        if( ( hood = get_eq_char( ch, WEAR_ABOUT ) ) != NULL
        && can_see_prop( looker, hood ) && hood->item_type == ITEM_CLOTHING
        && IS_SET( hood->value[1], HOODED )
        && IS_SET( hood->value[1], HOOD_UP ) )
            return TRUE;
    }
    return FALSE;
}
