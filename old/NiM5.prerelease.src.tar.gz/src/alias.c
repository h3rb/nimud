/*
struct alias_data {
    char *name;
    char *exp
    ALIAS_DATA *next;
}

struct command_queue {
    char *command;
    COMMAND_QUEUE *next;
}
 */

ALIAS_DATA *aliases;

/*
 * Adds an alias to a char.
 */
void add_alias( PLAYER_DATA *ch, char *name, char *exp )
{
     ALIAS_DATA *alias;
     ALIAS_DATA *alias_next;

     if ( IS_NPC(ch) ) return;

     alias_next = PC(ch,aliases)
     alias = new_alias_data( );
     alias->alias = str_dup( name );
     alias->alias = str_dup( exp );
     PC(ch,aliases) = alias;
     return;
}

/*
 * Finds an alias from the command.
 */
ALIAS_DATA *find_alias( PLAYER_DATA *ch, char *exp )
{
     ALIAS_DATA *alias;

     if ( IS_NPC(ch) ) return NULL;

     alias = PC(ch,alias);
     if ( alias == NULL ) return NULL;

     for ( alias = PC(ch,alias);  alias != NULL;  alias = alias->next )
     if ( alias && !str_cmp( alias->exp, exp ) ) return alias;

     return NULL;
}

/*
 * Syntax: alias [name]
 *         alias [name] edit
 *         alias [name] [command-list]
 *         alias [name] remove
 *         alias [name] delete
 *         alias off
 *
 * Related feature: 
 *         set alias
 */
void cmd_alias( PLAYER_DATA *ch, char *argument )
{
     char arg[MAX_STRING_LENGTH];
     ALIAS_DATA *alias;

     if ( IS_NPC(ch) ) return;

     argument = one_argument( argument, arg );
     
     if ( !IS_SET(ch->act2, PLR_ALIASES) )
     {
     SET_BIT(ch->act2,PLR_ALIASES);
     send_to_char( "Aliases enabled.\n\r", ch );
     return;
     }

     if ( !str_cmp( arg, "off" ) ) {
     send_to_char( "Aliases disabled.\n\r", ch );
     REMOVE_BIT(ch->act2,PLR_ALIASES);
     return;
     }

     if ( (alias = find_alias( ch, arg ) ) == NULL ) {
     add_alias( ch, arg, argument );     
     send_to_char( "Alias added." );
     return;
     }

     if ( !str_prefix( argument, "edit" )
     {
     string_append( ch, &alias->exp );
     return;
     }
 
     if ( !str_prefix( argument, "delete" )
       || !str_prefix( argument, "remove" )
     {
     ALIAS_DATA *alias_next;
     alias = alias->next;
     return;
     }
}

/*
 * Converts an alias to a command queue.
 * Adds the queue to the end of a command list.
 */
char *alias_to_queue( PLAYER_DATA *ch, char *exp )
{
    COMMAND_DATA *cd;
const char command[MAX_STRING_LENGTH];
    char *point;
    char *original; 

    /*
     * Grab the command.
     * cmd;cmd
     * ^
     */

    while ( *exp != '\0' ) {  

    exp = skip_spaces( exp );
    point = command;
    while ( *exp != ';'
         && *exp != ' '
         && *exp != '\0' ) *point++ = *exp++;
    *point = '\0';
    exp = skip_spaces( exp );

    cd = new_command_queue_data( );
    cd->command = str_dup( command ); 
    cd->next = NULL;

            

    }
    return;
}

