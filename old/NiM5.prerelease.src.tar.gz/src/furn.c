/******************************************************************************
 * Locke's   __ -based on merc v2.2-____        NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5.1a  Version 5.1a (ALPHA)          *
 * |  /   \  __|  \__/  |  | |  |      |        unreleased+revamped 2004      *
 * |       ||  |        |  \_|  | ()   |                                      *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/

#if defined(BSD)
#include <types.h>
#else
#include <sys/types.h>
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "nimud.h"

/*
 * List occupants.
 */
void show_occupants_to_char( PROP_DATA *obj, PLAYER_DATA *ch )
{
    PLAYER_DATA *och;

    for ( och = ch->in_scene->people; och != NULL; och = och->next_in_scene )
    {
    if ( och->furniture == obj && can_see( ch, och ) )
    act( "$N $K $t on it.", ch, position_name( och->position ), och, TO_CHAR );
    }
    return;
}


/*
 * Count occupants.
 */
int count_occupants( PROP_DATA *obj )
{
    PLAYER_DATA *och;
    int count = 0;

    if ( obj->in_scene == NULL )
    return -1;

    for ( och = char_list; och != NULL; och = och->next )
        if ( och->furniture == obj ) count++;

    return count;
}



bool has_occupant( PROP_DATA *obj )
{
    PLAYER_DATA *och;

    for ( och = char_list; och != NULL; och = och->next )
    {
        if ( och->furniture == obj )
          return TRUE;
    }
    return FALSE;
}



bool occupant( PROP_DATA *obj )
{
    PLAYER_DATA *och;

    for ( och = char_list; och != NULL; och = och->next )
    {
        if ( och->furniture == obj  )
          return TRUE;
    }
    return FALSE;
}


PLAYER_DATA *hitched( PROP_DATA *obj )
{
    PLAYER_DATA *och;

    for ( och = char_list; och != NULL; och = och->next )
    {
        if ( och->hitched_to == obj )
          return och;
    }
    return NULL;
}




PROP_DATA *get_furn_here( PLAYER_DATA *ch, char *argument )
{
    PROP_DATA *obj;
    PROP_DATA *saved = NULL;

    for ( obj = ch->in_scene->contents;  obj != NULL;  obj = obj->next_content )
    {
        if ( is_name(argument,STR(obj,name))
          && obj->item_type == ITEM_FURNITURE
          && ( saved == NULL || !OCCUPADO(obj) ) )
            saved = obj;
    }       
    return saved;
}




void set_furn( PLAYER_DATA *ch, PROP_DATA *obj )
{
    ch->furniture = NULL;

    if ( obj == NULL ) return;

    if ( OCCUPADO(obj) )
    {
        bug( "set_furn: Occupado.", 0 );
        return;
    }

    ch->furniture = obj;
    return;
}


