/*
 * Mood effects for NPCs and PCs.
 */


char *mood_to_face( int mood ) {
     switch ( mood ) {
         case MOOD_HAPPY: return "=)"; break;
         case MOOD_SAD: return "=("; break;
         case MOOD_ANGRY: return ";O"; break;
         case MOOD_DESPAIR: return "D="; break;
         case MOOD_EXCITED: return "=D"; break;
          default: return ":0"; break;
     }
}
