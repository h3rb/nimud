/******************************************************************************
 * Locke's   __ -based on merc v2.2-____        NIM Server Software           *
 * ___ ___  (__)__    __ __   __ ___|  | v5.1a  Version 5.1a                  *
 * |  /   \  __|  \__/  |  | |  |      |        documentation release         *
 * |       ||  |        |  \_|  | ()   |        Valentines Day Massacre 2003  *
 * |    |  ||  |  |__|  |       |      |                                      *
 * |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
 *   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
 ******************************************************************************/

/*
 * Connected state for a channel.
 */
#define CON_PLAYING                      0
#define CON_SHOW_TITLE                   1
#define CON_READ_MOTD                    2
#define CON_HOTBOOT_RECOVER		 3

#define CON_LOGIN_MENU                  10
#define CON_DOC_MENU                    20

#define CON_GEN_MENU                    30
#define CON_GEN_RACES                   31
#define CON_GEN_SEX                     32
#define CON_GEN_NAME                    33

/*
 * Connected state for a channel.
 */
#define CON_PLAYING			 0
#define CON_SHOW_TITLE                   1
#define CON_READ_MOTD                    2

#define CON_LOGIN_MENU                  10
#define CON_DOC_MENU                    20

#define CON_STAT_MENU                   50
#define CON_STAT_STR                    51
#define CON_STAT_INT                    52
#define CON_STAT_WIS                    53
#define CON_STAT_DEX                    54
#define CON_STAT_CON                    55
#define CON_STAT_AGE                    56
#define CON_STAT_SIZE                   57

#define CON_CONFIRM_NEW_NAME            60
#define CON_GET_NEW_PASSWORD            61
#define CON_CONFIRM_NEW_PASSWORD        62
#define CON_SHOW_INTRO                  63

#define CON_CHAR_GEN_NAME               64
#define CON_CHAR_GEN_EMAIL              65
#define CON_CHAR_GEN_SUBSCRIBE          66
#define CON_CHAR_GEN_COLOR              67

#define CON_CHAR_GEN_SEX                69
#define CON_CHAR_GEN_RACE               70
#define CON_CHAR_GEN_RACE_CONFIRM       71

#define CON_GET_NAME                    73
#define CON_GET_OLD_PASSWORD            74

#define CON_MESSAGES                    -1

#define CON_ZEDITOR                     -5
#define CON_REDITOR                     -6
#define CON_AEDITOR                     -7
#define CON_OEDITOR                     -8
#define CON_SEDITOR                     -9
#define CON_HEDITOR                     -10
#define CON_RECOVER                     -99

#define CONNECTED(d)        ( d->connected <= CON_PLAYING )

