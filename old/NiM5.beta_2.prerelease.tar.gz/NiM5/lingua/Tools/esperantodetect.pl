#! /usr/bin/perl

# Detect encoding used for Esperanto text file.

use strict;

my @tmp;

my ($fundamento,$funda1,$funda2);
my $ikest;
my $ccitt1;
my $ccitt2;
my $iso88593;
my $utf8;

while (<>) {
	$funda1     += scalar (@tmp = /[hj]h/g);	# u^ is not in this encoding
	$funda2     += scalar (@tmp = /[cgs]h/g);	# u^ is not in this encoding
	$ikest      += scalar (@tmp = /[cghjsu]x/g);
	$ccitt1     += scalar (@tmp = /(\^[cghjs]|\~u)/g);
	$ccitt2     += scalar (@tmp = /([cghjs]\^|u\~)/g);
	$iso88593   += scalar (@tmp = /[������]/g);
	$utf8       += scalar (@tmp = /(�[��������]|�[����])/g);
}

$fundamento = $funda1 + $funda2;

print "Fundamento:\t$funda1 (+$funda2)\n";
print "IKEST:\t\t$ikest\n";
print "CCITT (1):\t$ccitt1\n";
print "CCITT (2):\t$ccitt2\n";
print "ISO-8859-3:\t$iso88593\n";
print "UTF-8:\t\t$utf8\n";
