# vi: ts=8 sw=8 sts=8

package Tongues::GaganaSamoa;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Baltic CP1257 / ISO 8859-13 / Latin-7

# Alphabetical order
# A E (H) I (K) O U F G L M N P (R) S T V
# a e (h) i (k) o u f g l m n p (r) s t v

# Extra characters (ISO & Windows)
# � � � � �
# � � � � � `

# "Break" is usualy written ' or left single quote "6", I'm using ` because
#   Hawaiian uses it, Latin-7 doesn't support "6", and ' is ambiguous.
# The "accent" macron is often omitted and possibly sometimes a double vowel
#   is used in its place.
# "Break" and "accent" don't affect sorting.

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::BalticWin;

$charset = new Charsets::BalticWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# GaganaSamoa to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 'le'	=> { 'x' => 'the',
	     't' => 'art' },
 #   Indefinite articles
 #    Singular
 'se'	=> { 'x' => 'a',
		     '#' => 'an',
	     't' => 'art' },
 'si'	=> { 'x' => 'a',
		     '#' => 'an; diminutive',
	     't' => 'art' },
 #    Plural
 'ni'	=> { 'x' => 'some',
		     '#' => 'really an article?',
	     't' => 'art' },
 'nai'	=> { 'x' => 'some',
		     '#' => 'diminutive; really an article?',
	     't' => 'art' },
 #  Pronouns & possessive adjectives
 #   1st person inclusive
# 'kita' (te)
# 'a\'u' '(\'ou ~ o\'u)'
# 'o\'e' '(\'ee)'
 #   1st person exclusive
# 'kita' '(te)'
# '\'itaa\'ua' '(taa)'
# '\'itaatou' '(taatou)'
 #   2nd person (past here is still Maori)
# 'koe'
# 'koorua'
# 'koutou'
 #   3rd person
# 'ia'
# 'raaua'
# 'raatou'
 #   1st person exclusive
 #   2nd person
 #   3rd person
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 'a'	=> { 'x' => 'of',
		     '#' => 'active; cf o',
	     't' => 'p' },
 'o'	=> { 'x' => 'of',
		     '#' => 'passive; cf a',
	     't' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'tasi'		=> { 'x' => 'one' },
 'lua'		=> { 'x' => 'two' },
 'tolu'		=> { 'x' => 'three' },
 'f�'		=> { 'x' => 'four' },
 'lima'		=> { 'x' => 'five' },
 'ono'		=> { 'x' => 'six' },
 'fitu'		=> { 'x' => 'seven' },
 'valu'		=> { 'x' => 'eight' },
 'iva'		=> { 'x' => 'nine' },
 'sefulu'	=> { 'x' => 'ten' },
 'gafulu'	=> { 'x' => 'ten' },
 'lau'		=> { 'x' => 'hundred' },
 'selau'	=> { 'x' => 'hundred' },
 'afe'		=> { 'x' => 'thousand' },
 # Days and months
 # Key verbs
 'ola'		=> { 'x' => 'live',
		     '#' => 'be',
		     't' => 'v' },
 'nofo'		=> { 'x' => 'stay',
		     '#' => 'be',
		     't' => 'v' },
 'maua'		=> { 'x' => 'obtain',
		     '#' => 'aquire, have got',
		     't' => 'v' },
 # Vocabulary
 'mataupu'	=> { 'x' => 'article',
		     't' => 'n' },
);
}

1;

