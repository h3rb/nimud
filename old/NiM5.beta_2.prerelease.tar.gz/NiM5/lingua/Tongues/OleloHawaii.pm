# vi: ts=8 sw=8 sts=8

package Tongues::OleloHawaii;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Baltic CP1257 / ISO 8859-13 / Latin-7

# Alphabetical order
# A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
# a b c d e f g h i j k l m n o p q r s t u v w x y z

# Extra characters (ISO & Windows)
# � � � � �
# � � � � � `

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::BalticWin;

$charset = new Charsets::BalticWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# OleloHawaii to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #  (From http://www.ultrasw.com/pawlowski/brendan/Hawaiian.html)
 #   1st person inclusive
 'k�ua'		=> { 'x' => 'we' },
 'k�kou'	=> { 'x' => 'we' },
 #   1st person exclusive
 '`au'		=> { 'x' => 'i' },
 'wau'		=> { 'x' => 'i' },
 'm�ua'		=> { 'x' => 'we' },
 'm�kou'	=> { 'x' => 'we' },
 #   2nd person (past here is still Maori)
 '`oe'		=> { 'x' => 'you' },
 '`olua'	=> { 'x' => 'you' },
 '`oukou'	=> { 'x' => 'you' },
 #   3rd person
 'ia'		=> { 'x' => 'he' },
 'l�ua'		=> { 'x' => 'they' },
 'l�kou'	=> { 'x' => 'they' },
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # From Perth library book on Polynesian languages:
 'kahi'		=> { 'x' => 'one' },
 'lua'		=> { 'x' => 'two' },
 'kolu'		=> { 'x' => 'three' },
 'haa'		=> { 'x' => 'four' },
 'lima'		=> { 'x' => 'five' },
 'ono'		=> { 'x' => 'six' },
 'hiku'		=> { 'x' => 'seven' },
 'walu'		=> { 'x' => 'eight' },
 'iwa'		=> { 'x' => 'nine' },
 '`umi'		=> { 'x' => 'ten' },
 'haneli'	=> { 'x' => 'hundred' },
 'kaukani'	=> { 'x' => 'thousand' },
 # From Internet http://ourworld.compuserve.com/homepages/GenX_jt_mtjr/GenXHawaiian.html 
 # and http://www.geocities.com/TheTropics/Shores/6794/olelonumbers8-20-97.html
 # and http://www.ultrasw.com/pawlowski/brendan/Hawaiian.html
 '`ole'		=> { 'x' => 'zero' },
 '`ekahi'	=> { 'x' => 'one' },
 'ho`okahi'	=> { 'x' => 'one' },
 '`elua'	=> { 'x' => 'two' },
 '`ekolu'	=> { 'x' => 'three' },
 '`eh�'		=> { 'x' => 'four' },
 '`elima'	=> { 'x' => 'five' },
 '`eono'	=> { 'x' => 'six' },
 '`ehiku'	=> { 'x' => 'seven' },
 '`ewalu'	=> { 'x' => 'eight' },
 '`eiwa'	=> { 'x' => 'nine' },
 '`umie'	=> { 'x' => 'ten' },
 '`umi'		=> { 'x' => 'ten' },
 'hanele'	=> { 'x' => 'hundred' },
 'haneli'	=> { 'x' => 'hundred' },
 'haneri'	=> { 'x' => 'hundred' },
 'kaukani'	=> { 'x' => 'thousand' },
 'miliona'	=> { 'x' => 'million' },
 # Days and months
 # Key verbs
 # Vocabulary
 'aloha'	=> { 'x' => 'love' },
 '`awapuhi'	=> { 'x' => 'ginger',
		     't' => 'n' },
 'honi'		=> { 'x' => 'kiss',
		     '#' => 'noun and verb; smell; sniff; scent' },
 'ho`oheno'	=> { 'x' => 'cherish',
		     '#' => 'love, caress',
		     't' => 'v' },
 'ipo'		=> { 'x' => 'sweetheart',
		     't' => 'n' },
 'kanak�'	=> { 'x' => 'candy',
		     '#' => 'lollies; sweets',
		     't' => 'n' },
 'lei'		=> { 'x' => 'garland',
		     '#' => 'necklace',
		     't' => 'n' },
 'liko'		=> { 'x' => 'bud',
		     '#' => 'of flower',
		     't' => 'n' },
 'mahamaha'	=> { 'x' => 'show affection',
		     't' => 'v' },
 'pauk�'	=> { 'x' => 'article',
		     't' => 'n' },
 'p�'		=> { 'x' => 'babe',
		     't' => 'n' },
 'p�p�'		=> { 'x' => 'baby',
		     't' => 'n' },
 'pua'		=> { 'x' => 'flower',
		     't' => 'n' },
 'pu`uwai'	=> { 'x' => 'heart',
		     't' => 'n' },
 '`ume'		=> { 'x' => 'attractive',
		     '#' => 'attraction' },
);
}

1;

