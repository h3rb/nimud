# vi: ts=8 sw=8 sts=8

package Tongues::Islensku;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A � B (C) D E � F G H I � J K L M N O � P (Q) R S T U � V (W) X Y � (Z) � � �
# a � b (c) d e � f g h i � j k l m n o � p (q) r s t u � v (w) x y � (z) � � �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Nouns
 #  Strong nouns
 #   Strong masculine nouns
 #    Group SM1 Genitive Singular -s (-ar), Nominative Plural -ar.
 #     Hestur - horse
 #[ 'ur',	'ur',	'',		'',	'n' ],	# NS
 [ 'ar',	'ur',	'',		's',	'n' ],	# NP
 [ '',		'ur',	'',		'',	'n' ],	# AS
 [ 'a',		'ur',	'',		's',	'n' ],	# AP
 [ 'i',		'ur',	'',		'',	'n' ],	# DS
 [ 'um',	'ur',	'',		's',	'n' ],	# DP
 [ 's',		'ur',	'',		'',	'n' ],	# GS
 [ 'a',		'ur',	'',		's',	'n' ],	# GP
 #    St�ll - Chair 
 #[ 'l',	'l',	'',		'',	'n' ],	# N
 [ 'ar',	'l',	'',		's',	'n' ],	# NP
 [ '',		'l',	'',		'',	'n' ],	# A
 [ 'a',		'l',	'',		's',	'n' ],	# AP
 [ 'i',		'l',	'',		'',	'n' ],	# D
 [ 'um',	'l',	'',		's',	'n' ],	# DP
 [ 's',		'l',	'',		'',	'n' ],	# G
 [ 'a',		'l',	'',		's',	'n' ],	# GP
 #    Group SM2 Genitive Singular -s (-jar), Nominative Plural -ir. 
 #     Smi�ur - smith 
 #[ 'ur',	'ur',	'',		'',	'n' ],	# N
 [ 'ir',	'ur',	'',		'',	'n' ],	# NP
 [ '',		'ur',	'',		'',	'n' ],	# A
 [ 'i',		'ur',	'',		'',	'n' ],	# AP
 [ '',		'ur',	'',		'',	'n' ],	# D
 [ 'um',	'ur',	'',		'',	'n' ],	# DP
 [ 's',		'ur',	'',		'',	'n' ],	# G
 [ 'a',		'ur',	'',		'',	'n' ],	# GP
 #     Veggur - wall 
 #    Group SM3 Genitive Singular -ar, Nominative Plural -ir. 
 #    Group SM4 Nominative Plural -ur. Only six common words: 
 #   Strong feminine nouns
 #    Group SF1 Genitive Singular -ar, (-r), Nominative Plural -ar. 
 #    Group SF2
 #    Group SF3 Genitive Singular -ar (-ur, r), Nominative Plural -ur (-r). 
 #   Strong neuter nouns
 #    Genitive Singular -s, Nominative Plural without ending. 
 #  Weak nouns
 #   Weak masculine nouns
 #    Group WM1 Genitive Singular -a, Nominative Plural -ar. 
 #    Group WM2 Genitive Singular -a, Nominative Plural -ur. 
 #   Weak feminine nouns
 #    Group WF1
 #    Group WF2 Genitive Singular -i (-is), Nominative Plural without ending or -ar, ir. 
 #   Weak neuter nouns
 # Adjectives
 #  Strong adjectives
 #   Singular
 #[ 'ur',	'ur',	'',		'',	'a' ],	# NM
 [ '',		'ur',	'',		'',	'a' ],	# NF
 [ 't',		'ur',	'',		'',	'a' ],	# NN
 [ 'an',	'ur',	'',		'',	'a' ],	# AM
 [ 'a',		'ur',	'',		'',	'a' ],	# AF
 [ 't',		'ur',	'',		'',	'a' ],	# AN
 [ 'um',	'ur',	'',		'',	'a' ],	# DM
 [ 'ri',	'ur',	'',		'',	'a' ],	# DF
 [ 'u',		'ur',	'',		'',	'a' ],	# DN
 [ 's',		'ur',	'',		'',	'a' ],	# GM
 [ 'rar',	'ur',	'',		'',	'a' ],	# GF
 [ 's',		'ur',	'',		'',	'a' ],	# GN
 #   Plural
 [ 'ir',	'ur',	'',		'',	'a' ],	# NMP
 [ 'ar',	'ur',	'',		'',	'a' ],	# NFP
 [ '',		'ur',	'',		'',	'a' ],	# NNP
 [ 'a',		'ur',	'',		'',	'a' ],	# AMP
 [ 'ar',	'ur',	'',		'',	'a' ],	# AFP
 [ '',		'ur',	'',		'',	'a' ],	# ANP
 [ 'um',	'ur',	'',		'',	'a' ],	# DMP
 [ 'um',	'ur',	'',		'',	'a' ],	# DFP
 [ 'um',	'ur',	'',		'',	'a' ],	# DNP
 [ 'ra',	'ur',	'',		'',	'a' ],	# GMP
 [ 'ra',	'ur',	'',		'',	'a' ],	# GFP
 [ 'ra',	'ur',	'',		'',	'a' ],	# GNP
 #  Weak adjectives - Used when there is an article or pronoun present. 
 # Verbs
 #  Group 1 Weak Verbs: Telja, etc.
 #   telja - to count: # tel--taldi--t�ldum--talinn/taldur 
 #   spyrja - to ask: # spyr--spur�i--spur�um--spur�ur 
 #   fl�ja - to flee: # fl�--fl��i--fl��um--fl�inn 
 #  Group 2 Weak Verbs: D�ma, etc.
 #   d�ma - to judge: # d�mi--d�mdi--d�mdum--d�mdur 
 #   s�kkva - to sink (transitive): # s�kkvi--s�kkti--s�kktum--s�kktur 
 #  Group 3 Weak Verbs: Lifa, etc.
 #   lifa - to live: # lifi--lif�i--lif�um--lif�ur 
 #   segja - to say: # segi--sag�i--s�g�um--sag�ur 
 #   vaka - to be awake: # vaki--vakti--v�ktum--vakinn/vaktur 
 #  Group 4 Weak Verbs: Kalla, etc.
 #   kalla - to call: # kalla--kalla�i--k�llu�um--kalla�ur 
 #   h�rga - to gladden: # h�rga--h�rga�i--h�rgu�um--h�rga�ur 
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine		default for words ending in a
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative

# Islensku to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 'hins'		=> { 'x' => 'the',
		     '#' => 'mn:g' },
 'hina'		=> { 'x' => 'the',
		     '#' => 'f,mp:a' },
 'hinum'	=> { 'x' => 'the',
		     '#' => 'm:d,mnfp:d' },
 'hinna'	=> { 'x' => 'the',
		     '#' => 'mfnp:g' },
 'hin'		=> { 'x' => 'the',
		     '#' => 'f:n,np:na' },
 #    Masculine
 #     Singular
 'hinn'		=> { 'x' => 'the',
		     '#' => 'm:n,a' },
 #     Plural
 'hinir'	=> { 'x' => 'the',
		     '#' => 'mp:n' },
 #    Feminine
 #     Singular
 'hinni'	=> { 'x' => 'the',
		     '#' => 'f:d' },
 'hinnar'	=> { 'x' => 'the',
		     '#' => 'f:g' },
 #     Plural
 'hinar'	=> { 'x' => 'the',
		     '#' => 'fp:na' },
 #    Neuter
 #     Singular
 'hi�'		=> { 'x' => 'the',
		     '#' => 'n:n,a' },
 'hinu'		=> { 'x' => 'the',
		     '#' => 'n:d' },
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 '�g'		=> { 'x' => 'i',
		     '#' => 'nom',
 		     't' => 'pro' },
 'vi�'		=> { 'x' => 'we',
		     '#' => 'nom',
 		     't' => 'pro' },
 'mig'		=> { 'x' => 'me',
		     '#' => 'acc',
 		     't' => 'pro' },
 'okkur'	=> { 'x' => 'us',
		     '#' => 'acc,dat',
 		     't' => 'pro' },
 'm�r'		=> { 'x' => 'me',
		     '#' => 'dat',
 		     't' => 'pro' },
 'm�n'		=> { 'x' => 'my',
		     '#' => 'gen' },
 'pro'		=> { 'x' => 'our',
		     '#' => 'gen' },
 #   2nd person
 '��'		=> { 'x' => 'you',
		     '#' => 'N sing',
 		     't' => 'pro' },
 '�i�'		=> { 'x' => 'you',
		     '#' => 'N plu',
 		     't' => 'pro' },
 '��r'		=> { 'x' => 'you',
		     '#' => 'N polite',
 		     't' => 'pro' },
 '�ig'		=> { 'x' => 'you',
		     '#' => 'A sing',
 		     't' => 'pro' },
 'ykkur'	=> { 'x' => 'you',
		     '#' => 'A plu',
 		     't' => 'pro' },
 'y�ur'		=> { 'x' => 'you',
		     '#' => 'A polite',
 		     't' => 'pro' },
 '��r'		=> { 'x' => 'you',
		     '#' => 'D sing',
 		     't' => 'pro' },
 'ykkur'	=> { 'x' => 'you',
		     '#' => 'D plu',
 		     't' => 'pro' },
 'y�ur'		=> { 'x' => 'you',
		     '#' => 'D polite',
 		     't' => 'pro' },
 '��n'		=> { 'x' => 'your',
		     '#' => 'G sing' },
 'ykkar'	=> { 'x' => 'your',
		     '#' => 'G plu' },
 'y�ar'		=> { 'x' => 'your',
		     '#' => 'G polite' },
 #   3rd person
 #    Masculine
 'hann'		=> { 'x' => 'he',
		     '#' => 'N',
 		     't' => 'pro' },
 '�eir'		=> { 'x' => 'they',
		     '#' => 'N',
 		     't' => 'pro' },
 'hann'		=> { 'x' => 'him',
		     '#' => 'A',
 		     't' => 'pro' },
 '��'		=> { 'x' => 'them',
		     '#' => 'A',
 		     't' => 'pro' },
 'honum'	=> { 'x' => 'him',
		     '#' => 'D',
 		     't' => 'pro' },
 '�eim'		=> { 'x' => 'them',
		     '#' => 'D (masc+fem)',
 		     't' => 'pro' },
 'hans'		=> { 'x' => 'his',
		     '#' => 'G' },
 '�eirra'	=> { 'x' => 'their',
		     '#' => 'G (masc+fem)' },
 #    Feminine
 'h�n'		=> { 'x' => 'she',
		     '#' => 'N',
 		     't' => 'pro' },
 '��r'		=> { 'x' => 'they',
		     '#' => 'N',
 		     't' => 'pro' },
 'hana'		=> { 'x' => 'her',
		     '#' => 'A',
 		     't' => 'pro' },
 '��r'		=> { 'x' => 'them',
		     '#' => 'A',
 		     't' => 'pro' },
 'henni'	=> { 'x' => 'her',
		     '#' => 'D',
 		     't' => 'pro' },
# '�eim'	=> { 'x' => 'them',
#		     '#' => 'D',
# 		     't' => 'pro' },
 'hennar'	=> { 'x' => 'her',
		     '#' => 'G' },
# '�eirra'	=> { 'x' => 'their',
#		     '#' => 'G' },
 #    Neuter
 '�a�'		=> { 'x' => 'it',
		     '#' => 'N',
 		     't' => 'pro' },
 '�au'		=> { 'x' => 'they',
		     '#' => 'N',
 		     't' => 'pro' },
 '�a�'		=> { 'x' => 'it',
		     '#' => 'A',
 		     't' => 'pro' },
 '�au'		=> { 'x' => 'them',
		     '#' => 'A',
 		     't' => 'pro' },
 '�v�'		=> { 'x' => 'it',
		     '#' => 'D',
 		     't' => 'pro' },
 '�eim'		=> { 'x' => 'them',
		     '#' => 'D',
 		     't' => 'pro' },
 '�ess'		=> { 'x' => 'its',
		     '#' => 'G' },
 '�eirra'	=> { 'x' => 'their',
		     '#' => 'G' },
 #   Other pronouns
 'hver'		=> { 'x' => 'who',
		     '#' => 'which (of many); nom.masc+fem.sng' },
  'hverjum'	=> { 'x' => 'who',
		     '#' => 'dat.masc.sng;dat.plur' },
 #  Other functional words
 #   Prepositions Governing the Accusative
 #'fyrir ofan'	=> { 'x' => 'above', 
 #		     't' => 'p' },
 'gegnum'	=> { 'x' => 'through', 
		     't' => 'p' },
 'kringum'	=> { 'x' => 'round',
		     '#' => 'around ',
		     't' => 'p' },
 'um'		=> { 'x' => 'about',
		     '#' => 'around; across; during, by ',
		     't' => 'p' },
 'umfram'	=> { 'x' => 'above',
		     '#' => 'beyond ',
		     't' => 'p' },
 'umhverfis'	=> { 'x' => 'around',
		     't' => 'p' },
 #   Prepositions Governing the Dative.
 'a�'		=> { 'x' => 'to',
		     '#' => 'upto, at',
		     't' => 'p' },
 'af'		=> { 'x' => 'of',
		     '#' => 'from, by, off',
		     't' => 'p' },
 'andsp�nis'	=> { 'x' => 'directly',
		     '#' => 'opposite',
		     't' => 'p' },
 '�samt'	=> { 'x' => 'together',
		     '#' => 'with',
		     't' => 'p' },
 'fr�'		=> { 'x' => 'from',
		     't' => 'p' },
 'gagn'		=> { 'x' => 'against',
		     't' => 'p' },
 'gagnvart'	=> { 'x' => 'opposite',
		     't' => 'p' },
 'gegnt'	=> { 'x' => 'opposite to',
		     't' => 'p' },
 'handa'	=> { 'x' => 'for',
		     '#' => 'to',
		     't' => 'p' },
 'hj�'		=> { 'x' => 'with',
		     '#' => 'by, near',
		     't' => 'p' },
 'me�fram'	=> { 'x' => 'along',
		     't' => 'p' },
 'm�t'		=> { 'x' => 'against',
		     '#' => 'opposite',
		     't' => 'p' },
 'm�ti'		=> { 'x' => 'against',
		     '#' => 'opposite',
		     't' => 'p' },
 'n�l�gt'	=> { 'x' => 'near',
		     't' => 'p' },
 'undan'	=> { 'x' => 'from under',
		     't' => 'p' },
 '�r'		=> { 'x' => 'from',
		     '#' => ', out of',
		     't' => 'p' },
 #   Prepositions Governing the Accusative or Dative.
 '�'		=> { 'x' => 'on',
		     '#' => 'at, in, of',
		     't' => 'p' },
 'eftir'	=> { 'x' => 'after',
		     '#' => 'by, behind',
		     't' => 'p' },
 'fyrir'	=> { 'x' => 'for',
		     '#' => 'before, in front of, because of',
		     't' => 'p' },
 '�'		=> { 'x' => 'in',
		     '#' => 'at',
		     't' => 'p' },
 'me�'		=> { 'x' => 'with',
		     't' => 'p' },
 'undir'	=> { 'x' => 'under',
		     't' => 'p' },
 'vi�'		=> { 'x' => 'at',
		     '#' => 'against, by, near',
		     't' => 'p' },
 'yfir'		=> { 'x' => 'above',
		     '#' => 'over, across',
		     't' => 'p' },
 #   Prepositions Governing the Genitive.
 '�n'		=> { 'x' => 'without',
		     't' => 'p' },
 'auk'		=> { 'x' => 'besides',
		     't' => 'p' },
 'austan'	=> { 'x' => 'East of',
		     't' => 'p' },
 'innan'	=> { 'x' => 'inside',
		     '#' => 'within',
		     't' => 'p' },
 #'� sta�'	=> { 'x' => 'instead of',
 #		     't' => 'p' },
 'me�al'	=> { 'x' => 'among',
		     't' => 'p' },
 'megin'	=> { 'x' => 'next to',
		     '#' => 'on the side of',
		     't' => 'p' },
 'milli'	=> { 'x' => 'between',
		     't' => 'p' },
 'millum'	=> { 'x' => 'between',
		     't' => 'p' },
 'ne�an'	=> { 'x' => 'below',
		     't' => 'p' },
 'nor�an'	=> { 'x' => 'north of',
		     't' => 'p' },
 'ofan'		=> { 'x' => 'above',
		     't' => 'p' },
 'sakir'	=> { 'x' => 'on account of',
		     't' => 'p' },
 'sunnan'	=> { 'x' => 'south of',
		     't' => 'p' },
 's�kum'	=> { 'x' => 'on account of',
		     't' => 'p' },
 'til'		=> { 'x' => 'to',
		     '#' => 'till, for',
		     't' => 'p' },
 'utan'		=> { 'x' => 'outside',
		     't' => 'p' },
 'vegna'	=> { 'x' => 'on account of',
		     't' => 'p' },
 'vestan'	=> { 'x' => 'west of',
		     't' => 'p' },
 #   Coordinating Conjunctions
 'og'		=> { 'x' => 'and', 
		     't' => 'conj' },
 'en'		=> { 'x' => 'but', 
		     't' => 'conj' },
 'e�a'		=> { 'x' => 'or', 
		     't' => 'conj' },
 'n�'		=> { 'x' => 'nor',
		     't' => 'conj' },
 'b��i'		=> { 'x' => 'both' },
 'hvorki'	=> { 'x' => 'neither' },
 'hvort'	=> { 'x' => 'whether' },
 'anna�hvort'	=> { 'x' => 'either' },
 #   Subordinating Conjunctions
 #    Cause 
 #'af �v� a�'	=> { 'x' => 'because',; 
 #'�v� a�'	=> { 'x' => 'for',, because; 
 #'fyrir �v� a�'	=> { 'x' => 'as',, because; 
 #'�r �v� a�'	=> { 'x' => 'since',, seeing that; 
 #'s�kum �ess a�'	=> { 'x' => 'since',; 
 #'vegna �ess a�'	=> { 'x' => 'as',, because of, owing to the fact that; 
 #'�ar sem'	=> { 'x' => 'since',, as; 
 'fyrst'	=> { 'x' => 'since',
		     '#' => 'as. ',
 		     't' => 'conj' },
 #    Condition 
 'ef'		=> { 'x' => 'if',
 		     't' => 'conj' },
 'nema'		=> { 'x' => 'unless',
 		     't' => 'conj' },
 #'svo framarlega sem'	=> { 'x' => 'provided', that, on condition that. 
 #    Result 
 #'svo a�'	=> { 'x' => 'so', that; 
 'a�'		=> { 'x' => 'that' }, 
 #    Concession 
 #'�� a�'	=> { 'x' => 'though',, although; 
 '��tt'		=> { 'x' => 'although',
		     '#' => ', notwithstanding; ' },
 #'enda ��tt'	=> { 'x' => 'although',, even if; 
 #'�r�tt fyrir �a� a�'	=> { 'x' => 'in', spite of the fact that. 
 #    Purpose 
 #'til �ess a�'	=> { 'x' => 'in',
 #		     '#' => 'order to; ',
 #'til a�'	=> { 'x' => '(so) that', 
 #'svo a�'	=> { 'x' => '(so) that',
 #'til �ess a� ekki'	=> { 'x' => 'lest',
 #		     '#' => 'for fear that. ',
 #    Comparison 
 #'eins og'	=> { 'x' => 'as',
 #		     '#' => 'like; ',
 'og'		=> { 'x' => 'as', 
 		     't' => 'conj' },
 #'heldur en'	=> { 'x' => 'than', 
 #'svo sem'	=> { 'x' => 'as', 
 'sem'		=> { 'x' => 'as', 
 		     't' => 'conj' },
 '�v�'		=> { 'x' => 'the',
 		     't' => 'conj' },
 #    Time 
 '�egar'	=> { 'x' => 'when', 
 		     't' => 'conj' },
 's��an'	=> { 'x' => 'since', 
 		     't' => 'conj' },
 #'��ur en'	=> { 'x' => 'before',; 
 #'undireins og'	=> { 'x' => 'as', soon as; 
 #'(�) me�an'	=> { 'x' => 'while',; 
 #'strax og'	=> { 'x' => 'as', soon as; 
 #'eftir a�'	=> { 'x' => 'after',; 
 #'um lei� og'	=> { 'x' => 'at', the same time as; 
 #'�egar er'	=> { 'x' => 'as', soon as; 
 #'�anga� til a�'	=> { 'x' => 'till',, until; 
 #'�ar til er'	=> { 'x' => 'till',, until; 
 #'fyrr en'	=> { 'x' => 'before',; 
 #'jafnskj�tt sem ...'	=> { 'x' => 'as', soon as ..., the moment ...; 
 #'�� er'	=> { 'x' => 'when',; 
 #'��ar en'	=> { 'x' => 'no', sooner ... than. 
 #    Place 
 #'�ar sem'	=> { 'x' => 'where', 
 #'�anga� sem'	=> { 'x' => 'where',
 #		     '#' => 'whither; ',
 #'hvert sem'	=> { 'x' => 'wherever', 
 #'hvar sem'	=> { 'x' => 'wherever', 
 #'hvert er'	=> { 'x' => 'wherever', 
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 'sunnudagur'	=> { 'x' => 'sunday' },
 'm�nudagur'	=> { 'x' => 'monday' },
 '�ri�judagur'	=> { 'x' => 'tuesday' },
 'mi�vikudagur'	=> { 'x' => 'wednesday' },
 'fimmtudagur'	=> { 'x' => 'thursday' },
 'f�studagur'	=> { 'x' => 'friday' },
 'laugardagur'	=> { 'x' => 'saturday' },
 'jan�ar'	=> { 'x' => 'january' },
 'febr�ar'	=> { 'x' => 'february' },
 'mars'		=> { 'x' => 'march' },
 'apr�l'	=> { 'x' => 'april' },
 'ma�'		=> { 'x' => 'may' },
 'j�n�'		=> { 'x' => 'june' },
 'j�l�'		=> { 'x' => 'july' },
 '�g�st'	=> { 'x' => 'august' },
 'september'	=> { 'x' => 'september' },
 'okt�ber'	=> { 'x' => 'october' },
 'n�vember'	=> { 'x' => 'november' },
 'desember'	=> { 'x' => 'december' },
 # Key verbs
 #  vera - to be
 #   Supine: veri�; Present Participle: verandi
 'vera'		=> { 'x' => 'be' },
 'verandi'	=> { 'x' => 'being' },
 #    1ps
 'er'		=> { 'x' => 'am',
		     '#' => 'pres.ind.' },
 's�'		=> { 'x' => 'am',
		     '#' => 'pres.subj. (veri)' },
 'var'		=> { 'x' => 'was',
		     '#' => 'past.ind.' },
 'v�ri'		=> { 'x' => 'was',
		     '#' => 'past.subj.' },
 #    2ps
 'ert'		=> { 'x' => 'are',
		     '#' => 'pres.ind.' },
 's�rt'		=> { 'x' => 'are',
		     '#' => 'pres.subj. (verir)' },
 'varst'	=> { 'x' => 'were',
		     '#' => 'past.ind.' },
 'v�rir'	=> { 'x' => 'were',
		     '#' => 'past.subj.' },
 #    3ps
 'er'		=> { 'x' => 'is',
		     '#' => 'pres.ind.' },
 's�'		=> { 'x' => 'is',
		     '#' => 'pres.subj. (veri)' },
 'var'		=> { 'x' => 'was',
		     '#' => 'past.ind.' },
 'v�ri'		=> { 'x' => 'was',
		     '#' => 'past.subj.' },
 #    1pp
 'erum'		=> { 'x' => 'are',
		     '#' => 'pres.ind.' },
 's�um'		=> { 'x' => 'are',
		     '#' => 'pres.subj. (verum)' },
 'vorum'	=> { 'x' => 'were',
		     '#' => 'past.ind.' },
 'v�rum'	=> { 'x' => 'were',
		     '#' => 'past.subj.' },
 #    2pp
 'eru�'		=> { 'x' => 'are',
		     '#' => 'pres.ind.' },
 's�u�'		=> { 'x' => 'are',
		     '#' => 'pres.subj. (veri�)' },
 'voru�'	=> { 'x' => 'were',
		     '#' => 'past.ind.' },
 'v�ru�'	=> { 'x' => 'were',
		     '#' => 'past.subj.' },
 #    3pp
 'eru'		=> { 'x' => 'are',
		     '#' => 'pres.ind.' },
 's�u'		=> { 'x' => 'are',
		     '#' => 'pres.subj. (veri)' },
 'voru'		=> { 'x' => 'were',
		     '#' => 'past.ind.' },
 'v�ru'		=> { 'x' => 'were',
		     '#' => 'past.subj.' },
 #  eiga - to ought to; to have, own
 #   Supine: �tt; Present Participle: eigandi
 #   Note: eiga takes the supine. 
 'eiga'		=> { 'x' => 'have',
		     '#' => 'ought to, own',
 		     't' => 'v' },
 'fara'		=> { 'x' => 'go',
		     '#' => 'travel, leave',
 		     't' => 'v' },
 'f�'		=> { 'x' => 'get',
		     '#' => 'receive, have something done',
 		     't' => 'v' },
 'geta'		=> { 'x' => 'can',
		     '#' => 'be able to',
 		     't' => 'v' },
 'hafa'		=> { 'x' => 'have',
 		     't' => 'v' },
 'kunna'	=> { 'x' => 'know',
 		     't' => 'v' },
 'mega'		=> { 'x' => 'may',
		     '#' => 'be allowed',
 		     't' => 'v' },
 'muna'		=> { 'x' => 'remember',
 		     't' => 'v' },
 'munu'		=> { 'x' => 'shall',
		     '#' => 'will',
 		     't' => 'v' },
 'skulu'	=> { 'x' => 'shall',
		     '#' => 'will',
 		     't' => 'v' },
 'unna'		=> { 'x' => 'love',
		     '#' => 'grant, not grudge',
 		     't' => 'v' },
 # Vocabulary
 'afi'		=> { 'x' => 'grandfather',
 		     't' => 'n',
		     'g' => 'm' },
 'aflvana '	=> { 'x' => 'impotent',
		     '#' => 'invar.',
 		     't' => 'a' },
 'auga'		=> { 'x' => 'eye',
 		     't' => 'n',
		     'g' => 'n' },
 'austur'	=> { 'x' => 'east',
		     '#' => 'no normal!',
 		     't' => 'a' },
 '�fi'		=> { 'x' => 'life',
 		     't' => 'n',
		     'g' => 'f' },
 'bakari'	=> { 'x' => 'baker',
 		     't' => 'n',
		     'g' => 'm' },
 'barn'		=> { 'x' => 'child',
 		     't' => 'n',
		     'g' => 'n' },
 'boginn'	=> { 'x' => 'bent',
		     '#' => 'curved',
 		     't' => 'a' },
 'b�k'		=> { 'x' => 'book',
 		     't' => 'n',
		     'g' => 'f' },
 'br��ir'	=> { 'x' => 'brother',
 		     't' => 'n',
		     'g' => 'm' },
 'dau�vona '	=> { 'x' => 'moribund',
		     '#' => 'invar.',
 		     't' => 'a' },
 'einmana '	=> { 'x' => 'alone',
		     '#' => 'lonely, invar.',
 		     't' => 'a' },
 'fa�ir'	=> { 'x' => 'father',
 		     't' => 'n',
		     'g' => 'm' },
 'farlama '	=> { 'x' => 'decrepit',
		     '#' => 'invar.',
 		     't' => 'a' },
 'f�tur'	=> { 'x' => 'foot',
 		     't' => 'n',
		     'g' => 'm' },
 'fingur'	=> { 'x' => 'finger',
 		     't' => 'n',
		     'g' => 'm' },
 'fj�r�ur'	=> { 'x' => 'fjord',
		     '#' => 'firth',
 		     't' => 'n',
		     'g' => 'm' },
 'gamall'	=> { 'x' => 'old',
		     '#' => 'irreg.',
 		     't' => 'a' },
 'g��ur'	=> { 'x' => 'good',
		     '#' => 'irreg.',
 		     't' => 'a' },
 'grein'	=> { 'x' => 'article',
		     't' => 'n' },
 'hestur'	=> { 'x' => 'horse',
 		     't' => 'n',
		     'g' => 'm' },
 'hlutur'	=> { 'x' => 'thing',
 		     't' => 'n',
		     'g' => 'm' },
 'hugsi '	=> { 'x' => 'meditative',
		     '#' => 'invar.',
 		     't' => 'a' },
 'illur'	=> { 'x' => 'bad',
		     '#' => 'irreg.',
 		     't' => 'a' },
 'kerling'	=> { 'x' => 'woman',
		     '#' => 'old woman',
 		     't' => 'n',
		     'g' => 'f' },
 'lifur'	=> { 'x' => 'liver',
 		     't' => 'n',
		     'g' => 'f' },
 'l�till'	=> { 'x' => 'little',
		     '#' => 'irreg.',
 		     't' => 'a' },
 'lygi'		=> { 'x' => 'lie',
 		     't' => 'n',
		     'g' => 'f' },
 'ma�ur'	=> { 'x' => 'man',
 		     't' => 'n',
		     'g' => 'm' },
 'margur'	=> { 'x' => 'many',
		     '#' => 'irreg.',
 		     't' => 'a' },
 'mikill'	=> { 'x' => 'great',
		     '#' => 'large; irreg.',
 		     't' => 'a' },
 'm��ir'	=> { 'x' => 'mother',
 		     't' => 'n',
		     'g' => 'f' },
 'nemandi'	=> { 'x' => 'student',
 		     't' => 'n',
		     'g' => 'm' },
 'nor�ur'	=> { 'x' => 'north',
		     '#' => 'no normal!',
 		     't' => 'a' },
 'r�vita '	=> { 'x' => 'insane',
		     '#' => 'crazy, invar.',
 		     't' => 'a' },
 'r�kur'	=> { 'x' => 'rich',
		     '#' => 'strong, powerful',
 		     't' => 'a' },
 'sl�mur'	=> { 'x' => 'bad',
		     '#' => 'irreg.',
 		     't' => 'a' },
 'smi�ur'	=> { 'x' => 'smith',
 		     't' => 'n',
		     'g' => 'm' },
 'st�ll'	=> { 'x' => 'chair',
 		     't' => 'n',
		     'g' => 'm' },
 'su�ur'	=> { 'x' => 'south',
		     '#' => 'no normal!',
 		     't' => 'a' },
 'sumar'	=> { 'x' => 'summer',
 		     't' => 'n',
		     'g' => 'n' },
 'veggur'	=> { 'x' => 'wall',
 		     't' => 'n',
		     'g' => 'm' },
 'vestur'	=> { 'x' => 'west',
		     '#' => 'no normal!',
 		     't' => 'a' },
 'vetur'	=> { 'x' => 'winter',
 		     't' => 'n',
		     'g' => 'm' },
 'vondur'	=> { 'x' => 'bad',
		     '#' => 'irreg.',
		     't' => 'a' },
);
}

1;

