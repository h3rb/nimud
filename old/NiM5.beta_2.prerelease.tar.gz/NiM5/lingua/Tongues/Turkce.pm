# vi: ts=8 sw=8

package Tongues::Turkce;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Turkish CP1254
# not ISO 8859-2 / Latin-5

# Alphabetical order
# A B C � D E F G � H I � J K L M N O � P R S � T U � V Y Z
# a b c � d e f g � h i � j k l m n o � p r s � t u � v y z

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::TurkishWin;

$charset = new Charsets::TurkishWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative

# Turkish to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 'o'		=> { 'x' => 'he',
		     '#' => 'she, it',
 		     't' => 'pro',
		     'p' => '3' },
 #  Other functional words
 'bu'		=> { 'x' => 'this',
		     '#' => 'pron. or adj.?' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'bir'		=> { 'x' => 'one' },
 'iki'		=> { 'x' => 'two' },
 '��'		=> { 'x' => 'three' },
 'd�rt'		=> { 'x' => 'four' },
 'be�'		=> { 'x' => 'five' },
 'alt�'		=> { 'x' => 'six' },
 'yedi'		=> { 'x' => 'seven' },
 'sekiz'	=> { 'x' => 'eight' },
 'dokuz'	=> { 'x' => 'nine' },
 'on'		=> { 'x' => 'ten' },
 'yirmi'	=> { 'x' => 'twenty' },
 'otuz'		=> { 'x' => 'thirty' },
 'k�rk'		=> { 'x' => 'forty' },
 'elli'		=> { 'x' => 'fifty' },
 'altm��'	=> { 'x' => 'sixty' },
 'yetmi�'	=> { 'x' => 'seventy' },
 'seksen'	=> { 'x' => 'eighty' },
 'doksan'	=> { 'x' => 'ninety' },
 'y�z'		=> { 'x' => 'hundred' },
 'bin'		=> { 'x' => 'thousand' },
 'milyon'	=> { 'x' => 'million' },
 'milyar'	=> { 'x' => 'billion' },
 # Days and months
 'pazar'	=> { 'x' => 'sunday' },
 'pazartesi'	=> { 'x' => 'monday' },
 'sal�'		=> { 'x' => 'tuesday' },
 '�ar�amba'	=> { 'x' => 'wednesday' },
 'per�embe'	=> { 'x' => 'thursday' },
 'cuma'		=> { 'x' => 'friday' },
 'cumartesi'	=> { 'x' => 'saturday' },
 'ocak'		=> { 'x' => 'january' },
 '�ubat'	=> { 'x' => 'february' },
 'mart'		=> { 'x' => 'march' },
 'nisan'	=> { 'x' => 'april' },
 'may�s'	=> { 'x' => 'may' },
 'haziran'	=> { 'x' => 'june' },
 'temmuz'	=> { 'x' => 'july' },
 'a�ustos'	=> { 'x' => 'august' },
 'eyl�l'	=> { 'x' => 'september' },
 'ekim'		=> { 'x' => 'october' },
 'kas�m'	=> { 'x' => 'november' },
 'aral�k'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 'anne'		=> { 'x' => 'mother',
		     't' => 'n' },
 'arkada�'	=> { 'x' => 'friend',
 		     't' => 'n' },
 'astronot'	=> { 'x' => 'astronaut',
 		     't' => 'n' },
 'avustralya'	=> { 'x' => 'australia',
 		     't' => 'n' },
 'b��ak'	=> { 'x' => 'knife',
 		     't' => 'n' },
 'baba'		=> { 'x' => 'father',
 		     't' => 'n' },
 'bal�k'	=> { 'x' => 'fish',
 		     't' => 'n' },
 'bardak'	=> { 'x' => 'glass',
 		     't' => 'n' },
 'beyaz'	=> { 'x' => 'white',
 		     't' => 'a' },
 'biber'	=> { 'x' => 'pepper',
 		     't' => 'n' },
 'bira'		=> { 'x' => 'beer',
 		     't' => 'n' },
 'b�y�k'	=> { 'x' => 'big',
		     '#' => 'large',
 		     't' => 'a' },
 'buz'		=> { 'x' => 'ice',
 		     't' => 'n' },
 '�atal'	=> { 'x' => 'fork',
 		     't' => 'n' },
 '�ay'		=> { 'x' => 'tea',
 		     't' => 'n' },
 '�ocuk'	=> { 'x' => 'child',
 		     't' => 'n' },
 '�orba'	=> { 'x' => 'soup',
 		     't' => 'n' },
 'dondurma'	=> { 'x' => 'ice-cream',
 		     't' => 'n' },
 'ekmek'	=> { 'x' => 'bread',
 		     't' => 'n' },
 'elektrik'	=> { 'x' => 'electricity',
 		     't' => 'n' },
 'erkek'	=> { 'x' => 'man',
		     '#' => 'male' },
 'et'		=> { 'x' => 'meat',
 		     't' => 'n' },
 'fincan'	=> { 'x' => 'cup',
 		     't' => 'n' },
 '�spanya'	=> { 'x' => 'spain',
		     '#' => 'proper, place',
 		     't' => 'n' },
 '�spanyolca'	=> { 'x' => 'spanish',
		     '#' => 'noun & adj?' },
 'japonya'	=> { 'x' => 'japan',
 		     't' => 'n' },
 'ka��k'	=> { 'x' => 'spoon',
 		     't' => 'n' },
 'kad�n'	=> { 'x' => 'woman',
 		     't' => 'n' },
 'kahve'	=> { 'x' => 'coffee',
 		     't' => 'n' },
 'karde�'	=> { 'x' => 'sibling',
 		     't' => 'n' },
 'kitap'	=> { 'x' => 'book',
 		     't' => 'n' },
 'k�rm�z�'	=> { 'x' => 'red',
 		     't' => 'a' },
 'k�z'		=> { 'x' => 'girl',
		     '#' => 'daughter',
 		     't' => 'n' },
 'korece'	=> { 'x' => 'korean',
		     '#' => 'noun & adj?' },
 'kozmonot'	=> { 'x' => 'cosmonaut',
 		     't' => 'n' },
 'k���k'	=> { 'x' => 'small',
		     '#' => 'little',
 		     't' => 'a' },
 'madde'	=> { 'x' => 'article',
 		     't' => 'n' },
 'mesaj'	=> { 'x' => 'message',
 		     't' => 'n' },
 'meyva'	=> { 'x' => 'fruit',
 		     't' => 'n' },
 'meze'		=> { 'x' => 'appetizers',
 		     't' => 'n' },
 'oglan'	=> { 'x' => 'boy',
 		     't' => 'n' },
 'ogul'		=> { 'x' => 'son',
 		     't' => 'n' },
 'pahal�'	=> { 'x' => 'expensive',
 		     't' => 'a' },
 'peynir'	=> { 'x' => 'cheese',
 		     't' => 'n' },
 'pilav'	=> { 'x' => 'pilaf',
 		     't' => 'n' },
 'proje'	=> { 'x' => 'project',
 		     't' => 'n' },
 'salata'	=> { 'x' => 'salad',
		     '#' => 'lettuce',
 		     't' => 'n' },
 'sandvi�'	=> { 'x' => 'sandwich',
 		     't' => 'n' },
 'sebze'	=> { 'x' => 'vegetable',
 		     't' => 'n' },
 'soguk'	=> { 'x' => 'cold',
 		     't' => 'a' },
 'su'		=> { 'x' => 'water',
 		     't' => 'n' },
 's�t'		=> { 'x' => 'milk',
 		     't' => 'n' },
 '�arap'	=> { 'x' => 'wine',
 		     't' => 'n' },
 '�eker'	=> { 'x' => 'sugar',
		     '#' => 'candy, sweet' },
 'tabak'	=> { 'x' => 'plate',
 		     't' => 'n' },
 'tatl�'	=> { 'x' => 'dessert',
 		     't' => 'n' },
 'tavuk'	=> { 'x' => 'chicken',
 		     't' => 'n' },
 'tereyag�'	=> { 'x' => 'butter',
 		     't' => 'n' },
 'haritac�l�k'	=> { 'x' => 'cartography',
 		     't' => 'n' },
 'tuz'		=> { 'x' => 'salt',
 		     't' => 'n' },
);
}

1;

