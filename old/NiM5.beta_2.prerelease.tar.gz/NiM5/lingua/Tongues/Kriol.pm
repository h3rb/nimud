# vi: ts=8 sw=8 sts=8

package Tongues::Kriol;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
# a b c d e f g h i j k l m n o p q r s t u v w x y z

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb continuous
 [ 'in',	'',	'',		'ing',	'v' ],
 [ 'ing',	'',	'',		'ing',	'v' ],
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# Kriol to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'ai'		=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'x' => 'i' },
 'mi'		=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'x' => 'me' },
 'mai'		=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'x' => 'my' },
 #   1st person inclusive
 'yunmi'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     '#' => 'inclusive',
		     'x' => 'we' },
 'wi'		=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     '#' => 'inclusive',
		     'x' => 'we' },
 #   1st person exclusive
 'mindubala'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     '#' => 'exclusive',
		     'x' => 'we' },
 'mibala'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     '#' => 'exclusive',
		     'x' => 'we' },
 #   2nd person
 'yu'		=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'x' => 'you' },
 'yundubala'	=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'x' => 'you' },
 'yubala'	=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'x' => 'you' },
 #   3rd person
 'im'		=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'x' => [ 'he', 'she', 'it', 'him', 'her'  ] },
 'dubala'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'x' => 'they' },
 'olabat'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'x' => 'they' },
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 'atha'		=> { 'x' => 'other' },
 'bek'		=> { 'x' => 'back' },
 'bin'		=> { '#' => 'past marker' },
 'den'		=> { 'x' => 'then' },
 'deya'		=> { 'x' => 'there' },
 'dis'		=> { 'x' => 'this' },
 'en'		=> { 'x' => 'and' },
 'fo'		=> { 'x' => 'for' },
 'from'		=> { 'x' => 'from' },
# 'garra'	=> { '#' => 'ASSOC' },
# 'la'		=> { '#' => 'LOC' },
 'nau'		=> { 'x' => 'now' },
 'neba'		=> { 'x' => 'never' },
 'sam'		=> { 'x' => 'some' },
 'tharran'	=> { 'x' => 'that',
		     '#' => 'that one' },
 'til'		=> { 'x' => 'until' },
 'tudei'	=> { 'x' => 'now',
		     '#' => 'today' },
 'wen'		=> { 'x' => 'when' },
 'yusdu'	=> { 'x' => 'used to' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 # Key verbs
 'kipgoun'	=> { 'x' => 'continue' },
 # Vocabulary
 'alidei'	=> { 'x' => 'holiday',
		     't' => 'n' },
 'figit'	=> { 'x' => 'forget',
		     't' => 'v' },
 'gardiya'	=> { 'x' => 'european',
		     't' => 'n' },
 'gib'		=> { 'x' => 'give',
		     't' => 'v' },
 'go'		=> { 'x' => 'go',
		     't' => 'v' },
 'god'		=> { 'x' => 'god',
		     '#' => 'capitalize',
		     't' => 'n' },
 'kam'		=> { 'x' => 'come',
		     't' => 'v' },
 'kid'		=> { 'x' => 'child',
		     't' => 'n' },
 'kriol'	=> { 'x' => 'kriol',
		     't' => 'n' },
 'lait'		=> { 'x' => 'light',
		     't' => 'n' },
 'lisin'	=> { 'x' => 'listen',
		     't' => 'v' },
 'luk'		=> { 'x' => 'look',
		     't' => 'v' },
 'mishin'	=> { 'x' => 'mission',
		     't' => 'n' },
 'pipul'	=> { 'x' => 'people',
		     't' => 'n' },
 'skul'		=> { 'x' => 'school',
		     't' => 'n' },
 'teik'		=> { 'x' => 'take',
		     't' => 'v' },
 'tok'		=> { 'x' => 'talk',
		     't' => 'v' },
 'wed'		=> { 'x' => 'language',
		     't' => 'n' },
);
}

1;

