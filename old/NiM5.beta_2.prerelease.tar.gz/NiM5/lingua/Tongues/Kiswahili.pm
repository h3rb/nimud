# vi: ts=8 sw=8

package Tongues::Kiswahili;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B C D E F G H I J K L M N O P (Q) R S T U V W (X) Y Z
# a b c d e f g h i j k l m n o p (q) r s t u v w (x) y z

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# Kiswahili to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'mimi'		=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'sisi'		=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 #   2nd person
 'wewe'		=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'nyinyi'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p' },
 #   3rd person
 'yeye'		=> { 'x' => 'he',
		     '#' => 'she',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's' },
 'wao'		=> { 'x' => 'they',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p' },
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 'de'	=> { 'x' => 'of',
	     't' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'moja'		=> { 'x' => 'one' }, 
 'mbili'	=> { 'x' => 'two' },  
 'tatu'		=> { 'x' => 'three' },  
 'nne'		=> { 'x' => 'four' },  
 'tano'		=> { 'x' => 'five' },  
 'sita'		=> { 'x' => 'six' }, 
 'saba'		=> { 'x' => 'seven' },  
 'nane'		=> { 'x' => 'eight' },  
 'tisa'		=> { 'x' => 'nine' },  
 'kumi'		=> { 'x' => 'ten' },  
 'ishirini'	=> { 'x' => 'twenty' },  
 'thelathini'	=> { 'x' => 'thirty' },  
 'arobaini'	=> { 'x' => 'forty' },  
 'hamsini'	=> { 'x' => 'fifty' },  
 'sitini'	=> { 'x' => 'sixty' },  
 'sabini'	=> { 'x' => 'seventy' },  
 'themanini'	=> { 'x' => 'eighty' },  
 'tisini'	=> { 'x' => 'ninety' },  
 'mia'		=> { 'x' => 'hundred' },  
 'elfu'		=> { 'x' => 'thousand' },  
 'nusu'		=> { 'x' => 'half' },  
 'robo'		=> { 'x' => 'quarter' },  
 # Days and months
 'jumapili'	=> { 'x' => 'sunday' },
 'jumatatu'	=> { 'x' => 'monday' },
 'jumanne'	=> { 'x' => 'tuesday' },
 'jumatano'	=> { 'x' => 'wednesday' },
 'alhamisi'	=> { 'x' => 'thursday' },
 'ijumaa'	=> { 'x' => 'friday' },
 'jumamosi'	=> { 'x' => 'saturday' },
 'januari'	=> { 'x' => 'january' },
 'februari'	=> { 'x' => 'february' },
 'machi'	=> { 'x' => 'march' },
 'aprili'	=> { 'x' => 'april' },
 'mei'		=> { 'x' => 'may' },
 'juni'		=> { 'x' => 'june' },
 'julai'	=> { 'x' => 'july' },
 'agosti'	=> { 'x' => 'august' },
 'septemba'	=> { 'x' => 'september' },
 'oktoba'	=> { 'x' => 'october' },
 'novemba'	=> { 'x' => 'november' },
 'desemba'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 'alasiri'	=> { 'x' => 'late afternoon' },
 'alfajiri'	=> { 'x' => 'early morning' },
 'asubuhi'	=> { 'x' => 'morning' },
 'dakika'	=> { 'x' => 'minute' },
 'jioni'	=> { 'x' => 'evening',
		     '#' => 'late afternoon' },
 'magharibi'	=> { 'x' => 'dusk' },
 'mchana'	=> { 'x' => 'afternoon' },
 'saa'		=> { 'x' => 'time',
		     '#' => 'hour; watch, clock' },
 'usiku'	=> { 'x' => 'night',
		     '#' => 'evening' },
 );
}

1;

