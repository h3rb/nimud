# vi: ts=4 sw=4

package Charsets::EUC_KR;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw();
$VERSION	= 0.00;

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters {
	return "([A-Za-z]|([\x81-\xfd][\x41-\xfe]))";
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z/a-z/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z/A-Z/;

	return $str;
}

sub BEGIN {
}

1;
