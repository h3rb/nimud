DECLARE_DO_FUN( do_aedit         );
DECLARE_DO_FUN( do_redit         );
DECLARE_DO_FUN( do_oedit         );
DECLARE_DO_FUN( do_medit         );

extern          int             top_affect;
extern          int             top_area;
extern          int             top_ed;
extern          int             top_exit;
extern          int             top_help;
extern          int             top_mob_index;
extern          int             top_obj_index;
extern          int             top_reset;
extern          int             top_room;
extern          int             top_shop;

extern  MOB_INDEX_DATA *        mob_index_hash  [MAX_KEY_HASH];
extern  OBJ_INDEX_DATA *        obj_index_hash  [MAX_KEY_HASH];
extern  ROOM_INDEX_DATA *       room_index_hash [MAX_KEY_HASH];


extern  SHOP_DATA *             shop_first;
extern  SHOP_DATA *             shop_last;

#define         AREA_NONE       0
#define         AREA_CHANGED    1
#define         AREA_ADDED      2

#define         SEX_NONE        4

#define         ROOM_NONE       0

#define         EX_NONE         0

#define         ITEM_NONE       0

#define         EXTRA_NONE      0

#define         ITEM_WEAR_NONE  0

#define         ACT_NONE        0

#define         AFFECT_NONE     0


