# vi: ts=8 sw=8

package Tongues::Romana;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Central European CP1250
# not ISO 8859-2

# Alphabetical order
# A � � B C D E F G H I � J K L M N O P Q R S � T � U V W X Y Z
# a � � b c d e f g h i � j k l m n o p q r s � t � u v w x y z 
# K Q W Y occur only in loan words.

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::CentralEuroWin;

$charset = new Charsets::CentralEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun
 #  Noun gender
 [ '�',		'',	'',		'',	'n' ],	# fem.
 #  Noun plural
 [ 'i',		'',	'',		's',	'n' ],	# masc.
 [ 'i',		'e',	'',		's',	'n' ],	# masc. (and fem.)
 [ 'i',		'u',	'',		's',	'n' ],	# masc.
 [ 'e',		'�',	'',		's',	'n' ],	# fem.
 [ 'i',		'�',	'',		's',	'n' ],	# fem.
 [ 'ele',	'ea',	'',		's',	'n' ],	# fem.
 [ '�i',	's',	'',		's',	'n' ],
 [ '�i',	't',	'',		's',	'n' ],
 [ '�i',	'te',	'',		's',	'n' ],
 [ 'zi',	'd',	'',		's',	'n' ],
 [ 'i',		'l',	'',		's',	'n' ],
 #[ 'i',		'e',	'',		's',	'n' ],	# fem.
 [ 'uri',	'',	'',		's',	'n' ],	# neut.
 [ 'e',		'',	'',		's',	'n' ],	# neut.
 [ 'ouri',	'ou',	'',		's',	'n' ],	# neut.
 #  Noun definite
 [ 'ul',	'',	'the ',		'',	'n' ],	# masc -cons sing nom
 [ 'ului',	'',	'the ',		'',	'n' ],	# masc -cons sing dat
 [ '�ii',	't',	'the ',		's',	'n' ],	# masc -cons plur nom
 [ '�ilor',	't',	'the ',		's',	'n' ],	# masc -cons plur dat
 [ 'ele',	'e',	'the ',		'',	'n' ],	# masc -e sing nom
 [ 'elui',	'e',	'the ',		'',	'n' ],	# masc -e sing dat
 [ '�ii',	'te',	'the ',		's',	'n' ],	# masc -e plur nom
 [ '�ilor',	'te',	'the ',		's',	'n' ],	# masc -e plur dat
 [ 'ul',	'u',	'the ',		'',	'n' ],	# masc -u sing nom
 [ 'ului',	'u',	'the ',		'',	'n' ],	# masc -u sing dat
 [ 'ii',	'u',	'the ',		's',	'n' ],	# masc -u plur nom
 [ 'ilor',	'u',	'the ',		's',	'n' ],	# masc -u plur dat
 [ 'a',		'�',	'the ',		'',	'n' ],	# fem -� sing nom
 [ 'ei',	'�',	'the ',		'',	'n' ],	# fem -� sing dat
 [ 'ele',	'�',	'the ',		's',	'n' ],	# fem -� plur nom
 [ 'elor',	'�',	'the ',		's',	'n' ],	# fem -� plur dat
 [ 'ea',	'e',	'the ',		'',	'n' ],	# fem -e sing nom
 #  other -e examples change root a to � and t to �... more info needed
 [ 'ia',	'ie',	'the ',		'',	'n' ],	# fem -ie sing nom
 [ 'ei',	'ie',	'the ',		'',	'n' ],	# fem -ie sing dat
 [ 'ile',	'ie',	'the ',		's',	'n' ],	# fem -ie plur nom
 [ 'ilor',	'ie',	'the ',		's',	'n' ],	# fem -ie plur dat
 [ 'eaua',	'ea',	'the ',		'',	'n' ],	# fem -ea sing nom
 [ 'elei',	'ea',	'the ',		'',	'n' ],	# fem -ea sing dat
 [ 'elele',	'ea',	'the ',		's',	'n' ],	# fem -ea plur nom
 [ 'elelor',	'ea',	'the ',		's',	'n' ],	# fem -ea plur dat
 [ 'ul',	'',	'the ',		'',	'n' ],	# neu -cons sing nom
 [ 'ului',	'',	'the ',		'',	'n' ],	# neu -cons sing dat
 [ 'urile',	'',	'the ',		's',	'n' ],	# neu -cons plur nom
 [ 'urilor',	'',	'the ',		's',	'n' ],	# neu -cons plur dat
 [ 'oul',	'',	'the ',		'',	'n' ],	# neu -ou sing nom
 [ 'oului',	'',	'the ',		'',	'n' ],	# neu -ou sing dat
 [ 'ourile',	'',	'the ',		's',	'n' ],	# neu -ou plur nom
 [ 'ourilor',	'',	'the ',		's',	'n' ],	# neu -ou plur dat
 [ 'iul',	'ul',	'the ',		'',	'n' ],	# neu -iu sing nom
 [ 'iului',	'ul',	'the ',		'',	'n' ],	# neu -iu sing dat
 [ 'iile',	'ul',	'the ',		'',	'n' ],	# neu -iu plur nom
 [ 'iilor',	'ul',	'the ',		'',	'n' ],	# neu -iu plur dat
 # Adjective
 #[ '',		'',	'',		'',	'a' ],	# masc/neut. sing.
 [ '�',		'',	'',		'',	'a' ],	# fem. sing.
 [ 'i',		'',	'',		'',	'a' ],	# masc. plur.
 [ 'e',		'',	'',		'',	'a' ],	# fem/neut. plur.
 [ 'toare',	'tor',	'',		'',	'a' ],	# fs/p, np
 [ 'tori',	'tor',	'',		'',	'a' ],	# masc. plur.
 # Verb
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 #  -a
 [ '',		'a',	'(i) ',		'',	'v' ],	# 1s
 [ 'ez',	'a',	'(i) ',		'',	'v' ],	# 1s
 [ 'i',		'a',	'(you) ',	'',	'v' ],	# 2s (it->i�)
 [ 'ezi',	'a',	'(you) ',	'',	'v' ],	# 2s (it->i�)
 [ '�',		'a',	'(he/they) ',	's',	'v' ],	# 3s/3p
 [ 'eaz�',	'a',	'(he/they) ',	's',	'v' ],	# 3s/3p
 [ '�m',	'a',	'(we) ',	'',	'v' ],	# 1p
 [ 'a�i',	'a',	'(you) ',	'',	'v' ],	# 2p
 #[ '�',		'a',	'(he) ',	's',	'v' ],	# 3s
 #  -ea
 [ '',		'ea',	'(i/they) ',	'',	'v' ],	# 1s/3p (�cea->ac)
 [ 'i',		'ea',	'(you) ',	'',	'v' ],	# 2s (�cea->aci)
 [ 'e',		'ea',	'(he) ',	's',	'v' ],	# 3s (�cea->ece)
 [ 'em',	'ea',	'(we) ',	'',	'v' ],	# 1p
 [ 'e�i',	'ea',	'(you) ',	'',	'v' ],	# 2p
 #  -e
 [ '',		'e',	'(i/they) ',	'',	'v' ],	# 1s/3p
 #[ 
 #[ 'e',		'e',	'(i) ',		'',	'v' ],	# 3s
 [ 'em',	'e',	'(we) ',	'',	'v' ],	# 1p
 [ 'e�i',	'e',	'(you) ',	'',	'v' ],	# 2p
 #  -i
 [ 'esc',	'i',	'(i/they) ',	'',	'v' ],	# 1s/3p
 [ 'iu',	'i',	'(i/they) ',	'',	'v' ],	# 1s/3p
 [ 'e�ti',	'i',	'(you) ',	'',	'v' ],	# 2s
 [ 'ii',	'i',	'(you) ',	'',	'v' ],	# 2s
 [ 'e�te',	'i',	'(he) ',	's',	'v' ],	# 3s
 [ 'ie',	'i',	'(he) ',	's',	'v' ],	# 3s
 [ 'im',	'i',	'(we) ',	'',	'v' ],	# 1p
 [ 'i�i',	'i',	'(you) ',	'',	'v' ],	# 2p
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine
#	f -> feminine
#	n -> neuter
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:			nouns, pronouns, adjectives
#	n -> nominative (subject) / accusative (direct object)
#	g -> genitive (possessive) / dative (indirect object)
#	v -> vocative (address)

# Romanian to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #    Neuter
 #     Singular
 #     Plural
 #   Indefinite articles
 #    Masculine / Neuter
 'un'		=> { 'x' => 'a',
		     '#' => 'an; masc. & neut.',
 		     't' => 'art',
		     'n' => 's',
		     'c' => 'n' },
 'unu'		=> { 'x' => 'a',
		     '#' => 'an; masc. & neut.',
 		     't' => 'art',
		     'n' => 's' },
 'unul'		=> { 'x' => 'a',
		     '#' => 'an; masc. & neut.',
 		     't' => 'art',
		     'n' => 's' },
 'unui'		=> { 'x' => 'a',
		     '#' => 'an',
 		     't' => 'art',
		     'n' => 's',
		     'c' => 'g' },
 #    Feminine
 'o'		=> { 'x' => 'a',
		     '#' => 'an; fem.',
 		     't' => 'art',
		     'g' => 'f',
		     'n' => 's',
		     'c' => 'n' },
 'una'		=> { 'x' => 'a',
		     '#' => 'an; fem.',
 		     't' => 'art',
		     'g' => 'f',
		     'n' => 's' },
 'unei'		=> { 'x' => 'a',
		     '#' => 'an',
 		     't' => 'art',
		     'g' => 'f',
		     'n' => 's',
		     'c' => 'g' },
 #    Plural
 'unor'		=> { 'x' => 'some',
 		     't' => 'art',
		     'n' => 'p',
		     'c' => 'g' },
 #  Pronouns & possessive adjectives
 #   1st person
 'eu'		=> { 'x' => 'i',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'noi'		=> { 'x' => 'we',
 		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 'meu'		=> { 'x' => 'my',
		     '#' => 'poss. adj.',
 		     't' => 'a' },
 'nostru'	=> { 'x' => 'our',
		     '#' => 'poss. adj.',
 		     't' => 'a' },
 #   2nd person
 'tu'		=> { 'x' => 'you',
		     '#' => 'intimate',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'dumneata'	=> { 'x' => 'you',
		     '#' => '(d-ta) friendly',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 'voi'		=> { 'x' => 'you',
		     '#' => 'familiar',
 		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p' },
 'dumneavoastr�'	=> { 'x' => 'you',
			     '#' => '(dvs.) one or more pers.',
 			     't' => 'pro',
			     '#' => 'polite',
			     'p' => '2',
			     'n' => 'p' },
 #   3rd person
 'el'		=> { 'x' => 'he',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
 'dumnealui'	=> { 'x' => 'he',
		     '#' => 'polite',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
 'ea'		=> { 'x' => 'she',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f' },
 'dumneaei'	=> { 'x' => 'she',
		     '#' => 'polite',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm' },
 'ei'		=> { 'x' => 'they',
		     '#' => 'also poss. pron. her',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'g' => 'm' },
 'ele'		=> { 'x' => 'they',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'g' => 'f' },
 'dumnealor'	=> { 'x' => 'they',
		     '#' => 'polite plur. m&f',
 		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p' },
 'lui'		=> { 'x' => 'his',
		     '#' => 'poss. pron.' },
 'lor'		=> { 'x' => 'their',
		     '#' => 'poss. pron. invariable' },
 #  Other functional words
 'acas�'	=> { 'x' => 'home',
		     '#' => 'homeward',
 		     't' => 'adv' },
 'acest'	=> { 'x' => 'this',
		     '#' => 'demon. preceed noun',
 		     't' => 'a' },
 'acolo'	=> { 'x' => 'there',
 		     't' => 'adv' },
 'acum'		=> { 'x' => 'now',
 		     't' => 'adv' },
 'acuma'	=> { 'x' => 'now',
 		     't' => 'adv' },
 'aici'		=> { 'x' => 'here',
 		     't' => 'adv' },
 'aicea'		=> { 'x' => 'here',
 		     't' => 'adv' },
 'alt'		=> { 'x' => 'another',
		     '#' => 'other; preceed noun',
 		     't' => 'a' },
 'apoi'		=> { 'x' => 'then',
		     '#' => 'busequently',
 		     't' => 'adv' },
 'aproape'	=> { 'x' => 'nearby',
 		     't' => 'adv' },
 'apropro'	=> { 'x' => 'by the way',
		     '#' => 'three words!',
 		     't' => 'adv' },
 'a�a'		=> { 'x' => 'thus',
		     '#' => 'so, in this way, like this',
 		     't' => 'adv',
		     '#' => 'cf spanish as�' },
 'ca'		=> { 'x' => 'than',
		     '#' => 'as; prep & conj' },
 'c�'		=> { 'x' => 'that',
 		     't' => 'conj' },
 'ce'		=> { 'x' => 'what',
		     '#' => 'interr. pron.',
 		     't' => 'pro' },
 'cine'		=> { 'x' => 'who',
		     '#' => 'interr. pron.',
 		     't' => 'pro' },
 'c�t'		=> { 'x' => 'how much',
		     '#' => 'interr. how many' },
 'c�t�'		=> { 'x' => 'how much',
		     '#' => 'interr. how many' },
 'c�te'		=> { 'x' => 'how much',
		     '#' => 'interr. how many' },
 'c��i'		=> { 'x' => 'how much',
		     '#' => 'interr. how many' },
 'cu'		=> { 'x' => 'with',
 		     't' => 'p' },
 'da'		=> { 'x' => 'yes',
 		     't' => 'interj' },
 'deci'		=> { 'x' => 'therefore',
 		     't' => 'conj' },
 'dec�t'	=> { 'x' => 'than',
		     '#' => 'prep & conj' },
 'deja'		=> { 'x' => 'already',
 		     't' => 'adv' },
 'doamna'	=> { 'x' => 'mrs' },
 'domni�oara'	=> { 'x' => 'miss' },
 'domnul'	=> { 'x' => 'mr' },
 'dup�'		=> { 'x' => 'after',
		     '#' => 'behind',
 		     't' => 'p' },
 'fiindc�'	=> { 'x' => 'because',
 		     't' => 'conj' },
 'iar'		=> { 'x' => 'and',
		     '#' => 'but; adv. again',
 		     't' => 'conj' },
 'ieri'		=> { 'x' => 'yesterday',
 		     't' => 'adv' },
 '�n'		=> { 'x' => 'in',
 		     't' => 'p' },
 '�nc�'		=> { 'x' => 'yet',
		     '#' => 'still, another',
 		     't' => 'adv' },
 '�ntr'		=> { 'x' => 'in',
		     '#' => '�ntr-o, �ntr-un',
 		     't' => 'p' },
 '�ntre'	=> { 'x' => 'between',
 		     't' => 'p' },
 'la'		=> { 'x' => 'at',
		     '#' => 'to',
 		     't' => 'p' },
 'l�ng�'	=> { 'x' => 'near',
		     '#' => 'beside',
 		     't' => 'p' },
 'mai'		=> { 'x' => 'more',
		     '#' => 'still, in addition',
 		     't' => 'adv',
		     '#' => 'used in comparison' },
 'm�ine'	=> { 'x' => 'tomorrow',
 		     't' => 'adv' },
 'mult'		=> { 'x' => 'much',
 		     't' => 'a' },
 'nic�ieri'	=> { 'x' => 'nowhere',
 		     't' => 'adv' },
 'nici'		=> { 'x' => 'neither' },
 'niciodat�'	=> { 'x' => 'never',
 		     't' => 'adv' },
 'nimic'	=> { 'x' => 'nothing',
 		     't' => 'pro' },
 'nimeni'	=> { 'x' => 'nobody',
 		     't' => 'pro' },
 'ni�te'	=> { 'x' => 'some',
		     '#' => 'invar. adj.' },
 'nu'		=> { 'x' => 'not',
		     '#' => 'negative particle' },
 'pe'		=> { 'x' => 'on',
 		     't' => 'p' },
 'pentru'	=> { 'x' => 'for',
 		     't' => 'p' },
 'pu�in'	=> { 'x' => 'few',
		     '#' => 'little',
 		     't' => 'a' },
 'sub'		=> { 'x' => 'under',
 		     't' => 'p' },
 '�i'		=> { 'x' => 'and',
		     '#' => 'adv: also, too',
 		     't' => 'conj' },
 'spre'		=> { 'x' => 'towards',
 		     't' => 'p' },
 'tot'		=> { 'x' => 'also',
		     '#' => 'still, continuously',
 		     't' => 'adv' },
 'unde'		=> { 'x' => 'where',
		     '#' => 'interr.',
 		     't' => 'pro' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'doi'		=> { 'x' => 'two' },
 'dou�'		=> { 'x' => 'two' },
 'trei'		=> { 'x' => 'three' },
 'patru'	=> { 'x' => 'four' },
 'cinci'	=> { 'x' => 'five' },
 '�ase'		=> { 'x' => 'six' },
 '�apte'	=> { 'x' => 'seven' },
 'opt'		=> { 'x' => 'eight' },
 'nou�'		=> { 'x' => 'nine' },
 'zece'		=> { 'x' => 'ten' },
 # Days and months
 'duminic�'	=> { 'x' => 'sunday' },
 'luni'		=> { 'x' => 'monday' },
 'mar�i'	=> { 'x' => 'tuesday' },
 'miercuri'	=> { 'x' => 'wednesday' },
 'joi'		=> { 'x' => 'thursday' },
 'vineri'	=> { 'x' => 'friday' },
 's�mb�t�'	=> { 'x' => 'saturday' },
 'ianuarie'	=> { 'x' => 'january' },
 'februarie'	=> { 'x' => 'february' },
 'martie'	=> { 'x' => 'march' },
 'aprilie'	=> { 'x' => 'april' },
 'mai'		=> { 'x' => 'may' },
 'iunie'	=> { 'x' => 'june' },
 'iulie'	=> { 'x' => 'july' },
 'august'	=> { 'x' => 'august' },
 'septembrie'	=> { 'x' => 'september' },
 'octombrie'	=> { 'x' => 'october' },
 'noiembrie'	=> { 'x' => 'november' },
 'decembrie'	=> { 'x' => 'december' },
 # Key verbs
 #  a fi - to be
 'fi'		=> { 'x' => 'be',
 		     't' => 'v' },
  's�nt'	=> { 'x' => '(i) am' },
  'e�ti'	=> { 'x' => '(you) are' },
  'este'	=> { 'x' => '(he) is' },
  's�ntem'	=> { 'x' => '(we) are' },
  's�nte�i'	=> { 'x' => '(you) are' },
  's�nt'	=> { 'x' => '(they) are' },
 #  a avea - to have
 'avea'		=> { 'x' => 'have',
 		     't' => 'v' },
  'am'		=> { 'x' => '(i) have',
  		     'r' => 'avea',
		     't' => 'v' },
  'ai'		=> { 'x' => '(you) have',
  		     'r' => 'avea',
		     't' => 'v' },
  'are'		=> { 'x' => '(he) has',
		     '#' => 'she, it',
  		     'r' => 'avea',
		     't' => 'v' },
  'avem'	=> { 'x' => '(we) have',
  		     'r' => 'avea',
		     't' => 'v' },
  'ave�i'	=> { 'x' => '(you) have',
  		     'r' => 'avea',
		     't' => 'v' },
  'au'		=> { 'x' => '(they) have',
  		     'r' => 'avea',
		     't' => 'v' },
 #  a face - to do
 'face'		=> { 'x' => 'do',
		     '#' => 'make',
 		     't' => 'v' },
 #  a merge - to go
 'merge'	=> { 'x' => 'go',
 		     't' => 'v' },
 # Vocabulary
 'ajunge'	=> { 'x' => 'enough',
		     '#' => 'it is enough/sufficient (basta?)',
 		     't' => 'interj' },
 'ambasad�'	=> { 'x' => 'embassy',
 		     't' => 'n',
		     'g' => 'f' },
 'an'		=> { 'x' => 'year',
 		     't' => 'n',
		     'g' => 'm' },
 'animal'	=> { 'x' => 'animal',
 		     't' => 'n',
		     'g' => 'n' },
 'ap�'		=> { 'x' => 'water',
		     '#' => 'river',
 		     't' => 'n',
		     'g' => 'f' },
 'apartament'	=> { 'x' => 'apartment',
		     '#' => 'flat',
 		     't' => 'n',
		     'g' => 'n' },
 'articolul'	=> { 'x' => 'article',
 		     't' => 'n' },
 'autobuz'	=> { 'x' => 'bus',
 		     't' => 'n',
		     'g' => 'n' },
 'auzi'		=> { 'x' => 'hear',
 		     't' => 'v' },
 'avion'	=> { 'x' => 'aeroplane',
 		     't' => 'n',
		     'g' => 'n' },
 'bar'		=> { 'x' => 'bar',
 		     't' => 'n',
		     'g' => 'n',
		     'p' => 'uri' },
 'bea'		=> { 'x' => 'drink',
		     '#' => 'irreg.',
 		     't' => 'v' },
 'b�iat'	=> { 'x' => 'boy',
		     '#' => 'son',
 		     't' => 'n',
		     'g' => 'm' },
 'bec'		=> { 'x' => 'light bulb',
 		     't' => 'n',
		     'g' => 'n' },
 'bere'		=> { 'x' => 'beer',
 		     't' => 'n',
		     'g' => 'f' },
 'bilet'	=> { 'x' => 'ticket',
 		     't' => 'n',
		     'g' => 'n' },
 'bine'		=> { 'x' => 'well',
		     '#' => 'good',
 		     't' => 'adv' },
 'bou'		=> { 'x' => 'ox',
 		     't' => 'n' },
 'britanic'	=> { 'x' => 'british',
 		     't' => 'a' },
 'br�nz�'	=> { 'x' => 'cheese',
		     '#' => 'types of cheese',
 		     't' => 'n',
		     'g' => 'f' },
 'bun'		=> { 'x' => 'good',
 		     't' => 'a' },
 'cafea'	=> { 'x' => 'coffee',
 		     't' => 'n',
		     'g' => 'f' },
 'camer�'	=> { 'x' => 'room',
 		     't' => 'n',
		     'g' => 'f' },
 'cap'		=> { 'x' => 'head',
 		     't' => 'n',
		     'g' => 'n' },
 'carte'	=> { 'x' => 'book',
 		     't' => 'n',
		     'g' => 'f' },
 'cas�'		=> { 'x' => 'house',
 		     't' => 'n',
		     'g' => 'f' },
 'c�min'	=> { 'x' => 'hostel',
		     '#' => 'hall of residence',
 		     't' => 'n',
		     'g' => 'n' },
 'centur�'	=> { 'x' => 'belt',
 		     't' => 'n',
		     'g' => 'f' },
 'cinema'	=> { 'x' => 'cinema',
 		     't' => 'n',
		     'g' => 'n' },
 'ciocolot�'	=> { 'x' => 'chocolate',
 		     't' => 'n',
		     'g' => 'f',
		     'p' => 'e' },
 'citi'		=> { 'x' => 'read',
 		     't' => 'v' },
 'citronad�'	=> { 'x' => 'lemonade',
 		     't' => 'n',
		     'g' => 'f' },
 'c�ine'	=> { 'x' => 'dog',
 		     't' => 'n',
		     'g' => 'm' },
 'cofet�rie'	=> { 'x' => 'cafe',
		     '#' => 'coffee shop, confectioner\'s',
 		     't' => 'n',
		     'g' => 'f' },
 'conversa�ie'	=> { 'x' => 'conversation',
 		     't' => 'n',
		     'g' => 'f' },
 'cosmonaut'	=> { 'x' => 'cosmonaut',
 		     't' => 'n' },
 'creion'	=> { 'x' => 'pencil',
 		     't' => 'n',
		     'g' => 'n' },
 'cump�ra'	=> { 'x' => 'buy',
		     '#' => 'irreg.',
 		     't' => 'v' },
 'curat'	=> { 'x' => 'clean',
 		     't' => 'a' },
 'cutie'	=> { 'x' => 'box',
 		     't' => 'n',
		     'g' => 'f' },
 'da'		=> { 'x' => 'give',
 		     't' => 'v' },
 'declara'	=> { 'x' => 'declare',
 		     't' => 'v' },
 'deschide'	=> { 'x' => 'open',
		     '#' => 'turn on',
 		     't' => 'v' },
 'deschis'	=> { 'x' => 'open',
 		     't' => 'a' },
 'dic�ionar'	=> { 'x' => 'dictionary',
 		     't' => 'n',
		     'g' => 'n' },
 'diferen��'	=> { 'x' => 'difference',
 		     't' => 'n',
		     'g' => 'f' },
 'dinte'	=> { 'x' => 'tooth',
 		     't' => 'n' },
 'doamn�'	=> { 'x' => 'lady',
 		     't' => 'n',
		     'g' => 'f' },
 'domn'		=> { 'x' => 'man',
		     '#' => 'gentelman',
 		     't' => 'n',
		     'g' => 'm' },
 'domni�oar�'	=> { 'x' => 'young lady',
		     '#' => 'cf senorita, fraulein',
 		     't' => 'n',
		     'g' => 'f' },
 'dori'		=> { 'x' => 'wish',
		     '#' => 'want',
 		     't' => 'v' },
 'dormi'	=> { 'x' => 'sleep',
 		     't' => 'v' },
 'drept'	=> { 'x' => 'right',
		     '#' => 'law',
 		     't' => 'n',
		     'g' => 'n' },
 'dulce'	=> { 'x' => 'sweet',
 		     't' => 'a' },
 'electricitate'	=> { 'x' => 'electricity',
 			     't' => 'n' },
 'englez'	=> { 'x' => 'english',
		     '#' => 'with masc. nouns',
 		     't' => 'a' },
 'englez�'	=> { 'x' => 'english',
		     '#' => '?',
 		     't' => 'a' },
 'englezesc'	=> { 'x' => 'english',
		     '#' => 'with fem/neut. nouns',
 		     't' => 'adj' },
 'engleze�te'	=> { 'x' => 'english',
		     '#' => 'not adj. or noun!',
 		     't' => 'adv' },
 'exagera'	=> { 'x' => 'exaggerate',
 		     't' => 'v' },
 'expedia'	=> { 'x' => 'send',
 		     't' => 'v' },
 'familie'	=> { 'x' => 'family',
 		     't' => 'n',
		     'g' => 'f' },
 'fat�'		=> { 'x' => 'girl',
		     '#' => 'daughter',
 		     't' => 'n',
		     'g' => 'f' },
 'fel'		=> { 'x' => 'kind',
		     '#' => 'sort',
 		     't' => 'n',
		     'g' => 'n' },
 'fereastra'	=> { 'x' => 'window',
 		     't' => 'n' },
 'folositor'	=> { 'x' => 'useful',
 		     't' => 'a' },
 'formular'	=> { 'x' => 'form',	
 		     't' => 'n',
		     'g' => 'n' },
 'francez'	=> { 'x' => 'french',
		     '#' => 'with masc. nouns',
 		     't' => 'a' },
 'fran�a'	=> { 'x' => 'france',
 		     't' => 'n',
		     'g' => 'f' },
 'fran�uzesc'	=> { 'x' => 'french',
		     '#' => 'with fem/neut. nouns',
 		     't' => 'adj' },
 'fran�uz�te'	=> { 'x' => 'french',
		     '#' => 'not adj. or noun!',
 		     't' => 'adv' },
 'gar�'		=> { 'x' => 'station',
 		     't' => 'n',
		     'g' => 'f' },
 'german�'	=> { 'x' => 'german',
 		     't' => 'a' },
 'gesticula'	=> { 'x' => 'gesticulate',
 		     't' => 'v' },
 'gol'		=> { 'x' => 'empty',
 		     't' => 'a' },
 'gr�din�'	=> { 'x' => 'garden',
 		     't' => 'n',
		     'g' => 'f' },
 'gre�eal�'	=> { 'x' => 'mistake',
		     '#' => 'wrong number',
 		     't' => 'n',
		     'g' => 'f' },
 'hart�'	=> { 'x' => 'map',
 		     't' => 'n',
		     'g' => 'f' },
 'h�rtie'	=> { 'x' => 'paper',
 		     't' => 'n',
		     'g' => 'f' },
 'hotel'	=> { 'x' => 'hotel',
 		     't' => 'n',
		     'g' => 'n' },
 'iarb�'	=> { 'x' => 'grass',
		     '#' => 'herbs',
 		     't' => 'n',
		     'g' => 'f' },
 'iarn�'	=> { 'x' => 'winter',
 		     't' => 'n',
		     'g' => 'f' },
 'informa�ie'	=> { 'x' => 'information',
 		     't' => 'n',
		     'g' => 'f',
		     'p' => 'i' },
 'inginer'	=> { 'x' => 'engineer',
 		     't' => 'n',
		     'g' => 'm' },
 'intra'	=> { 'x' => 'enter',
 		     't' => 'v' },
 'invita'	=> { 'x' => 'invite',
 		     't' => 'v' },
 '�mb�tr�ni'	=> { 'x' => 'grow old',
		     '#' => 'two words',
 		     't' => 'v' },
 '�nchide'	=> { 'x' => 'close',
 		     't' => 'v' },
 '�nchis'	=> { 'x' => 'closed',
 		     't' => 'a' },
 '�nghe�at�'	=> { 'x' => 'ice-cream',
 		     't' => 'n',
		     'g' => 'f' },
 '�ntreba'	=> { 'x' => 'ask',
 		     't' => 'v' },
 '�nv��a'	=> { 'x' => 'learn',
 		     't' => 'v' },
 'lamp�'	=> { 'x' => 'lamp',
 		     't' => 'n',
		     'g' => 'f' },
 'lat'		=> { 'x' => 'wide',
 		     't' => 'a' },
 'lec�ie'	=> { 'x' => 'lesson',
 		     't' => 'n',
		     'g' => 'f' },
 'leu'		=> { 'x' => 'lion',
		     '#' => 'leu (monetary unit)',
 		     't' => 'n',
		     'g' => 'm' },
 'liber'	=> { 'x' => 'free',
		     '#' => 'empty',
 		     't' => 'a' },
 'libertate'	=> { 'x' => 'freedom',
 		     't' => 'n',
		     'g' => 'f' },
 'limb�'	=> { 'x' => 'language',
 		     't' => 'n',
		     'g' => 'f' },
 'limonad�'	=> { 'x' => 'lemonade',
 		     't' => 'n',
		     'g' => 'f' },
 'locui'	=> { 'x' => 'live',
		     '#' => 'irreg.',
 		     't' => 'v' },
 'lucra'	=> { 'x' => 'work',
 		     't' => 'v' },
 'lua'		=> { 'x' => 'take',
 		     't' => 'v' },
 'lun�'		=> { 'x' => 'month',
		     '#' => 'moon',
 		     't' => 'n',
		     'g' => 'f',
		     'p' => 'i' },
 'mam�'		=> { 'x' => 'mother',
 		     't' => 'n',
		     'g' => 'f' },
 'manual'	=> { 'x' => 'text-book',
 		     't' => 'n',
		     'g' => 'n' },
 'mare'		=> { 'x' => 'big',
 		     't' => 'a' },
 'mas�'		=> { 'x' => 'table',
		     '#' => 'meal',
 		     't' => 'n',
		     'g' => 'f' },
 'm�r'		=> { 'x' => 'apple',
 		     't' => 'n',
		     'g' => 'n' },
 'mesaj'	=> { 'x' => 'message',
 		     't' => 'n' },
 'mic'		=> { 'x' => 'small',
 		     't' => 'a' },
 'mili�ian'	=> { 'x' => 'policeman',
 		     't' => 'n',
		     'g' => 'm' },
 'minut'	=> { 'x' => 'minute',
 		     't' => 'n',
		     'g' => 'n' },
 'm�nca'	=> { 'x' => 'eat',
		     '#' => 'irreg.',
 		     't' => 'v' },
 'm�n�'		=> { 'x' => 'hand',
 		     't' => 'n',
		     'g' => 'f' },
 'mod'		=> { 'x' => 'manner',
 		     't' => 'n',
		     'g' => 'n' },
 'modifica'	=> { 'x' => 'modify',
 		     't' => 'v' },
 'moned�'	=> { 'x' => 'coin',
 		     't' => 'n',
		     'g' => 'f' },
 'munte'	=> { 'x' => 'mountain',
 		     't' => 'n',
		     'g' => 'm' },
 'murdar'	=> { 'x' => 'dirty',
 		     't' => 'a' },
 'na�ional'	=> { 'x' => 'national',
 		     't' => 'a' },
 'na�iune'	=> { 'x' => 'nation',
 		     't' => 'n',
		     'g' => 'f' },
 'nem�e�te'	=> { 'x' => 'german',
		     '#' => 'not adj. or noun!',
 		     't' => 'adv' },
 'noroc'	=> { 'x' => 'cheers',
		     '#' => 'good luck',
 		     't' => 'interj' },
 'nou'		=> { 'x' => 'new',
 		     't' => 'a' },
 'num�r'	=> { 'x' => 'number',
 		     't' => 'n',
		     'g' => 'n' },
 'ocupat'	=> { 'x' => 'busy',
		     '#' => 'engaged',
 		     't' => 'a' },
 'om'		=> { 'x' => 'man',
 		     't' => 'n',
		     'g' => 'm' },
 'ou'		=> { 'x' => 'egg',
 		     't' => 'n',
		     'g' => 'n' },
 'pahar'	=> { 'x' => 'glass',
 		     't' => 'n',
		     'g' => 'n' },
 'p�l�rie'	=> { 'x' => 'hat',
 		     't' => 'n',
		     'g' => 'f' },
 'parc'		=> { 'x' => 'park',
 		     't' => 'n',
		     'g' => 'n' },
 'pa�aport'	=> { 'x' => 'passport',
 		     't' => 'n',
		     'g' => 'n' },
 'pat'		=> { 'x' => 'bed',
 		     't' => 'n',
		     'g' => 'n' },
 'pe�te'	=> { 'x' => 'fish',
 		     't' => 'n' },
 'pix'		=> { 'x' => 'pen',
		     '#' => 'ball-point',
 		     't' => 'n',
		     'g' => 'm' },
 'p�ine'	=> { 'x' => 'bread',
		     '#' => 'loaf',
 		     't' => 'n',
		     'g' => 'f' },
 'pleca'	=> { 'x' => 'leave',
 		     't' => 'v' },
 'plecare'	=> { 'x' => 'departure',
 		     't' => 'n',
		     'g' => 'f' },
 'poezie'	=> { 'x' => 'poem',
		     '#' => 'poetry',
 		     't' => 'n',
		     'g' => 'f' },
 'poli�ist'	=> { 'x' => 'detective',
 		     't' => 'a' },
 'pom'		=> { 'x' => 'tree',
		     '#' => 'fruit tree',
 		     't' => 'n',
		     'g' => 'm' },
 'portofel'	=> { 'x' => 'wallet',
 		     't' => 'n',
		     'g' => 'n' },
 'prezenta'	=> { 'x' => 'introduce',
 		     't' => 'v' },
 'profesionist'	=> { 'x' => 'professional',
 		     't' => 'a' },
 'profesor'	=> { 'x' => 'professor',
 		     't' => 'n',
		     'g' => 'm' },
 'proiect'	=> { 'x' => 'project',
 		     't' => 'n' },
 'pui'		=> { 'x' => 'chicken',
 		     't' => 'n',
		     'g' => 'm' },
 'pune'		=> { 'x' => 'put',
 		     't' => 'v' },
 'pung�'	=> { 'x' => 'bag',
		     '#' => 'plastic bag',
 		     't' => 'n',
		     'g' => 'f' },
 'raft'		=> { 'x' => 'shelf',
 		     't' => 'n',
		     'g' => 'n' },
 'r�u'		=> { 'x' => 'bad',
 		     't' => 'a' },
 'rece'		=> { 'x' => 'cold',
 		     't' => 'a' },
 'roman'	=> { 'x' => 'novel',
 		     't' => 'n',
		     'g' => 'n' },
 'rom�n'	=> { 'x' => 'romanian',
		     '#' => 'with masc. nouns',
 		     't' => 'a' },
 'rom�nia'	=> { 'x' => 'romania',
 		     't' => 'n' },
 'rom�nesc'	=> { 'x' => 'romanian',
		     '#' => 'with fem/neut. nouns',
 		     't' => 'a' },
 'rom�ne�te'	=> { 'x' => 'romanian',
		     '#' => 'not adj. or noun!',
 		     't' => 'adv' },
 'ruga'		=> { 'x' => 'ask',
 		     't' => 'v' },
 'rus'		=> { 'x' => 'russian',
		     '#' => 'with masc. nouns',
 		     't' => 'a' },
 'rus�'		=> { 'x' => 'russian',
 		     't' => 'a' },
 'rusesc'	=> { 'x' => 'russian',
		     '#' => 'with fem/neut. nouns',
 		     't' => 'a' },
 'ruse�te'	=> { 'x' => 'russian',
		     '#' => 'not adj. or noun!',
 		     't' => 'adv' },
 'sac'		=> { 'x' => 'sack',
 		     't' => 'n',
		     'g' => 'm',
		     'p' => 'i' },
 's�ruta'	=> { 'x' => 'kiss',
 		     't' => 'v' },
 'scrie'	=> { 'x' => 'write',
 		     't' => 'v' },
 'scrisoare'	=> { 'x' => 'letter',
 		     't' => 'n',
		     'g' => 'f' },
 'sec'		=> { 'x' => 'dry',
 		     't' => 'a' },
 'senin'	=> { 'x' => 'bright',
 		     't' => 'a' },
 'soacr�'	=> { 'x' => 'mother-in-law',
 		     't' => 'n',
		     'g' => 'f' },
 'soare'	=> { 'x' => 'sun',
 		     't' => 'n' },
 'social'	=> { 'x' => 'social',
 		     't' => 'a' },
 'socru'	=> { 'x' => 'father-in-law',
 		     't' => 'n',
		     'g' => 'm' },
 'solidaritate'	=> { 'x' => 'solidarity',
 		     't' => 'n' },
 'sosi'		=> { 'x' => 'arrive',
 		     't' => 'v' },
 'spune'	=> { 'x' => 'say',
		     '#' => 'tell - more elegant than zice',
 		     't' => 'v' },
 'sta'		=> { 'x' => 'sit',
		     '#' => 'reside, stand',
 		     't' => 'v' },
 'stat'		=> { 'x' => 'state',
		     '#' => 'nation',
 		     't' => 'n',
		     'g' => 'n' },
 'sticl�'	=> { 'x' => 'bottle',
 		     't' => 'n',
		     'g' => 'f' },
 'strad�'	=> { 'x' => 'street',
		     '#' => 'road',
 		     't' => 'n',
		     'g' => 'f',
		     'p' => 'str�zi' },
 'str�in'	=> { 'x' => 'foreign',
 		     't' => 'a' },
 'student'	=> { 'x' => 'student',
 		     't' => 'n',
		     'g' => 'm' },
 '�osea'	=> { 'x' => 'road',
		     '#' => 'main road',
 		     't' => 'n',
		     'g' => 'f' },
 '�ti'		=> { 'x' => 'know',
 		     't' => 'v' },
 'tat�'		=> { 'x' => 'father',
 		     't' => 'n',
		     'g' => 'm' },
 'taxi'		=> { 'x' => 'taxi',
 		     't' => 'n',
		     'g' => 'n' },
 't�cea'	=> { 'x' => 'be silent',
		     '#' => 'two words',
 		     't' => 'v' },
 'termen'	=> { 'x' => 'term',
		     '#' => 'expression',
 		     't' => 'n',
		     'g' => 'm' },
 'text'		=> { 'x' => 'text',
 		     't' => 'n',
		     'g' => 'n' },
 'timp'		=> { 'x' => 'weather',
		     '#' => 'time',
 		     't' => 'n',
		     'g' => 'n' },
 'trimite'	=> { 'x' => 'send',
 		     't' => 'v' },
 '�ar�'		=> { 'x' => 'country',
 		     't' => 'n' },
 'uman'		=> { 'x' => 'human',
 		     't' => 'a' },
 'universitate'	=> { 'x' => 'university',
 		     't' => 'n',
		     'g' => 'f' },
 'valabil'	=> { 'x' => 'valid',
 		     't' => 'a' },
 'v�r'		=> { 'x' => 'cousin',
 		     't' => 'n',
		     'g' => 'm' },
 'vechi'	=> { 'x' => 'old',
 		     't' => 'a' },
 'vedea'	=> { 'x' => 'see',
 		     't' => 'v' },
 'vin'		=> { 'x' => 'wine',
 		     't' => 'n',
		     'g' => 'n' },
 'volum'	=> { 'x' => 'volume',
 		     't' => 'n',
		     'g' => 'n' },
 'vorbi'	=> { 'x' => 'speak',
		     '#' => 'talk',
 		     't' => 'v' },
 'vreme'	=> { 'x' => 'weather',
		     '#' => 'time',
 		     't' => 'n',
		     'g' => 'f' },
 'ze'		=> { 'x' => 'day',
 		     't' => 'n',
		     'g' => 'f',
		     'p' => 'zile' },
 'zice'		=> { 'x' => 'say',
		     '#' => 'more colloquial than spune',
 		     't' => 'v' },
 'zilnic'	=> { 'x' => 'daily',
 		     't' => 'adv' },
);
}

1;

