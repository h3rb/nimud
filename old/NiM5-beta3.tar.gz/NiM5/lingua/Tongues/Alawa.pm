# vi: ts=8 sw=8 sts=8

package Tongues::Alawa;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B D E G J L M N R S U W Y
# a b d e g j l m n r s u w y

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:				pronouns
#	d -> direct
#	i -> indirect

# Alawa to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'ngina'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'x' => 'i',
		     'c' => 'd' },
 'ngaba'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'x' => 'i',
		     'c' => 'i' },
 #   1st person inclusive
 'nyanu'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     '#' => 'inclusive',
		     'x' => 'we',
		     'c' => 'd' },
 'nyaga'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     '#' => 'inclusive',
		     'x' => 'we',
		     'c' => 'i' },
 'nyalu'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     '#' => 'inclusive',
		     'x' => 'we',
		     'c' => 'd' },
 'nyalanga'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     '#' => 'inclusive',
		     'x' => 'we',
		     'c' => 'i' },
 #   1st person exclusive
 'ngarru'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     '#' => 'exclusive',
		     'x' => 'we',
		     'c' => 'd' },
 'ngarranga'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     '#' => 'exclusive',
		     'x' => 'we',
		     'c' => 'i' },
 'ngalu'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     '#' => 'exclusive',
		     'x' => 'we',
		     'c' => 'd' },
 'ngalanga'	=> { 't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     '#' => 'exclusive',
		     'x' => 'we',
		     'c' => 'i' },
 #   2nd person
 'nyanggana'	=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'x' => 'you',
		     'c' => 'd' },
 'nyamba'	=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'x' => 'you',
		     'c' => 'i' },
 'wurru'	=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'x' => 'you',
		     'c' => 'd' },
 'wurrunga'	=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'x' => 'you',
		     'c' => 'i' },
 'wulu'		=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'x' => 'you',
		     'c' => 'd' },
 'wulunga'	=> { 't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'x' => 'you',
		     'c' => 'i' },
 #   3rd person
 'nula'		=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm',
		     'x' => 'he',
		     'c' => 'd' },
 'nurla'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm',
		     'x' => 'he',
		     'c' => 'd' },
 'niba'		=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'm',
		     'x' => 'he',
		     'c' => 'i' },
 'ngandula'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'x' => 'she',
		     'c' => 'd' },
 'ngadu'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'x' => 'she',
		     'c' => 'i' },
 'yirrula'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'x' => 'they',
		     'c' => 'd' },
 'yirrunga'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'x' => 'they',
		     'c' => 'i' },
 'yilula'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'x' => 'they',
		     'c' => 'd' },
 'yilunga'	=> { 't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'x' => 'they',
		     'c' => 'i' },
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 # Key verbs
 # Vocabulary
);
}

1;

