# vi: ts=8 sw=8 sts=8

package Tongues::Galego;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B C CH D E F G H I (J K) L LL M N � O P Q R S T U V (W) X (Y) Z
# a b c ch d e f g h i (j k) l ll m n � o p q r s t u v (w) x (y) z

# Extra characters (ISO & Windows)
# � � � � � � �
# � � � � � � �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun gender
 # Noun plural
 [ 'as',	'a',	'',		's',	'n' ],
 [ 'es',	'e',	'',		's',	'n' ],
 [ 'os',	'o',	'',		's',	'n' ],
 [ 'ns',	'm',	'',		's',	'n' ],
 [ '�es',	'�o',	'',		's',	'n' ],
 # Adjectives
 [ 'a',		'o',	'',		'',	'a' ],	# fem.
 [ 'os',	'o',	'',		'',	'a' ],	# pl.
 [ 'as',	'o',	'',		'',	'a' ],	# fem. pl.
 [ 's',		'',	'',		'',	'a' ],	# pl.
 # Verb past participle
 [ 'ado',	'ar',	'',		'ed',	'v' ],
 [ 'ada',	'ar',	'',		'ed',	'v' ],
 [ 'ados',	'ar',	'',		'ed',	'v' ],
 [ 'adas',	'ar',	'',		'ed',	'v' ],
 [ 'ido',	'er',	'',		'ed',	'v' ],
 [ 'ida',	'er',	'',		'ed',	'v' ],
 [ 'idos',	'er',	'',		'ed',	'v' ],
 [ 'idas',	'er',	'',		'ed',	'v' ],
 [ 'ido',	'ir',	'',		'ed',	'v' ],
 [ 'ida',	'ir',	'',		'ed',	'v' ],
 [ 'idos',	'ir',	'',		'ed',	'v' ],
 [ 'idas',	'ir',	'',		'ed',	'v' ],
 # Verb gerund
 [ 'ando',	'ar',	'',		'ing',	'v' ],
 [ 'endo',	'er',	'',		'ing',	'v' ],
 [ 'indo',	'ir',	'',		'ing',	'v' ],
 # Verb present participle
 # Verb present
 [ 'o',		'ar',	'(i) ',		'',	'v' ],
 [ 'o',		'er',	'(i) ',		'',	'v' ],
 [ 'o',		'ir',	'(i) ',		'',	'v' ],
 [ 'as',	'ar',	'(you) ',	'',	'v' ],
 [ 'es',	'er',	'(you) ',	'',	'v' ],
 [ 'es',	'ir',	'(you) ',	'',	'v' ],
 [ 'a',		'ar',	'(he) ',	's',	'v' ],
 [ 'e',		'er',	'(he) ',	's',	'v' ],
 [ 'e',		'ir',	'(he) ',	's',	'v' ],
 [ 'amos',	'ar',	'(we) ',	'',	'v' ],
 [ 'emos',	'er',	'(we) ',	'',	'v' ],
 [ 'imos',	'ir',	'(we) ',	'',	'v' ],
 [ '�is',       'ar',   '(you) ',       '',     'v' ],
 [ '�is',       'er',   '(you) ',       '',     'v' ],
 [ '�s',        'ir',   '(you) ',       '',     'v' ],
 [ 'an',	'ar',	'(they) ',	'',	'v' ],
 [ 'en',	'er',	'(they) ',	'',	'v' ],
 [ 'en',	'ir',	'(they) ',	'',	'v' ],
 # Verb present subjunctive, imperitive
 [ 'e',		'ar',	'',		'',	'v' ],
 [ 'a', 	'ar',	'',     	'',	'v' ],
 [ 'e',		'ar',	'',     	'',	'v' ],
 [ 'emos',	'ar',	'let\'s ',     	'',	'v' ],
 [ 'ai',        'ar',   '',             '',     'v' ],
 [ 'em',	'ar',	'',     	'',	'v' ],
 [ 'a',		'er',	'',		'',	'v' ],
 [ 'e', 	'er',	'',     	'',	'v' ],
 [ 'a',		'er',	'',     	'',	'v' ],
 [ 'amos',	'er',	'let\'s ',     	'',	'v' ],
 [ 'ei',        'er',   '',             '',     'v' ],
 [ 'am',	'er',	'',     	'',	'v' ],
 [ 'a',		'ir',	'',		'',	'v' ],
 [ 'e', 	'ir',	'',     	'',	'v' ],
 [ 'a',		'ir',	'',     	'',	'v' ],
 [ 'amos',	'ir',	'let\'s ',     	'',	'v' ],
 [ 'i',         'ir',   '',             '',     'v' ],
 [ 'am',	'ir',	'',     	'',	'v' ],
 # Verb preterite
 [ 'ei',	'ar',	'(i) ',		'ed',	'v' ],
 [ 'i',		'er',	'(i) ',		'ed',	'v' ],
 [ 'i',		'ir',	'(i) ',		'ed',	'v' ],
 [ 'aste',	'ar',	'(you) ',	'ed',	'v' ],
 [ 'este',	'er',	'(you) ',	'ed',	'v' ],
 [ 'iste',	'ir',	'(you) ',	'ed',	'v' ],
 [ 'ou',	'ar',	'(he) ',	'ed',	'v' ],
 [ 'eu',	'er',	'(he) ',	'ed',	'v' ],
 [ 'io',	'ir',	'(he) ',	'ed',	'v' ],
 [ 'amos',	'ar',	'(we) ',	'ed',	'v' ],
 [ 'emos',	'er',	'(we) ',	'ed',	'v' ],
 [ 'imos',	'ir',	'(we) ',	'ed',	'v' ],
 [ 'astes',	'ar',	'(you) ',	'ed',	'v' ],
 [ 'estes',	'er',	'(you) ',	'ed',	'v' ],
 [ 'istes',	'ir',	'(you) ',	'ed',	'v' ],
 [ 'aram',	'ar',	'(they) ',	'ed',	'v' ],
 [ 'eram',	'er',	'(they) ',	'ed',	'v' ],
 [ 'iram',	'ir',	'(they) ',	'ed',	'v' ],
 # Verb imperfect
 [ 'ava',	'ar',	'(he) ',	'ed',	'v' ],	# I
 [ 'ia',	'er',	'(he) ',	'ed',	'v' ],	# I
 [ 'ia',	'ir',	'(he) ',	'ed',	'v' ],	# I
 [ 'avas',	'ar',	'(you) ',	'ed',	'v' ],
 [ 'ias',	'er',	'(you) ',	'ed',	'v' ],
 [ 'ias',	'ir',	'(you) ',	'ed',	'v' ],
 [ '�vamos',	'ar',	'(we) ',	'ed',	'v' ],
 [ '�amos',	'er',	'(we) ',	'ed',	'v' ],
 [ '�amos',	'ir',	'(we) ',	'ed',	'v' ],
 [ '�veis',	'ar',	'(you) ',	'ed',	'v' ],
 [ '�veis',	'er',	'(you) ',	'ed',	'v' ],
 [ '�eis',	'ir',	'(you) ',	'ed',	'v' ],
 [ 'avan',	'ar',	'(they) ',	'ed',	'v' ],
 [ '�an',	'er',	'(they) ',	'ed',	'v' ],
 [ '�an',	'ir',	'(they) ',	'ed',	'v' ],
 # Verb future
 [ 'arei',	'ar',	'(i) will ',	'',	'v' ],
 [ 'ar�s',	'ar',	'(you) will ',	'',	'v' ],
 [ 'ar�',	'ar',	'(he) will ',	'',	'v' ],
 [ 'aremos',	'ar',	'(we) will ',	'',	'v' ],
 [ 'areis',	'ar',	'(you) will ',	'',	'v' ],
 [ 'ar�o',	'ar',	'(they) will ',	'',	'v' ],
 [ 'erei',	'er',	'(i) will ',	'',	'v' ],
 [ 'er�s',	'er',	'(you) will ',	'',	'v' ],
 [ 'er�',	'er',	'(he) will ',	'',	'v' ],
 [ 'eremos',	'er',	'(we) will ',	'',	'v' ],
 [ 'ereis',	'er',	'(you) will ',	'',	'v' ],
 [ 'er�o',	'er',	'(they) will ',	'',	'v' ],
 [ 'irei',	'ir',	'(i) will ',	'',	'v' ],
 [ 'ir�s',	'ir',	'(you) will ',	'',	'v' ],
 [ 'ir�',	'ir',	'(he) will ',	'',	'v' ],
 [ 'iremos',	'ir',	'(we) will ',	'',	'v' ],
 [ 'ireis',	'ir',	'(you) will ',	'',	'v' ],
 [ 'ir�o',	'ir',	'(they) will ',	'',	'v' ],
 # Verb conditional
 [ 'aria',	'ar',	'(i) would ',	'',	'v' ],
 [ 'arias',	'ar',	'(you) would ',	'',	'v' ],
 [ 'aria',	'ar',	'(he) would ',	'',	'v' ],
 [ 'ar�amos',	'ar',	'(we) would ',	'',	'v' ],
 [ 'ar�eis',	'ar',	'(you) would ',	'',	'v' ],
 [ 'ariam',	'ar',	'(they) would ',	'',	'v' ],
 [ 'eria',	'er',	'(i) would ',	'',	'v' ],
 [ 'erias',	'er',	'(you) would ',	'',	'v' ],
 [ 'eria',	'er',	'(he) would ',	'',	'v' ],
 [ 'er�amos',	'er',	'(we) would ',	'',	'v' ],
 [ 'er�eis',	'er',	'(you) would ',	'',	'v' ],
 [ 'eriam',	'er',	'(they) would ',	'',	'v' ],
 [ 'iriam',	'ir',	'(they) would ',	'',	'v' ],
 # Some other quasi-regular conjugations
 [ 'quei',	'car',	'(i) ', 	'ed ',	'v' ],  # 1p s. preterite
 [ 'que',	'car',	'',     	'',	'v' ],  # 1p s. pres. subj., imp.
 [ 'que',	'car',	'',     	'',	'v' ],  # 2p s. pres. subj., imp.
 [ 'que',	'car',	'',     	'',	'v' ],  # 3p s. pres. subj., imp.
 [ 'quemos',	'car',	'let\'s',     	'',	'v' ],  # 1p pl. pres. subj., imp.
 [ 'quei',	'car',	'',     	'',	'v' ],  # 2p pl. pres. subj., imp.
 [ 'que',	'car',	'',     	'',	'v' ],  # 3p pl. pres. subj., imp.

 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine		default for words ending in a
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative

# Galegoe to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 'o'		=> { 'x' => 'the',
		     't' => 'art',
		     'n' => 's',
		     'g' => 'm' },
 'os'		=> { 'x' => 'the',
		     't' => 'art',
		     'n' => 'p',
		     'g' => 'm' },
 'a'		=> { 'x' => 'the',
		     't' => 'art',
		     'n' => 's',
		     'g' => 'f' },
 'as'		=> { 'x' => 'the',
		     't' => 'art',
		     'n' => 's',
		     'g' => 'f' },
 #   Indefinite articles
 'un'		=> { 'x' => 'a',
		     '#' => 'an',
 		     't' => 'art',
		     'n' => 's',
		     'g' => 'm' },
 'unha'		=> { 'x' => 'a',
		     '#' => 'an',
 		     't' => 'art',
		     'n' => 's',
		     'g' => 'f' },
 'uns'		=> { 'x' => 'some',
 		     't' => 'art',
		     'n' => 'p',
		     'g' => 'm' },
 'unhas'	=> { 'x' => 'some',
 		     't' => 'art',
		     'n' => 's',
		     'g' => 'f' },
 #  Pronouns & possessive adjectives
 #   1st person singular
 'eu'		=> { 'x' => 'i',
		     't' => 'pro' },
 'meu'		=> { 'x' => 'my',
		     't' => 'a' },
 'minha'	=> { 'x' => 'my',
		     't' => 'a' },
 #   2nd person singular
 'tu'		=> { 'x' => 'you',
		     't' => 'pro', },
 'vostede'	=> { 'x' => 'you',
		     '#' => 'formal; gramm. 3rd pers. sing.',
		     't' => 'pro' },
 'teu'		=> { 'x' => 'your',
		     't' => 'a' },
 'tua'		=> { 'x' => 'you',
		     't' => 'a' },
 #   3rd person singular
 'ele'	        => { 'x' => 'he',
		     't' => 'pro', },
 'ela'	        => { 'x' => 'she',
		     't' => 'pro', },
 'sua'  	=> { 'x' => 'your',
		     't' => 'a' },
 #   1st person plural
 'n�s'		=> { 'x' => 'we',
		     't' => 'pro' },
 'nosso'	=> { 'x' => 'my',
		     't' => 'a' },
 #   2nd person plural
 'v�s'		=> { 'x' => 'you',
		     't' => 'pro', },
 'vostedes'	=> { 'x' => 'you',
		     '#' => 'formal; gramm. 3rd pers. plur.',
		     't' => 'pro' },
 'vosso'	=> { 'x' => 'your',
		     't' => 'a' },
 #   3rd person plural
 'eles'	        => { 'x' => 'they',
		     't' => 'pro', },
 'elas'	        => { 'x' => 'they',
		     't' => 'pro', },
 #  Other functional words (only words marked gl are verified galician, others are pt)
 'aqui' 	=> { 'x' => 'here',
		     't' => 'adv' },
 'atrav�s'	=> { 'x' => 'through',
		     '#' => 'also prep?',
		     't' => 'adv' },
 'com'		=> { 'x' => 'with',
 		     't' => 'p' },
 'de'		=> { 'x' => 'of',
 		     't' => 'p' },
 'e'            => { 'x' => 'and',
		     '#' => 'gl' },
 'esta'         => { 'x' => 'this' },
 'mais'		=> { 'x' => 'more' },
 'moito'	=> { 'x' => 'very',
		     '#' => 'gl' },
 'outro'	=> { 'x' => 'another',
		     '#' => 'other?',
		     't' => 'a' },
 'para'		=> { 'x' => 'to',
		     '#' => 'for',
 		     't' => 'p' },
 'por'		=> { 'x' => 'for',
		     '#' => 'by, per',
		     't' => 'p' },
 'quando'	=> { 'x' => 'when' },
 'que'		=> { 'x' => 'that',
		     '#' => 'than' },
 'se'		=> { 'x' => 'if' },
 'tamb�m'	=> { 'x' => 'also',
		     '#' => 'too' },
 't�o'		=> { 'x' => 'so' },
 'tudo'		=> { 'x' => 'everything' },
 'v�rios'	=> { 'x' => 'various',
 		     't' => 'a',
		     'n' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'zero'		=> { 'x' => 'zero' },
 'dois'		=> { 'x' => 'two' },
 'tr�s'		=> { 'x' => 'three' },
 'quatro'	=> { 'x' => 'four' },
 'cinco'	=> { 'x' => 'five' },
 'seis'		=> { 'x' => 'six' },
 'sete' 	=> { 'x' => 'seven' },
 'oito'		=> { 'x' => 'eight' },
 'nove' 	=> { 'x' => 'nine' },
 'dez'		=> { 'x' => 'ten' },
 'cem'		=> { 'x' => 'hundred' },
 'mil'		=> { 'x' => 'thousand' },

 'primeiro'	=> { 'x' => 'first',
 		     't' => 'a' },
 'segundo'	=> { 'x' => 'second',
 		     't' => 'a' },
 'terceiro'	=> { 'x' => 'third',
 		     't' => 'a' },

 # Days and months
 'domingo'	=> { 'x' => 'sunday' },
 'luns'		=> { 'x' => 'monday' },
 'martes'	=> { 'x' => 'tuesday' },
 'm�rcores'	=> { 'x' => 'wednesday' },
 'xoves'	=> { 'x' => 'thursday' },
 'venres'	=> { 'x' => 'friday' },
 's�bado'	=> { 'x' => 'saturday' },
 'xaneiro'	=> { 'x' => 'january' },
 'febreiro'	=> { 'x' => 'february' },
 'marzo'	=> { 'x' => 'march' },
 'abril'	=> { 'x' => 'april' },
 'maio'		=> { 'x' => 'may' },
 'xu�o'		=> { 'x' => 'june' },
 'xullo'	=> { 'x' => 'july' },
 'agosto'	=> { 'x' => 'august' },
 'setembro'	=> { 'x' => 'september' },
 'outubro'	=> { 'x' => 'october' },
 'novembro'	=> { 'x' => 'november' },
 'decembro'	=> { 'x' => 'december' },
 # Key verbs
 'ser'  	=> { 'x' => 'be',
		     't' => 'v' },
 'sou'  	=> { 'x' => '(i) am',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 '�s'   	=> { 'x' => '(you) are',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 '�'    	=> { 'x' => '(it) is',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'somos'  	=> { 'x' => '(we) are',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'sois'  	=> { 'x' => '(you) are',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 's�o'  	=> { 'x' => '(they) are',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'fui'  	=> { 'x' => '(i) was',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'foste'  	=> { 'x' => '(you) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'foi'  	=> { 'x' => '(he) was',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'fomos'  	=> { 'x' => '(we) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'fostes'  	=> { 'x' => '(i) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'foram'  	=> { 'x' => '(i) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'era'  	=> { 'x' => '(i) was',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 'eras'  	=> { 'x' => '(you) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 'era'  	=> { 'x' => '(he) was',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 '�ramos'  	=> { 'x' => '(we) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 '�reis'  	=> { 'x' => '(i) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 'eram'  	=> { 'x' => '(i) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },

 'estar'	=> { 'x' => 'be',
		     't' => 'v' },
 'estou'  	=> { 'x' => '(i) am',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'est�s'   	=> { 'x' => '(you) are',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'est�'    	=> { 'x' => '(it) is',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'estamos'  	=> { 'x' => '(we) are',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'estais'  	=> { 'x' => '(you) are',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'est�o'  	=> { 'x' => '(they) are',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'p' },
 'estive'  	=> { 'x' => '(i) was',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'estiveste'  	=> { 'x' => '(you) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'esteve'  	=> { 'x' => '(he) was',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'estivemos'  	=> { 'x' => '(we) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'estiveste'  	=> { 'x' => '(you) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'estiveram'  	=> { 'x' => '(they) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 't' },
 'estava'  	=> { 'x' => '(i) was',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 'estavas'  	=> { 'x' => '(you) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 'estava'  	=> { 'x' => '(he) was',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 'est�vamos'  	=> { 'x' => '(we) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 'est�veis'  	=> { 'x' => '(you) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },
 'estavam'  	=> { 'x' => '(they) were',
		     'r' => 'ser',
		     't' => 'v',
		     'c' => 'i' },

 'ter'  	=> { 'x' => 'have',
		     't' => 'v' },
 'tenho'  	=> { 'x' => '(i) have',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'p' },
 'tens'  	=> { 'x' => '(you) have',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'p' },
 'temos'  	=> { 'x' => '(we) have',
		     '#' => 'this is not really necessary, cause this is a regular form',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'p' },
 'tem'  	=> { 'x' => '(he) has',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'p' },
 'tendes'  	=> { 'x' => '(you) have',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'p' },
 't�m'  	=> { 'x' => '(they) have',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'p' },
 'tive'  	=> { 'x' => '(i) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 't' },
 'tiveste'  	=> { 'x' => '(you) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 't' },
 'teve'  	=> { 'x' => '(we) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 't' },
 'tivemos'  	=> { 'x' => '(he) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 't' },
 'tivestes'  	=> { 'x' => '(you) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 't' },
 'tiveram'  	=> { 'x' => '(they) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 't' },
 'tinha'  	=> { 'x' => '(i) had',
		     'r' => 'have',
		     't' => 'i',
		     'c' => 't' },
 'tinhas'  	=> { 'x' => '(you) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'i' },
 'tinha'  	=> { 'x' => '(we) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'i' },
 't�nhamos'  	=> { 'x' => '(he) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'i' },
 't�nheis'  	=> { 'x' => '(you) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'i' },
 'tinham'  	=> { 'x' => '(they) had',
		     'r' => 'have',
		     't' => 'v',
		     'c' => 'i' },

 'vou'  	=> { 'x' => 'will',
		     '#' => 'means also "(i) go"',
		     'r' => 'ir',
		     't' => 'v',
		     'c' => 'p' },
 'vais'  	=> { 'x' => 'will',
		     '#' => '(you) go',
		     'r' => 'ir',
		     't' => 'v',
		     'c' => 'p' },
 'vai'  	=> { 'x' => 'will',
		     '#' => '(he or you) goes',
		     'r' => 'ir',
		     't' => 'v',
		     'c' => 'p' },
 'vamos'  	=> { 'x' => 'will',
		     '#' => '(we) go',
		     'r' => 'ir',
		     't' => 'v',
		     'c' => 'p' },
 'ides'  	=> { 'x' => 'will',
		     '#' => '(you) go',
		     'r' => 'ir',
		     't' => 'v',
		     'c' => 'p' },
 'v�o'  	=> { 'x' => 'will',
		     '#' => '(them or you) go',
		     'r' => 'ir',
		     't' => 'v',
		     'c' => 'p' },

 # Vocabulary
 'artigo'  	=> { 'x' => 'article',
		     't' => 'n' },
 'branco'	=> { 'x' => 'white',
		     't' => 'a' },
 'cousa'	=> { 'x' => 'thing',
		     't' => 'n' },
 'falar'	=> { 'x' => 'speak',
		     't' => 'v' },
 'libro'	=> { 'x' => 'book',
		     't' => 'n' },
 'unir'		=> { 'x' => 'unite',
		     't' => 'v' },
 'vender'	=> { 'x' => 'sell',
		     't' => 'v' },
);
}

1;

