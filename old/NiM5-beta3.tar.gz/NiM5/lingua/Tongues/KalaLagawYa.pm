# vi: ts=8 sw=8 sts=8

package Tongues::KalaLagawYa;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B D E G I K L M N O P R S T U W Y Z
# a b d e g i k l m n o p r s t u w y z

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:				pronouns
#	n -> nominative/ergative (subject)
#	a -> accusative (object)
#	p -> possessive
#	l -> locative (accompaniment)
#	abl -> ablative (from)
#	d -> dative (to)
#	i -> immitative (like)

# KalaLagawYa to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   Nominative/Ergative (Subject)
 'ngay'		=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'n',
		     '#' => 'intransitive' },
 'ngath'	=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'n',
		     '#' => 'transitive' },
 'ngalbe'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'd',
		     'c' => 'n' },
 'ngoey'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'p',
		     'c' => 'n' },

 'ngoeba'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'd',
		     'c' => 'n' },
 'ngalpa'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'p',
		     'c' => 'n' },

 'ngi'		=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'n',
		     '#' => 'intransitive' },
 'ngidh'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'n',
		     '#' => 'transitive' },
 'ngipel'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'n' },
 'ngitha'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'n' },

 'na'		=> { 'x' => 'she',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'n',
		     '#' => 'intransitive' },
 'nadh'		=> { 'x' => 'she',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'n',
		     '#' => 'transitive' },
 'nuy'		=> { 'x' => 'he',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'n',
		     '#' => 'intransitive' },
 'nuydh'	=> { 'x' => 'he',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'n',
		     '#' => 'transitive' },
 'palay'	=> { 'x' => 'they',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 'n' },
 'thana'	=> { 'x' => 'they',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'n' },

 #   Accusative (Object)
 'ngoena'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'a' },
 'ngin'		=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'a' },
 'nan'		=> { 'x' => 'her',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'a' },
 'nuyn'		=> { 'x' => 'him',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'a' },

 #   Possessive
 'ngaw'		=> { 'x' => 'my',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'p' },
 'nguzu'	=> { 'x' => 'my',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'g' => 'm',
		     'c' => 'p' },
 'ngalben'	=> { 'x' => 'our',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'd',
		     'c' => 'p' },
 'ngoeymun'	=> { 'x' => 'our',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'p',
		     'c' => 'p' },

 'ngoeban'	=> { 'x' => 'our',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'd',
		     'c' => 'p' },
 'ngalpan'	=> { 'x' => 'our',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'p',
		     'c' => 'p' },

 'nginu'	=> { 'x' => 'your',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'p' },
 'ngipen'	=> { 'x' => 'your',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'p' },
 'ngithamun'	=> { 'x' => 'your',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'p' },

 'nanu'		=> { 'x' => 'her',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'p' },
 'nungu'	=> { 'x' => 'his',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'p' },
 'palamun'	=> { 'x' => 'their',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 'p' },
 'thanamun'	=> { 'x' => 'their',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'p' },

 #   Locative (accompaniment)
 'ngaybiya'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'l' },
 'ngalbeniya'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'd',
		     'c' => 'l' },
 'ngoeymuniya'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'p',
		     'c' => 'l' },

 'ngoebaniya'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'd',
		     'c' => 'l' },
 'ngalpaniya'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'p',
		     'c' => 'l' },

 'ngibiya'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'l' },
 'ngipeniya'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'l' },
 'ngithamuniya'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'l' },

 'nabiya'	=> { 'x' => 'her',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'l' },
 'nubiya'	=> { 'x' => 'him',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'l' },
 'palamuniya'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 'l' },
 'thanamuniya'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'l' },

 #   Ablative (from)
 'ngawngu'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'abl' },
 'ngalbelngu'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'd',
		     'c' => 'abl' },
 'ngoeymulngu'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'p',
		     'c' => 'abl' },

 'ngoebalngu'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'd',
		     'c' => 'abl' },
 'ngalpalngu'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'p',
		     'c' => 'abl' },

 'ngingunu'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'abl' },
 'ngipelngu'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'abl' },
 'ngithamulngu'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'abl' },

 'nanunga'	=> { 'x' => 'her',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'abl' },
 'nungungu'	=> { 'x' => 'him',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'abl' },
 'palamulngu'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 'abl' },
 'thanamulngu'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'abl' },

 #   Dative (to)
 'ngayapa'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'd' },
 'ngalbepa'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'd',
		     'c' => 'd' },
 'ngoeymulpa'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'p',
		     'c' => 'd' },

 'ngoebalpa'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'd',
		     'c' => 'd' },
 'ngalpalpa'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'p',
		     'c' => 'd' },

 'ngibepa'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'd' },
 'ngipelpa'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'd' },
 'ngithamulpa'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'd' },

 'nabepa'	=> { 'x' => 'her',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'd' },
 'nubepa'	=> { 'x' => 'him',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'd' },
 'palamulpa'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 'd' },
 'thanmulpa'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'd' },

 #   Immitative (like)
 'ngawdh'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'i' },
 'ngalbedh'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'd',
		     'c' => 'i' },
 'ngoemudh'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'exclusive',
		     'n' => 'p',
		     'c' => 'i' },

 'ngoebadh'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'd',
		     'c' => 'i' },
 'ngalpadh'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     '#' => 'inclusive',
		     'n' => 'p',
		     'c' => 'i' },

 'nginudh'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'i' },
 'ngipedh'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'i' },
 'ngithamudh'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'i' },

 'nanudh'	=> { 'x' => 'her',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'g' => 'f',
		     'c' => 'i' },
 'nungudh'	=> { 'x' => 'him',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'i' },
 'palamudh'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 'i' },
 'thanmudh'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'i' },
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 # Key verbs
 # Vocabulary
);
}

1;

