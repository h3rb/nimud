#! /usr/bin/perl

# vi: ts=8 sw=8 sts=8

# Extract headwords from Linguaphile "Tongues" language modules

use strict;
use lib ".";

require TongueParser;

my $p = new TongueParser;

local *fh = \*STDIN;

# Filename on command line?
if ($ARGV[0]) {
	print "** opening $ARGV[0]\n";
	open fh, $ARGV[0] or die "** File not found";
}

$p->init(\*fh,
	undef,
	\&section_h,
	undef,
	undef,
	\&head_h,
	undef);

my $in_vocab = 0;

$p->parse();

exit;

sub section_h {
	my $section = shift;

	$in_vocab = 1 if ($section eq 'vocab');
}

sub head_h {
	my ($head, $is_comment, $indent) = @_;

	$in_vocab || return;
	$indent < 2 || return;
	
	$head =~ s/\\'/'/g;
	print "$head\n";
}

