#! /usr/bin/perl

# Convert Glenn Slayden's dictionary file into linguaphile perl source code

use strict;

my $entry;

my %partofspeech = (
	'n'	=> 'n',		# noun
	'v'	=> 'v',		# verb
	'a'	=> 'a',		# adjective
	'r'	=> 'pro',	# pronoun
	'h'	=> 'interj',	# interjection
	'd'	=> 'adv',	# adverb
	'e'	=> 'p',		# preposition
	'c'	=> 'conj',	# conjunction
	'p'	=> 'n',		# proper noun
);

while (<>) {
	next if /^#/;
	my $first_e = 1;
	while (/\|([TDEPSRC])([^|\r]+)/g) {
		if ($1 eq 'T') {
			emit($entry);
			$entry->{thai} = $2;
			#@$entry->{def} = ();
			$entry->{t} = undef;
			$entry->{x} = undef;
			$entry->{comment} = '';
		} elsif ($1 eq 'D') {
			# push(@$entry->{def}, $2);
		} elsif ($1 eq 'E') {
			if ($first_e) {
				$first_e = 0;
				$entry->{x} = lc($2);
			} else {
				$entry->{comment} && ( $entry->{comment} .= ', ' );
				$entry->{comment} .= lc($2);
			}
		} elsif ($1 eq 'P') {
			$entry->{t} = $2;
		} else {
			#print "'$1' '$2'\n";
		}
	}
}

emit($entry);

exit;

sub emit {
	my $entry = shift;

	if ($entry->{thai}) {
		if ($entry->{x}) {
			my $t = $entry->{t};
			$t = $partofspeech{$t} if $t;
			$entry->{t} = $t if $t;

			$entry->{x} =~ s/'/\\'/;
			print " '$entry->{thai}'\t\t=> { 'x' => '$entry->{x}'";
			print ' }' unless $entry->{t};
			print ',';
			$entry->{comment} && print "\t# $entry->{comment}";
			$entry->{t} && print "\n\t\t     't' => '$entry->{t}' },";
			print "\n";
		} else {
			print " # $entry->{thai} no E, but there is D...\n";
		}
	}
}
