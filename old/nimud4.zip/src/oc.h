/*
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___| G| v4.0   Version 4.0 GOLD EDITION      *
* |  /   \  __|  \__/  |  | |  |     O|        documentation release         *
* |       ||  |        |  \_|  | ()  L|        Hallow's Eve 1999             *
* |    |  ||  |  |__|  |       |     D|                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 */

DECLARE_DO_FUN( do_aedit         );
DECLARE_DO_FUN( do_redit         );
DECLARE_DO_FUN( do_oedit         );
DECLARE_DO_FUN( do_medit         );
DECLARE_DO_FUN( do_sedit         );

extern  MOB_INDEX_DATA *        mob_index_hash  [MAX_KEY_HASH];
extern  OBJ_INDEX_DATA *        obj_index_hash  [MAX_KEY_HASH];
extern  ROOM_INDEX_DATA *       room_index_hash [MAX_KEY_HASH];


extern  SHOP_DATA *             shop_first;
extern  SHOP_DATA *             shop_last;

#define         AREA_NONE       0
#define         AREA_CHANGED    1
#define         AREA_ADDED      2
#define         AREA_STATIC     4

#define         SEX_NONE        4

#define         ROOM_NONE       0

#define         EX_NONE         0

#define         ITEM_NONE      -1

#define         EXTRA_NONE      0

#define         ITEM_WEAR_NONE  0

#define         ACT_NONE        0

#define         AFFECT_NONE     0


