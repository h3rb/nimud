/*
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___| G| v4.0   Version 4.0 GOLD EDITION      *
* |  /   \  __|  \__/  |  | |  |     O|        documentation release         *
* |       ||  |        |  \_|  | ()  L|        Hallow's Eve 1999             *
* |    |  ||  |  |__|  |       |     D|                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
*/

/*
 * Connected state for a channel.
 */
#define CON_PLAYING                       0
#define CON_SHOW_TITLE                   1
#define CON_READ_MOTD                    2

#define CON_LOGIN_MENU                  10
#define CON_DOC_MENU                    20

#define CON_GEN_MENU                    30
#define CON_GEN_RACES                   31
#define CON_GEN_SEX                     32
#define CON_GEN_NAME                    33

/*
 * Connected state for a channel.
 */
#define CON_PLAYING			 0
#define CON_SHOW_TITLE                   1
#define CON_READ_MOTD                    2

#define CON_LOGIN_MENU                  10
#define CON_DOC_MENU                    20

#define CON_GEN_MENU                    30
#define CON_GEN_RACES                   31
#define CON_GEN_SEX                     32
#define CON_GEN_NAME                    33
#define CON_GEN_SHORT                   34
#define CON_GEN_KEYWORDS                35
#define CON_GEN_LONG                    36
#define CON_GEN_DESCRIPTION             37
#define CON_GEN_EMAIL                   38
#define CON_GEN_SUBMIT                  39
#define CON_GEN_RACES_2                 40

#define CON_STAT_MENU                   50
#define CON_STAT_STR                    51
#define CON_STAT_INT                    52
#define CON_STAT_WIS                    53
#define CON_STAT_DEX                    54
#define CON_STAT_CON                    55
#define CON_STAT_AGE                    56
#define CON_STAT_SIZE                   57

#define CON_CONFIRM_NEW_NAME            60
#define CON_GET_NEW_PASSWORD            61
#define CON_CONFIRM_NEW_PASSWORD        62
#define CON_SHOW_INTRO                  63
#define CON_CHAR_GEN_NAME               64
#define CON_CHAR_GEN_EMAIL              65
#define CON_CHAR_GEN_RACE               66
#define CON_CHAR_GEN_RACE2              67
#define CON_CHAR_GEN_SEX                68
#define CON_CHAR_GEN_SHORT              69
#define CON_CHAR_GEN_LONG               70
#define CON_CHAR_GEN_KEYWORDS           71

#define CON_GET_NAME                    80
#define CON_GET_OLD_PASSWORD            81

#define CON_GET_NAME_NOLOGIN            82
#define CON_GET_OLD_PASSWORD_NOLOGIN    83

#define CON_WRITE_APPLICATION           86
#define CON_SEND_APPLICATION            87
#define CON_CONFIRM_RESUBMIT            88

#define CON_AEDITOR                     -1
#define CON_REDITOR                     -2
#define CON_MEDITOR                     -3
#define CON_OEDITOR                     -4
#define CON_SEDITOR                     -5

#define CONNECTED(d)        ( d->connected <= CON_PLAYING )

