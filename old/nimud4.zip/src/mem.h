/*
******************************************************************************
* Locke's   __ -based on merc v2.2-____        NIM Server Software           *
* ___ ___  (__)__    __ __   __ ___| G| v4.0   Version 4.0 GOLD EDITION      *
* |  /   \  __|  \__/  |  | |  |     O|        documentation release         *
* |       ||  |        |  \_|  | ()  L|        Hallow's Eve 1999             *
* |    |  ||  |  |__|  |       |     D|                                      *
* |____|__|___|__|  |__|\___/__|______|        http://www.nimud.org/nimud    *
*   n a m e l e s s i n c a r n a t e          dedicated to chris cool       *
******************************************************************************
 */

extern int         top_affect;
extern int         top_area;
extern int         top_ed;
extern int         top_exit;
extern int         top_help;
extern int         top_mob_index;
extern int         top_obj_index;
extern int         top_reset;
extern int         top_room;
extern int         top_shop;
extern int         top_variable;
extern int         top_trigger;
extern int         top_script;

extern int         top_vnum_script;
extern int         top_vnum_mob;
extern int         top_vnum_obj;
extern int         top_vnum_room;

