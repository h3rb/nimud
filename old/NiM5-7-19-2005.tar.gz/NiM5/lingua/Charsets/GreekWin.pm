# vi: ts=4 sw=4

package Charsets::GreekWin;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw(letters_upper letters_lower);
$VERSION	= 0.00;

# Character set Windows Greek code page 1253
# not ISO 8859-7

my $upper = "A-Z\xa2\xb8-\xba\xbc\xbe-\xbf\xc1-\xd1\xd3-\xdb";
my $lower = "a-z\xc0\xdc-\xfe";

my (%_from_utf8, %_to_utf8);

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters_upper {
	return '[' . $upper . ']';
}

sub letters_lower {
	return '[' . $lower . ']';
} 

sub letters {
	return '[' . $upper . $lower . ']';
}

# One uppercase Sigma maps to two lower cases
# Lowercase Iota with diaresis and acute maps to uppercase with only diaresis

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z\xa2\xb8-\xba\xbc\xbe-\xbf\xc1-\xd1\xd3-\xdb/a-z\xdc\xdd-\xdf\xfc\xfd-\xfe\xe1-\xf1\xf3-\xfb/;
	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z\xc0\xdc-\xe0\xe1-\xfb/A-Z\xda\xa2\xb8-\xba\xbc\xfb\xc1-\xd1\xd1\xd2-\xdb/;

	return $str;
}

sub to_utf8 {
	my ($self, $input) = @_;
	my $output = '';

	while (($input =~ /(.|\n|\r)/g) ne undef) {
		my $c = $1;
		my $o = ord($c);
		my $u = $_to_utf8{$o};
		$output .= $u ? $u : $c;
	}
	return $output;
}

sub from_utf8 {
	my ($self, $input) = @_;
	my $output = '';
	my $state = 0;
	my $len;
	my $u;

	while (($input =~ /(.|\n|\r)/g) ne undef) {
		my $c = $1;
		my $o = ord($c);
		if ($state == 0) {
			if ($o >= 0xfe) {
				# Invalid initial byte
				$output .= '?';
				print STDERR "** invalid initial byte\n";
			} elsif ($o >= 0xc0) {
				$state = 1;
				if ($o >= 0xfc) {
					$len = 6;
				} elsif ($o >= 0xf8) {
					$len = 5;
				} elsif ($o >= 0xf0) {
					$len = 4;
				} elsif ($o >= 0xe0) {
					$len = 3;
				} else {
					$len = 2;
				}
				$u = $o & ((1 << (7 - $len)) - 1);
			} else {
				$output .= $c;
			}
		} else {
			if (($o & 0xc0) != 0x80) {
				# Invalid trailing byte
				$output .= '?';
				print STDERR "** invalid trailing byte\n";
				$state = 0;
			} else {
				$u <<= 6;
				$u += ($o & 0x3f);
				--$len;
				if ($len <= 1) {
					$state = 0;
					my $a = $_from_utf8{$u};
					if ($a) {
						$output .= chr($a);
					} else {
						$output .= '?';
					}
				}
			}
		}
	}
	return $output;
}

sub BEGIN {
	$_from_utf8{0x20AC} = 0x80;
	$_from_utf8{0x201A} = 0x82;
	$_from_utf8{0x0192} = 0x83;
	$_from_utf8{0x201E} = 0x84;
	$_from_utf8{0x2026} = 0x85;
	$_from_utf8{0x2020} = 0x86;
	$_from_utf8{0x2021} = 0x87;
	$_from_utf8{0x2030} = 0x89;
	$_from_utf8{0x2039} = 0x8B;
	$_from_utf8{0x2018} = 0x91;
	$_from_utf8{0x2019} = 0x92;
	$_from_utf8{0x201C} = 0x93;
	$_from_utf8{0x201D} = 0x94;
	$_from_utf8{0x2022} = 0x95;
	$_from_utf8{0x2013} = 0x96;
	$_from_utf8{0x2014} = 0x97;
	$_from_utf8{0x2122} = 0x99;
	$_from_utf8{0x203A} = 0x9B;
	$_from_utf8{0x00A0} = 0xA0;
	$_from_utf8{0x0385} = 0xA1;
	$_from_utf8{0x0386} = 0xA2;
	$_from_utf8{0x00A3} = 0xA3;
	$_from_utf8{0x00A4} = 0xA4;
	$_from_utf8{0x00A5} = 0xA5;
	$_from_utf8{0x00A6} = 0xA6;
	$_from_utf8{0x00A7} = 0xA7;
	$_from_utf8{0x00A8} = 0xA8;
	$_from_utf8{0x00A9} = 0xA9;
	$_from_utf8{0x00AB} = 0xAB;
	$_from_utf8{0x00AC} = 0xAC;
	$_from_utf8{0x00AD} = 0xAD;
	$_from_utf8{0x00AE} = 0xAE;
	$_from_utf8{0x2015} = 0xAF;
	$_from_utf8{0x00B0} = 0xB0;
	$_from_utf8{0x00B1} = 0xB1;
	$_from_utf8{0x00B2} = 0xB2;
	$_from_utf8{0x00B3} = 0xB3;
	$_from_utf8{0x0384} = 0xB4;
	$_from_utf8{0x00B5} = 0xB5;
	$_from_utf8{0x00B6} = 0xB6;
	$_from_utf8{0x00B7} = 0xB7;
	$_from_utf8{0x0388} = 0xB8;
	$_from_utf8{0x0389} = 0xB9;
	$_from_utf8{0x038A} = 0xBA;
	$_from_utf8{0x00BB} = 0xBB;
	$_from_utf8{0x038C} = 0xBC;
	$_from_utf8{0x00BD} = 0xBD;
	$_from_utf8{0x038E} = 0xBE;
	$_from_utf8{0x038F} = 0xBF;
	$_from_utf8{0x0390} = 0xC0;
	$_from_utf8{0x0391} = 0xC1;
	$_from_utf8{0x0392} = 0xC2;
	$_from_utf8{0x0393} = 0xC3;
	$_from_utf8{0x0394} = 0xC4;
	$_from_utf8{0x0395} = 0xC5;
	$_from_utf8{0x0396} = 0xC6;
	$_from_utf8{0x0397} = 0xC7;
	$_from_utf8{0x0398} = 0xC8;
	$_from_utf8{0x0399} = 0xC9;
	$_from_utf8{0x039A} = 0xCA;
	$_from_utf8{0x039B} = 0xCB;
	$_from_utf8{0x039C} = 0xCC;
	$_from_utf8{0x039D} = 0xCD;
	$_from_utf8{0x039E} = 0xCE;
	$_from_utf8{0x039F} = 0xCF;
	$_from_utf8{0x03A0} = 0xD0;
	$_from_utf8{0x03A1} = 0xD1;
	$_from_utf8{0x03A3} = 0xD3;
	$_from_utf8{0x03A4} = 0xD4;
	$_from_utf8{0x03A5} = 0xD5;
	$_from_utf8{0x03A6} = 0xD6;
	$_from_utf8{0x03A7} = 0xD7;
	$_from_utf8{0x03A8} = 0xD8;
	$_from_utf8{0x03A9} = 0xD9;
	$_from_utf8{0x03AA} = 0xDA;
	$_from_utf8{0x03AB} = 0xDB;
	$_from_utf8{0x03AC} = 0xDC;
	$_from_utf8{0x03AD} = 0xDD;
	$_from_utf8{0x03AE} = 0xDE;
	$_from_utf8{0x03AF} = 0xDF;
	$_from_utf8{0x03B0} = 0xE0;
	$_from_utf8{0x03B1} = 0xE1;
	$_from_utf8{0x03B2} = 0xE2;
	$_from_utf8{0x03B3} = 0xE3;
	$_from_utf8{0x03B4} = 0xE4;
	$_from_utf8{0x03B5} = 0xE5;
	$_from_utf8{0x03B6} = 0xE6;
	$_from_utf8{0x03B7} = 0xE7;
	$_from_utf8{0x03B8} = 0xE8;
	$_from_utf8{0x03B9} = 0xE9;
	$_from_utf8{0x03BA} = 0xEA;
	$_from_utf8{0x03BB} = 0xEB;
	$_from_utf8{0x03BC} = 0xEC;
	$_from_utf8{0x03BD} = 0xED;
	$_from_utf8{0x03BE} = 0xEE;
	$_from_utf8{0x03BF} = 0xEF;
	$_from_utf8{0x03C0} = 0xF0;
	$_from_utf8{0x03C1} = 0xF1;
	$_from_utf8{0x03C2} = 0xF2;
	$_from_utf8{0x03C3} = 0xF3;
	$_from_utf8{0x03C4} = 0xF4;
	$_from_utf8{0x03C5} = 0xF5;
	$_from_utf8{0x03C6} = 0xF6;
	$_from_utf8{0x03C7} = 0xF7;
	$_from_utf8{0x03C8} = 0xF8;
	$_from_utf8{0x03C9} = 0xF9;
	$_from_utf8{0x03CA} = 0xFA;
	$_from_utf8{0x03CB} = 0xFB;
	$_from_utf8{0x03CC} = 0xFC;
	$_from_utf8{0x03CD} = 0xFD;
	$_from_utf8{0x03CE} = 0xFE;
	$_to_utf8{0x80} = '€';
	$_to_utf8{0x82} = '‚';
	$_to_utf8{0x83} = 'ƒ';
	$_to_utf8{0x84} = '„';
	$_to_utf8{0x85} = '…';
	$_to_utf8{0x86} = '†';
	$_to_utf8{0x87} = '‡';
	$_to_utf8{0x89} = '‰';
	$_to_utf8{0x8B} = '‹';
	$_to_utf8{0x91} = '‘';
	$_to_utf8{0x92} = '’';
	$_to_utf8{0x93} = '“';
	$_to_utf8{0x94} = '”';
	$_to_utf8{0x95} = '•';
	$_to_utf8{0x96} = '–';
	$_to_utf8{0x97} = '—';
	$_to_utf8{0x99} = '™';
	$_to_utf8{0x9B} = '›';
	$_to_utf8{0xA0} = ' ';
	$_to_utf8{0xA1} = '΅';
	$_to_utf8{0xA2} = 'Ά';
	$_to_utf8{0xA3} = '£';
	$_to_utf8{0xA4} = '¤';
	$_to_utf8{0xA5} = '¥';
	$_to_utf8{0xA6} = '¦';
	$_to_utf8{0xA7} = '§';
	$_to_utf8{0xA8} = '¨';
	$_to_utf8{0xA9} = '©';
	$_to_utf8{0xAB} = '«';
	$_to_utf8{0xAC} = '¬';
	$_to_utf8{0xAD} = ' ';
	$_to_utf8{0xAE} = '®';
	$_to_utf8{0xAF} = '―';
	$_to_utf8{0xB0} = '°';
	$_to_utf8{0xB1} = '±';
	$_to_utf8{0xB2} = '²';
	$_to_utf8{0xB3} = '³';
	$_to_utf8{0xB4} = '΄';
	$_to_utf8{0xB5} = 'µ';
	$_to_utf8{0xB6} = '¶';
	$_to_utf8{0xB7} = '·';
	$_to_utf8{0xB8} = 'Έ';
	$_to_utf8{0xB9} = 'Ή';
	$_to_utf8{0xBA} = 'Ί';
	$_to_utf8{0xBB} = '»';
	$_to_utf8{0xBC} = 'Ό';
	$_to_utf8{0xBD} = '½';
	$_to_utf8{0xBE} = 'Ύ';
	$_to_utf8{0xBF} = 'Ώ';
	$_to_utf8{0xC0} = 'ΐ';
	$_to_utf8{0xC1} = 'Α';
	$_to_utf8{0xC2} = 'Β';
	$_to_utf8{0xC3} = 'Γ';
	$_to_utf8{0xC4} = 'Δ';
	$_to_utf8{0xC5} = 'Ε';
	$_to_utf8{0xC6} = 'Ζ';
	$_to_utf8{0xC7} = 'Η';
	$_to_utf8{0xC8} = 'Θ';
	$_to_utf8{0xC9} = 'Ι';
	$_to_utf8{0xCA} = 'Κ';
	$_to_utf8{0xCB} = 'Λ';
	$_to_utf8{0xCC} = 'Μ';
	$_to_utf8{0xCD} = 'Ν';
	$_to_utf8{0xCE} = 'Ξ';
	$_to_utf8{0xCF} = 'Ο';
	$_to_utf8{0xD0} = 'Π';
	$_to_utf8{0xD1} = 'Ρ';
	$_to_utf8{0xD3} = 'Σ';
	$_to_utf8{0xD4} = 'Τ';
	$_to_utf8{0xD5} = 'Υ';
	$_to_utf8{0xD6} = 'Φ';
	$_to_utf8{0xD7} = 'Χ';
	$_to_utf8{0xD8} = 'Ψ';
	$_to_utf8{0xD9} = 'Ω';
	$_to_utf8{0xDA} = 'Ϊ';
	$_to_utf8{0xDB} = 'Ϋ';
	$_to_utf8{0xDC} = 'ά';
	$_to_utf8{0xDD} = 'έ';
	$_to_utf8{0xDE} = 'ή';
	$_to_utf8{0xDF} = 'ί';
	$_to_utf8{0xE0} = 'ΰ';
	$_to_utf8{0xE1} = 'α';
	$_to_utf8{0xE2} = 'β';
	$_to_utf8{0xE3} = 'γ';
	$_to_utf8{0xE4} = 'δ';
	$_to_utf8{0xE5} = 'ε';
	$_to_utf8{0xE6} = 'ζ';
	$_to_utf8{0xE7} = 'η';
	$_to_utf8{0xE8} = 'θ';
	$_to_utf8{0xE9} = 'ι';
	$_to_utf8{0xEA} = 'κ';
	$_to_utf8{0xEB} = 'λ';
	$_to_utf8{0xEC} = 'μ';
	$_to_utf8{0xED} = 'ν';
	$_to_utf8{0xEE} = 'ξ';
	$_to_utf8{0xEF} = 'ο';
	$_to_utf8{0xF0} = 'π';
	$_to_utf8{0xF1} = 'ρ';
	$_to_utf8{0xF2} = 'ς';
	$_to_utf8{0xF3} = 'σ';
	$_to_utf8{0xF4} = 'τ';
	$_to_utf8{0xF5} = 'υ';
	$_to_utf8{0xF6} = 'φ';
	$_to_utf8{0xF7} = 'χ';
	$_to_utf8{0xF8} = 'ψ';
	$_to_utf8{0xF9} = 'ω';
	$_to_utf8{0xFA} = 'ϊ';
	$_to_utf8{0xFB} = 'ϋ';
	$_to_utf8{0xFC} = 'ό';
	$_to_utf8{0xFD} = 'ύ';
	$_to_utf8{0xFE} = 'ώ';
}

1;

