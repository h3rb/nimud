# vi: ts=4 sw=4

package Charsets::ISO_8859_2;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw(letters_upper letters_lower);
$VERSION	= 0.00;

# Character set ISO 8859-2
# not Windows Central European (code page 1250)
#
# Albanian 
# Bosnian 
# Croatian 
# Czech 
# English 
# Finnish 
# Hungarian 
# Irish 
# German 
# Polish 
# Romanian 
# Serbian (Latin transcription) 
# Slovak 
# Slovenian 
# Sorbian (Lusatian) 

my $upper = "A-Z\xa1\xa3\xa5-\xa6\xa9-\xac\xae-\xaf\xc0-\xd6\xd8-\xde";
my $lower = "a-z\xb1\xb3\xb5-\xb6\xb9-\xbc\xbe-\xbf\xe0-\xf6\xf8-\xfe";
my $invariant = "\xdf";

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters_upper {
	return '[' . $upper . ']';
}

sub letters_lower {
	return '[' . $lower . ']';
}

sub letters {
	return '[' . $upper . $lower . $invariant . ']';
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str = tr/A-Z\xa1\xa3\xa5-\xa6\xa9-\xac\xae-\xaf\xc0-\xd6\xd8-\xde/a-z\xb1\xb3\xb5-\xb6\xb9-\xbc\xbe-\xbf\xe0-\xf6\xf8-\xfe/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str = tr/a-z\xb1\xb3\xb5-\xb6\xb9-\xbc\xbe-\xbf\xe0-\xf6\xf8-\xfe/A-Z\xa1\xa3\xa5-\xa6\xa9-\xac\xae-\xaf\xc0-\xd6\xd8-\xde/;

	return $str;
}

sub BEGIN {
}

1;
