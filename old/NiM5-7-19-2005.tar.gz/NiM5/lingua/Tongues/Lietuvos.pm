# vi: ts=8 sw=8

package Tongues::Lietuvos;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Baltic CP1257 / ISO 8859-13 / Latin-7

# Alphabetical order
# A � B C � D E � � F G H I � Y J K L M N O P R S � T U � � V Z �
# a � b c � d e � � f g h i � y j k l m n o p r s � t u � � v z �

# These pages have slightly different alphabets listed:
# http://hot.ee/elu/Keel/zodynas.htm
# http://www.ask-group.co.uk/publish/lithuanianalph.htm
# I've used the hot.ee one above, with the other letters listed below.

# Extra characters (ISO & Windows)
# � E-caron? �
# � e-caron? �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::BalticWin;

$charset = new Charsets::BalticWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# Lietuvos to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 'de'	=> { 'x' => 'of',
	     't' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 'sekmadienis'	=> { 'x' => 'sunday' },
 'pirmadienis'	=> { 'x' => 'monday' },
 'antradienis'	=> { 'x' => 'tuesday' },
 'tre�iadienis'	=> { 'x' => 'wednesday' },
 'ketvirtadienis'	=> { 'x' => 'thursday' },
 'penktadienis'	=> { 'x' => 'friday' },
 '�e�tadienis'	=> { 'x' => 'saturday' },
 'sausio'	=> { 'x' => 'january' },
 'vasario'	=> { 'x' => 'february' },
 'kovo'		=> { 'x' => 'march' },
 'baland�io'	=> { 'x' => 'april' },
 'gegu��s'	=> { 'x' => 'may' },
 'bir�elio'	=> { 'x' => 'june' },
 'liepos'	=> { 'x' => 'july' },
 'rugpj��io'	=> { 'x' => 'august' },
 'rugs�jo'	=> { 'x' => 'september' },
 'spalio'	=> { 'x' => 'october' },
 'lapkri�io'	=> { 'x' => 'november' },
 'gruod�io'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 'straipsnis'	=> { 'x' => 'article',
		     't' => 'n' },
);
}

1;

