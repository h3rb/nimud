# vi: ts=4 sw=4 sts=4

package Charsets::BalticWin;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw(letters lowercase);
@EXPORT_OK	= qw(letters_upper letters_lower);
$VERSION	= 0.00;

# Character set Windows Baltic code page 1257

# A � B C � D E � F G � H I � J K � L � M N O P R S � T U � V Z �

my $upper = 'A-Z���-��-�';
my $lower = 'a-z���-��-�';
my $invariant = '�';

my (%_from_utf8, %_to_utf8);

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub letters_upper {
	return '[' . $upper . ']';
}

sub letters_lower {
	return '[' . $lower . ']';
} 

sub letters {
	return '[' . $upper . $lower . $invariant . ']';
}

sub lowercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/A-Z���-��-�/a-z���-��-�/;

	return $str;
}

sub uppercase {
	my $self = shift;
	my $str = shift;

	$str =~ tr/a-z���-��-�/A-Z���-��-�/;

	return $str;
}

sub to_utf8 {
	my ($self, $input) = @_;
	my $output = '';

	while ($input =~ /(.|\r|\n)/g) {
		my $c = $1;
		my $o = ord($c);
		my $u = $_to_utf8{$o};
		$output .= $u ? $u : $c;
	}
	return $output;
}

sub from_utf8 {
	my ($self, $input) = @_;
	my $output = '';
	my $state = 0;
	my $len;
	my $u;

	while ($input =~ /(.|\r|\n)/g) {
		my $c = $1;
		my $o = ord($c);
		if ($state == 0) {
			if ($o >= 0xfe) {
				# Invalid initial byte
				$output .= '?';
			} elsif ($o >= 0xc0) {
				$state = 1;
				if ($o >= 0xfc) {
					$len = 6;
				} elsif ($o >= 0xf8) {
					$len = 5;
				} elsif ($o >= 0xf0) {
					$len = 4;
				} elsif ($o >= 0xe0) {
					$len = 3;
				} else {
					$len = 2;
				}
				$u = $o & ((1 << (7 - $len)) - 1);
			} else {
				$output .= $c;
			}
		} else {
			if (($o & 0xc0) != 0x80) {
				# Invalid trailing byte
				$output .= '?';
				$state = 0;
			} else {
				$u <<= 6;
				$u += ($o & 0x3f);
				--$len;
				if ($len <= 1) {
					$state = 0;
					my $a = $_from_utf8{$u};
					if ($a) {
						$output .= chr($a);
					} else {
						$output .= '?';
					}
				}
			}
		}
	}
	return $output;
}

sub BEGIN {
	$_from_utf8{0x20AC} = 0x80;
	$_from_utf8{0x201A} = 0x82;
	$_from_utf8{0x201E} = 0x84;
	$_from_utf8{0x2026} = 0x85;
	$_from_utf8{0x2020} = 0x86;
	$_from_utf8{0x2021} = 0x87;
	$_from_utf8{0x2030} = 0x89;
	$_from_utf8{0x2039} = 0x8B;
	$_from_utf8{0x00A8} = 0x8D;
	$_from_utf8{0x02C7} = 0x8E;
	$_from_utf8{0x00B8} = 0x8F;
	$_from_utf8{0x2018} = 0x91;
	$_from_utf8{0x2019} = 0x92;
	$_from_utf8{0x201C} = 0x93;
	$_from_utf8{0x201D} = 0x94;
	$_from_utf8{0x2022} = 0x95;
	$_from_utf8{0x2013} = 0x96;
	$_from_utf8{0x2014} = 0x97;
	$_from_utf8{0x2122} = 0x99;
	$_from_utf8{0x203A} = 0x9B;
	$_from_utf8{0x00AF} = 0x9D;
	$_from_utf8{0x02DB} = 0x9E;
	$_from_utf8{0x00A0} = 0xA0;
	$_from_utf8{0x00A2} = 0xA2;
	$_from_utf8{0x00A3} = 0xA3;
	$_from_utf8{0x00A4} = 0xA4;
	$_from_utf8{0x00A6} = 0xA6;
	$_from_utf8{0x00A7} = 0xA7;
	$_from_utf8{0x00D8} = 0xA8;
	$_from_utf8{0x00A9} = 0xA9;
	$_from_utf8{0x0156} = 0xAA;
	$_from_utf8{0x00AB} = 0xAB;
	$_from_utf8{0x00AC} = 0xAC;
	$_from_utf8{0x00AD} = 0xAD;
	$_from_utf8{0x00AE} = 0xAE;
	$_from_utf8{0x00C6} = 0xAF;
	$_from_utf8{0x00B0} = 0xB0;
	$_from_utf8{0x00B1} = 0xB1;
	$_from_utf8{0x00B2} = 0xB2;
	$_from_utf8{0x00B3} = 0xB3;
	$_from_utf8{0x00B4} = 0xB4;
	$_from_utf8{0x00B5} = 0xB5;
	$_from_utf8{0x00B6} = 0xB6;
	$_from_utf8{0x00B7} = 0xB7;
	$_from_utf8{0x00F8} = 0xB8;
	$_from_utf8{0x00B9} = 0xB9;
	$_from_utf8{0x0157} = 0xBA;
	$_from_utf8{0x00BB} = 0xBB;
	$_from_utf8{0x00BC} = 0xBC;
	$_from_utf8{0x00BD} = 0xBD;
	$_from_utf8{0x00BE} = 0xBE;
	$_from_utf8{0x00E6} = 0xBF;
	$_from_utf8{0x0104} = 0xC0;
	$_from_utf8{0x012E} = 0xC1;
	$_from_utf8{0x0100} = 0xC2;
	$_from_utf8{0x0106} = 0xC3;
	$_from_utf8{0x00C4} = 0xC4;
	$_from_utf8{0x00C5} = 0xC5;
	$_from_utf8{0x0118} = 0xC6;
	$_from_utf8{0x0112} = 0xC7;
	$_from_utf8{0x010C} = 0xC8;
	$_from_utf8{0x00C9} = 0xC9;
	$_from_utf8{0x0179} = 0xCA;
	$_from_utf8{0x0116} = 0xCB;
	$_from_utf8{0x0122} = 0xCC;
	$_from_utf8{0x0136} = 0xCD;
	$_from_utf8{0x012A} = 0xCE;
	$_from_utf8{0x013B} = 0xCF;
	$_from_utf8{0x0160} = 0xD0;
	$_from_utf8{0x0143} = 0xD1;
	$_from_utf8{0x0145} = 0xD2;
	$_from_utf8{0x00D3} = 0xD3;
	$_from_utf8{0x014C} = 0xD4;
	$_from_utf8{0x00D5} = 0xD5;
	$_from_utf8{0x00D6} = 0xD6;
	$_from_utf8{0x00D7} = 0xD7;
	$_from_utf8{0x0172} = 0xD8;
	$_from_utf8{0x0141} = 0xD9;
	$_from_utf8{0x015A} = 0xDA;
	$_from_utf8{0x016A} = 0xDB;
	$_from_utf8{0x00DC} = 0xDC;
	$_from_utf8{0x017B} = 0xDD;
	$_from_utf8{0x017D} = 0xDE;
	$_from_utf8{0x00DF} = 0xDF;
	$_from_utf8{0x0105} = 0xE0;
	$_from_utf8{0x012F} = 0xE1;
	$_from_utf8{0x0101} = 0xE2;
	$_from_utf8{0x0107} = 0xE3;
	$_from_utf8{0x00E4} = 0xE4;
	$_from_utf8{0x00E5} = 0xE5;
	$_from_utf8{0x0119} = 0xE6;
	$_from_utf8{0x0113} = 0xE7;
	$_from_utf8{0x010D} = 0xE8;
	$_from_utf8{0x00E9} = 0xE9;
	$_from_utf8{0x017A} = 0xEA;
	$_from_utf8{0x0117} = 0xEB;
	$_from_utf8{0x0123} = 0xEC;
	$_from_utf8{0x0137} = 0xED;
	$_from_utf8{0x012B} = 0xEE;
	$_from_utf8{0x013C} = 0xEF;
	$_from_utf8{0x0161} = 0xF0;
	$_from_utf8{0x0144} = 0xF1;
	$_from_utf8{0x0146} = 0xF2;
	$_from_utf8{0x00F3} = 0xF3;
	$_from_utf8{0x014D} = 0xF4;
	$_from_utf8{0x00F5} = 0xF5;
	$_from_utf8{0x00F6} = 0xF6;
	$_from_utf8{0x00F7} = 0xF7;
	$_from_utf8{0x0173} = 0xF8;
	$_from_utf8{0x0142} = 0xF9;
	$_from_utf8{0x015B} = 0xFA;
	$_from_utf8{0x016B} = 0xFB;
	$_from_utf8{0x00FC} = 0xFC;
	$_from_utf8{0x017C} = 0xFD;
	$_from_utf8{0x017E} = 0xFE;
	$_from_utf8{0x02D9} = 0xFF;
	$_to_utf8{0x80} = '€';
	$_to_utf8{0x82} = '‚';
	$_to_utf8{0x84} = '„';
	$_to_utf8{0x85} = '…';
	$_to_utf8{0x86} = '†';
	$_to_utf8{0x87} = '‡';
	$_to_utf8{0x89} = '‰';
	$_to_utf8{0x8B} = '‹';
	$_to_utf8{0x8D} = '¨';
	$_to_utf8{0x8E} = 'ˇ';
	$_to_utf8{0x8F} = '¸';
	$_to_utf8{0x91} = '‘';
	$_to_utf8{0x92} = '’';
	$_to_utf8{0x93} = '“';
	$_to_utf8{0x94} = '”';
	$_to_utf8{0x95} = '•';
	$_to_utf8{0x96} = '–';
	$_to_utf8{0x97} = '—';
	$_to_utf8{0x99} = '™';
	$_to_utf8{0x9B} = '›';
	$_to_utf8{0x9D} = '¯';
	$_to_utf8{0x9E} = '˛';
	$_to_utf8{0xA0} = ' ';
	$_to_utf8{0xA2} = '¢';
	$_to_utf8{0xA3} = '£';
	$_to_utf8{0xA4} = '¤';
	$_to_utf8{0xA6} = '¦';
	$_to_utf8{0xA7} = '§';
	$_to_utf8{0xA8} = 'Ø';
	$_to_utf8{0xA9} = '©';
	$_to_utf8{0xAA} = 'Ŗ';
	$_to_utf8{0xAB} = '«';
	$_to_utf8{0xAC} = '¬';
	$_to_utf8{0xAD} = ' ';
	$_to_utf8{0xAE} = '®';
	$_to_utf8{0xAF} = 'Æ';
	$_to_utf8{0xB0} = '°';
	$_to_utf8{0xB1} = '±';
	$_to_utf8{0xB2} = '²';
	$_to_utf8{0xB3} = '³';
	$_to_utf8{0xB4} = '´';
	$_to_utf8{0xB5} = 'µ';
	$_to_utf8{0xB6} = '¶';
	$_to_utf8{0xB7} = '·';
	$_to_utf8{0xB8} = 'ø';
	$_to_utf8{0xB9} = '¹';
	$_to_utf8{0xBA} = 'ŗ';
	$_to_utf8{0xBB} = '»';
	$_to_utf8{0xBC} = '¼';
	$_to_utf8{0xBD} = '½';
	$_to_utf8{0xBE} = '¾';
	$_to_utf8{0xBF} = 'æ';
	$_to_utf8{0xC0} = 'Ą';
	$_to_utf8{0xC1} = 'Į';
	$_to_utf8{0xC2} = 'Ā';
	$_to_utf8{0xC3} = 'Ć';
	$_to_utf8{0xC4} = 'Ä';
	$_to_utf8{0xC5} = 'Å';
	$_to_utf8{0xC6} = 'Ę';
	$_to_utf8{0xC7} = 'Ē';
	$_to_utf8{0xC8} = 'Č';
	$_to_utf8{0xC9} = 'É';
	$_to_utf8{0xCA} = 'Ź';
	$_to_utf8{0xCB} = 'Ė';
	$_to_utf8{0xCC} = 'Ģ';
	$_to_utf8{0xCD} = 'Ķ';
	$_to_utf8{0xCE} = 'Ī';
	$_to_utf8{0xCF} = 'Ļ';
	$_to_utf8{0xD0} = 'Š';
	$_to_utf8{0xD1} = 'Ń';
	$_to_utf8{0xD2} = 'Ņ';
	$_to_utf8{0xD3} = 'Ó';
	$_to_utf8{0xD4} = 'Ō';
	$_to_utf8{0xD5} = 'Õ';
	$_to_utf8{0xD6} = 'Ö';
	$_to_utf8{0xD7} = '×';
	$_to_utf8{0xD8} = 'Ų';
	$_to_utf8{0xD9} = 'Ł';
	$_to_utf8{0xDA} = 'Ŕ';
	$_to_utf8{0xDB} = 'Ū';
	$_to_utf8{0xDC} = 'Ü';
	$_to_utf8{0xDD} = 'Ż';
	$_to_utf8{0xDE} = 'Ž';
	$_to_utf8{0xDF} = 'ß';
	$_to_utf8{0xE0} = 'ą';
	$_to_utf8{0xE1} = 'į';
	$_to_utf8{0xE2} = 'ā';
	$_to_utf8{0xE3} = 'ć';
	$_to_utf8{0xE4} = 'ä';
	$_to_utf8{0xE5} = 'å';
	$_to_utf8{0xE6} = 'ę';
	$_to_utf8{0xE7} = 'ē';
	$_to_utf8{0xE8} = 'č';
	$_to_utf8{0xE9} = 'é';
	$_to_utf8{0xEA} = 'ź';
	$_to_utf8{0xEB} = 'ė';
	$_to_utf8{0xEC} = 'ģ';
	$_to_utf8{0xED} = 'ķ';
	$_to_utf8{0xEE} = 'ī';
	$_to_utf8{0xEF} = 'ļ';
	$_to_utf8{0xF0} = 'š';
	$_to_utf8{0xF1} = 'ń';
	$_to_utf8{0xF2} = 'ņ';
	$_to_utf8{0xF3} = 'ó';
	$_to_utf8{0xF4} = 'ō';
	$_to_utf8{0xF5} = 'õ';
	$_to_utf8{0xF6} = 'ö';
	$_to_utf8{0xF7} = '÷';
	$_to_utf8{0xF8} = 'ų';
	$_to_utf8{0xF9} = 'ł';
	$_to_utf8{0xFA} = 'ś';
	$_to_utf8{0xFB} = 'ū';
	$_to_utf8{0xFC} = 'ü';
	$_to_utf8{0xFD} = 'ż';
	$_to_utf8{0xFE} = 'ž';
	$_to_utf8{0xFF} = '˙';
}

1;
