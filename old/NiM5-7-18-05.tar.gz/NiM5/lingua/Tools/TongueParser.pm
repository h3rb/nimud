# vi: ts=8 sw=8 sts=8
package TongueParser;

# Parser for Linguaphile "Tongues" language modules

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw();
@EXPORT_OK	= qw();
$VERSION	= 0.00;

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub init {
	my $self = shift;
	$self->{fh} = shift;
	$self->{comment_h} = shift;
	$self->{section_h} = shift;
	$self->{dict_start_h} = shift;
	$self->{dict_end_h} = shift;
	$self->{head_h} = shift;
	$self->{entry_h} = shift;

	return 1;
}

sub parse {
	my $self = shift;
	local *fh = $self->{fh};

	# Look for start of dictionary
	while (<fh>) {
		if (/^# (([A-Z][a-z]+)(([A-Z][a-z]+))*) to English dictionary/) {
			$self->parse_dict();
			return;
		}
	}
}

sub parse_dict {
	my $self = shift;
	local *fh = $self->{fh};
	my %entry;

	<fh>;	# %dictionary = (
	$self->{dict_start_h}() if ($self->{dict_start_h});

	while (<fh>) {
		last if (/^\s*\);\s*$/);

		# start of general vocab section?
		$self->{section_h}('vocab') if (/^ # Vocabulary$/ && $self->{section_h});

		# skip comment lines
		next if (/^ *#/);
		
		# skip blank lines
		next if (/^\s*$/);

		if (/^(#?)(\s+)'(([^']|\\')*)'(\s*)=> { '([^']+)' => '(([^']|\\')*)'( })?,(\s+# (.*))?/) {
			# $1 comment?
			# $2 ws
			# $3 headword
			# $5 ws
			# $6 field
			# $7 value
			# $9 end brace?
			# $10 comment?
			$self->{head_h}($3, $1 ? 1 : 0, length($2)) if ($self->{head_h});
			$self->{entry_h}($6, $7) if ($self->{entry_h});
			next if $9 eq ' }';
			while (<fh>) { # {
				if (/^(\s*)(#?)(\s*)'([^']+)' => '(([^']|\\')*)'( })?,(\s+# (.*))?/) {
					# $1 ws?
					# $2 comment?
					# $3 ws
					# $4 field
					# $5 value
					# $7 end brace?
					# $8 comment?
					#print "$_";
					$self->{entry_h}($4, $5) if ($self->{entry_h});
					last if $7;
				}
				else
				{
					print STDERR "** error in entry: $_";
					exit;
				}
			}
		} else {
			print STDERR "** error in head: $_";
			exit;
		}
	}
	$self->{dict_end_h}() if ($self->{dict_end_h});
}

sub BEGIN {
}

1;
