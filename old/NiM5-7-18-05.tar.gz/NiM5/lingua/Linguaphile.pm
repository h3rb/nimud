# vi: ts=4 sw=4 sts=4
package Linguaphile;

require 5.002;
use strict;
use lib ".";
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use Exporter   ();
# set the version for version checking
@ISA		= qw(Exporter);
@EXPORT		= qw();
@EXPORT_OK	= qw();
$VERSION	= 0.00;

my $default_src_lang = 'en';
my $default_dst_lang = 'es';

# Constants for using grammar array
my ($G_CONJ_PAT, $G_ROOT_END, $G_PREFIX, $G_POSTFIX, $G_TYPE) = (0, 1, 2, 3, 4);

my $letters;
my $digits  = '[0-9]';

my %langmap;
$langmap{AER} = 'arrernte';
$langmap{af} = 'afrikaans';		# afr;AFK
$langmap{ah} = 'amharic';		# amh;AMH
$langmap{ALH} = 'alawa';
$langmap{ar} = 'arabic';		# ara;ABV
$langmap{ARE} = 'arrarnta';		# western; cf arernte/AER above
$langmap{as} = 'assamese';		# asm;ASM
$langmap{az} = 'azerbaijani';	# aze;AZE;AZB
$langmap{ban} = 'bali';			# BZC
$langmap{be} = 'belarusian';	# bel;RUW
$langmap{bg} = 'bulgarian';		# bul;BLG
$langmap{bi} = 'bislama';		# bis;BCY
$langmap{bn} = 'bengali';		# ben;BNG
$langmap{bo} = 'tibetan';		# tib/bod;TIC
$langmap{bs} = 'bosnian';		# bos;SRC
$langmap{ca} = 'catalan';		# cat;CLN
$langmap{ce} = 'chechen';		# che;CJC
$langmap{cs} = 'czech';			# ces/cze;CZC
$langmap{cy} = 'welsh';			# cym/wel;WLS
$langmap{da} = 'danish';		# dan;DNS
$langmap{de} = 'german';		# deu/ger;GER
$langmap{el} = 'greek';			# ell/gre;GRK
$langmap{en} = 'english';		# eng;ENG
$langmap{eo} = 'esperanto';		# epo;ESP
$langmap{es} = 'spanish';		# esl/spa;SPN
$langmap{et} = 'estonian';		# est;EST
$langmap{eu} = 'basque';		# baq/eus;BSQ
$langmap{fa} = 'farsi';			# per/fas;PES
$langmap{fi} = 'finnish';		# fin;FIN
$langmap{fj} = 'fijian';		# fij;FJI
$langmap{fo} = 'faroese';		# fao;FAE
$langmap{fr} = 'french';		# fra/fre;FRN
$langmap{ga} = 'irish';			# gai/iri;GLI
$langmap{GBZ} = 'dari';			# From Iran/Afghanistan - needed by DARPA Babylon
$langmap{gl} = 'galician';		# glg;GLN
$langmap{grc} = 'ancient greek';	# GKO
$langmap{gu} = 'gujarati';		# guj;GJR
$langmap{haw} = 'hawaiian';		# HWI
$langmap{he} = 'hebrew';		# heb;HBR
$langmap{hi} = 'hindi';			# hin;HND
$langmap{hr} = 'croatian';		# scr/hrv; Serbo-Croatian is sh/scr;SRC
$langmap{hu} = 'hungarian';		# hun;HNG
$langmap{hy} = 'armenian';		# arm/hye;ARM
$langmap{ia} = 'interlingua';	# ina;INR
$langmap{id} = 'indonesian';	# ind;INZ
$langmap{is} = 'icelandic';		# ice/isl;ICE
$langmap{it} = 'italian';		# ita;ITN
$langmap{ja} = 'japanese';		# jpn;JPN
$langmap{jw} = 'javanese';		# jav;JAN
$langmap{ka} = 'georgian';		# geo/cat;GEO
$langmap{kk} = 'kazakh';		# kaz;KAZ
$langmap{kl} = 'inuktitut';		# kal;ESG
$langmap{km} = 'khmer';			# khm;KMR
$langmap{kn} = 'kannada';		# kan;KJV
$langmap{ko} = 'korean';		# kor;KKN
$langmap{ks} = 'kashmiri';		# kas;KSH
$langmap{ky} = 'kirghiz';		# kir;KDO
$langmap{KYL} = 'kabyle';
$langmap{la} = 'latin';			# lat;LTN
$langmap{lb} = 'luxembourgish';	# ltz;LUX
$langmap{lo} = 'lao';			# lao;NOL
$langmap{lt} = 'lithuanian';	# lit;LIT
$langmap{lv} = 'latvian';		# lav;LAT
$langmap{mi} = 'maori';			# mao/mri;MBF
$langmap{mk} = 'macedonian';	# mac/mkd;MKJ
$langmap{ml} = 'malayalam';		# mal;MJS
$langmap{mr} = 'marathi';		# mar;MRT
$langmap{ms} = 'malay';			# may/msa;MLI
$langmap{mn} = 'mongolian';		# mon;KHK;MVF
$langmap{mt} = 'maltese';		# mlt;MLS
$langmap{MWP} = 'kala lagaw ya';
$langmap{my} = 'myanmar';		# bur/mya;BMS
$langmap{ne} = 'nepali';		# nep;NEP
$langmap{nl} = 'dutch';			# dut/nla;DUT
$langmap{no} = 'norwegian';		# nor, Bokm�l="nb/nob", Nynorsk="nn/nno";NRR;NRN
$langmap{oc} = 'occitan';		# oci;GSC;PRV;...
$langmap{or} = 'oriya';			# ori;ORY
$langmap{pa} = 'punjabi';		# pan;PNJ
$langmap{PJT} = 'pitjantjatjara';
$langmap{pl} = 'polish';		# pol;PQL
$langmap{ps} = 'pashto';		# pus;PBT;PBU
$langmap{pt} = 'portuguese';	# por;POR
$langmap{rm} = 'romansch';		# roh;RHE
$langmap{ro} = 'romanian';		# ron/rum;RUM
$langmap{ROP} = 'kriol';
$langmap{ru} = 'russian';		# rus;RUS
$langmap{sa} = 'sanskrit';		# san;SKT
$langmap{se} = 'saami';			# sme;LPR
$langmap{SHI} = 'tachelhit';
$langmap{si} = 'sinhala';		# sin;SNH
$langmap{sk} = 'slovak';		# slk/slo;SLO
$langmap{sl} = 'slovenian';		# slv;SLV
$langmap{sm} = 'samoan';		# smo;SMY
$langmap{sq} = 'albanian';		# alb/sqi;ALS;ALN
$langmap{sr} = 'serbian';		# scc/srp; Serbo-Croatian is sh/scr;SRC
$langmap{sv} = 'swedish';		# sve/swe;SWD
$langmap{sw} = 'swahili';		# swa;SWA
$langmap{syr} = 'syriac';		# SYC
$langmap{ta} = 'tamil';			# tam;TCV
$langmap{TCS} = 'torres strait creole';
$langmap{te} = 'telugu';		# tel;TCW
$langmap{tet} = 'tetun';		# TTM
$langmap{tg} = 'tajiki';		# tgk;PET
$langmap{th} = 'thai';			# tha;THJ
$langmap{tk} = 'turkmen';		# tuk;TCK
$langmap{tl} = 'tagalog';		# tgl;TGL
$langmap{ton} = 'tongan';		# TOV
$langmap{tpi} = 'tok pisin';	# PDG;
$langmap{tr} = 'turkish';		# tur;TRK (Ottoman="ota";TRK)
$langmap{tvl} = 'tuvaluan';		# ELL
$langmap{ty} = 'tahitian';		# tah;THT
$langmap{TZM} = 'tamazight';	# central atlas, morocco
$langmap{ug} = 'uyghur';		# uig;UIG
$langmap{uk} = 'ukrainian';		# ukr;UKR
$langmap{ULK} = 'meriam';
$langmap{ur} = 'urdu';			# urd;URD
$langmap{uz} = 'uzbek';			# uzb;UZB;UZS
$langmap{vi} = 'vietnamese';	# vie;VIE
$langmap{WBP} = 'warlpiri';
$langmap{xh} = 'xhosa';			# xho;XOS
$langmap{yi} = 'yiddish';		# yid;YDD
$langmap{zh} = 'chinese';		# chi/zho;CHN,...
$langmap{zu} = 'zulu';			# zul;ZUU

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub init {
	my ($self, $opt_s, $opt_d) = @_;
	my $success = 1;

	$self->{opt_s} = $opt_s;
	$self->{opt_d} = $opt_d;

	$self->{opt_s} = $default_src_lang unless $opt_s;
	$self->{opt_d} = $default_dst_lang unless $opt_d;

	# Load language files
	if ($opt_s eq 'AER') {
		require Tongues::Arrernte;
		$self->{src_lang} = new Tongues::Arrernte;
	} elsif ($opt_s eq 'ALH') {
		require Tongues::Alawa;
		$self->{src_lang} = new Tongues::Alawa;
	} elsif ($opt_s eq 'af') {
		require Tongues::Afrikaans;
		$self->{src_lang} = new Tongues::Afrikaans;
	} elsif ($opt_s eq 'be') {
		require Tongues::Belaruski;
		$self->{src_lang} = new Tongues::Belaruski;
	} elsif ($opt_s eq 'bg') {
		require Tongues::Balgarski;
		$self->{src_lang} = new Tongues::Balgarski;
	} elsif ($opt_s eq 'ca') {
		require Tongues::Catala;
		$self->{src_lang} = new Tongues::Catala;
	} elsif ($opt_s eq 'cy') {
		require Tongues::Cymraeg;
		$self->{src_lang} = new Tongues::Cymraeg;
	} elsif ($opt_s eq 'cs') {
		require Tongues::Cesky;
		$self->{src_lang} = new Tongues::Cesky;
	} elsif ($opt_s eq 'da') {
		require Tongues::Dansk;
		$self->{src_lang} = new Tongues::Dansk;
	} elsif ($opt_s eq 'de') {
		require Tongues::Deutsch;
		$self->{src_lang} = new Tongues::Deutsch;
	} elsif ($opt_s eq 'el') {
		require Tongues::Ellinika;
		$self->{src_lang} = new Tongues::Ellinika;
	} elsif ($opt_s eq 'en') {
		require Tongues::English;
		$self->{src_lang} = new Tongues::English;
	} elsif ($opt_s eq 'eo') {
		require Tongues::Esperanto;
		$self->{src_lang} = new Tongues::Esperanto;
	} elsif ($opt_s eq 'es') {
		require Tongues::Espanol;
		$self->{src_lang} = new Tongues::Espanol;
	} elsif ($opt_s eq 'et') {
		require Tongues::Eesti;
		$self->{src_lang} = new Tongues::Eesti;
	} elsif ($opt_s eq 'eu') {
		require Tongues::Euskara;
		$self->{src_lang} = new Tongues::Euskara;
	} elsif ($opt_s eq 'fi') {
		require Tongues::Suomi;
		$self->{src_lang} = new Tongues::Suomi;
	} elsif ($opt_s eq 'fr') {
		require Tongues::Francais;
		$self->{src_lang} = new Tongues::Francais;
	} elsif ($opt_s eq 'ga') {
		require Tongues::Gaeilge;
		$self->{src_lang} = new Tongues::Gaeilge;
	} elsif ($opt_s eq 'gl') {
		require Tongues::Galego;
		$self->{src_lang} = new Tongues::Galego;
	} elsif ($opt_s eq 'haw') {
		require Tongues::OleloHawaii;
		$self->{src_lang} = new Tongues::OleloHawaii;
	} elsif ($opt_s eq 'hr') {
		require Tongues::Hrvatski;
		$self->{src_lang} = new Tongues::Hrvatski;
	} elsif ($opt_s eq 'hu') {
		require Tongues::Magyar;
		$self->{src_lang} = new Tongues::Magyar;
	} elsif ($opt_s eq 'ia') {
		require Tongues::Interlingua;
		$self->{src_lang} = new Tongues::Interlingua;
	} elsif ($opt_s eq 'id') {
		require Tongues::BahasaIndonesia;
		$self->{src_lang} = new Tongues::BahasaIndonesia;
	} elsif ($opt_s eq 'is') {
		require Tongues::Islensku;
		$self->{src_lang} = new Tongues::Islensku;
	} elsif ($opt_s eq 'it') {
		require Tongues::Italiano;
		$self->{src_lang} = new Tongues::Italiano;
	} elsif ($opt_s eq 'ko') {
		require Tongues::Hanguk;
		$self->{src_lang} = new Tongues::Hanguk;
	} elsif ($opt_s eq 'lt') {
		require Tongues::Lietuvos;
		$self->{src_lang} = new Tongues::Lietuvos;
	} elsif ($opt_s eq 'lv') {
		require Tongues::Latviesu;
		$self->{src_lang} = new Tongues::Latviesu;
	} elsif ($opt_s eq 'mi') {
		require Tongues::Maori;
		$self->{src_lang} = new Tongues::Maori;
	} elsif ($opt_s eq 'ms') {
		require Tongues::BahasaMalaysia;
		$self->{src_lang} = new Tongues::BahasaMalaysia;
	} elsif ($opt_s eq 'mt') {
		require Tongues::Malti;
		$self->{src_lang} = new Tongues::Malti;
	} elsif ($opt_s eq 'MWP') {
		require Tongues::KalaLagawYa;
		$self->{src_lang} = new Tongues::KalaLagawYa;
	} elsif ($opt_s eq 'nl') {
		require Tongues::Nederlands;
		$self->{src_lang} = new Tongues::Nederlands;
	} elsif ($opt_s eq 'no') {
		require Tongues::Norsk;
		$self->{src_lang} = new Tongues::Norsk;
	} elsif ($opt_s eq 'PJT') {
		require Tongues::Pitjantjatjara;
		$self->{src_lang} = new Tongues::Pitjantjatjara;
	} elsif ($opt_s eq 'pl') {
		require Tongues::Polskiej;
		$self->{src_lang} = new Tongues::Polskiej;
	} elsif ($opt_s eq 'pt') {
		require Tongues::Portugues;
		$self->{src_lang} = new Tongues::Portugues;
	} elsif ($opt_s eq 'ro') {
		require Tongues::Romana;
		$self->{src_lang} = new Tongues::Romana;
	} elsif ($opt_s eq 'ROP') {
		require Tongues::Kriol;
		$self->{src_lang} = new Tongues::Kriol;
	} elsif ($opt_s eq 'ru') {
		require Tongues::Russky;
		$self->{src_lang} = new Tongues::Russky;
	} elsif ($opt_s eq 'sk') {
		require Tongues::Slovencine;
		$self->{src_lang} = new Tongues::Slovencine;
	} elsif ($opt_s eq 'sl') {
		require Tongues::Slovenscina;
		$self->{src_lang} = new Tongues::Slovenscina;
	} elsif ($opt_s eq 'sm') {
		require Tongues::GaganaSamoa;
		$self->{src_lang} = new Tongues::GaganaSamoa;
	} elsif ($opt_s eq 'sq') {
		require Tongues::Shqip;
		$self->{src_lang} = new Tongues::Shqip;
	} elsif ($opt_s eq 'sr') {
		require Tongues::Srpski;
		$self->{src_lang} = new Tongues::Srpski;
	} elsif ($opt_s eq 'sv') {
		require Tongues::Svenska;
		$self->{src_lang} = new Tongues::Svenska;
	} elsif ($opt_s eq 'sw') {
		require Tongues::Kiswahili;
		$self->{src_lang} = new Tongues::Kiswahili;
	} elsif ($opt_s eq 'th') {
		require Tongues::Thai;
		$self->{src_lang} = new Tongues::Thai;
		# TODO
		$digits = Charsets::TIS_620->digits();
	} elsif ($opt_s eq 'tl') {
		require Tongues::Tagalog;
		$self->{src_lang} = new Tongues::Tagalog;
	} elsif ($opt_s eq 'tpi') {
		require Tongues::TokPisin;
		$self->{src_lang} = new Tongues::TokPisin;
	} elsif ($opt_s eq 'tr') {
		require Tongues::Turkce;
		$self->{src_lang} = new Tongues::Turkce;
	} elsif ($opt_s eq 'uk') {
		require Tongues::Ukrayinska;
		$self->{src_lang} = new Tongues::Ukrayinska;
	} elsif ($opt_s eq 'WBP') {
		require Tongues::Warlpiri;
		$self->{src_lang} = new Tongues::Warlpiri;
	} else {
		if ($langmap{$opt_s}) {
			print STDERR "** Language not implemented: $langmap{$opt_s}\n";
			$success = 0;
		}
		else {
			print STDERR "** Unknown language: $opt_s\n";
			$success = 0;
		}
	}

	if ($success) {
		# Language is okay, do language-independant initialization
		$self->{src_eng_name} = $langmap{$opt_s};
		$self->{dst_eng_name} = $langmap{$opt_d};
		$letters = $self->{src_lang}->charset()->letters();
	}

	return $success;
}

#
# Set the text used to bracket untranlated words
#

sub set_untrans_brackets {
	my ($self, $left, $right) = @_;
	$self->{untrans_brac_l} = $left;
	$self->{untrans_brac_r} = $right;
}

#
# Set parenthesized word hiding on/off
#

sub set_hide_parenth_words {
	my ($self, $onoff) = @_;

	$self->{hide_parenth} = $onoff;
}

sub translate {
	my ($self, $in_text, $is_utf8) = @_;

	$in_text = $self->{src_lang}->charset()->from_utf8($in_text) if ($is_utf8);

	my $out_text = $self->do_translate($in_text);

	$out_text = $self->{src_lang}->charset()->to_utf8($out_text) if ($is_utf8);

	return $out_text;
}

sub do_translate {
	my $self = shift;
	my $line = shift;
	my $translated_line = '';
	my $oldflags = 0;

	for (;;) {
		# get next word (or punctuation etc)
		my ($word, $flags) = $self->getword(\$line);
		last if $word eq '';

		# translate it if it's a word
		my $trword = $flags & 1 ? $self->trans_word($word) : $word;

		# remove helping words in parentheses
		$trword =~ s/ ?\(\w+\) ?//g if ($self->{hide_parenth});

		# log untranslated words?
		if ($self->{opt_l} && ($flags & 1) && !$trword) {
			# TODO should log lowercased/normalized words
			print STDERR "$word\n";
		}

		# output word (numbers and punctuation too)
		$self->emit_word(\$translated_line, ($trword or $word), $trword ? 1 : 0, $oldflags & 2 ? 1 : 0, $flags & 2 ? 1 : 0);

		$oldflags = $flags;
	}

	return $translated_line;
}


############################################################################

#
# Read one word or punctuation
#

sub getword {
	my $self = shift;
	my $line = shift;
	my @retval = ( '', 0 );
	my $i;			# index
	my $a;			# scratch

	return () if $$line eq '';				# empty list for eof

	SWITCH: for ($$line) {
		# word
		/^$letters/ and do {
			/^($letters+)/;
			$i = length $1;
			$retval[0] = $1;
			$retval[1] = 1 | 2;							# translate, separate
			for (; substr($$line,$i,1) eq ' '; ++$i) {}	# Eat whitespace
			last SWITCH;
		};

		# number
		/^$digits/ and do {
			/^([$digits+)/;
			$i = length $1;

			my $number = $1;
			
			# Translate native digits
			if ($self->{opt_s} eq 'th') {
				$number = Charsets::TIS_620->translate_digits($number);
			}
			
			$retval[0] = $number;
			$retval[1] = 2;								# separate
			for (; substr($$line,$i,1) eq ' '; ++$i) {}	# Eat whitespace
			last SWITCH;
		};

		# Default - the word is this single character
		do {
			$retval[0] = substr($$line,0,1);
			$retval[1] = 0;								# no translate or sep.
			$i = 1;
			last SWITCH;
		};
	 }

	# Erase the bit we just got
	substr($$line,0,$i) = '';

	return @retval;
}

#
# Translate one word
#

sub trans_word {
	my $self = shift;
	my $word = shift;
	
	# Normalize - currently lowercase based on charset
	$word = $self->{src_lang}->charset()->lowercase($word);
	if ($self->{opt_s} eq 'eo') {
		$word =~ s/cx/ĉ/g;
		$word =~ s/gx/ĝ/g;
		$word =~ s/hx/ĥ/g;
		$word =~ s/jx/ĵ/g;
		$word =~ s/sx/ŝ/g;
		$word =~ s/ux/ŭ/g;
	} elsif ($self->{opt_s} eq 'fr') {
		$word =~ s/�/oe/g;
	}

	my $entry = $self->lookup($self->{src_lang}->dictionary,$word);				# Lookup as is...
	my $newword;

	$newword = $self->entry_to_word($entry);

	# If it's not in the dictionary as is, try variations
	$newword = $self->lookup_variations($word) unless ($newword);

	return $newword;
}

#
# Extract the word field from a dictionary entry
#

sub entry_to_word {
	my $self = shift;
	my $entry = shift;
	my $result = $entry;
	
	#return ref($entry) ? $entry->{'x'} : $entry;
	if (ref($entry)) {
		if ($entry->{"x-$self->{opt_d}"}) {
			$result = $entry->{"x-$self->{opt_d}"};
		} else {
			$result = $entry->{'x'};
		}
	}
	if (ref($result) eq 'ARRAY') {
		$result = $result->[0];
	}
	return $result;
}

#
# Lookup word in dictionary
#

sub lookup {
	my ($self, $dict, $word) = @_;

	return $dict->{$word};			# Lookup new form
}

#
# Lookup variations of a word in dictionary
#

sub lookup_variations {
	my $self = shift;
	my $word = shift;
	my $newword = '';

	# Iterate over each rule
	loop: for (my $i = 0; $self->{src_lang}->grammar->[$i]; ++$i) {
	
		if ($newword = $self->get_root_form($word, $self->{src_lang}->grammar->[$i][$G_CONJ_PAT], $self->{src_lang}->grammar->[$i][$G_ROOT_END])) {

			if (my $entry = $self->lookup($self->{src_lang}->dictionary,$newword)) {			# Lookup new form
				# Don't apply conjugation to known wrong types
				if (ref($entry) && exists $entry->{'t'} && $entry->{'t'} ne $self->{src_lang}->grammar->[$i][$G_TYPE]) {
					($newword = '', next);
				}

				$newword = $self->entry_to_word($entry);

				$newword = $self->reconjugate($newword, $self->{src_lang}->grammar->[$i][$G_PREFIX], $self->{src_lang}->grammar->[$i][$G_POSTFIX]);
				last loop;
			}
			else { $newword = ''; }
		}
	}
	return $newword;
}

#
# Get root form of a word (based on given grammar rule)
#

sub get_root_form {
	my ($self, $word, $match_pat, $subs_pat) = @_;
	my ($match_pre, $match_suf) = ('', '');
	my ($subs_pre, $subs_suf) = ('', '');
	my $umlaut = 0;
	my $origword = $word;

	# Is match a prefix and ending or only an ending?
	if ($match_pat =~ /-/) {
		($match_pre, $match_suf) = ($match_pat =~ /(.*)-(.*)/)
	} else {
		$match_suf = $match_pat;
	}

	# Is substitute a prefix and ending or only an ending?
	if ($subs_pat =~ /-/) {
		($subs_pre, $subs_suf) = ($subs_pat =~ /(.*)-(.*)/)
	} else {
		$subs_suf = $subs_pat;
	}

#	print STDERR "xform: $match_pre-$match_suf -> -$subs_pat\n";

	# Pattern contains umlaut?
	$umlaut = 1 if ($match_suf =~ s/�//);
	
	if ($word =~ s/^$match_pre(.*)$match_suf$/$subs_pre$1$subs_suf/) {
#		print STDERR " match\n";
		if ($umlaut) {
			my ($r1, $r2);
			if ($word =~ /([���].*)/) {
				($r1, $r2) = ($1, $1);
				$r2 =~ tr/���/aou/;
				$word =~ s/$r1/$r2/;
#				print STDERR "  umlaut\n";
			}
		}
#		print STDERR " $origword -> $word\n";
		return $word;
	} else {
		return undef;
	}
}

#
# Re-conjugate translated word
#

sub reconjugate {
	my ($self, $newword, $prefix, $postfix) = @_;
	my @words = split ' ', $newword;		# Split multi-word

	# Conjugate 1st word not in brackets
	foreach my $word (@words) {
		next if (substr($word,0,1) eq '(');
		$word .= $postfix;
		last;
	}

	# Rejoin multi-word
	$newword = $prefix . join ' ', @words;

	return $newword;
}

#
# Display the (hopefully translated) word somehow
#

sub emit_word {
	my ($self, $line, $word, $is_translated, $space_before, $space_after) = @_;

	# separate two words with a space
	$$line .= ' ' if ($space_after && $space_before);

	if ($is_translated) {
		$$line .= $word;
	} else {
		$$line .= $self->{untrans_brac_l} . $word . $self->{untrans_brac_r};
	}
}

sub BEGIN {
}

1;
