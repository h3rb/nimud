# vi: ts=8 sw=8

package Tongues::Malti;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set ISO 8859-3 / Latin-3

# Alphabetical order
# A B C � D E F G � H � ձ I Ie J K L M N O P Q R S T U V W X (Y) Z �
# a b c � d e f g � h � �� i ie j k l m n o p q r s t u v w x (y) z �

# Digraphs ձ, Ie not always considered separate letters

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::Latin3;

$charset = new Charsets::Latin3;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# Malti to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'jiena'	=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's' },
 'a�na'		=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p' },
 #   2nd person
 'inti'		=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's' },
 #   3rd person
 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 'iva'		=> { 'x' => 'yes' },
 'iwa'		=> { 'x' => 'yes' },
 'le'		=> { 'x' => 'no' },
 'ming�ajr'	=> { 'x' => 'without',
 		     't' => 'p' },
 'ta�t'		=> { 'x' => 'under',
 		     't' => 'p' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'wie�ed'	=> { 'x' => 'one' },
 'tnejn'	=> { 'x' => 'two' },
 'tlieta'	=> { 'x' => 'three' },
 'erbg�a'	=> { 'x' => 'four' },
 # Days and months
 'il-�add'	=> { 'x' => 'sunday' },
 'it-tnejn'	=> { 'x' => 'monday' },
 'it-tlieta'	=> { 'x' => 'tuesday' },
 'l-erbg�a'	=> { 'x' => 'wednesday' },
 'il-�amis'	=> { 'x' => 'thursday' },
 'il-�img�a'	=> { 'x' => 'friday' },
 'is-sibt'	=> { 'x' => 'saturday' },
 'jannar'	=> { 'x' => 'january' },
 'frar'		=> { 'x' => 'february' },
 'marzu'	=> { 'x' => 'march' },
 'april'	=> { 'x' => 'april' },
 'mejju'	=> { 'x' => 'may' },
 '�unju'	=> { 'x' => 'june' },
 'lulju'	=> { 'x' => 'july' },
 'awissu'	=> { 'x' => 'august' },
 'settembru'	=> { 'x' => 'september' },
 'ottubru'	=> { 'x' => 'october' },
 'novembru'	=> { 'x' => 'november' },
 'di�embru'	=> { 'x' => 'december' },
 # Key verbs
 'g�andi'	=> { 'x' => '(i) have' },
 # Vocabulary
 'art'		=> { 'x' => 'ground',
		     '#' => 'floor',
 		     't' => 'n' },
 'bewl'		=> { 'x' => 'urine',
 		     't' => 'n' },
 'dinja'	=> { 'x' => 'world',
 		     't' => 'n' },
 'frawla'	=> { 'x' => 'strawberry',
 		     't' => 'n' },
 'g�awm'	=> { 'x' => 'swimming',
		     '#' => 'noun/verb?' },
 'istenna'	=> { 'x' => 'wait',
 		     't' => 'v' },
 'jum'		=> { 'x' => 'day',
 		     't' => 'n' },
 'kulur'	=> { 'x' => 'colour',
 		     't' => 'n' },
 'lown'		=> { 'x' => 'colour',
 		     't' => 'n' },
 'mag�ruf'	=> { 'x' => 'well-known',
 		     't' => 'a' },
 'ri�'		=> { 'x' => 'wind',
 		     't' => 'n' },
 'suf'		=> { 'x' => 'wool',
 		     't' => 'n' },
 'tiekol'	=> { 'x' => '(you) eat',
 		     't' => 'v' },
 'mewt'		=> { 'x' => 'death',
 		     't' => 'n' },
 'moxt'		=> { 'x' => 'comb',
		     '#' => 'noun/verb?' },
 'nemex'	=> { 'x' => 'freckles',
 		     't' => 'n' },
 'trux'		=> { 'x' => 'deaf',
 		     't' => 'a' },
 '�jara'	=> { 'x' => 'visit',
		     '#' => 'noun/verb?' },
);
}

1;

