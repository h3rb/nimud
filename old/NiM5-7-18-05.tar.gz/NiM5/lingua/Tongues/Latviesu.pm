# vi: ts=8 sw=8

package Tongues::Latviesu;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Baltic CP1257 / ISO 8859-13 / Latin-7

# Alphabetical order
# A � B C � D E � F G � H I � J K � L � M N O P R S � T U � V Z �
# a � b c � d e � f g � h i � j k � l � m n o p r s � t u � v z �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::BalticWin;

$charset = new Charsets::BalticWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative
#	g -> genitive
#	d -> dative
#	a -> accusative
#	inst -> instrumental
#	l -> locative

# Latvian to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 #  Other functional words
 'pa'		=> { 'x' => 'along',
		     '#' => '; on; to; during ',
 		     't' => 'p' },
 'par'		=> { 'x' => 'for',
		     '#' => 'of; about; ',
 		     't' => 'p' },
 'pat'		=> { 'x' => 'even', 
 		     't' => 'adv' },
 'pats'		=> { 'x' => 'self',
		     '#' => 'very ' },
 'p�r'		=> { 'x' => 'over' },
 'p�r�k'	=> { 'x' => 'too',
 		     't' => 'adv' },
 'p�r�jais'	=> { 'x' => 'rest',
		     '#' => 'the rest',
 		     't' => 'n' },
 'p�ri'		=> { 'x' => 'above',
		     '#' => 'over; across; past; beyond ' },
 'p�c'		=> { 'x' => 'in',
		     '#' => 'after; by; ',
 		     't' => 'p' },
 'pie'		=> { 'x' => 'by',
		     '#' => 'at; on; to; against ',
 		     't' => 'p' },
 'pirms'	=> { 'x' => 'before',
		     '#' => 'prep or adv.?' },
 'pret'		=> { 'x' => 'against',
		     '#' => '; for; to ',
 		     't' => 'p' },
 'priek�u'	=> { 'x' => 'forward',
		     '#' => '(uz priesku); adv.?' },
 'proj�m'	=> { 'x' => 'away',
		     '#' => 'adv.? ' },
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 'pirmais'	=> { 'x' => 'first' },
 'piektais'	=> { 'x' => 'fifth' },
 # Days and months
 'pirmdiena'	=> { 'x' => 'monday' },
 'piektdiena'	=> { 'x' => 'friday' },
 'decembr�'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 'asambleja'	=> { 'x' => 'assembly',
 		     't' => 'n' },
 'deklar�cija'	=> { 'x' => 'declaration',
 		     't' => 'n' },
 '�ener�l�'	=> { 'x' => 'general',
 		     't' => 'a' },
 'pacelt'	=> { 'x' => 'lift',
		     '#' => 'to pick up ',
 		     't' => 'v' },
 'pacelties'	=> { 'x' => 'rise',
 		     't' => 'v' },
 'padar�t'	=> { 'x' => 'do',
		     '#' => 'finish ',
 		     't' => 'v' },
 'padom�t'	=> { 'x' => 'think over',
		     '#' => 'multiword',
 		     't' => 'v' },
 'padome'	=> { 'x' => 'council',
		     '#' => 'soviet ',
 		     't' => 'v' },
 'padoms'	=> { 'x' => 'advice',
 		     't' => 'n' },
 'pagaid�m'	=> { 'x' => 'for now',
		     '#' => 'for the time being; for the present ',
 		     't' => 'adv' },
 'pagaid�t'	=> { 'x' => 'wait',
		     '#' => 'wait a little; wait for a while ',
 		     't' => 'v' },
 'pagalms'	=> { 'x' => 'yard',
 		     't' => 'n' },
 'paiet'	=> { 'x' => 'go',
		     '#' => 'to walk; to pass ',
 		     't' => 'v' },
 'pak�peniski'	=> { 'x' => 'gradually',
 		     't' => 'adv' },
 'palags'	=> { 'x' => 'sheet',
 		     't' => 'n' },
 'paldies'	=> { 'x' => 'thank you',
 		     't' => 'interj' },
 'palielin�ties'	=> { 'x' => 'increase',
	 		     't' => 'v' },
 'palielin�t'	=> { 'x' => 'increase',
		     '#' => 'sth.; enlarge ',
 		     't' => 'v' },
 'palikt'	=> { 'x' => 'remain',
		     '#' => 'stay; put ',
 		     't' => 'v' },
 'pal�dz�t'	=> { 'x' => 'help',
		     '#' => 'aid ',
 		     't' => 'v' },
 'pal�dz�ba'	=> { 'x' => 'help',
		     '#' => 'aid ',
 		     't' => 'n' },
 'pal�gs'	=> { 'x' => 'helper',
		     '#' => 'assistant (person)',
 		     't' => 'n' },
 'palodze'	=> { 'x' => 'window sill',
		     '#' => 'multiword',
 		     't' => 'n' },
 'paman�t'	=> { 'x' => 'notice',
 		     't' => 'v' },
 'pamats'	=> { 'x' => 'base',
		     '#' => 'basis; reason; foundation ',
 		     't' => 'n' },
 'pamest'	=> { 'x' => 'leave',
 		     't' => 'v' },
 'pan�kt'	=> { 'x' => 'achieve',
		     '#' => 'catch up ',
 		     't' => 'v' },
 'pan�kums'	=> { 'x' => 'success',
		     '#' => 'achievement ',
 		     't' => 'n' },
 'pa�emt'	=> { 'x' => 'take',
 		     't' => 'v' },
 'pa��miens'	=> { 'x' => 'way',
		     '#' => 'method ',
 		     't' => 'n' },
 'pants'	=> { 'x' => 'article',
 		     't' => 'n' },
 'pap�dis'	=> { 'x' => 'heel',
 		     't' => 'n' },
 'pap�rs'	=> { 'x' => 'paper',
 		     't' => 'n' },
 'parasti'	=> { 'x' => 'usually',
 		     't' => 'adv' },
 'parasts'	=> { 'x' => 'usual',
		     '#' => 'ordinary ',
 		     't' => 'a' },
 'paraugs'	=> { 'x' => 'example',
		     '#' => 'sample; standard; model ',
 		     't' => 'n' },
 'par�d�t'	=> { 'x' => 'show', 
 		     't' => 'v' },
 'par�d�ties'	=> { 'x' => 'appear',
		     '#' => 'emerge ',
 		     't' => 'v' },
 'paredz�t'	=> { 'x' => 'foresee', 
 		     't' => 'v' },
 'pareizi'	=> { 'x' => 'correctly',
		     '#' => 'right ',
 		     't' => 'adv' },
 'pareizs'	=> { 'x' => 'correct',
		     '#' => 'right ',
 		     't' => 'a' },
 'par�t'	=> { 'x' => 'the day after tomorrow',
		     '#' => 'multiword',
 		     't' => 'n' },
 'parun�t'	=> { 'x' => 'speak',
		     '#' => 'talk ',
 		     't' => 'v' },
 'pasaka'	=> { 'x' => 'fairy tale',
 		     't' => 'v' },
 'pasaule'	=> { 'x' => 'world',
 		     't' => 'n' },
 'pas�kums'	=> { 'x' => 'enterprise',
 		     't' => 'n' },
 'paskat�ties'	=> { 'x' => 'look at',
		     '#' => 'multiword',
 		     't' => 'n' },
 'pasniegt'	=> { 'x' => 'hand',
		     '#' => 'present ',
 		     't' => 'v' },
 'past�st�t'	=> { 'x' => 'tell',
		     '#' => 'to narrate ',
 		     't' => 'v' },
 'pa�apkalpo�an�s'	=> { 'x' => 'self-service',
		     '#' => 'multiword?',
 			     't' => 'n' },
 'pa�laik'	=> { 'x' => 'now',
		     '#' => 'just now ',
 		     't' => 'adv' },
 'pa�reiz'	=> { 'x' => 'now',
		     '#' => 'at present ',
 		     't' => 'adv' },
 'pateikt'	=> { 'x' => 'say',
		     '#' => 'tell ',
 		     't' => 'v' },
 'pateikties'	=> { 'x' => 'thank',
 		     't' => 'v' },
 'paties�ba'	=> { 'x' => 'truth',
 		     't' => 'n' },
 'patie��m'	=> { 'x' => 'indeed',
		     '#' => 'really ',
 		     't' => 'adv' },
 'patikt'	=> { 'x' => 'like',
 		     't' => 'v' },
 'pavad�t'	=> { 'x' => 'accompany',
		     '#' => 'see off',
 		     't' => 'v' },
 'pavasaris'	=> { 'x' => 'spring',
 		     't' => 'n' },
 'pavisam'	=> { 'x' => 'entirely',
 		     't' => 'adv' },
 'pazaud�t'	=> { 'x' => 'lose',
 		     't' => 'v' },
 'paz�t'	=> { 'x' => 'recognize',
		     '#' => 'know ',
 		     't' => 'v' },
 'pazust'	=> { 'x' => 'disappear',
 		     't' => 'v' },
 'p�rbaud�t'	=> { 'x' => 'examine',
		     '#' => 'check ',
 		     't' => 'v' },
 'p�rdev�js'	=> { 'x' => 'salesperson',
		     '#' => 'shop assistant (person)',
 		     't' => 'n' },
 'p�rdot'	=> { 'x' => 'sell',
 		     't' => 'v' },
 'p�reja'	=> { 'x' => 'passage',
 		     't' => 'n' },
 'p�riet'	=> { 'x' => 'cross',
		     '#' => 'stop; cease ',
 		     't' => 'v' },
 'p�ris'	=> { 'x' => 'pair',
		     '#' => 'couple; several; few ',
 		     't' => 'n' },
 'p�rn�kt'	=> { 'x' => 'return',
 		     't' => 'v' },
 'p�rsniegt'	=> { 'x' => 'exceed',
 		     't' => 'v' },
 'p�rtika'	=> { 'x' => 'food',
 		     't' => 'n' },
 'p�rtraukt'	=> { 'x' => 'interrupt',
		     '#' => 'stop ',
 		     't' => 'v' },
 'p�rtraukums'	=> { 'x' => 'break',
		     '#' => 'interval ',
 		     't' => 'n' },
 'p�rv�rsties'	=> { 'x' => 'change',
		     '#' => 'change into ',
 		     't' => 'v' },
 'pele'		=> { 'x' => 'mouse',
		     '#' => 'animate',
 		     't' => 'n' },
 'pel�ks'	=> { 'x' => 'grey', 
 		     't' => 'a' },
 'p�cpusdiena'	=> { 'x' => 'afternoon',
 		     't' => 'n' },
 'p�da'		=> { 'x' => 'foot',
		     '#' => 'footprint ',
 		     't' => 'n' },
 'p�d�jais'	=> { 'x' => 'last',
		     '#' => 'the latest ',
 		     't' => 'a' },
 'p�k��i'	=> { 'x' => 'suddenly',
 		     't' => 'adv' },
 'pieaugt'	=> { 'x' => 'grow',
		     '#' => 'increase ',
 		     't' => 'v' },
 'piecelties'	=> { 'x' => 'rise',
 		     't' => 'v' },
 'pieci'	=> { 'x' => 'fife',
 		     't' => 'n' },
 'piedal�ties'	=> { 'x' => 'participate',
 		     't' => 'v' },
 'pieder�t'	=> { 'x' => 'belong to',
		     '#' => 'multiword',
 		     't' => 'v' },
 'piedot'	=> { 'x' => 'forgive',
 		     't' => 'v' },
 'piem�rs'	=> { 'x' => 'example',
 		     't' => 'n' },
 'piemineklis'	=> { 'x' => 'monument',
 		     't' => 'n' },
 'pien�kt'	=> { 'x' => 'come',
		     '#' => 'come up; arrive ',
 		     't' => 'v' },
 'pien�kums'	=> { 'x' => 'duty',
 		     't' => 'n' },
 'piens'	=> { 'x' => 'milk',
 		     't' => 'n' },
 'pie�emt'	=> { 'x' => 'receive',
		     '#' => 'accept; adopt; engage; hire ',
 		     't' => 'v' },
 'pierast'	=> { 'x' => 'get used to',
		     '#' => 'accustom',
 		     't' => 'v' },
 'pier�d�t'	=> { 'x' => 'prove',
 		     't' => 'v' },
 'piere'	=> { 'x' => 'forehead',
 		     't' => 'n' },
 'pieredze'	=> { 'x' => 'experience',
 		     't' => 'n' },
 'pietikt'	=> { 'x' => 'suffice',
		     '#' => 'be enough; have enough ',
 		     't' => 'v' },
 'pietura'	=> { 'x' => 'stop',
 		     't' => 'n' },
 'pildspalva'	=> { 'x' => 'pen',
		     '#' => 'fountain-pen ',
 		     't' => 'n' },
 'piln�gi'	=> { 'x' => 'completely',
		     '#' => 'absolutely ',
 		     't' => 'adv' },
 'pilns'	=> { 'x' => 'full',
 		     't' => 'a' },
 'pils�ta'	=> { 'x' => 'town',
		     '#' => 'city ',
 		     't' => 'n' },
 'pilsonis'	=> { 'x' => 'citizen',
		     '#' => '(person)',
 		     't' => 'n' },
 'pirc�js'	=> { 'x' => 'buyer',
		     '#' => 'customer (person)',
 		     't' => 'n' },
 'pirksts'	=> { 'x' => 'finger',
 		     't' => 'n' },
 'pirkt'	=> { 'x' => 'buy',
 		     't' => 'v' },
 'p�le'		=> { 'x' => 'duck',
		     '#' => 'animate',
 		     't' => 'n' },
 'pla�i'	=> { 'x' => 'widely',
 		     't' => 'adv' },
 'pla�s'	=> { 'x' => 'wide',
		     '#' => 'spacious; extensive ',
 		     't' => 'a' },
 'plats'	=> { 'x' => 'broad',
		     '#' => 'wide ',
 		     't' => 'a' },
 'platums'	=> { 'x' => 'width',
		     '#' => 'latitude ',
 		     't' => 'n' },
 'plauksta'	=> { 'x' => 'palm', 
 		     't' => 'n' },
 'plaukts'	=> { 'x' => 'shelf',
 		     't' => 'n' },
 'pl�ns'	=> { 'x' => 'thin',
		     '#' => 'adj.; plan noun' },
 'plecs'	=> { 'x' => 'shoulder',	
 		     't' => 'n' },
 'pl�me'	=> { 'x' => 'plum',
 		     't' => 'n' },
 'pl�st'	=> { 'x' => 'flow',
 		     't' => 'v' },
 'p�ava'	=> { 'x' => 'meadow',
 		     't' => 'n' },
 'poga'		=> { 'x' => 'button',
 		     't' => 'n' },
 'posms'	=> { 'x' => 'period',
		     '#' => 'span ',
 		     't' => 'n' },
 'pras�ba'	=> { 'x' => 'demand',
		     '#' => 'requirement ',
 		     't' => 'n' },
 'pras�t'	=> { 'x' => 'ask',
		     '#' => 'demand ',
 		     't' => 'v' },
 'prast'	=> { 'x' => 'know',
		     '#' => 'to be able ',
 		     't' => 'v' },
 'pr�ts'	=> { 'x' => 'mind',
		     '#' => 'intellect ',
 		     't' => 'n' },
 'preambula'	=> { 'x' => 'preamble',
 		     't' => 'n' },
 'prece'	=> { 'x' => 'article',
		     '#' => 'goods ',
 		     't' => 'n' },
 'pretest�ba'	=> { 'x' => 'resistance', 
 		     't' => 'n' },
 'pret�js'	=> { 'x' => 'opposite',
		     '#' => 'adj., prep.?' },
 'priec�ties'	=> { 'x' => 'be glad',
		     '#' => 'enjoy oneself (multiword)',
 		     't' => 'v' },
 'priec�gs'	=> { 'x' => 'glad',
		     '#' => 'happy ',
 		     't' => 'a' },
 'priede'	=> { 'x' => 'pine',
 		     't' => 'n' },
 'prieks'	=> { 'x' => 'joy',
		     '#' => 'pleasure ',
 		     't' => 'n' },
 'priek�a'	=> { 'x' => 'front',
 		     't' => 'n' },
 'priek�nieks'	=> { 'x' => 'head',
		     '#' => 'chief (poss. person)',
 		     't' => 'n' },
 'priek�s�d�t�js'	=> { 'x' => 'chairman',
		     '#' => '(person) ',
	 		     't' => 'n' },
 'protams'	=> { 'x' => 'certainly',
 		     't' => 'adv' },
 'pudele'	=> { 'x' => 'bottle',
 		     't' => 'n' },
 'puika'	=> { 'x' => 'boy',
		     '#' => '(person)',
 		     't' => 'n' },
 'puisis'	=> { 'x' => 'lad',
		     '#' => 'bachelor; farmhand (person)',
 		     't' => 'n' },
 'pu�e'		=> { 'x' => 'flower',
 		     't' => 'n' },
 'pulkstenis'	=> { 'x' => 'clock',
 		     't' => 'n' },
 'pulveris'	=> { 'x' => 'powder',
 		     't' => 'n' },
 'punkts'	=> { 'x' => 'point',
		     '#' => 'full stop ',
 		     't' => 'n' },
 'purvs'	=> { 'x' => 'bog',
		     '#' => 'marsh ',
 		     't' => 'n' },
 'pusdiena'	=> { 'x' => 'noon',
		     '#' => 'which part of speech?' },
 'pusdienas'	=> { 'x' => 'dinner', 
 		     't' => 'n' },
 'puse'		=> { 'x' => 'half',
		     '#' => 'side ',
 		     't' => 'n' },
 'putns'	=> { 'x' => 'bird',
		     '#' => 'animate',
 		     't' => 'n' },
 'putra'	=> { 'x' => 'porridge',	
 		     't' => 'n' },
 'putraimi'	=> { 'x' => 'groats',
		     '#' => '??' },
 'visp�r�j�'	=> { 'x' => 'universal',
 		     't' => 'a' },
);
}

1;

