# vi: ts=8 sw=8 sts=8

package Tongues::Pitjantjatjara;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A G I J K L L_ M N N_ P R R_ T T_ U W Y
# a g i j k l l_ m n n_ p r r_ t t_ u w y

# Note that the 2nd L, N, R, and T properly include
# a combining macron below which may not be available on many systems.
# We'll subsitute the underscore for now.

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun case
 # Noun gender
 # Noun plural
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	m -> masculine		default
#	f -> feminine
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	d -> dual
#	t -> trial
#	p -> plural
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative
# c -> case:
#	n -> nominative 		default
#	a -> accusative 

# Pitjantjatjara to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Masculine
 #     Singular
 #     Plural
 #    Feminine
 #     Singular
 #     Plural
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 'ngayulu'	=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 's' },
 'ngali'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     'c' => 's' },
 'nganan_a'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 's' },

 'ngayunya'	=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'o' },
 'ngalinya'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     'c' => 'o' },
 'nganananya'	=> { 'x' => 'us',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'o' },

 '-na'		=> { 'x' => 'i',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 's' },
 '-ni'		=> { 'x' => 'me',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 's',
		     'c' => 'o' },
 '-li'		=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     'c' => 's' },
 '-linya'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'd',
		     'c' => 'o' },
 '-la'		=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 's' },
 '-lanya'	=> { 'x' => 'we',
		     't' => 'pro',
		     'p' => '1',
		     'n' => 'p',
		     'c' => 'o' },

 #   2nd person
 'nyuntu'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 's' },
 'nyupali'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 's' },
 'nyura'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 's' },

 'nyuntunya'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'o' },
 'nyupalinya'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'd',
		     'c' => 'o' },
 'nyura'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 'p',
		     'c' => 'o' },

 '-n,-nta'	=> { 'x' => 'you',
		     't' => 'pro',
		     'p' => '2',
		     'n' => 's',
		     'c' => 'b' },

 #   3rd person
 'palur_u'	=> { 'x' => 'he',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 's' },
 'pula'		=> { 'x' => 'they',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 's' },
 'tjana'	=> { 'x' => 'they',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 's' },

 'palunya'	=> { 'x' => 'him',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 's',
		     'c' => 'o' },
 'pulanya'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'd',
		     'c' => 'o' },
 'tjana'	=> { 'x' => 'them',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'o' },

 '-ya'		=> { 'x' => 'they',
		     't' => 'pro',
		     'p' => '3',
		     'n' => 'p',
		     'c' => 'b' },

 #   Other pronouns
 #  Interrogatives
 #  Other functional words
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 # Key verbs
 # Vocabulary
);
}

1;

