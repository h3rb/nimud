# vi: ts=8 sw=8 sts=8

package Tongues::Svenska;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK $charset $grammar %dictionary);

use Exporter   ();
# set the version for version checking
@ISA         = qw(Exporter);
@EXPORT      = qw(charset grammar dictionary);
@EXPORT_OK   = qw();
$VERSION     = 0.00;

# Character set Windows Western European CP1252 / ISO 8859-1 / Latin-1

# Alphabetical order
# A B C D E F G H I J K L M N O P Q R S T U V W X Y Z � � �
# a b c d e f g h i j k l m n o p q r s t u v w x y z � � �

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

sub charset {
	return $charset;
}

sub grammar {
	return $grammar;
}

sub dictionary {
	return \%dictionary;
}

sub BEGIN {

require Charsets::WestEuroWin;

$charset = new Charsets::WestEuroWin;

# Table for converting words to root form
$grammar = [
 # Noun
 #  Noun definiteness
 [ 'a',		'',	'a ',		'',	'n' ],	# sing. indef. decl. 1, uter/common
 [ 'an',	'',	'the ',		'',	'n' ],	# sing. def.   decl. 1
 [ 'or',	'',	'some ',	'',	'n' ],	# plur. indef. decl. 1
 [ 'orna',	'',	'the ',		'',	'n' ],	# plur. def.   decl. 1
 [ 'e',		'',	'a ',		'',	'n' ],	# sing. indef. decl. 2, uter/common
 [ 'en',	'',	'the ',		'',	'n' ],	# sing. def.   decl. 2
 [ 'ar',	'',	'some ',	'',	'n' ],	# plur. indef. decl. 2
 [ 'arna',	'',	'the ',		'',	'n' ],	# plur. def.   decl. 2
 #[ '',		'',	'a ',		'',	'n' ],	# sing. indef. decl. 3, neuter/uter
 #[ 'en',	'',	'the ',		'',	'n' ],	# sing. def.   decl. 3
 [ 'er',	'',	'some ',	'',	'n' ],	# plur. indef. decl. 3
 [ 'erna',	'',	'the ',		'',	'n' ],	# plur. def.   decl. 3
 #[ '',		'',	'a ',		'',	'n' ],	# sing. indef. decl. 4, neuter
 [ 't',		'',	'the ',		'',	'n' ],	# sing. def.   decl. 4
 [ 'n',		'',	'some ',	'',	'n' ],	# plur. indef. decl. 4
 [ 'a',		'',	'the ',		'',	'n' ],	# plur. def.   decl. 4
 #[ '',		'',	'a ',		'',	'n' ],	# sing. indef. decl. 5, neuter/uter
 [ 'et',	'',	'the ',		'',	'n' ],	# sing. def.   decl. 5
 #[ '',		'',	'some ',	'',	'n' ],	# plur. indef. decl. 5
 #[ 'en',	'',	'the ',		'',	'n' ],	# plur. def.   decl. 5
 # Adjectives
 # Verb past participle
 # Verb gerund
 # Verb present participle
 # Verb present
 # Verb present subjunctive
 # Verb imperitive
 # Verb preterite
 # Verb imperfect
 # Verb future
 # Verb conditional
 # Adverb
 # Higher level transformations
];

#Fields:
# x -> translatioin		all words
# r -> root			irregular declensions
# t -> type:			all words
#	n -> noun
#	v -> verb
#	a -> adjective
#	p -> preposition
#	art -> article
#	pro -> pronoun
#	conj -> conjugation
#	adv -> adverb
# g -> gender:			nouns, pronouns, adjectives
#	c -> common
#	n -> neuter
# n -> number:			articles, pronouns, verbs, adjectives
#	s -> singular		default
#	p -> plural		default for words ending in s
# p -> person:			pronouns, verbs
#	1 -> 1st person
#	2 -> 2nd person
#	3 -> 3rd person		default
# c -> conjugation:
#	p -> present
#	i -> imperfect
#	f -> future
#	c -> conditional
#	t -> preterite
#	ps -> present subjunctive
#	is -> imperfect subjunctive
#	inf -> infinitive		default
#	pp -> past participle
#	g -> gerund
#	imp -> imperative

# Swedish to English dictionary
%dictionary = (
 # Functional words
 #  Articles
 #   Definite articles
 #    Common
 #     Singular
 #     Plural
 'en'		=> { 'x' => 'the',
 		     't' => 'art',
		     'g' => 'c' },
 #    Neuter
 #     Singular
 #     Plural
 'et'		=> { 'x' => 'the',
 		     't' => 'art',
		     'g' => 'n' },
 #   Indefinite articles
 #  Pronouns & possessive adjectives
 #   1st person
 #   2nd person
 #   3rd person
 #  Other functional words
 #   Partitive / Contractions
 # Numbers: cardinal and ordinal
 # Days and months
 's�ndag'	=> { 'x' => 'sunday' },
 'm�ndag'	=> { 'x' => 'monday' },
 'tisdag'	=> { 'x' => 'tuesday' },
 'onsdag'	=> { 'x' => 'wednesday' },
 'torsdag'	=> { 'x' => 'thursday' },
 'fredag'	=> { 'x' => 'friday' },
 'l�rdag'	=> { 'x' => 'saturday' },
 'januari'	=> { 'x' => 'january' },
 'februari'	=> { 'x' => 'february' },
 'mars'		=> { 'x' => 'march' },
 'april'	=> { 'x' => 'april' },
 'maj'		=> { 'x' => 'may' },
 'juni'		=> { 'x' => 'june' },
 'juli'		=> { 'x' => 'july' },
 'augusti'	=> { 'x' => 'august' },
 'september'	=> { 'x' => 'september' },
 'oktober'	=> { 'x' => 'october' },
 'november'	=> { 'x' => 'november' },
 'december'	=> { 'x' => 'december' },
 # Key verbs
 # Vocabulary
 'artikel'	=> { 'x' => 'article',
		     't' => 'n' },
 'australien'	=> { 'x' => 'australia',
 		     't' => 'n' },
 'bok'		=> { 'x' => 'book',
 		     't' => 'n' },
 'elektricitet'	=> { 'x' => 'electricity',
 		     't' => 'n' },
 'f�nster'	=> { 'x' => 'window',
 		     't' => 'n' },
 'gemenskap'	=> { 'x' => 'solidarity',
 		     't' => 'n' },
 'gestikulera'	=> { 'x' => 'gesticulate',
 		     't' => 'v' },
 'gr�n'		=> { 'x' => 'green',
 		     't' => 'a' },
 'japan'	=> { 'x' => 'japan',
 		     't' => 'n' },
 'liten'	=> { 'x' => 'little',
		     '#' => 'small',
		     't' => 'a' },
 'modifiera'	=> { 'x' => 'modify',
 		     't' => 'v' },
 'ordbok'	=> { 'x' => 'dictionary',
 		     't' => 'n' },
 'projekt'	=> { 'x' => 'project',
 		     't' => 'n' },
 'simma'	=> { 'x' => 'swim',
 		     't' => 'v' },
 'skit'		=> { 'x' => 'shit',
 		     't' => 'n' },
 'tyskland'	=> { 'x' => 'germany',
 		     't' => 'n' },
 'version'	=> { 'x' => 'version',
 		     't' => 'n' },
 'vid'		=> { 'x' => 'wide',
 		     't' => 'a' },
 'vit'		=> { 'x' => 'white',
 		     't' => 'a' },
);
}

1;

